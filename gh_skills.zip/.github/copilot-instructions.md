# Mission-critical microservices playbook

Stack/tool defaults and instruction file scopes are centralized in `.github/shared/playbook-defaults.yaml`.

This repository is mission-critical.
Optimize for: correctness, determinism, bounded behavior, idempotency, backward compatibility, and verifiability.
Prefer simple, explicit code over clever abstractions.
This repository uses a requirements-driven development process that incorporates TDD.

## Non-negotiables (high level):
- No recursion. No unbounded loops/retries. All IO has explicit timeouts.
- Validate all external inputs at boundaries and enforce max sizes.
- Idempotency for any side-effecting operation that may be retried.
- Backward compatibility: no breaking API changes unless versioned.
- Errors are consistent and safe (no stack traces / secrets).
- Every change includes appropriate tests (unit + contract + component/mock + integration; perf/resilience where relevant).
- Add code-based guard tests (Architecture/Convention) so unsafe patterns and missing tests are caught by test runs.
- Observability is scope, not afterthought. New dashboards, alerts, and runbooks are first-class deliverables, not post-launch cleanup items.

## Non-negotiables (MUST- Detailed)
A) Simple, analyzable control flow
- No recursion.
- Avoid hidden control flow: over-clever streams, reflection tricks, dynamic proxies beyond framework needs.
- Keep nesting shallow; prefer early returns for error paths.

B) Bounded execution and bounded resources
- Every loop/retry/poll MUST have a hard upper bound.
- Every outbound call MUST have timeouts + bounded retries + an overall deadline/budget.
- No unbounded collections, caches, queues, or fan-out in request paths.
- Enforce max sizes for: payloads, page sizes, batch sizes, headers, uploaded files.

C) Contracts and defensive checks
- Validate all external inputs at boundaries (controllers/message consumers).
- Service methods enforce invariants explicitly (side-effect free checks).
- Fail fast with typed errors; do not continue after detecting invalid state.
- Cascade validation: annotate nested DTOs, Map values, and Collection elements with `@Valid` — without it, child constraints are silently skipped.
- Constraint propagation: override/child/per-tenant types MUST mirror parent constraints — no unconstrained bypass paths.
- Doc-code invariant consistency: every stated bound (Javadoc, comments, config metadata) MUST have a matching runtime constraint and boundary test.

D) Error-handling discipline
- Never swallow exceptions.
- Never ignore return values, futures, or I/O outcomes.
- Catch only what you can handle; otherwise convert to a typed domain error.

E) Concurrency discipline
- Avoid shared mutable state.
- No manual thread creation.
- No unbounded executors/queues.
- Parallelism must be explicitly bounded and cancellation-aware.

F) "Zero warnings" culture
- Compile with maximum warnings; treat warnings as errors when possible.
- Run static analysis in CI and allow zero new findings.

G) Observability as a first-class deliverable
- Every inbound and outbound edge has structured logging (correlationId/traceId, operation, outcome, latency).
- New features include metrics, alerts, and dashboard updates as part of the definition of done.
- Runbooks for new failure modes are required, not optional.
- Observability gaps are quality gate findings, not backlog items.
- Structure Code/workflows/bpmn for Observability

H) Code generation discipline (applies to ALL generated code — by any agent, skill, or manual prompt)
- Zero new dependencies: NEVER introduce a new library, framework, or runtime dependency unless the developer explicitly requests it. Use only existing project dependencies. If a feature genuinely requires a new dependency, STOP and ask.
- Boundary symmetry: every numeric, string, and collection parameter/field must have BOTH a lower AND upper bound. One-sided constraints (e.g., `@Min` without `@Max`) leave the other direction unbounded.
- Defensive defaults: every default value, fallback, and "not provided" sentinel must itself satisfy all declared constraints on that field. A default that violates its own constraint is a latent runtime error.
- Test completeness symmetry: every positive assertion needs a negative counterpart. Every constraint needs a violation test. Every boundary must be tested at the limit AND one past it. Happy-path-only coverage is incomplete.
- Error chain integrity: catch only specific exception types you can meaningfully handle. Always preserve the cause chain when wrapping. Never catch broader than you act on.
- Resource acquisition symmetry: every resource opened (connection, stream, lock, file handle) must have a guaranteed close path — try-with-resources, finally, or framework-managed lifecycle.
- Singleton safety: no mutable instance-level fields in Spring singleton beans unless inherently thread-safe (AtomicReference, ConcurrentHashMap, immutable after construction).
- API surface stability: public API changes are additive only. No removal, rename, or semantic change of existing fields, params, status codes, or error codes without a new API version. Deprecate before removing.

## Spring MVC microservice rules (MUST)
- Controllers are thin: mapping + validation + calling services only.
- Consistent error envelope (RFC7807-style JSON) with stable errorCode and correlationId/traceId.
- Observability: structured logs + metrics around inbound/outbound edges. Include correlationId/traceId, operation name, outcome, and latency in every log entry.
- Security: never log secrets, validate all external input, default-deny authorization.

## Java Clean Code Principles (MUST)
- Affirmative Conditionals: Prefer positive checks (`isValid`, `isSuccess`) over negated conditions (`!isInvalid`). Guard clauses should state what you're looking for, not what you're avoiding.
- Single Responsibility: Each method has one job — orchestrators coordinate flow, handlers complete the full operation (transform + side effects). Never split responsibility so the caller must "finish the job."
- High Cohesion / Tell Don't Ask: Keep related logic together. Handlers should transform data AND execute side effects — callers should never re-check conditions already evaluated inside a delegated method. No partial delegation.
- Guard Clauses with Explicit Cases: Handle each case with named early returns: happy path → error cases → unknown. Avoid catch-all `else` branches that hide intent.
- Null-Safe Utilities Over Direct Checks: Use `StringUtils.isBlank()`, `CollectionUtils.isEmpty()`, `ObjectUtils.isEmpty()` instead of direct `== null` / `!= null` checks — they handle more edge cases (null, empty, whitespace) and convey intent clearly.
- Constants Over Magic Strings/Numbers: Extract all string literals and numeric values into `SCREAMING_SNAKE_CASE` constants. Enables single source of truth, IDE refactoring safety, and prevents typos.
- DRY — Extract Reusable Logic: If logic appears in 2+ places and has multiple steps or conditions, extract it into a named helper method. Test once, fix once, use everywhere.

## Terminal command discipline (MUST)
- **Write multi-line content** (scripts, JSON, config) using the `create_file` tool, then execute with a single-line terminal command (`bash /tmp/script.sh`).
- **Write single-line content** using `echo "..." > file`.
- **Query ELK** exclusively through `elk-query.sh` — the only approved entry point:
  - `elk-query.sh search --service <name> --level ERROR --hours 2` — filtered log search
  - `elk-query.sh raw --body '{"size":0, ...}'` — custom Elasticsearch JSON
  - `elk-query.sh raw --body-file /tmp/query.json` — large JSON queries via file
  - `elk-query.sh trace <trackingId>` — end-to-end request tracing
  - `elk-query.sh errors --service <name> --hours 4` — error summary
  - `elk-query.sh top-errors --hours 1` — cross-service error ranking
- This rule applies to ALL agents, skills, and workflows — no exceptions.

**Constraints** (violations are blocked at runtime):
- Heredoc patterns (`<< 'EOF'`, `<< EOF`) hang VS Code's integrated terminal — use `create_file` instead.
- `elk-lib.sh` has a caller guard (`BASH_SOURCE[1]`) that rejects all callers except `elk-query.sh`. Direct sourcing (`source elk-lib.sh`), inline chaining (`source elk-lib.sh && elk_search ...`), and script wrapping (`/tmp/*.sh` that sources elk-lib.sh) all fail with an error message and exit code 1.
- `elk_search` and `elk_load_env` are internal functions — calling them directly is not possible without bypassing the guard.
- **Script pre-flight gate** — before creating any `/tmp/*.sh` ELK script via `create_file`, answer: does this script contain custom aggregations (`aggs`), multi-query sequences with inter-query logic, or Python post-processing that `elk-query.sh` named commands cannot express? If **no** → use an `elk-query.sh` one-liner directly in the terminal. If **yes** → the script MUST call `elk-query.sh raw`, never `source elk-lib.sh`. Single-query scripts that wrap a built-in command (`search`, `errors`, `trace`, `identify`, `top-errors`, `phase1-triage`, `bpmn-variables`, `phase1-bpmn`, `first-occurrence`, `field-values`) are always unnecessary.

## Security:
- Validate all inputs; use allow-lists.
- Never build SQL strings; use prepared statements.
- Do not expose internals or stack traces in API responses.
- Avoid Expression Language method invocations unless explicitly required and reviewed (treat EL as code execution).

## Engineering philosophy
- Well-tested code is non-negotiable; I'd rather have too many tests than too few.
- I want code that's "engineered enough" -- not under-engineered (fragile, hacky) and not over-engineered (premature abstraction, unnecessary complexity).
- I error on the side of handling more edge cases, not fewer; thoughtfulness > speed.
- Observability is scope, not afterthought. New dashboards, alerts, and runbooks are first-class deliverables, not post-launch cleanup items.

## When you generate code:
- Enforce ALL non-negotiables (A through H). Pay special attention to:
  - Bounded execution (B): hard caps on loops, retries, collections, fan-out
  - Contracts and defensive checks (C): cascade validation, constraint propagation, doc-code invariant consistency
  - Error-handling discipline (D): error chain integrity
  - Code generation discipline (H): zero new deps, boundary symmetry, defensive defaults, test symmetry, resource closure, singleton safety, API stability
- Add/update unit tests and (for HTTP) integration tests.
- Add boundary tests for max sizes, retry limits, and timeouts.
- If anything is ambiguous, ask questions and choose the safest default.
- Provide runnable snippets, including imports, configuration, and tests.
- Include negative-path tests (timeouts, duplicate request, retries exhausted).
- Add comments that state invariants and bounds (timeouts, max retries, max sizes).

## Workflow execution precedence
1. Follow the selected custom agent workflow when an agent is selected.
2. Use matching skills when they auto-load or are directly invoked.
3. If a skill does not load, continue by executing the same steps inline from:
   - this file
   - `.github/instructions/*.instructions.md`
4. Never skip the final mission-critical quality gate.

## Primary workflows
- New feature or behavior change from business needs:
  - prefer the `dev-pilot` agent
  - start from requirements and acceptance criteria
- Groom a requirement, ticket, or feature request:
  - prefer the `requirements-grooming` agent
  - turn raw requirements into structured grooming packages with ACs, stories, impact preview, and definition of ready
- Generate or update tests for current code changes:
  - prefer the `test-generator` agent
  - use `#changes` in VS Code as the primary change context
- Review (change-fit across the whole project):
  - prefer the `code-review` agent
  - if requirements are provided, use them for traceability
  - if requirements are NOT provided:
    - infer intent from the diff and existing project patterns
    - ask probing questions only when you detect functional ambiguity or technical risk that cannot be resolved through static analysis and pattern matching alone
- Pull request review (lead-facing, comprehensive):
  - prefer the `pr-code-review` agent
  - evaluates diff + full-repo fit + ticket traceability + cross-service impact + deployment readiness + cognitive debiasing
  - produces a Change Fit Report with composite risk score and merge verdict
- Documentation (create, update, validate, or beautify):
  - prefer the `doc-maintainer` agent
  - use `#changes` in VS Code or explicit requests as input
  - creates/updates living documentation across 4 audience levels + machine manifests
- Log investigation, error diagnosis, request tracing, production analysis:
  - prefer the `incident-investigator` agent
  - translates natural language to ELK/Elasticsearch queries
  - uses `elk-log-search` skill for schema reference and query templates
  - analyzes results and provides structured findings with root cause hypotheses
  - for quick severity assessment, uses `quick-triage` skill with FMEA scoring
  - for impact scoping, uses `blast-radius` skill (services, DCs, channels, customers)
  - for multi-service error tracing, uses `service-traversal` skill (DAG traversal)
  - for code-level investigation, uses `code-forensics` skill (configLabel → commit → code)
  - for full RCA, uses `rca-synthesis` skill (Five Whys, FMEA, Ishikawa, Fault Tree, Swiss Cheese, Cynefin)
  - for hypothesis elimination, uses ACH Matrix + Abductive Forward Verification (Tier 2+)
  - for adversarial critique, uses `rca-quality-gate` skill (3 parallel critics + meta-reviewer)
  - uses adaptive investigation depth (Tier 1/2/3) with Socratic quality gates between phases
  - for fix proposals and prevention, uses `rca-recommendations` skill
  - classifies errors using `error-taxonomy` skill (8 categories, 30+ subcategories)
  - produces complete RCA reports using templates at `.github/shared/templates/`

## Cross-cutting: Jira & Wiki context (automatic)
When a Jira ticket key (`PROJECT-123`) or Confluence wiki URL (`etwiki.sys.comcast.net/...`) appears in user input, PR context, branch names, or commit messages, agents MUST automatically invoke the `jira-wiki-reader` skill to fetch full context. Wiki links found in ticket descriptions are fetched automatically without asking. See `.github/instructions/jira-wiki-context.instructions.md` for activation rules and `.github/skills/jira-wiki-reader/SKILL.md` for the full procedure.

## Cross-cutting: ServiceNow context (automatic)
When a ServiceNow ticket number (`INC*`, `CHG*`, `CAS*`) or ServiceNow URL (`comcast.service-now.com/...`) appears in user input, agents MUST automatically invoke the `servicenow-reader` skill to fetch full ticket context. If the cookie is missing or expired, agents MUST auto-refresh it by running `snow-query.sh login` — do NOT ask the user to paste cookies manually unless all automated attempts fail. During incident investigations, correlate ELK findings with ServiceNow incidents. See `.github/skills/servicenow-reader/SKILL.md` for the full procedure.

## Cross-cutting: Tableau dashboard data
When a user asks about stuck orders, fallout counts, BPM volumes, order trends, dashboard metrics, or Tableau data, load `.github/skills/tableau-reader/SKILL.md` before executing any commands. Verify auth first: `tableau-query.sh check` — if auth fails, run `tableau-query.sh set-pat`. For daily stuck order categorization reports, use `.github/prompts/daily-stuck-order-fallout-report.prompt.md`. See `.github/skills/tableau-reader/SKILL.md` for the full procedure.

## Cross-cutting: Git SSH protocol (mandatory)
All git operations that reference repositories MUST use SSH URLs (`git@github.com:{owner}/{repo}.git`), never HTTPS. This applies to: `git clone`, `git remote add`, `git submodule add`, and any repository URL shown to the developer. When the developer asks to look at, clone, or reference another repository, construct the SSH URL using the org default `comcast-modesto` unless a different owner is specified. See `toolingDefaults.git` in `.github/shared/playbook-defaults.yaml`.

When a developer provides a GitHub HTTPS URL (e.g., `https://github.com/comcast-modesto/SomeRepo`) to browse, read, or reference — convert it to the SSH form (`git@github.com:comcast-modesto/SomeRepo.git`) before performing any git operation. For read-only browsing (fetching file contents, checking structure), clone via SSH into a temporary location or use the GitHub API. Never pass HTTPS URLs to `git clone` or `git remote`.

## Cross-cutting: Retrieving data from other repositories (private-repo safe)
When a developer asks to fetch, read, or compare specific files, PRs, or issues from other repositories, match the need to the right approach:

| Need | Approach | When to use |
|---|---|---|
| **Single file by known path** | `gh api repos/{owner}/{repo}/contents/{path} --jq '.content' \| base64 -d` | You know the exact file path. Fastest option — single API call, no clone. Uses `gh auth` session. Pipe to `jq` for JSON, `yq` for YAML, or redirect to a temp file for further analysis. |
| **Few specific files across one or more repos** | Multiple `gh api repos/{owner}/{repo}/contents/{path}` calls | Comparing configs, manifests, or versions across repos. Run sequentially (terminal limitation). Faster than cloning each repo. |
| **List directory contents** | `gh api repos/{owner}/{repo}/contents/{directory} --jq '.[].name'` | You need to discover filenames in a directory before fetching specific files. Returns file/dir listing. Chain with a second `gh api` call to read the target file. |
| **Search files by name pattern** | `gh api repos/{owner}/{repo}/git/trees/{branch}?recursive=1 --jq '.tree[].path'` then filter with `grep` | You know a filename pattern but not the full path. Fetches the full file tree; filter locally with `grep -E 'pattern'`. For very large repos, prefer clone. |
| **PR or issue details** | `github-pull-request_issue_fetch` with issue/PR number and `repo: {name, owner}` | Fetching PR diffs, review comments, approval status, or issue details. Uses your VS Code GitHub token — no SSO issues. |
| **Search for code by concept** | `github_repo` tool with owner/repo and a descriptive query | You know the repo but not the exact file; need semantic search. |
| **Broad exploration / grep / build** | Clone via SSH (`git@github.com:{owner}/{repo}.git --depth 1`) into a temporary directory | You need multi-file grep, directory traversal, or to run builds/tests. Use `--depth 1` to minimize download. **Last resort** — prefer `gh api` for targeted reads. |

## Skill invocation rule (MANDATORY)
When any workflow step references a skill by name, you MUST use `read_file` to load `.github/skills/<skill-name>/SKILL.md` and follow every step it defines. Inline summaries in agent/instruction files are for orientation only — they do NOT replace the full skill procedure. If you skip reading the SKILL.md file, skills will not execute properly.


## Testing expectations (high level)
Whenever production code changes, add or update the relevant tests:
- unit tests for business rules
- MockMvc tests for REST behavior
- contract verification if the repo uses it
- stubbed dependency tests for outbound HTTP behavior
- repository integration tests for DB constraints and rollback semantics
- resilience/security behavior tests where relevant
- guard tests (ArchUnit or equivalent) only when they prevent future drift

For canonical details on mandatory test scenarios, test type decision matrix, failure classification, fix loop rules, and validation before execution, see `testing-and-determinism.instructions.md` sections 11–14.

## Mandatory final self-review
Before considering work complete, critically inspect the generated code and tests:
- Does each acceptance criterion or code change have direct test coverage?
- Are negative, boundary, dependency failure, and duplicate/idempotency scenarios covered where applicable?
- Are tests deterministic and non-brittle?
- Are there testability blockers that need a small refactor?

Apply introspection questions, gap regeneration rules, and confidence statement from `testing-and-determinism.instructions.md` section 14.

## If skills do not auto-load
Skills are opportunistic. If a skill is unavailable or not loaded, follow the same workflow directly from:
- this file
- `.github/instructions/*.instructions.md`
- the selected custom agent prompt

Do not block progress just because a skill did not load.


## Living documentation is part of done
Documentation is a required output of both development and test-generation workflows.
Use 4 primary documentation levels plus cross-cutting overlays plus 1 machine-readable dimension.

Primary levels:
- Level 0 (10,000 ft): Business capabilities and outcomes
- Level 1 (1,000–3,000 ft): Service context, boundaries, upstream/downstream systems
- Level 2 (100–1,000 ft): Runtime flows, API behavior, dependency interactions, rules
- Level 3 (100 ft): Technical map for developers (components, packages, configs, tests, operational rules)

See `dimension-extraction.instructions.md` for the full extraction framework, rule inventory template, and entity catalog template.


## Output expectations for generated work
When generating code or tests, provide:
- files created or updated
- what scenarios/tests now prove
- remaining risks or blockers
- compatibility statement if public API behavior changed
- quality gate findings and any regeneration performed

Before output, challenge the goal, assumptions, boundaries, failure modes, evidence, compatibility, and operational impact. Ask people only when the answer materially changes risk or correctness.

Documentation is part of done. When code or tests change, update the affected business, technical, operations, and machine-readable docs so a business person, a developer/operator, and an LLM can all understand the service and its likely impact areas.