---
description: "Daily stuck order fallout report — last 24h categorization with closure action buckets from Tableau"
---

# Daily Stuck Order Fallout Report

Generate the stuck order fallout report for the last 24 hours from Tableau.

---

## Instructions

### Step 1 — Load the Tableau skill
Read `.github/skills/tableau-reader/SKILL.md` before executing any commands.
Verify auth: `tableau-query.sh check` — confirm user and site are valid. If auth fails, follow the PAT refresh procedure in the skill.

---

### Step 2 — Pull stuck order detail from Tableau

```bash
tableau-query.sh stuck-detail /tmp/stuck_detail_raw.csv
```

Tableau emits **2 rows per instance** (one per measure). Deduplicate by keeping only rows where:
```
Measure Names == "START_TIME"
```

This yields unique instances. Note total row count before and after dedup.

---

### Step 3 — Filter to last 24 hours

Parse `START_TIME` as a datetime. Keep only rows where:
```
START_TIME >= now - 24 hours
```

If fewer than 10 rows remain after filtering, warn: "⚠️ Very low fallout count — verify Tableau data freshness."

---

### Step 4 — Categorize every instance

For each row, classify the `EXCEPTION_MSG` field into one of the named exception categories below using keyword matching (case-insensitive). If no pattern matches, assign `UNKNOWN`.

**Exception Categories (use these exact names):**

| Category | Keywords to match |
|---|---|
| `ASYNCCANCEL_EMPTY_ITEMS` | `XOMSBILLER_5002` + `ASYNCCANCEL` or `orderItems` empty |
| `CMT_DATA_MISSING` | `getCustomerOrder`, `cmt`, `data not found`, `no cmt` |
| `BYONDEL_500` | `byondel`, `500`, `createByondelLine` |
| `ASCENDON_ERROR` | `ascendon` |
| `CONVERGENCE_CSG_ERROR` | `convergence`, `csg`, `CSG_` |
| `ASSURANT_ENROLLMENT` | `assurant`, `enrollment` |
| `XOMSBILLER_5002` | `XOMSBILLER_5002` (non-ASYNCCANCEL) |
| `XOMSBILLER_OTHER` | `XOMSBILLER_` (other codes) |
| `TIMEOUT` | `timeout`, `timed out`, `read timeout`, `connect timeout` |
| `CONNECTION_REFUSED` | `connection refused`, `connection reset`, `ECONNREFUSED` |
| `NULL_POINTER` | `NullPointerException`, `null pointer`, `NPE` |
| `ILLEGAL_STATE` | `IllegalStateException`, `illegal state` |
| `ILLEGAL_ARGUMENT` | `IllegalArgumentException`, `illegal argument` |
| `OPTIMISTIC_LOCK` | `OptimisticLockException`, `optimistic lock`, `StaleObjectStateException` |
| `DB_CONSTRAINT` | `ConstraintViolationException`, `duplicate key`, `unique constraint` |
| `DB_CONNECTION` | `JDBCConnectionException`, `db connection`, `datasource` |
| `AUTH_ERROR` | `401`, `403`, `unauthorized`, `forbidden`, `auth` |
| `NOT_FOUND_404` | `404`, `not found` |
| `VALIDATION_ERROR` | `422`, `400`, `validation`, `invalid request` |
| `SERVICE_UNAVAILABLE` | `503`, `service unavailable` |
| `GATEWAY_TIMEOUT` | `504`, `gateway timeout` |
| `BAD_GATEWAY` | `502`, `bad gateway` |
| `KAFKA_ERROR` | `kafka`, `KafkaException`, `producer`, `consumer` |
| `PROCESS_LOCKED` | `process locked`, `FlowableLockTimeoutException` |
| `TASK_ALREADY_COMPLETE` | `already completed`, `task complete`, `FlowableObjectNotFoundException` |
| `MISSING_VARIABLE` | `variable not found`, `process variable`, `missing variable` |
| `CAMUNDA_BPMN_ERROR` | `BpmnError`, `bpmn error` |
| `CIRCUIT_OPEN` | `circuit open`, `CircuitBreakerOpenException`, `Resilience4j` |
| `RULE_ENGINE_ERROR` | `drools`, `rule engine`, `KieSession` |
| `UNKNOWN` | (no match) |

---

### Step 5 — Map each category to a closure action

| Category | Action Type | Action Description |
|---|---|---|
| `ASYNCCANCEL_EMPTY_ITEMS` | `CODE FIX` | Empty orderItems guard missing — dev fix required, then retrigger |
| `CMT_DATA_MISSING` | `DATA FIX` | CMT data absent in upstream — fix data, then retrigger |
| `BYONDEL_500` | `DOWNSTREAM HEALTH` | Byondel service returning 500 — check Byondel health, retrigger when healthy |
| `ASCENDON_ERROR` | `DOWNSTREAM HEALTH` | Ascendon system error — check Ascendon status |
| `CONVERGENCE_CSG_ERROR` | `DOWNSTREAM HEALTH` | Convergence/CSG error — check downstream health |
| `ASSURANT_ENROLLMENT` | `DOWNSTREAM HEALTH` | Assurant enrollment failure — check Assurant |
| `XOMSBILLER_5002` | `DATA FIX` | Biller data issue — verify order data, retrigger |
| `XOMSBILLER_OTHER` | `INVESTIGATE` | Unknown biller error code — investigate individually |
| `TIMEOUT` | `DOWNSTREAM HEALTH` | Upstream timeout — check downstream health, retrigger when stable |
| `CONNECTION_REFUSED` | `DOWNSTREAM HEALTH` | Downstream unreachable — check service health |
| `NULL_POINTER` | `INVESTIGATE` | NPE — check logs for stack trace, identify root cause |
| `ILLEGAL_STATE` | `INVESTIGATE` | Unexpected process state — review process history |
| `ILLEGAL_ARGUMENT` | `DATA FIX` | Bad input data — fix data, retrigger |
| `OPTIMISTIC_LOCK` | `RETRIGGER NOW` | Concurrency conflict — safe to retrigger |
| `DB_CONSTRAINT` | `DATA FIX` | Duplicate or constraint violation — fix data |
| `DB_CONNECTION` | `DOWNSTREAM HEALTH` | DB connectivity — check DB health |
| `AUTH_ERROR` | `INVESTIGATE` | Auth/token issue — check credentials/token refresh |
| `NOT_FOUND_404` | `DATA FIX` | Resource missing — verify order/account data |
| `VALIDATION_ERROR` | `DATA FIX` | Bad payload — fix request data |
| `SERVICE_UNAVAILABLE` | `DOWNSTREAM HEALTH` | Downstream 503 — wait for recovery, retrigger |
| `GATEWAY_TIMEOUT` | `DOWNSTREAM HEALTH` | Gateway timeout — check downstream latency |
| `BAD_GATEWAY` | `DOWNSTREAM HEALTH` | Bad gateway — check infrastructure |
| `KAFKA_ERROR` | `INVESTIGATE` | Kafka publish/consume issue — check Kafka health |
| `PROCESS_LOCKED` | `RETRIGGER NOW` | Flowable lock expired — safe to retrigger |
| `TASK_ALREADY_COMPLETE` | `RETRIGGER NOW` | Race condition resolved — retrigger |
| `MISSING_VARIABLE` | `INVESTIGATE` | Process variable missing — check process history |
| `CAMUNDA_BPMN_ERROR` | `INVESTIGATE` | BPMN boundary error — review process definition |
| `CIRCUIT_OPEN` | `DOWNSTREAM HEALTH` | Circuit breaker open — check downstream, wait for reset |
| `RULE_ENGINE_ERROR` | `INVESTIGATE` | Rules engine failure — check Drools config |
| `UNKNOWN` | `MANUAL TRIAGE` | No pattern matched — manually review EXCEPTION_MSG |

**Action Type Definitions:**
- `CODE FIX` — Bug requires developer fix before orders can be closed
- `DOWNSTREAM HEALTH` — Waiting on a downstream system to recover; retrigger once healthy
- `DATA FIX` — Order/account data is wrong; fix the data then retrigger
- `RETRIGGER NOW` — Transient/concurrency error; safe to retrigger immediately
- `INVESTIGATE` — Needs deeper log review before action
- `MANUAL TRIAGE` — Unclassified; engineer must review individually
- `DB ESCALATION` — DB-level issue requiring DBA or infra involvement

---

### Step 6 — Group into buckets

Group rows by `(APP, ACTIVITY_ID, ExcCat)` — each unique combination is one bucket.

For each bucket:
- Count of instances
- Percentage of total 24h fallout
- `APP` value
- `ACTIVITY_ID` value
- Exception category name
- Closure action type + description
- Order types breakdown (parse BUSINESS_KEY for order type hints if available, else show `BUSINESS_KEY` prefixes)
- Sample EXCEPTION_MSG (first 120 chars)
- Sample `PROCESS_INSTANCE_ID` values (up to 5)

Sort buckets descending by count. Label B01, B02, B03 ... BNN.

---

### Step 7 — Generate the report

Output the following sections in order:

---

#### HEADER

```
Daily Stuck Order Fallout Report
Date: <YYYY-MM-DD>  |  Window: Last 24 hours  |  Total instances: <N>
```

---

#### CLOSURE ACTION SUMMARY TABLE

| Action Type | Count | % | What it means |
|---|---|---|---|
| CODE FIX | N | % | ... |
| DOWNSTREAM HEALTH | N | % | ... |
| DATA FIX | N | % | ... |
| RETRIGGER NOW | N | % | ... |
| INVESTIGATE | N | % | ... |
| MANUAL TRIAGE | N | % | ... |
| DB ESCALATION | N | % | ... |
| **TOTAL** | **N** | **100%** | |

---

#### BUCKET DETAIL TABLE

For each bucket (B01 → BNN):

```
B01 | N instances (X%) | APP: <app> | Activity: <activity>
    | Error: <ExcCat> | Action: <ACTION TYPE>
    | Order types: <breakdown>
    | Action: <full action description>
    | Sample exception: <first 120 chars>
    | Sample PIDs: <pid1>, <pid2>, <pid3>
```

---

#### APP-LEVEL SUMMARY TABLE

| App | Count | % of Total | Top Error Category | Top Action |
|---|---|---|---|---|

---

#### FASTEST PATH TO CLOSE

Prioritized list of the highest-impact actions an on-call engineer should take RIGHT NOW:

1. **RETRIGGER NOW** — List buckets safe to retrigger immediately with total PID count
2. **DOWNSTREAM HEALTH** — Which downstreams are unhealthy and how many orders are blocked on each
3. **DATA FIX** — Highest-count data fix buckets with data repair instructions
4. **CODE FIX** — Buckets blocked on a code fix (count, ticket reference if known)
5. **INVESTIGATE** — Buckets that need deeper review before action

---

#### COMPARISON TO PRIOR DAY (if prior report exists)

If a previous daily report exists in `docs/generated/standup/`, load it and show:
- Total count delta (↑ / ↓ / ≈)
- New buckets not in yesterday's report
- Buckets resolved since yesterday
- Action type distribution shift

If no prior report exists, skip this section with a note.

---

### Step 8 — Save the report

Save the report to:
```
docs/generated/standup/stuck-orders-<YYYY-MM-DD>.md
```

Use today's date in the filename.

Confirm: `📄 Report written to: docs/generated/standup/stuck-orders-<YYYY-MM-DD>.md`

---

## Quality checks before saving

- [ ] All 24h rows processed (no silent truncation)
- [ ] Dedup applied (Measure Names == "START_TIME" filter)
- [ ] All 7 action types present in summary (or noted as 0)
- [ ] Buckets sorted descending by count
- [ ] Sample PIDs are real values from the data (not fabricated)
- [ ] FASTEST PATH TO CLOSE section present
- [ ] Report saved to `docs/generated/standup/` with correct date
