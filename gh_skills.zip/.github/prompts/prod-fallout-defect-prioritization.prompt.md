---
description: "Prod fallout defect prioritization report — detail-aware, per-board scoring and actionable HTML for epic CMXOTD-3181"
---

# Prod Fallout Defect Prioritization Report

Generate detail-aware prioritized defect reports for all boards in the OT_Fallout_DefectTracker_2026 epic (CMXOTD-3181).
Produces one HTML report per board plus an index dashboard linking them all.

---

## Instructions

### Step 0 — Verify prerequisites

Confirm `JIRA_PAT` is available:
```bash
[[ -n "${JIRA_PAT:-}" ]] && echo "✅ JIRA_PAT set" || (source ~/.jira-reader.env 2>/dev/null && echo "✅ loaded from file" || echo "❌ MISSING")
```

If missing, STOP and guide user to create `~/.jira-reader.env`.

---

### Step 1 — Fetch all tickets from the epic

```bash
bash .github/skills/jira-wiki-reader/scripts/fetch-epic-tickets.sh CMXOTD-3181 \
  --status-filter "Closed,Canceled,Released,Resolved,Accepted" \
  --output /tmp/epic-tickets.json
```

This fetches only actionable tickets from CMXOTD-3181 (excludes terminal statuses at the API level). Output: `/tmp/epic-tickets.json`

**Verify:** Print board distribution summary:
```bash
python3 -c "
import json
from collections import Counter
data = json.load(open('/tmp/epic-tickets.json'))
print(f'Total: {len(data)} actionable tickets')
for p,c in Counter(t['prefix'] for t in data).most_common():
    print(f'  {p}: {c}')
"
```

---

### Step 1b — Fetch recently-closed tickets (last 3 weeks)

```bash
bash .github/skills/jira-wiki-reader/scripts/fetch-epic-tickets.sh CMXOTD-3181 \
  --mode include \
  --status-filter "Closed,Canceled,Released,Resolved,Accepted" \
  --updated-days 21 \
  --output /tmp/epic-tickets-closed.json
```

This fetches tickets that were recently closed/resolved/canceled in the last 21 days. Output: `/tmp/epic-tickets-closed.json`

The signal builder (Step 3a) will automatically pick up this file if present. It enables:
- **Fallout correlation alert**: rows in the Ticket↔Fallout Correlation table are highlighted with `⚠ CLOSED` when the matched ticket has been closed but fallout is still occurring post-closure
- **"Recently Closed (Last 3 Weeks)" section**: a per-board table showing each closed ticket's status, resolution, assignee, close date, and events-after-close count
- **Closed ticket insights**: automatically inserted into the board's insight list (e.g., "3 tickets closed but still have active post-close fallout")
- **Closed count stat card**: added to the report's stat boxes (green if no post-close fallout, red if any)

**Verify:**
```bash
python3 -c "
import json
from collections import Counter
data = json.load(open('/tmp/epic-tickets-closed.json'))
print(f'Total: {len(data)} recently-closed tickets')
for p,c in Counter(t['prefix'] for t in data).most_common():
    print(f'  {p}: {c} ({[t[\"status\"] for t in data if t[\"prefix\"]==p]})')
"
```

> **Note:** If no tickets were closed in the last 3 weeks the file will be empty (`[]`) — this is normal. The signal builder gracefully skips the closed-ticket section when no data is present.

---

### Step 2 — Fetch full ticket details for each board

Default behavior is detail-aware prioritization. Do not stop at the summary-only dataset from Step 1.

For every board with at least 2 actionable tickets:
- Create `/tmp/priority-details/<board>/`
- Use `bash .github/skills/jira-wiki-reader/scripts/fetch-batch.sh ... --compact` in chunks of up to 20 ticket keys
- Save each batch response into that board directory
- Fetch full ticket context before ranking: description, recent comments, linked issues, subtasks, labels, story points, and status history signals exposed by the ticket payload

Implementation rules:
- Use the Jira skill scripts, not raw `curl`, for ticket-detail retrieval
- Treat `/tmp/priority-details/` as ephemeral working state; never persist it in the repo
- Boards below the minimum threshold can be skipped during detail fetch just as they are skipped during report generation

---

### Step 3a — Analyze ticket details + Tableau fallout, build transient prioritization signals

This step produces the base signal files by combining Jira ticket analysis with live Tableau fallout data.

**Tableau data export** (run first, before ticket analysis):
```bash
# Verify Tableau auth
bash .github/skills/tableau-reader/scripts/tableau-query.sh check

# Export 10-day fallout detail (per-instance with EXCEPTION_MSG, BUSINESS_KEY, START_TIME)
bash .github/skills/tableau-reader/scripts/tableau-query.sh export \
  13cb7486-7867-48ee-8576-8593aa99ebc1 /tmp/fallout-full.csv
```

**Run the signal builder script** (automated analysis of tickets + Tableau correlation):
```bash
python3 .github/shared/scripts/defect-prioritization/build-signals-with-tableau.py
```

This script:
- Reads ticket details from `/tmp/priority-details/` and fallout detail from `/tmp/fallout-full.csv`
- Derives ALL metrics from the 10-day fallout detail: daily trends, per-app totals, error groupings
- Identifies stalled, blocked, unassigned tickets with specific owners and durations
- Clusters tickets by shared BPM task name and error type (e.g., "Insurance Capability Cluster: 14 tickets")
- Correlates Tableau error groupings with Jira tickets (matched vs unmatched fallout patterns)
- Each distinct (APP + Activity + Error Category) combination without a matching ticket gets its own highlighted row
- Generates per-board HTML Tableau sections with: stat cards, daily trend sparklines, error grouping table, unmatched fallout warnings, ticket↔fallout correlation
- Detects incident-linked tickets, In Test status, recommend cancel candidates
- Produces rich weekly actions, per-ticket actions for T1/T2/T3, and workflow insights
- Writes signal files to `/tmp/priority-signals/<board>.json`

These files are internal analysis artifacts consumed by the report generator. They are ephemeral and should not be committed.

**Signal file format** (`/tmp/priority-signals/<board>.json`):
```json
{
  "tier_overrides":     { "TICKET-123": [1, "Reason for tier 1 override"] },
  "special_flags":      { "TICKET-123": ["sev3", "Short description of flag"] },
  "insights":           ["🚨 <strong>Title:</strong> Explanation text"],
  "per_ticket_actions": [{"key": "TICKET-123", "tier": 1, "action": "What to do", "color": "red"}],
  "weekly_actions":     [{"urgency": "today", "action": "Description", "ticket": "TICKET-123", "owner": "Name"}],
  "extra_stats":        [{"value": 3, "label": "De-facto Stalled", "color": "#6b21a8", "bg": "#faf5ff"}],
  "assignee_callouts":  [{"text": "⚠ <strong>Name</strong> has 4 tickets...", "color": "#6b21a8", "bg": "#faf5ff"}],
  "workflow_insights":  ["80% of tickets are Not Started..."],
  "tableau_section":    "<div>...rich HTML Tableau section...</div>"
}
```

**Flag types:** `sev3`, `blocker`, `blocked`, `cancel`, `urgent`, `release`, `impact`, `stalled`, `info`

---

**Run the automated enrichment script** (tier rebalancing + fallout-aware scoring):
```bash
python3 .github/shared/scripts/defect-prioritization/enrich-priority-signals.py
```

This script performs ADDITIVE enrichment on top of Step 3a: tier rebalancing (T1 max 8, T2 max 13),
fallout-volume scoring (50+ events = +15 score), dependency chain detection, cluster promotion,
and activity-specific action text. It preserves all base insights and adds enriched ones.

### Step 3b — LLM semantic enrichment pass (deep analysis)

> **Why this step exists:** Even after the automated enrichment, actions reference BPM task
> names but lack the business context that only comes from reading ticket comments — things
> like "Anju Annayyan provided sample business keys" or "Sadhana confirmed issue persists".
> This step is where the report becomes ACTIONABLE vs merely data-accurate.
> Without it, actions are structurally correct but impersonal.

After the enrichment script runs, perform a **deep reading** of each board's tickets and produce bespoke enrichment. This is NOT optional — without it, the report provides no value over raw Jira.

**Quality bar:** Compare your output against this reference (from a high-quality report):
- ❌ BAD: "Blocked chain detected - Mounika U to escalate dependency owner"
- ✅ GOOD: "CMXOTB-4814 — 66-Day-Old HIGH (Mounika U): ByodInsuranceException: imei=null, accountGuid not found. Cloned from CMXOTB-785 suggesting recurring systemic issue. 3-ticket workload risk."
- ❌ BAD: "unknown Cluster (14 tickets): Recurring pattern 'unknown' appears across 14/55 tickets"
- ✅ GOOD: "Insurance Capability Super-Cluster (25 of 56 tickets): Nearly half the board traces to insurance-related BPM tasks across 9 distinct task names — invokeBoCapability*Insurance*, submitInsuranceOrderTask, assurantEnrollment_1. Common downstream errors: SubscriptionNotFound, LEAN_ACCOUNT_NOT_FOUND"

For each board with 5+ tickets:
1. **Re-read** all ticket detail files in `/tmp/priority-details/<board>/` and the existing signal file
2. **Generate bespoke insights** (minimum 8 per large board, 5 per small board) — not generic patterns but specific findings:
   - Quote actual people by name with specific dates from their comments
   - Reference specific order counts, business keys, deployment versions
   - Identify ticket clusters by shared BPM task/error pattern with specific task names listed
   - Call out premature closure attempts (SOP-resolved ≠ root-cause-fixed)
   - Identify deployment status (which tickets have code committed, in staging, in prod)
   - Highlight cross-ticket dependencies ("CMXOTB-6219 may share root cause with CMXOTB-6153")
   - Flag customer-blocking incidents with revenue/operational impact
   - Example: `🚨 <strong>Insurance Capability Cluster (14 of 20 tickets):</strong> The vast majority of CMXOTB fallout traces to invokeBoCapability*Insurance* tasks. Root-cause investigation at the BO integration layer could resolve multiple tickets simultaneously.`
3. **Per-ticket actions** — for every ticket in T1, T2, and T3 where an action is needed:
   - Each action: `{"key": "TICKET-123", "tier": 1, "action": "Description of what to do", "color": "red"}`
   - Colors: `red` (immediate risk), `orange` (escalate/unblock), `purple` (stalled/investigate), `green` (verify/close), `gray` (cancel/defer)
   - **QUALITY RULE**: Every action MUST reference the specific error/task and include what was learned from comments:
     - ❌ BAD: "Blocked chain detected - Name to escalate dependency owner"
     - ✅ GOOD: "CMXOTB-5700 — Blocked 27 days. Haritha Modem asked for latest orders on 4/28; Sadhana confirmed issue persists. Either provide fresh fallout orders for triage or document SOP as permanent workaround."
     - ❌ BAD: "Track progress on ticket"
     - ✅ GOOD: "NPE in updateMvnoOrderForForceBill — 80 orders impacted since 3/16. Known commit d42633d8 introduced the bug. Assign to ForcedBilled cluster owner for code fix."
4. **Weekly action list** — a consolidated, deduplicated list of the most important actions across all tiers:
   - Each entry: `{"urgency": "immediate", "action": "Description", "ticket": "TICKET-123", "owner": "Assignee Name"}`
   - Urgency values: `immediate`, `today`, `escalate`, `follow-up`, `verify`, `close`, `cancel`, `triage`, `queue`
   - Order by urgency (immediate first). Target 5-12 entries per board.
   - **QUALITY RULE**: Actions must be different from each other — if all actions say the same template with different names, REDO. Each action should describe a DIFFERENT situation requiring a DIFFERENT response.
5. **Extra stat boxes** — additional counters that help leads at a glance:
   - `{"value": 3, "label": "De-facto Stalled", "color": "#6b21a8", "bg": "#faf5ff"}`
   - Common extras: "De-facto Stalled", "Needs Triage", "Recommend Cancel", "Blocked Chain"
6. **Assignee callouts** — specific risk warnings about people:
   - `{"text": "⚠ <strong>J.Smith</strong> has 4 T1 tickets and 2 are stalled >30 days. Redistribute CMXOTR-450 to an available developer.", "color": "#6b21a8", "bg": "#faf5ff"}`
7. **Workflow insights** — cross-workflow pattern observations for the distribution chart:
   - Simple strings: `"80% of tickets are in OT Fallout workflow — consider splitting into sub-workflows for better triage"`

**Tier rebalancing guidelines:**
- T1 (Do Now): 4-8 tickets — highest risk, incident-linked, blocked chains, highest fallout volume
- T2 (Escalate): 6-13 tickets — high fallout, stalled, needs assignment
- T3 (In Flight): cluster members, active work, test verification
- T4 (Monitor): low urgency, near-done
- T5 (Queue): everything else
- Do NOT promote every ticket with active fallout to T2 — when multiple tickets share the same error pattern (e.g., 20+ tickets in an insurance cluster), promote only 2-3 representative tickets to T2 and keep the rest at T3 as "cluster member"
- A board with 55 tickets should NOT have T1=6, T2=4, T3=1, T5=35 — this means almost no analysis happened. Expect T1=6-8, T2=8-13, T3=20-30 for large boards.

**Merge into the signal file** — update each `/tmp/priority-signals/<board>.json` preserving `tableau_section` and `extra_stats` from Step 3a. Overwrite other fields with enriched versions.

**Critical format requirements** (the report generator will crash if these are wrong):
- `tier_overrides`: values must be `[int, string]` — e.g., `[2, "Reason"]`, NOT `{"from": 3, "to": 2, ...}`
- `special_flags`: values must be `["type", "description"]` — e.g., `["sev3", "Incident ref"]`, NOT bare strings
- `assignee_callouts`: values must be `{"text": "...", "color": "#hex", "bg": "#hex"}`, NOT bare strings
- `per_ticket_actions`: `tier` must be an integer, `color` is required
- `weekly_actions`: `urgency`, `action`, `ticket`, `owner` all required

Write the enriched file using `create_file` (overwriting the Step 3a version). Validate the JSON parses: `python3 -c "import json; json.load(open('/tmp/priority-signals/<board>.json'))"` for each board.

**Step 3b quality self-check (BLOCKING — do NOT proceed to Step 4 if any fail):**
1. Read back `weekly_actions` from each signal file. If >50% of actions contain the same phrase template (e.g., all say "escalate dependency owner"), REDO the enrichment for that board.
2. Check `insights` count: boards with 20+ tickets must have ≥8 insights, boards with 5+ must have ≥5.
3. Verify `per_ticket_actions` are unique: no two T1/T2 actions should be identical text with just the owner name swapped.
4. Check tier distribution: a board with 50+ tickets that has T5 > 60% means tier rebalancing was too timid — re-promote based on fallout volume and comment activity.
5. Verify at least 3 insights reference specific people, dates, or order counts (not just aggregate statistics).

---

### Step 4 — Generate all board reports with detail-aware prioritization

After Step 3b completes, generate the final reports using the enriched signal files:

```bash
# Use date subfolder for clean organization: priority/YYYY-MM-DD/
TODAY=$(date +%Y-%m-%d)
python3 .github/shared/scripts/defect-prioritization/generate-board-priority-report.py \
  --tickets /tmp/epic-tickets.json \
  --all-boards \
  --epic CMXOTD-3181 \
  --overrides-dir /tmp/priority-signals \
  --output-dir docs/generated/priority/${TODAY} \
  --min-tickets 2
```

This is the default final output path:
- One HTML report per board prefix with at least 2 actionable tickets
- An `index-YYYY-MM-DD.html` dashboard linking to all reports
- Tier notes and signal badges informed by ticket descriptions, comments, and linked work
- Per-tier specific action items with colored urgency borders (T1 red, T2 orange/purple, T3 green)
- Consolidated weekly action list with urgency badges and owner attribution
- Extra stat boxes (De-facto Stalled, Needs Triage, Recommend Cancel, Fallout w/o Ticket, Unassigned)
- Assignee overload callouts with specific ticket redistribution recommendations
- Workflow concentration narrative insights
- **Tableau Production Fallout section** with: stuck order stat cards, per-APP stuck table with daily sparklines, error grouping table with ticket match status, unmatched fallout warning panel, ticket↔fallout correlation table

---

### Step 5 — Review 

1. Open the index HTML in browser to verify all boards rendered
2. Spot-check the largest boards (CMXOTB, CMXOTP) to confirm tier notes and signal badges match ticket evidence from descriptions and comments
3. Review the Tableau section for accurate fallout counts, error groupings, and correlation with tickets

---

## Scoring Model

| Factor | Values |
|---|---|
| **Priority** | Critical=50, Highest=40, High=30, Medium=10, Low=2 |
| **Status** | Blocked=25, In Progress=15, Not Started=5, Test=3 |
| **Age** | >365d=+20, >180d=+15, >90d=+10, >60d=+7, >30d=+4, ≤30d=+1 |
| **Unassigned** | -5 penalty |

**Tier thresholds:** Score ≥38 → T1, ≥30 → T2, ≥25 → T3, ≥20 → T4, else T5

Base score is only the starting point. Transient prioritization signals from Step 3 take precedence when ticket details and comments show the metadata-based score is misleading.

---

## Output Structure

```
docs/generated/priority/
├── index-2026-05-01.html          ← Dashboard with links to all boards
├── cmxotb-priority-2026-05-01.html
├── cmxotp-priority-2026-05-01.html
├── cmxotr-priority-2026-05-01.html
├── cmxotos-priority-2026-05-01.html
├── cmxotf-priority-2026-05-01.html
└── cmxot2-priority-2026-05-01.html
```

---

## Excluded Statuses

These statuses are filtered out of actionable counts:
`Canceled`, `Released`, `Resolved`, `Closed`, `Accepted`
