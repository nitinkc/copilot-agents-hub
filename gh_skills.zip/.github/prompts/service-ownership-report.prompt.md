Generate a **Service Ownership & Documentation Coverage Report** for all OrderTech microservices.

## DATA SOURCES

1. **Service registry**: `.github/shared/service_mappings.json` — extract every entry that has a non-null `cf_app_name`. Deduplicate by `repo_name` (keep one entry per unique repo). Record the `service` name and `repo_name`.

2. **Documentation status**: For each unique repo, check whether `docs/generated/01-business-capabilities.md` exists on the default branch using `gh api repos/comcast-modesto/{repo_name}/contents/docs/generated/01-business-capabilities.md --jq '.name'` (200 = exists, 404 = missing).

3. **PR-based ownership**: For each repo, fetch the last 20 PRs (all states) using `gh pr list --repo comcast-modesto/{repo_name} --limit 20 --state all --json number,title,author`.

## OWNERSHIP HEURISTIC

For each repo, determine the owning team and probable developer owners:

### Ticket extraction
- Extract Jira ticket keys from **PR titles only** (not branch names) using pattern `[A-Z][A-Z0-9]{1,9}-\d+`.
- **Exclude cross-org rollout tickets** that appear across many repos and don't indicate domain ownership. Known cross-org tickets include: CMXOTCP-4146, CMXOTCP-3970, CMXOTCP-3704, CMXOTCP-3939, CMXOTCP-1408, CMXOTCP-2442, CMXOTCP-47, CMXOTCP-109, CMXOTCP-1223, CMXOTCP-1026, CMXOTCP-3322, CMXOTCP-3006, CMXOTCP-4110, CMXOTCP-780, CMXOTCP-90, CMXOTCP-167, CMXOTCP-1061. Add any new obvious cross-org tickets discovered during the run.

### Infra PR filtering
- Classify PRs as **infra** (not domain signal) if the title matches (case-insensitive): `rollout logtype`, `code owners`, `update csp connector`, `bump version`, `spring boot upgrade`, `rollout.*ot services`, `ot services.*rollout`. Include both `codeowners` and `code owners` (space variant).
- Infra PRs are excluded from feature-prefix counting and feature-author counting.

### Team prefix determination
- Count ticket prefixes from **feature PRs only** (non-infra, non-cross-org). One vote per PR (use the first non-excluded ticket).
- The prefix with the highest feature-PR count wins.
- **Platform prefix fallback**: If the winning prefix is `CMXOTCP` or `OTCP` (cross-platform teams), fall back to the next highest non-platform prefix. If fallback is used, mark with `~`.
- If no feature PRs exist, fall back to all-PR prefix counts (same platform fallback logic).

### Author determination
- **Feature-PR authors first**: rank authors by number of feature PRs they authored (non-infra PRs with domain tickets). Show top 3.
- If no feature-PR authors, fall back to all-PR author counts (top 3).
- Exclude bot accounts (login starts with `app/` or length ≥ 35 characters).

## OUTPUT FORMAT

Generate a **self-contained HTML file** at `docs/generated/ownership-report.html` with:

### Section 1 — Executive Summary (stat cards)
- Total repos analyzed
- Has documentation ✓ (count)
- Missing documentation ✗ (count)
- Doc coverage % 
- Platform fallback count (~)
- Unreachable repos count

### Section 2 — Ownership by Team (card grid)
Group services by their resolved team prefix. For each team card show:
- Team prefix and description
- Service count, ✓ docs count, ✗ missing count, doc %
- Visual bar (green/red) showing doc coverage proportion

Use these team descriptions:
| Prefix | Description |
|--------|-------------|
| CMXOTP / OTP | Provisioning & Account Lifecycle |
| CMXOTR / OTR | Risk, Retail & Returns |
| CMXOTOS / OTOS | Order & Commerce Services |
| CMXOTB / OTB | Billing |
| CMXOTF / OTF | Fulfillment |
| CMXOT2 | BO Account / Resource |
| CMXOT3 | Trade-In / 3rd Gen |
| CMXOT4 | Plan Addons / Usage |
| ECD / CMXRES | External Catalog & Data |
| CMXWRR | Buyflow / Cart |
| OTCP / CMXOTCP | Cross-Platform (weak signal) |

### Section 3 — Services WITHOUT Documentation ✗
Table with columns: Service (link to GitHub repo), Team (colour-coded pill), PRs, Recent Feature Tickets, Probable Owners. Filterable by text search and team dropdown. Sortable columns.

### Section 4 — Services WITH Documentation ✓
Same table format as Section 3.

### Section 5 — Unreachable Repos
Table showing repos that returned 404 or timeout errors.

### HTML requirements
- Dark theme, self-contained (no external CSS/JS dependencies)
- Team-colour-coded pills (consistent colours per prefix)
- `~fallback` indicator on services where platform prefix was overridden
- Live text filter + team dropdown filter per table
- Click-to-sort on all column headers
- Service names link to `https://github.com/comcast-modesto/{RepoName}`
- Footer with generation date and methodology note

## EXECUTION APPROACH

Write a Python script to `/tmp/ownership_report.py` that:
1. Reads `service_mappings.json` and deduplicates
2. Checks doc existence via `gh api` (batch, handle 404 gracefully)
3. Fetches 20 PRs per repo via `gh pr list` (handle errors, timeouts)
4. Applies the ownership heuristic (ticket extraction, infra filter, platform fallback, feature-author ranking)
5. Outputs structured JSON to stdout

Then generate the HTML file from that data. Run the script and produce the final HTML report.

## NOTES
- The `_comcast` suffix on author logins can be stripped for display.
- If a repo returns a GitHub API error (404, 504), record it in the unreachable section and continue.
- This report typically covers ~160 repos and takes 3-5 minutes to run.
