---
description: "Daily AI-agent adoption report — PRs in last 24h with docs/generated/ changes across OrderTech org"
---

# Daily AI-Agent Adoption Report

Generate an AI-agent adoption report for the last 24 hours across the `comcast-modesto` GitHub org.
Output: `docs/generated/ai-adoption-report-YYYY-MM-DD.html` (use today's date).

Scripts are in `.github/shared/scripts/ai-adoption-report/`:
- `collect-prs.sh` — Bash collector (GitHub API → pipe-delimited output)
- `generate-report.py` — Python HTML generator (pipe-delimited input → HTML report)

---

## Instructions

### Step 1 — Collect PR data from GitHub

**Always start fresh** — delete any stale cache before running:
```bash
rm -f /tmp/pr-report-output.txt /tmp/pr-report-name-cache.txt /tmp/pr-report-errors.log
```

Run the collector script directly (no script generation needed):
```bash
bash .github/shared/scripts/ai-adoption-report/collect-prs.sh 2>/tmp/pr-report-errors.log | tee /tmp/pr-report-output.txt
```

**CRITICAL: Wait for the script to finish before proceeding.** The script outputs one line per PR and takes ~2 sec/PR. Do NOT pipe through `head`, `wc`, or any filter that can send SIGPIPE. Do NOT start Step 2 until:
1. The terminal shows a shell prompt (command exited)
2. The file ends with `# COMPLETE` — verify: `tail -1 /tmp/pr-report-output.txt`

If `# COMPLETE` is missing, the run was interrupted or failed. Check `/tmp/pr-report-errors.log` and re-run.

---

### Step 2 — Generate the HTML report

**Pre-condition check** (MANDATORY before processing):
```bash
tail -1 /tmp/pr-report-output.txt | grep -q "^# COMPLETE$" || { echo "ABORT: pr-report-output.txt is incomplete (missing COMPLETE sentinel). Re-run Step 1."; exit 1; }
```
If this check fails, do NOT proceed — re-run Step 1.

Run the report generator:
```bash
python3 .github/shared/scripts/ai-adoption-report/generate-report.py \
  --input /tmp/pr-report-output.txt \
  --output-dir docs/generated
```

The generator handles all filtering, statistics, and HTML generation. It will:
- Skip comment lines and header rows automatically
- Exclude infra/config repos (MobileBackOfficeConfig, MspRuleConfig, OT-Automation-BDD, etc.)
- Exclude PRs with no Jira ticket in the title
- Compute KPIs, team breakdown, author stats, reviewer stats
- Generate a self-contained HTML file with modern CSS
- Print a summary to stdout

Optional arguments:
- `--date YYYY-MM-DD` — override report date (default: today)
- `--period "description"` — override period text (default: "last 24 hours")

---

### Step 3 — Report summary

After generating, the script prints:
- File path
- Total PRs, AI PRs, Adoption %
- Top 3 teams by adoption
- Any teams with 0% adoption
