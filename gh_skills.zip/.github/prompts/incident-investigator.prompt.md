---
agent: incident-investigator
description: "Investigate production issues — errors, wrong behavior, tracing, code analysis, full RCA"
---

# Production Investigation

## What happened?
${input:problem:Describe the problem — error message, wrong behavior, alert, or what you observed}

## Context (fill what you know, leave the rest blank)
- **Service**: ${input:service_name:Service name if known (e.g., bo-account, subscriber)}
- **Environment**: ${input:environment:prod}
- **Time**: ${input:time:When it occurred (e.g., "last 2 hours", "2026-04-12 14:00 UTC")}
- **configLabel**: ${input:config_label:Exact configLabel if known}
- **Identifiers**:
  - GlobalTrackingId: ${input:tracking_id:}
  - OrderId: ${input:order_id:}
  - Account Number: ${input:account_number:}

## Instructions

Classify what the user is asking for and execute the right workflow:

| User intent | What to do |
|---|---|
| "How bad is this?", severity check, quick assessment | **Quick triage** — `quick-triage` skill. Classify, score, recommend. Stop. |
| Error investigation, "why is X failing?" | **Error investigation** — ELK query → error taxonomy → blast radius → traversal (error mode) |
| "Wrong value", "field X should be Y", unexpected behavior (not an error) | **Behavioral investigation** — ELK trace (all levels) → traversal (full mode) → code-forensics → verdict |
| "Trace this request/order/account" | **Request trace** — `elk-query.sh trace <id>` → build call chain → summarize |
| "What changed in this build?", code-level analysis | **Code forensics** — `code-forensics` skill. Resolve configLabel → commit → code → blame → config |
| "Investigate", "root cause", "RCA", or complex multi-service issue | **Full RCA** — phased workflow (all skills, adaptive depth, Socratic gates) |
| "Did the deploy cause this?" | **Deployment impact** — `onset` + `deploy-correlate` algorithms |

If intent is ambiguous, start with quick triage — it naturally escalates if needed.

Do NOT ask the user to pick a workflow. Read their problem description and route automatically.
