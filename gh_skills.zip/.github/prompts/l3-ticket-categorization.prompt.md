---
description: "L3 production support ticket categorization — active non-recon tickets from ServiceNow with detailed analysis"
---

# L3 Production Support Ticket Categorization

Fetch all active, non-recon tickets for the OrderTechProductionSupport_L3 assignment group from ServiceNow. Categorize by error type, required action, and service impact.

---

## Instructions

### Step 1 — Load the ServiceNow skill
Read `.github/skills/servicenow-reader/SKILL.md` before executing any commands.
Verify connectivity: `snow-query.sh check`. If expired, follow the auto-refresh chain in the skill — do NOT ask the user to paste cookies.

---

### Step 2 — Fetch all active L3 tickets

Search for active incidents assigned to the L3 group, excluding recon tickets:

```bash
bash .github/skills/servicenow-reader/scripts/snow-query.sh search-incidents \
  "assignment_group.nameLIKEOrderTechProductionSupport_L3^active=true^short_descriptionNOT LIKERecon^short_descriptionNOT LIKErecon^short_descriptionNOT LIKERECON^ORDERBYDESCpriority" 200
```

Also search for active cases assigned to the same group:

```bash
bash .github/skills/servicenow-reader/scripts/snow-query.sh search-cases \
  "assignment_group.nameLIKEOrderTechProductionSupport_L3^active=true^short_descriptionNOT LIKERecon^short_descriptionNOT LIKErecon^ORDERBYDESCpriority" 200
```

Record the total count from each search. If either returns 0, note it and proceed with the other.

---

### Step 3 — Fetch full details for each ticket

For each ticket returned in Step 2, fetch the full details:

```bash
# For incidents
bash .github/skills/servicenow-reader/scripts/snow-query.sh get-incident <INC_NUMBER>

# For cases
bash .github/skills/servicenow-reader/scripts/snow-query.sh get-case <CAS_NUMBER>
```

Extract from each ticket:
- `number`, `short_description`, `description`, `priority`, `state`, `opened_at`, `assigned_to`
- `category`, `subcategory` (if present)
- `cmdb_ci` / service name
- Key details from description (account number, order ID, BPM order ID, error message, order type)

**Batch limit**: Fetch up to 50 individual ticket details. If >50 tickets, fetch details for the top 50 by priority, and summarize the rest from the search results.

---

### Step 4 — Categorize tickets

Classify each ticket into one of these primary categories based on `short_description` and `description` content:

| Category | Keywords / patterns |
|---|---|
| `STUCK_ORDER` | stuck, holding, BPM HOLDING, stuck state, cannot progress |
| `FAILED_ORDER` | failed, error, exception, failure, 500, timeout |
| `CANCEL_ISSUE` | cancel, ASYNCCANCEL, disconnect, revoke, cancel stuck |
| `BILLING_ISSUE` | billing, biller, CMT, invoice, charge, credit, XOMSBILLER |
| `PROVISIONING_ISSUE` | provision, activate, activation, entitlement, fulfillment |
| `DATA_FIX` | data fix, data correction, update account, manual update, wrong value |
| `DOWNSTREAM_FAILURE` | downstream, Ascendon, Byondel, CSG, Convergence, Assurant, vendor |
| `PERFORMANCE_ISSUE` | slow, latency, timeout, performance, high response time |
| `ACCESS_AUTH` | auth, 401, 403, forbidden, token, credential, SSO |
| `DEPLOYMENT_ISSUE` | deploy, release, config, version, rollback |
| `CUSTOMER_ESCALATION` | escalat, customer complaint, urgent customer, VIP |
| `MONITORING_ALERT` | alert, threshold, disk, CPU, memory, health check |
| `OTHER` | (no pattern matched) |

Then assign a secondary sub-category based on the specific service or error:
- Parse the affected service name from `cmdb_ci`, description, or short_description
- Parse the specific error code or exception type if present
- Parse the order type (ADD, CHANGE, CANCEL, ASYNCCANCEL, DISCONNECT) if present

---

### Step 5 — Determine required action for each ticket

| Action Type | When to assign |
|---|---|
| `RETRIGGER` | Transient failure, order can be safely retried |
| `DATA FIX` | Incorrect data needs correction before retry |
| `CODE FIX` | Bug in service code — needs dev fix |
| `DOWNSTREAM WAIT` | Blocked on external system recovery |
| `ESCALATE` | Needs L4/engineering or vendor involvement |
| `CLOSE — RESOLVED` | Issue already resolved, ticket can be closed |
| `CLOSE — DUPLICATE` | Duplicate of another active ticket |
| `INVESTIGATE` | Needs deeper analysis before action |
| `MANUAL INTERVENTION` | Requires manual DB/API operation |

---

### Step 6 — Generate the report

Output these sections in order:

---

#### HEADER

```
L3 Production Support Ticket Report
Date: <YYYY-MM-DD>  |  Total active non-recon: <N incidents> + <N cases>
```

---

#### CATEGORY SUMMARY TABLE

| Category | Count | % | Top Service | Top Action |
|---|---|---|---|---|
| STUCK_ORDER | N | % | ... | ... |
| FAILED_ORDER | N | % | ... | ... |
| ... | | | | |
| **TOTAL** | **N** | **100%** | | |

---

#### PRIORITY DISTRIBUTION

| Priority | Count | % | Categories |
|---|---|---|---|
| P1 — Critical | N | % | ... |
| P2 — High | N | % | ... |
| P3 — Medium | N | % | ... |
| P4 — Low | N | % | ... |

---

#### AGE ANALYSIS

| Age Bucket | Count | % | Oldest Ticket |
|---|---|---|---|
| < 24 hours | N | % | ... |
| 1-3 days | N | % | ... |
| 3-7 days | N | % | ... |
| 7-14 days | N | % | ... |
| 14-30 days | N | % | ... |
| > 30 days | N | % | ... |

---

#### TICKET DETAIL BY CATEGORY

For each category (sorted by count descending), list tickets:

```
## STUCK_ORDER (N tickets)

| # | Ticket | Priority | Age | Service | Description | Order Type | Action |
|---|--------|----------|-----|---------|-------------|------------|--------|
| 1 | INCxxx | P2 | 3d | wkfl-ott-fulfillment | updateCMTs stuck | ASYNCCANCEL | CODE FIX |
| 2 | CASxxx | P3 | 1d | bpm-billing-order | ... | ADD | RETRIGGER |
```

---

#### ACTION SUMMARY — FASTEST PATH TO RESOLUTION

Prioritized list for the L3 on-call engineer:

1. **CLOSE — RESOLVED / DUPLICATE** — List tickets that can be closed immediately
2. **RETRIGGER** — Tickets safe to retry now (with count and ticket numbers)
3. **DOWNSTREAM WAIT** — Which downstreams are unhealthy, how many tickets blocked
4. **DATA FIX** — Highest-count data issues with fix description
5. **ESCALATE** — Tickets that need L4/engineering/vendor (with justification)
6. **CODE FIX** — Tickets blocked on a code change
7. **INVESTIGATE** — Tickets needing deeper analysis

---

#### SERVICE IMPACT TABLE

| Service | Ticket Count | P1/P2 Count | Top Category | Top Action |
|---|---|---|---|---|

---

### Step 7 — Save the report

Save to:
```
docs/generated/standup/l3-tickets-<YYYY-MM-DD>.md
```

Confirm: `📄 Report written to: docs/generated/standup/l3-tickets-<YYYY-MM-DD>.md`

---

## Quality checks before saving

- [ ] Both incident and case searches executed (or noted as 0)
- [ ] Recon tickets excluded (NOT LIKE Recon filter applied)
- [ ] All tickets categorized (no uncategorized tickets outside OTHER)
- [ ] All tickets have an action type assigned
- [ ] Priority distribution adds up to total
- [ ] Category summary adds up to total
- [ ] Age calculated from `opened_at` to today
- [ ] ACTION SUMMARY section present with prioritized closure path
- [ ] Report saved to `docs/generated/standup/` with correct date
