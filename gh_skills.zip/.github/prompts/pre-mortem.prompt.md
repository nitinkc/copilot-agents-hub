---
mode: agent
agent: incident-investigator
description: "Pre-mortem analysis on an RCA — assume the fix fails and work backward"
---

# Pre-Mortem Analysis on RCA

Perform a pre-mortem analysis on the current Root Cause Analysis.

## Context

Use prospective hindsight (Kahneman/Klein research — increases correct failure
identification by 30%): assume it is 30 days from now, the fix was deployed,
but the same incident **recurred**. The RCA was **WRONG**.

## Instructions

Load the rca-quality-gate skill and cognitive biases reference:
```
read_file .github/skills/rca-quality-gate/SKILL.md
read_file .github/skills/rca-synthesis/COGNITIVE-BIASES.md
```

Working backward from the imagined failure, analyze:

1. **Evidence Misinterpretation**: Which evidence could we have misread? What
   alternative interpretation exists?

2. **False Assumptions**: Which Five Whys assumption was wrong? What if the
   causal link between two Whys doesn't hold?

3. **Missing Data**: What data source did we fail to consult? What question
   did we fail to ask?

4. **Dismissed Hypothesis**: Which alternative did we dismiss too quickly?
   What if it was actually correct?

5. **Temporal Coincidence**: What if two events that appeared causally linked
   were coincidental? (Same timestamp ≠ same cause)

6. **Fix Fragility**: What if the fix works for THIS instance but not the
   underlying class of failure? What conditions would cause a similar but
   not identical failure?

## Output

For each of the 6 dimensions:
- The most plausible failure scenario
- What evidence we would need to rule it out
- Whether this evidence was actually checked during the investigation
- Recommended action: **investigate further** / **acceptable risk** / **no action**
