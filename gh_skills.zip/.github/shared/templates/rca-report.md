# RCA Report — {{INCIDENT_ID}}

> **Generated**: {{TIMESTAMP}}
> **Severity**: {{SEVERITY}} | **RPN**: {{RPN_SCORE}} | **Priority**: {{PRIORITY}}
> **Status**: {{STATUS}}

---

## 1. Executive Summary

{{3-4 sentences: what happened, impact, root cause, fix status.}}

---

## 2. Incident Timeline

| Timestamp (UTC) | Service | configLabel | Event | Type |
|-----------------|---------|-------------|-------|------|
| {{TS}} | {{SERVICE}} | {{configLabel}} | {{EVENT}} | {{normal / error_origin / propagation / detection / mitigation}} |

**Inception Point**: {{FIRST_ABNORMAL_EVENT}}
**Detection Gap**: {{TIME_BETWEEN_INCEPTION_AND_DETECTION}}
**Total Duration**: {{TOTAL_INCIDENT_DURATION}}

---

## 3. Blast Radius

| Metric | Value |
|--------|-------|
| Services Affected | {{COUNT}} |
| Customer-Facing | {{YES/NO}} |
| Domains Impacted | {{DOMAIN_LIST}} |
| Datacenters Affected | {{DC_LIST}} |
| SalesChannels Affected | {{CHANNEL_LIST}} |
| Data Integrity Risk | {{NONE/LOW/MEDIUM/HIGH}} |
| Stuck Workflows | {{COUNT}} |
| Total Error Count | {{COUNT}} |

**Affected Services**:

| Service (serviceName slug) | Error Type | Error Count | DC Distribution |
|---|---|---|---|
| {{SERVICE}} | {{ERROR_TYPE}} | {{COUNT}} | {{wc-g2: N, po-g2: N, ...}} |

---

## 4. Error Propagation Chain

```
{{VISUAL_CHAIN — use service slugs from serviceName}}

Example:
[stock-sync] ──timeout──▶ [biller-account] ──500──▶ [customer-gateway] ──502──▶ [nginx]
  (ORIGIN: DB lock)        (NPE on null response)    (Unhandled upstream)      (Customer 502)
```

**Propagation Direction**: {{DOWNSTREAM/UPSTREAM/BIDIRECTIONAL}}
**Patterns Detected**: {{CASCADE / TIMEOUT_PROPAGATION / CIRCUIT_BREAKER_OPEN / RETRY_STORM / RESOURCE_EXHAUSTION}}

---

## 5. Five Whys Analysis

**Why 1**: Why did {{OBSERVABLE_SYMPTOM}}?
> **Because**: {{CAUSE_1}}
> **Evidence**: {{ELK log / code file:line / config key — with configLabel and timestamp}}

**Why 2**: Why did {{CAUSE_1}}?
> **Because**: {{CAUSE_2}}
> **Evidence**: {{reference}}

**Why 3**: Why did {{CAUSE_2}}?
> **Because**: {{CAUSE_3}}
> **Evidence**: {{reference}}

**Why 4**: Why did {{CAUSE_3}}?
> **Because**: {{CAUSE_4}}
> **Evidence**: {{reference}}

**Why 5**: Why did {{CAUSE_4}}?
> **Because**: {{ROOT_CAUSE}}
> **Evidence**: {{reference}}

### Root Cause Statement
> {{One paragraph connecting the full causal chain.}}

---

## 6. Ishikawa Analysis

| Dimension | Status | Finding |
|-----------|--------|---------|
| Technology | {{Not a factor / Contributing / Primary}} | {{DETAIL}} |
| Process | {{Not a factor / Contributing / Primary}} | {{DETAIL}} |
| People | {{Not a factor / Contributing / Primary}} | {{DETAIL}} |
| Environment | {{Not a factor / Contributing / Primary}} | {{DETAIL}} |
| Data | {{Not a factor / Contributing / Primary}} | {{DETAIL}} |
| Design | {{Not a factor / Contributing / Primary}} | {{DETAIL}} |

---

## 7. FMEA Score

| Dimension | Score | Justification |
|-----------|-------|---------------|
| Severity (S) | {{1-10}} | {{JUSTIFICATION}} |
| Occurrence (O) | {{1-10}} | {{JUSTIFICATION}} |
| Detection (D) | {{1-10}} | {{JUSTIFICATION}} |
| **RPN** | **{{S×O×D}}** | **{{PRIORITY_LABEL}}** |

---

## 8. Fault Tree

```
TOP EVENT: {{USER_VISIBLE_FAILURE}}
├── {{AND/OR}}
│   ├── {{INTERMEDIATE_EVENT_1}}
│   │   ├── BASIC: {{SPECIFIC_FAULT_1}}
│   │   └── BASIC: {{SPECIFIC_FAULT_2}}
│   └── {{INTERMEDIATE_EVENT_2}}
│       └── BASIC: {{SPECIFIC_FAULT_3}}
```

**Minimal Cut Sets**: {{LIST}}
**Single Points of Failure**: {{LIST}}

---

## 9. Swiss Cheese — Defense Layer Analysis

| # | Defense Layer | Status | Details |
|---|---|---|---|
| 1 | Input Validation | {{HELD/BREACHED/ABSENT}} | {{DETAIL}} |
| 2 | Unit Tests | {{HELD/BREACHED/ABSENT}} | {{DETAIL}} |
| 3 | Integration Tests | {{HELD/BREACHED/ABSENT}} | {{DETAIL}} |
| 4 | Code Review | {{HELD/BREACHED/ABSENT}} | {{DETAIL}} |
| 5 | Static Analysis | {{HELD/BREACHED/ABSENT}} | {{DETAIL}} |
| 6 | Circuit Breakers | {{HELD/BREACHED/ABSENT}} | {{DETAIL}} |
| 7 | Retry/Fallback | {{HELD/BREACHED/ABSENT}} | {{DETAIL}} |
| 8 | Health Checks | {{HELD/BREACHED/ABSENT}} | {{DETAIL}} |
| 9 | Monitoring/Alerting | {{HELD/BREACHED/ABSENT}} | {{DETAIL}} |
| 10 | Graceful Degradation | {{HELD/BREACHED/ABSENT}} | {{DETAIL}} |
| 11 | Runbook | {{HELD/BREACHED/ABSENT}} | {{DETAIL}} |
| 12 | Rollback Capability | {{HELD/BREACHED/ABSENT}} | {{DETAIL}} |

---

## 10. Classification

| Question | Answer |
|----------|--------|
| In Our Control? | {{IN_CONTROL / PARTIAL_CONTROL / EXTERNAL}} |
| Issue Type | {{BUG / SYSTEMIC / CONFIGURATION / PROCESS / DATA / LATENT}} |
| Cynefin Domain | {{CLEAR / COMPLICATED / COMPLEX / CHAOTIC}} |
| Error Category | {{From error-taxonomy skill}} |
| Recurring? | {{YES (N times since DATE) / NO}} |

---

## 11. Code Investigation Findings

### Error Origin

| Field | Value |
|-------|-------|
| Service | {{serviceName slug}} |
| configLabel | {{exact configLabel from ELK}} |
| Commit SHA | {{from Artifactory resolution}} |
| Source Repo | {{from service_mappings.json}} |
| File | {{FILE_PATH}} |
| Line | {{LINE_NUMBER}} |
| Method | {{METHOD_NAME}} |
| Layer | {{DOMAIN / APPLICATION / INFRASTRUCTURE / ADAPTER}} |
| PR | {{#NUMBER TITLE}} |
| Jira Ticket | {{TICKET_KEY}} |

### Suspicious Commits

| SHA | Author | Date | Message | Relevance | Suspicion |
|-----|--------|------|---------|-----------|-----------|
| {{SHA}} | {{AUTHOR}} | {{DATE}} | {{MESSAGE}} | {{direct/indirect}} | {{0.0-1.0}} |

### Configuration Findings

| Config Key | Current Value | Expected | Source |
|------------|--------------|----------|--------|
| {{KEY}} | {{VALUE}} | {{EXPECTED}} | {{configLabel branch in MobileBackOfficeConfig}} |

---

## 12. Recommendations

### Immediate Fix
{{DESCRIPTION}}

**Affected Files**: {{FILE_LIST}}
**Estimated Effort**: {{HOURS/DAYS}}
**Risk of Fix**: {{LOW/MEDIUM/HIGH}}

### Graceful Handling (if external)
{{DEGRADATION_STRATEGY}}

### Prevention Plan

| Timeframe | Action | Owner Role | Impact |
|-----------|--------|-----------|--------|
| This Sprint | {{ACTION}} | {{ROLE}} | {{HIGH/MED/LOW}} |
| This Quarter | {{ACTION}} | {{ROLE}} | {{HIGH/MED/LOW}} |
| Long-term | {{ACTION}} | {{ROLE}} | {{HIGH/MED/LOW}} |

---

## 13. Jira Tickets

| # | Title | Type | Priority | Points |
|---|-------|------|----------|--------|
| 1 | {{TITLE}} | {{BUG/STORY/TASK}} | {{P1-P4}} | {{SP}} |

---

## 14. ACH Matrix — Hypothesis Elimination (Tier 2+)

| Hypothesis | Contradictions | Supports | Weighted Score | Rank |
|------------|---------------|----------|---------------|------|
| {{H1 — Five Whys root cause}} | {{N}} | {{N}} | {{SCORE}} | {{1}} |
| {{H2 — Alternative}} | {{N}} | {{N}} | {{SCORE}} | {{2}} |
| {{H3 — Wild card}} | {{N}} | {{N}} | {{SCORE}} | {{3}} |

**Winning Hypothesis**: {{WINNING}}
**Gap Strength**: {{CLEAR / STRONG / MODERATE / WEAK / TOO_CLOSE}}
**Five Whys Agreement**: {{REINFORCED / DIVERGENT / INSUFFICIENT}}

**Diagnostic Evidence** (items that distinguish hypotheses):

| Evidence | Distinguishes | Pivotal? |
|----------|--------------|----------|
| {{EVIDENCE}} | {{HOW_IT_DIFFERENTIATES}} | {{YES/NO}} |

---

## 15. Adversarial Critique Audit (Tier 2+)

### Devil's Advocate

**Challenge Strength**: {{WEAK / MODERATE / STRONG / DEVASTATING}}
**Strongest Counter-Case**: {{DESCRIPTION}}
**Falsification Criteria**: {{WHAT_WOULD_DISPROVE_ROOT_CAUSE}}

### Evidence Audit

**Overall Grade**: {{A / B / C / D / F}}
**Evidence Coverage**: {{(A+B) / total claims}}
**Critical Gaps**: {{LIST}}

### Framework Completeness

**Verdict**: {{COMPLETE / MINOR_GAPS / SIGNIFICANT_GAPS / INCOMPLETE}}
**Cross-Framework Consistency**: {{CONSISTENT / MINOR_INCONSISTENCIES / MAJOR_CONTRADICTIONS}}

### Meta-Review Decision

| Metric | Value |
|--------|-------|
| Decision | {{ACCEPT / ACCEPT_WITH_CAVEATS / REVISE / REJECT}} |
| Composite Confidence | {{0.00-1.00}} |
| Revision Cycles | {{0-3}} |
| Convergent Issues | {{COUNT}} |

**Decision Rationale**: {{WHY_THIS_DECISION}}

### Confidence & Limitations

| Field | Value |
|-------|-------|
| Key Assumptions | {{LIST}} |
| Evidence Gaps | {{LIST — what we couldn't check}} |
| Alternative Hypotheses | {{NOT YET ELIMINATED}} |
| Human Review Required | {{YES/NO — always YES for P1/P2}} |
| Suggested Verification Steps | {{LIST — what an engineer should check}} |

---

## 16. Effectiveness Planning (Tier 3)

| Checkpoint | Date | Criteria | Owner |
|------------|------|----------|-------|
| 1 Week Post-Fix | {{DATE}} | {{MEASURABLE_CRITERIA}} | {{ROLE}} |
| 1 Month Post-Fix | {{DATE}} | {{MEASURABLE_CRITERIA}} | {{ROLE}} |
| 1 Quarter Post-Fix | {{DATE}} | {{MEASURABLE_CRITERIA}} | {{ROLE}} |

**Recurrence Escalation**: If same incident recurs → auto-escalate to Tier 3 RCA, flag as recurring.

---

## Appendix A: Raw Evidence

### Lessons Learned

> **A separate lessons-learned file has been generated alongside this RCA.**
> See: [`{{LESSONS_LEARNED_FILENAME}}`]({{LESSONS_LEARNED_FILENAME}})
>
> That file contains generic, ecosystem-wide lessons extracted from this incident's
> defense gaps, detection gaps, process gaps, architecture gaps, and knowledge gaps.
> **Share it with engineering leadership for feedback and prioritization.**

---

## Appendix B: Raw Evidence

### Key Log Entries
```json
{{RELEVANT_LOG_ENTRIES — include @timestamp, serviceName, configLabel, level, LogEventMessage}}
```

### Key Code Snippets
```java
// {{REPO}}:{{FILE}}:{{LINE}} (configLabel: {{VERSION}})
{{CODE_SNIPPET}}
```

### ELK Queries Used
```bash
{{LIST_OF_ELK_QUERIES_EXECUTED}}
```
