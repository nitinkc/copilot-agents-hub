# Lessons Learned — {{INCIDENT_ID}}

> **Generated**: {{TIMESTAMP}}  
> **Source RCA**: [{{RCA_FILENAME}}](../../docs/generated/rca/{{RCA_FILENAME}})  
> **Service**: {{SERVICE_SLUG}} | **Severity**: {{SEVERITY}} | **Root Cause Category**: {{ISHIKAWA_PRIMARY}}

---

> **To leadership**: Review these lessons and provide feedback on prioritization
> and organizational applicability. Each lesson is generic — it applies beyond
> this specific incident to any service in the ecosystem. Mark lessons as
> ACCEPTED / MODIFIED / DEFERRED with your rationale.

---

## How to read this document

Each lesson follows the same structure:
- **What we learned** — the generic principle (not incident-specific)
- **Why it matters** — the systemic risk if unaddressed
- **Where to change** — the specific files, configs, processes, or practices to update
- **How to change** — concrete, actionable steps (not aspirational statements)
- **Effort** — T-shirt size (S/M/L/XL)
- **Risk if deferred** — what happens if we don't act

---

## Lesson Categories

Categories A–E are **incident lessons** (about the production system).
Category F is an **agent self-reflection** (about the investigation process itself).
Both types are required for every investigation.

### A. Defense Gaps — Barriers That Were Absent or Breached

> Extract from Swiss Cheese analysis (Section 9 of RCA). Each BREACHED or ABSENT
> barrier becomes a lesson about strengthening that defense layer generically.

#### Lesson A1: {{BARRIER_NAME}}

| Field | Value |
|-------|-------|
| **What we learned** | {{Generic principle about this defense layer — NOT incident-specific}} |
| **Why it matters** | {{Systemic risk: what class of incidents does this barrier prevent?}} |
| **Where to change** | {{Specific locations: repo patterns, config, CI pipeline, process docs}} |
| **How to change** | {{Concrete steps: add guard test, add circuit breaker config, update runbook, etc.}} |
| **Effort** | {{S / M / L / XL}} |
| **Risk if deferred** | {{What future incidents become possible if this barrier stays absent?}} |

> *Repeat Lesson A2, A3, ... for each BREACHED/ABSENT barrier.*

---

### B. Detection Gaps — Why We Didn't Catch It Sooner

> Extract from FMEA Detection score (Section 7) and Detection Gap (Section 2).
> Focus on generic monitoring, alerting, and observability improvements.

#### Lesson B1: {{DETECTION_GAP}}

| Field | Value |
|-------|-------|
| **What we learned** | {{Generic principle about detection/alerting — NOT incident-specific}} |
| **Why it matters** | {{What is the cost of delayed detection for this class of error?}} |
| **Where to change** | {{Alert rules, dashboards, health checks, log patterns}} |
| **How to change** | {{Add alert for X metric exceeding Y threshold, add dashboard panel, etc.}} |
| **Effort** | {{S / M / L / XL}} |
| **Risk if deferred** | {{How long will similar incidents go undetected?}} |

---

### C. Process Gaps — What the Workflow Got Wrong

> Extract from Ishikawa Process dimension, Cynefin classification, and
> Prevention Plan. Focus on CI/CD, review, deployment, and operational processes.

#### Lesson C1: {{PROCESS_GAP}}

| Field | Value |
|-------|-------|
| **What we learned** | {{Generic principle about the process — NOT incident-specific}} |
| **Why it matters** | {{What class of defects does this process gap allow through?}} |
| **Where to change** | {{CI pipeline, review checklist, deployment procedure, runbook}} |
| **How to change** | {{Add pipeline stage, update checklist, change deployment order, etc.}} |
| **Effort** | {{S / M / L / XL}} |
| **Risk if deferred** | {{Likelihood and impact of recurrence without process change}} |

---

### D. Architecture / Design Gaps — Structural Weaknesses

> Extract from Fault Tree (single points of failure, minimal cut sets),
> Ishikawa Technology/Design dimensions, and Cynefin complexity classification.

#### Lesson D1: {{ARCHITECTURE_GAP}}

| Field | Value |
|-------|-------|
| **What we learned** | {{Generic architectural principle — NOT incident-specific}} |
| **Why it matters** | {{What systemic risk does this structural weakness create?}} |
| **Where to change** | {{Service boundaries, dependency patterns, data flow, config architecture}} |
| **How to change** | {{Decouple X from Y, add bulkhead, change data flow, add idempotency, etc.}} |
| **Effort** | {{S / M / L / XL}} |
| **Risk if deferred** | {{What class of cascading failures remains possible?}} |

---

### E. Knowledge / Testing Gaps — What We Didn't Know or Verify

> Extract from Evidence Gaps (Section 15), Human Review items (Section 7),
> and test coverage analysis from code forensics.

#### Lesson E1: {{KNOWLEDGE_GAP}}

| Field | Value |
|-------|-------|
| **What we learned** | {{Generic principle about testing or knowledge capture — NOT incident-specific}} |
| **Why it matters** | {{What risk accumulates when this knowledge is missing?}} |
| **Where to change** | {{Test suites, documentation, onboarding, knowledge base}} |
| **How to change** | {{Add integration test for X, document Y invariant, add to runbook, etc.}} |
| **Effort** | {{S / M / L / XL}} |
| **Risk if deferred** | {{How does this gap compound over time?}} |

---

### F. Agent & Tooling Optimization — How Our Investigation Process Can Improve

> Self-reflection on the investigation session itself. What did the agent do well,
> what was wasteful, what skills/scripts/queries need enhancement, and what process
> changes would make EVERY future investigation faster and more accurate?
>
> These lessons apply to the agent framework, skills, scripts, and investigation
> workflow — not to the production system being investigated.

#### Lesson F1: {{AGENT_OPTIMIZATION}}

| Field | Value |
|-------|-------|
| **What we learned** | {{Generic principle about investigation process — applies to ALL future investigations}} |
| **Why it matters** | {{What time/accuracy/context is wasted when this isn't addressed?}} |
| **Where to change** | {{Agent file, skill SKILL.md, script, template, FIELD-REFERENCE, INVESTIGATION-BRAIN, etc.}} |
| **How to change** | {{Add rule to skill, fix script, add query template, change phase ordering, etc.}} |
| **Effort** | {{S / M / L / XL}} |
| **Risk if deferred** | {{How does this gap repeat in every future investigation?}} |

> *Repeat Lesson F2, F3, ... for each investigation process improvement.*

**Mandatory self-reflection prompts** (answer ALL — skip none):

| # | Prompt | Answer |
|---|--------|--------|
| 1 | Which ELK queries returned zero useful results? Why? What would have been better? | {{answer}} |
| 2 | Which phase consumed the most context/time? Was it justified or wasteful? | {{answer}} |
| 3 | What information did we need but couldn't get? What tool/script/access gap blocked us? | {{answer}} |
| 4 | What information did we gather but never use? Could we have skipped it? | {{answer}} |
| 5 | Did any skill or script fail or produce unexpected results? What fix is needed? | {{answer}} |
| 6 | Were any phases executed out of order, skipped, or repeated unnecessarily? | {{answer}} |
| 7 | What query pattern or investigation shortcut would have saved time if it existed as a template? | {{answer}} |
| 8 | Did the agent present conclusions prematurely (before Phase 7)? Did it waste context on verbose output? | {{answer}} |
| 9 | What was the hardest evidence to obtain? How could the tooling make it easier next time? | {{answer}} |
| 10 | If you could change ONE thing about the agent/skill/script framework based on this session, what would it be? | {{answer}} |

---

## Summary — Prioritized Action List

| Priority | Lesson | Category | Effort | Impact | Owner Role |
|----------|--------|----------|--------|--------|------------|
| 1 | {{LESSON_ID}} | {{A/B/C/D/E/F}} | {{S/M/L/XL}} | {{HIGH/MED/LOW}} | {{Engineering / Platform / QA / Ops / Agent-Maintainer}} |
| 2 | {{LESSON_ID}} | {{A/B/C/D/E/F}} | {{S/M/L/XL}} | {{HIGH/MED/LOW}} | {{Role}} |
| ... | ... | ... | ... | ... | ... |

---

## Leadership Review

> **Action required**: Review each lesson and mark your decision.

| Lesson | Decision | Rationale | Target Date |
|--------|----------|-----------|-------------|
| {{LESSON_ID}} | {{ACCEPTED / MODIFIED / DEFERRED}} | {{Why}} | {{Sprint/Quarter}} |

---

## Cross-Applicability Check

> For each lesson, state which OTHER services or teams this lesson applies to.
> This turns a single incident into ecosystem-wide improvement.

| Lesson | Applies to services | Applies to teams/agents | Already addressed? |
|--------|-------------------|------------------------|-------------------|
| {{LESSON_ID}} | {{Service patterns: all wkfl-*, all gateway-*, etc. — or "All future investigations" for Cat F}} | {{Teams — or specific agent/skill files for Cat F}} | {{YES (where) / NO}} |

---

> **Share this file with engineering leadership for feedback and prioritization.**
> Lessons are generic and apply ecosystem-wide — they are NOT limited to {{SERVICE_SLUG}}.
