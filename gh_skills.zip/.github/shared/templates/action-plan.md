# Action Plan — {{INCIDENT_ID}}

> **Generated**: {{TIMESTAMP}}
> **Root Cause**: {{ONE_LINE_ROOT_CAUSE}}
> **Classification**: {{IN_CONTROL / PARTIAL_CONTROL / EXTERNAL}}

---

## Immediate Actions (Today)

### Action 1: {{TITLE}}
- **Description**: {{WHAT_TO_DO}}
- **Owner Role**: {{ROLE}}
- **Affected Service(s)**: {{serviceName slugs}}
- **Affected Files**: {{FILE_LIST with repo name}}
- **Code Suggestion**:
```java
// {{FILE}}:{{LINE}}
{{PSEUDOCODE_OR_DIFF}}
```
- **Risk of Fix**: {{LOW/MEDIUM/HIGH}}
- **Estimated Effort**: {{HOURS}}
- **Acceptance Criteria**:
  - [ ] {{CRITERION_1}}
  - [ ] {{CRITERION_2}}

---

## Graceful Handling Strategy (if EXTERNAL or PARTIAL_CONTROL)

### Pattern: {{CIRCUIT_BREAKER / FALLBACK / CACHE / RETRY_WITH_BACKOFF / BULKHEAD / GRACEFUL_REJECT}}

**Current State**: {{What we have now}}
**Recommended State**: {{What we should have}}

**Configuration Change** (in MobileBackOfficeConfig, configLabel branch):
```yaml
# application.yml
{{CONFIG_YAML}}
```

**Code Change**:
```java
// {{FILE}}
{{CODE_SNIPPET}}
```

---

## Regression Prevention

### New Tests Required

| Type | Description | Service | Priority |
|------|-------------|---------|----------|
| Unit Test | {{DESCRIPTION}} | {{SERVICE}} | {{HIGH/MED}} |
| Integration Test | {{DESCRIPTION}} | {{SERVICE}} | {{HIGH/MED}} |
| Guard Test (ArchUnit) | {{DESCRIPTION}} | {{SERVICE}} | {{MED}} |

### Monitoring Enhancements

| Enhancement | Description | Service |
|-------------|-------------|---------|
| New Alert | {{ALERT_RULE}} | {{SERVICE}} |
| Dashboard Update | {{METRIC/PANEL}} | {{SERVICE}} |
| Log Enhancement | {{WHAT TO LOG — structured field}} | {{SERVICE}} |

---

## Prevention Plan

### Short-term (This Sprint)
1. {{ACTION}} — Owner: {{ROLE}} — Impact: {{HIGH/MED/LOW}}

### Medium-term (This Quarter)
1. {{ACTION}} — Owner: {{ROLE}} — Impact: {{HIGH/MED/LOW}}

### Long-term (Architectural)
1. {{ACTION}} — Owner: {{ROLE}} — Impact: {{HIGH/MED/LOW}}

---

## Jira Tickets to Create

### Ticket 1: {{TITLE}}
- **Type**: {{Bug / Story / Task / Spike}}
- **Priority**: {{P1-Critical / P2-High / P3-Medium / P4-Low}}
- **Severity**: {{S1-Blocker / S2-Critical / S3-Major / S4-Minor}}
- **Components**: {{COMPONENT_LIST}}
- **Labels**: `rca`, `{{INCIDENT_ID}}`, `{{ERROR_CATEGORY}}`
- **Story Points**: {{ESTIMATE}}
- **Description**:
  > {{JIRA_DESCRIPTION — include root cause, evidence, and fix approach}}
- **Acceptance Criteria**:
  - [ ] {{CRITERION}}

---

## Next Steps Checklist

- [ ] {{IMMEDIATE_FIX}} — **IMMEDIATE**
- [ ] {{REGRESSION_TESTS}} — **TODAY**
- [ ] {{MONITORING_ENHANCEMENT}} — **THIS SPRINT**
- [ ] {{ARCHITECTURE_IMPROVEMENT}} — **THIS QUARTER**
- [ ] Schedule post-incident review meeting
- [ ] Share RCA report with stakeholders
- [ ] Update runbook with learnings
- [ ] Verify fix in lower env before prod deploy
