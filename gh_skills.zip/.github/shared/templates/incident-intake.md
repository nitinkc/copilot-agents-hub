# Incident Intake Record

> **Intake Time**: {{TIMESTAMP}}
> **Reported By**: {{REPORTER — user / alert / monitoring / Jira ticket}}

## Signal

| Field | Value |
|-------|-------|
| Signal Type | {{error_message / alert / user_report / log_snippet / Jira ticket}} |
| Raw Signal | {{THE_ORIGINAL_ERROR_OR_ALERT}} |

## Extracted Identifiers

| Identifier | Value | Source |
|------------|-------|--------|
| GlobalTrackingId | {{VALUE or N/A}} | {{ELK log / header / alert}} |
| ThreadContextId | {{VALUE or N/A}} | |
| SessionId | {{VALUE or N/A}} | |
| OrderId | {{VALUE or N/A}} | |
| Account Number | {{VALUE or N/A}} | |
| configLabel | {{VALUE or N/A}} | {{ELK configLabel field}} |
| Jira Ticket | {{VALUE or N/A}} | |

## Scope

| Field | Value |
|-------|-------|
| Primary Service | {{serviceName slug}} |
| configLabel | {{exact build version}} |
| Environment | {{mbosProd / mbosStage / mbosQa / mbosPreprod}} |
| Datacenter(s) | {{wc-g2, po-g2, as-g7, etc.}} |
| SalesChannel | {{WEB / TELESALES / RETAIL / XFINITY_APP / ALL}} |
| TenantId | {{POSTPAID / PREPAID / TRIAL / ALL}} |
| Time Window Start | {{ISO8601}} |
| Time Window End | {{ISO8601}} |
| Investigation Scope | {{single-service / multi-service / platform-wide}} |

## Initial Triage

| Field | Value |
|-------|-------|
| Error Category | {{FROM error-taxonomy SKILL}} |
| Error Subcategory | {{FROM error-taxonomy SKILL}} |
| Initial Severity | {{P1-Critical / P2-High / P3-Medium / P4-Low}} |
| Customer-Facing | {{YES / NO / UNKNOWN}} |
| Requires Immediate Action | {{YES / NO}} |
| FMEA Quick Score | S={{N}} × O={{N}} × D={{N}} = RPN {{N}} |

## Notes

{{Additional context from reporter, related incidents, recent deployments, etc.}}
