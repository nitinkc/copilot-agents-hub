#!/usr/bin/env bash
# _gh-lib.sh — Minimal shared helpers for shell scripts
# Source this file; do not execute directly.

log()  { echo "[INFO]  $*" >&2; }
warn() { echo "[WARN]  $*" >&2; }
err()  { echo "[ERROR] $*" >&2; }

require_tools() {
  for cmd in "$@"; do
    command -v "$cmd" >/dev/null 2>&1 || { err "Required tool not found: $cmd"; exit 1; }
  done
}
