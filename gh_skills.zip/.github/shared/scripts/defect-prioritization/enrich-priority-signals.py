"""
Enrichment pass for priority signal files.
This script performs ADDITIVE enrichment on top of build-signals-with-tableau.py output.
It does NOT replace the base insights/actions from Step 3a — it MERGES additional
analysis that requires cross-ticket scoring (tier rebalancing, dependency chains,
assignee load analysis).

The LLM semantic enrichment (Step 3b in the prompt) is expected to FURTHER enrich
after this script runs, adding bespoke insights from reading actual ticket comments.
"""
import json, glob, os, re, csv
from datetime import datetime, timezone
from collections import defaultdict, Counter

DETAIL_ROOT = '/tmp/priority-details'
SIGNAL_ROOT = '/tmp/priority-signals'
EPIC_TICKETS_PATH = '/tmp/epic-tickets.json'
FALLOUT_CSV = '/tmp/fallout-full.csv'
NOW = datetime.now(timezone.utc)

PRIORITY_POINTS = {'critical': 50, 'highest': 40, 'high': 30, 'medium': 10, 'low': 2}
STATUS_POINTS = {'blocked': 25, 'in progress': 15, 'not started': 5, 'test': 3, 'in test': 3}
INC_RE = re.compile(r'\b(?:CAS\d+|INC\d+|CHG\d+)\b', re.I)

# ─── Board → APP mapping (same as build-signals-with-tableau.py) ───
APP_BOARD_MAP = {
    "BPM_LEAN_ORCHESTRATOR": "cmxot2",
    "BPM_BILLING_ORDER": "cmxotb",
    "BPM_OTT_FULFILLMENT": "cmxotf",
    "BPM_PROVISION": "cmxotp",
    "BPM_FULFILLMENT": "cmxotos",
    "BPM_CONDOR": "cmxotr",
    "BPM_CANCEL_ORDER": "cmxotr",
    "CONVERGENCE": "cmxotr",
    "BPM_ASCNDN_BILLING_ORDER": "cmxotb",
    "BPM_PREPAID_BILLING_ORDER": "cmxotb",
    "BPM_HARDGOODS_FULFILLMENT": "cmxotos",
    "BPM_RECON": "cmxotr",
    "BPM_TRADEIN": "cmxotos",
    "BPM_CREDIT_CHECK": "cmxotp",
    "MDUCB": "cmxotp",
}


def parse_dt(s):
    if not s:
        return None
    s = s.replace('Z', '+00:00')
    try:
        return datetime.fromisoformat(s)
    except Exception:
        return None


def days_since(ts):
    dt = parse_dt(ts)
    if not dt:
        return 0
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return max(0, int((NOW - dt).total_seconds() // 86400))


def extract_cluster(summary):
    """Extract (service, activity, error) from ticket summary.
    Handles common OrderTech formats:
      - "WkflLeanOrchestrator | checkAmdocsOrderStatusTask | IllegalArgumentException"
      - "WkflLeanOrchestrator | checkAmdocsOrderStatusTask"
      - "WkflBillingOrder | createBillerOrder / HTTP 502"
    """
    parts = [p.strip() for p in (summary or '').split('|')]
    if len(parts) >= 3:
        service = parts[0]
        activity = parts[1].split('/')[0].strip() if '/' in parts[1] else parts[1]
        err = parts[2]
        return service, activity, err
    if len(parts) == 2:
        service = parts[0]
        activity = parts[1].split('/')[0].strip() if '/' in parts[1] else parts[1]
        # Try to extract error from activity part after space
        err_match = re.search(r'\b(\w*Exception|\w*Error|NPE|HTTP\s*\d{3}|timeout)\b', parts[1], re.I)
        err = err_match.group(1) if err_match else ''
        return service, activity, err
    # Fallback: try to extract BPM task name from anywhere in summary
    task_match = re.search(r'\b([a-z][A-Za-z]+(?:Task|Activity))\b', summary or '')
    if task_match:
        return '', task_match.group(1), ''
    return '', summary[:40] if summary else 'unknown', ''


def status_points(status):
    s = (status or '').lower()
    for k, v in STATUS_POINTS.items():
        if k in s:
            return v
    return 0


def age_points(days):
    if days > 365:
        return 20
    if days > 180:
        return 15
    if days > 90:
        return 10
    if days > 60:
        return 7
    if days > 30:
        return 4
    return 1


def base_tier(score):
    if score >= 38:
        return 1
    if score >= 30:
        return 2
    if score >= 25:
        return 3
    if score >= 20:
        return 4
    return 5


def owner_name(t):
    return t.get('assignee') or 'Unassigned'


def ticket_text_blob(t):
    comments = t.get('recent_comments') or []
    comment_text = ' '.join(str(c.get('body', '')) for c in comments if isinstance(c, dict))
    linked = ' '.join(f"{x.get('key', '')} {x.get('summary', '')}" for x in (t.get('linked_issues') or []))
    return ' '.join([str(t.get('summary', '')), str(t.get('description', '')), comment_text, linked])


def load_epic_keys_by_board():
    with open(EPIC_TICKETS_PATH, encoding="utf-8") as _f:
        data = json.load(_f)
    out = defaultdict(set)
    for t in data:
        prefix = (t.get('prefix') or '').lower()
        key = t.get('key')
        if prefix and key:
            out[prefix].add(key)
    return out


def load_fallout_by_board():
    """Load fallout CSV and aggregate by board for tier boosting."""
    fallout_by_board = defaultdict(lambda: defaultdict(int))  # board → activity → count
    if not os.path.exists(FALLOUT_CSV):
        return fallout_by_board
    with open(FALLOUT_CSV, encoding="utf-8") as f:
        for row in csv.DictReader(f):
            app = row.get('APP', '')
            act = row.get('ACTIVITY_ID', '')
            board = APP_BOARD_MAP.get(app, '')
            if board and act:
                fallout_by_board[board][act.lower()] += 1
    return fallout_by_board


def board_tickets(board, allowed_keys):
    tickets = []
    seen = set()
    for fp in sorted(glob.glob(os.path.join(DETAIL_ROOT, board, '*.json'))):
        with open(fp, encoding="utf-8") as _fh:
            d = json.load(_fh)
        for t in d.get('tickets', []):
            key = t.get('key')
            if not key or key in seen or key not in allowed_keys:
                continue
            seen.add(key)
            tickets.append(t)
    return tickets


def action_text(meta, fallout_activity_counts):
    """Generate specific action text using actual ticket details."""
    owner = meta['assignee']
    key = meta['key']

    # Incident-linked: use actual incident ID
    if meta['incidents']:
        inc_str = ', '.join(sorted(meta['incidents'])[:2])
        return (f"Incident-linked ({inc_str}) — {owner} to post ETA and mitigation update today. "
                f"Context: {meta['activity']}")

    # Blocked: include what's actually blocked and how long
    if meta['blocked']:
        age_note = f" ({meta['age_days']}d old)" if meta['age_days'] > 30 else ""
        return (f"Blocked{age_note} — {owner} to document specific blocking dependency "
                f"for {meta['activity']} or recommend cancellation.")

    # Stalled with details
    if meta['stalled_days'] >= 30:
        return (f"De-facto stalled ({meta['stalled_days']}d since last update) — "
                f"{owner} to provide progress update on {meta['activity']} or "
                f"move to Not Started for reassignment.")

    # Unassigned with fallout correlation
    if meta['unassigned']:
        activity_lower = meta['activity'].lower()
        fallout_count = fallout_activity_counts.get(activity_lower, 0)
        if fallout_count > 0:
            return (f"Unassigned with {fallout_count} active fallout events at {meta['activity']}. "
                    f"Assign owner and set target date this week.")
        return (f"Unassigned — {meta['priority']} priority, {meta['activity']}. "
                f"Assign DRI in standup.")

    # T3 cluster member with activity detail
    if meta.get('is_cluster_member'):
        return (f"Cluster member ({meta['activity']}) — {owner} to verify against "
                f"representative fix before closure.")

    # Fallout-boosted ticket
    activity_lower = meta['activity'].lower()
    fallout_count = fallout_activity_counts.get(activity_lower, 0)
    if fallout_count >= 5:
        return (f"Active fallout ({fallout_count} events at {meta['activity']}) — "
                f"{owner} to prioritize or escalate. Error: {meta['error'][:60]}")

    return f"Track progress on {meta['activity']} — {owner} to update status by end of week."


def urgency_for(meta):
    if meta.get('incidents'):
        return 'immediate'
    if meta['tier'] == 1:
        return 'immediate'
    if meta['blocked']:
        return 'escalate'
    if meta['tier'] == 2:
        return 'today'
    if meta['tier'] == 3 and meta['stalled_days'] >= 30:
        return 'follow-up'
    if meta['tier'] == 3:
        return 'triage'
    return 'queue'


def action_color(meta):
    if meta.get('incidents') or meta['tier'] == 1:
        return 'red'
    if meta['blocked'] or meta['tier'] == 2:
        return 'orange'
    if meta['stalled_days'] >= 30:
        return 'purple'
    if meta['tier'] == 3:
        return 'green'
    return 'gray'


def enrich_board(board, allowed_keys, fallout_activity_counts):
    signal_path = os.path.join(SIGNAL_ROOT, f'{board}.json')
    if not os.path.exists(signal_path):
        return None
    with open(signal_path, encoding="utf-8") as _f:
        base = json.load(_f)
    tickets = board_tickets(board, allowed_keys)
    if not tickets:
        return None

    metas = []
    cluster_groups = defaultdict(list)
    status_counts = Counter()
    assignee_counts = Counter()

    for t in tickets:
        key = t.get('key')
        assignee = owner_name(t)
        priority = (t.get('priority') or 'Medium').lower()
        status = t.get('status') or 'Not Started'
        created_days = days_since(t.get('created'))
        updated_days = days_since(t.get('updated'))
        text_blob = ticket_text_blob(t)
        incidents = set(x.upper() for x in INC_RE.findall(text_blob))
        linked = t.get('linked_issues') or []
        blocked = any('block' in (li.get('relationship', '').lower()) or 'depend' in (li.get('relationship', '').lower()) for li in linked)
        unassigned = assignee == 'Unassigned'

        # Base score
        score = PRIORITY_POINTS.get(priority, 10) + status_points(status) + age_points(created_days)
        if unassigned:
            score -= 5
        if incidents:
            score += 12
        if blocked:
            score += 8
        if updated_days >= 30:
            score += 6

        # Fallout boost: check if ticket's activity has active production fallout
        service, activity, err = extract_cluster(t.get('summary', ''))
        activity_lower = activity.lower()
        fallout_count = fallout_activity_counts.get(activity_lower, 0)
        if fallout_count >= 50:
            score += 15
        elif fallout_count >= 20:
            score += 10
        elif fallout_count >= 5:
            score += 5

        tier = base_tier(score)
        cluster_key = f"{service}::{activity}" if service else activity

        cluster_groups[cluster_key].append(key)

        meta = {
            'key': key,
            'summary': t.get('summary', ''),
            'status': status,
            'priority': t.get('priority') or 'Medium',
            'assignee': assignee,
            'age_days': created_days,
            'stalled_days': updated_days,
            'incidents': incidents,
            'blocked': blocked,
            'unassigned': unassigned,
            'tier': tier,
            'score': score,
            'cluster_key': cluster_key,
            'activity': activity,
            'error': err,
            'service': service,
            'fallout_count': fallout_count,
            'is_cluster_member': False,
        }
        metas.append(meta)
        status_counts[status] += 1
        assignee_counts[assignee] += 1

    metas.sort(key=lambda m: (m['score'], m['stalled_days']), reverse=True)

    # Find dominant cluster (exclude trivially-named ones)
    named_clusters = {k: v for k, v in cluster_groups.items()
                      if k and 'unknown' not in k.lower() and len(k) > 3}
    if named_clusters:
        dominant_cluster, dom_members = max(named_clusters.items(), key=lambda kv: len(kv[1]))
    else:
        dominant_cluster, dom_members = max(cluster_groups.items(), key=lambda kv: len(kv[1]))
    dom_count = len(dom_members)

    # Mark cluster members and limit promotion
    dom_sorted = [m for m in metas if m['cluster_key'] == dominant_cluster]
    for idx, m in enumerate(dom_sorted):
        if idx >= 3:
            m['is_cluster_member'] = True
            if m['tier'] < 3:
                m['tier'] = 3

    # Tier cap enforcement
    if len(metas) >= 5:
        t1 = [m for m in metas if m['tier'] == 1]
        if len(t1) > 8:
            for m in t1[8:]:
                m['tier'] = 2
        t2 = [m for m in metas if m['tier'] == 2]
        if len(t2) > 13:
            for m in t2[13:]:
                m['tier'] = 3

    # ─── Build enriched outputs ───
    tier_overrides = {}
    special_flags = {}
    per_ticket_actions = []

    for m in metas:
        reason = []
        if m['incidents']:
            reason.append(f"incident {','.join(sorted(m['incidents'])[:2])}")
        if m['blocked']:
            reason.append('blocked/dependency chain')
        if m['stalled_days'] >= 30:
            reason.append(f"stalled {m['stalled_days']}d")
        if m['fallout_count'] >= 5:
            reason.append(f"active fallout ({m['fallout_count']} events at {m['activity']})")
        if m['is_cluster_member']:
            reason.append('cluster member (kept at T3)')
        if m['unassigned']:
            reason.append('unassigned')
        if not reason:
            reason.append(f"score {m['score']}")

        tier_overrides[m['key']] = [int(m['tier']), '; '.join(reason)]

        # Special flags
        if m['incidents']:
            special_flags[m['key']] = ['sev3', f"Incident-linked: {', '.join(sorted(m['incidents'])[:2])}"]
        elif m['blocked']:
            special_flags[m['key']] = ['blocker', f"Blocked: dependency chain ({m['age_days']}d old)"]
        elif m['stalled_days'] >= 90:
            special_flags[m['key']] = ['stalled', f"No update for {m['stalled_days']}d"]
        elif m['unassigned'] and m['tier'] <= 2:
            special_flags[m['key']] = ['urgent', f"Unassigned {m['priority']} ticket"]
        elif m['tier'] >= 4 and m['age_days'] > 180:
            special_flags[m['key']] = ['cancel', f"Long-lived ({m['age_days']}d), review for cancel"]
        else:
            special_flags[m['key']] = ['info', f"Tier {m['tier']}: {m['activity'][:40]}"]

        # Per-ticket actions for T1/T2/T3
        if m['tier'] in (1, 2, 3):
            per_ticket_actions.append({
                'key': m['key'],
                'tier': int(m['tier']),
                'action': action_text(m, fallout_activity_counts),
                'color': action_color(m)
            })

    # ─── Weekly actions (deduplicated, urgency-ordered) ───
    weekly_actions = []
    seen_keys = set()
    for m in metas:
        if m['tier'] > 3:
            continue
        if m['key'] in seen_keys:
            continue
        if len(weekly_actions) >= 12:
            break
        seen_keys.add(m['key'])
        weekly_actions.append({
            'urgency': urgency_for(m),
            'action': action_text(m, fallout_activity_counts),
            'ticket': m['key'],
            'owner': m['assignee']
        })

    # ─── Insights (ADDITIVE — merged with base) ───
    enriched_insights = []

    # Tier summary
    t1_count = sum(1 for m in metas if m['tier'] == 1)
    t2_count = sum(1 for m in metas if m['tier'] == 2)
    enriched_insights.append(
        f"🚨 <strong>{board.upper()} Focus Set:</strong> {len(metas)} actionable tickets "
        f"analyzed with {t1_count} T1 and {t2_count} T2 candidates after tier rebalancing."
    )

    # Dominant cluster insight (use actual cluster name, not "unknown")
    cluster_display = dominant_cluster.replace('::', ' → ') if '::' in dominant_cluster else dominant_cluster
    if dom_count >= 3:
        enriched_insights.append(
            f"🚨 <strong>{cluster_display} Cluster ({dom_count} tickets):</strong> "
            f"Recurring pattern across {dom_count}/{len(metas)} tickets. "
            f"Top 3 promoted to T1/T2; remaining tracked as T3 cluster members."
        )

    # Top risk tickets with actual detail
    top3 = metas[:3]
    top3_parts = []
    for m in top3:
        detail = f"{m['key']} ({m['assignee']}, {m['stalled_days']}d since update"
        if m['fallout_count'] > 0:
            detail += f", {m['fallout_count']} fallout events"
        detail += ")"
        top3_parts.append(detail)
    enriched_insights.append(f"⚠ <strong>Highest Risk Tickets:</strong> {'; '.join(top3_parts)}.")

    # Stall pressure
    stalled_tickets = [m for m in metas if m['stalled_days'] >= 30]
    if stalled_tickets:
        stalled_names = ', '.join(f"{m['key']} ({m['assignee']})" for m in stalled_tickets[:3])
        enriched_insights.append(
            f"⚠ <strong>Stall Pressure ({len(stalled_tickets)} tickets):</strong> "
            f"{stalled_names} have not been updated for 30+ days."
        )

    # Unassigned
    unassigned_tickets = [m for m in metas if m['unassigned']]
    if unassigned_tickets:
        enriched_insights.append(
            f"⚠ <strong>Ownership Gaps:</strong> {len(unassigned_tickets)} tickets are unassigned "
            f"and require owner assignment during next standup triage."
        )

    # Incident-linked
    incident_tickets = [m for m in metas if m['incidents']]
    if incident_tickets:
        inc_list = sorted({inc for m in incident_tickets for inc in m['incidents']})[:5]
        enriched_insights.append(
            f"🚨 <strong>Incident-Linked ({len(incident_tickets)} tickets):</strong> "
            f"References {', '.join(inc_list)} require same-day status updates."
        )

    # Blocked
    blocked_tickets = [m for m in metas if m['blocked']]
    if blocked_tickets:
        sample = ', '.join(f"{m['key']} ({m['assignee']})" for m in blocked_tickets[:4])
        enriched_insights.append(
            f"⚠ <strong>Blocked Dependencies ({len(blocked_tickets)} tickets):</strong> "
            f"{sample}. Escalate with explicit unblock owners."
        )

    # ─── MERGE with base insights (not replace) ───
    # Keep base insights that are from Tableau correlation (fallout-specific)
    base_insights = base.get('insights', [])
    tableau_insights = [i for i in base_insights if 'Fallout' in i or 'fallout' in i or 'No Ticket for' in i]

    # Final insights = enriched tier/risk analysis + base fallout insights
    final_insights = enriched_insights + tableau_insights

    # ─── Assignee callouts ───
    assignee_callouts = []
    for assignee, cnt in assignee_counts.most_common():
        if assignee == 'Unassigned':
            continue
        a_t1 = [m for m in metas if m['assignee'] == assignee and m['tier'] == 1]
        a_stalled = [m for m in metas if m['assignee'] == assignee and m['stalled_days'] >= 30]
        if len(a_t1) >= 2 or (cnt >= 4 and len(a_stalled) >= 1):
            sample = ', '.join(m['key'] for m in (a_t1 + a_stalled)[:3])
            assignee_callouts.append({
                'text': (f"⚠ <strong>{assignee}</strong> has {cnt} tickets with {len(a_t1)} in T1 "
                         f"and {len(a_stalled)} stalled 30+d ({sample}). Rebalance load or confirm ETA."),
                'color': '#6b21a8', 'bg': '#faf5ff'
            })

    if unassigned_tickets:
        sample = ', '.join(m['key'] for m in unassigned_tickets[:4])
        assignee_callouts.append({
            'text': (f"⚠ <strong>Unassigned queue</strong> contains {len(unassigned_tickets)} tickets "
                     f"({sample}). Assign DRI and target date in this sprint."),
            'color': '#b45309', 'bg': '#fffbeb'
        })

    # ─── Workflow insights ───
    workflow_insights = []
    if len(metas) > 0:
        top_status, top_count = status_counts.most_common(1)[0]
        pct = top_count * 100 // len(metas)
        if pct >= 50:
            workflow_insights.append(
                f"{top_count}/{len(metas)} tickets ({pct}%) are in '{top_status}' status; "
                f"triage throughput should prioritize status conversion."
            )
        if dom_count >= 4:
            dom_pct = dom_count * 100 // len(metas)
            workflow_insights.append(
                f"Dominant cluster '{cluster_display}' represents {dom_pct}% of this board; "
                f"fix-at-source is higher leverage than ticket-by-ticket handling."
            )
        if blocked_tickets:
            workflow_insights.append(
                f"Dependency-linked tickets: {len(blocked_tickets)}. "
                f"Add explicit unblock owners and dates in weekly review notes."
            )

    # ─── Assemble final signal file (MERGE, not replace) ───
    enriched = {
        'tier_overrides': tier_overrides,
        'special_flags': special_flags,
        'insights': final_insights,
        'per_ticket_actions': per_ticket_actions,
        'weekly_actions': weekly_actions,
        # Preserve from base (Step 3a output):
        'extra_stats': base.get('extra_stats', []),
        'assignee_callouts': assignee_callouts,
        'workflow_insights': workflow_insights,
        'tableau_section': base.get('tableau_section', ''),
    }

    with open(signal_path, 'w', encoding="utf-8") as f:
        json.dump(enriched, f, indent=2)

    return {
        'board': board,
        'tickets': len(metas),
        'insights': len(final_insights),
        'weekly': len(weekly_actions),
        'actions': len(per_ticket_actions),
        't1': t1_count,
        't2': t2_count,
        't3': sum(1 for m in metas if m['tier'] == 3),
    }


# ─── Main ───
boards = sorted([os.path.splitext(os.path.basename(p))[0]
                 for p in glob.glob(os.path.join(SIGNAL_ROOT, '*.json'))])
epic_keys = load_epic_keys_by_board()
fallout_by_board = load_fallout_by_board()

results = []
for b in boards:
    activity_counts = fallout_by_board.get(b, {})
    r = enrich_board(b, epic_keys.get(b, set()), activity_counts)
    if r:
        results.append(r)

# Validate all signal files parse
for b in boards:
    p = os.path.join(SIGNAL_ROOT, f'{b}.json')
    with open(p, encoding="utf-8") as _f:
        json.load(_f)

print('Enrichment complete:')
for r in results:
    print(f"  {r['board']}: tickets={r['tickets']} insights={r['insights']} "
          f"weekly={r['weekly']} actions={r['actions']} tiers(T1/T2/T3)={r['t1']}/{r['t2']}/{r['t3']}")
