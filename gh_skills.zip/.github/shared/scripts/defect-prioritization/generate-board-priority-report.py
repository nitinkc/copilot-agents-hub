#!/usr/bin/env python3
"""
generate-board-priority-report.py — Per-board defect prioritization HTML report

Usage:
  python3 .github/shared/scripts/generate-board-priority-report.py \
    --tickets /tmp/epic-tickets.json \
    --board CMXOTR \
    --epic CMXOTD-3181 \
    --output docs/generated/priority/cmxotr-priority-2026-05-01.html

  # Generate for ALL boards at once:
  python3 .github/shared/scripts/generate-board-priority-report.py \
    --tickets /tmp/epic-tickets.json \
    --all-boards \
    --epic CMXOTD-3181 \
    --output-dir docs/generated/priority

  # With manual overrides from enrichment file:
  python3 .github/shared/scripts/generate-board-priority-report.py \
    --tickets /tmp/epic-tickets.json \
    --board CMXOTR \
    --epic CMXOTD-3181 \
    --overrides /tmp/overrides-cmxotr.json \
    --output docs/generated/priority/cmxotr-priority-2026-05-01.html

Override file format (JSON):
  {
    "tier_overrides": { "CMXOTR-3596": [1, "De-facto Blocked — product decision pending"] },
    "special_flags":  { "CMXOTR-2709": ["sev3", "Sev3 INC011330736"] },
    "insights":       ["🚨 Sev3 — CMXOTR-2709: ...", "⏸ Stalled — ..."]
  }
"""

import argparse
import json
import os
import sys
from collections import Counter, defaultdict
from datetime import date, datetime

# ═══════════════════════════════════════════════════════════════════════════════
# Constants
# ═══════════════════════════════════════════════════════════════════════════════

EXCLUDED_STATUSES = ('Canceled', 'Released', 'Resolved', 'Closed', 'Accepted')

PRIO_SCORE = {'Critical': 50, 'Highest': 40, 'High': 30, 'Medium': 10, 'Low': 2, 'None': 0}
STATUS_SCORE = {
    'Blocked': 25, 'In Progress': 15, 'Accepted': 10,
    'Not Started': 5, 'Test': 3, 'Resolved': -50,
    'Canceled': -100, 'Released': -100,
}

TIER_THRESHOLDS = [(38, 1), (30, 2), (25, 3), (20, 4)]  # score >= threshold → tier
DEFAULT_TIER = 5

TIER_LABELS = {
    1: 'T1 · Do Now', 2: 'T2 · Escalate', 3: 'T3 · In Flight',
    4: 'T4 · Monitor', 5: 'T5 · Queue',
}
TIER_COLORS = {
    1: ('#7f1d1d', '#fee2e2'), 2: ('#7c2d12', '#ffedd5'),
    3: ('#1e3a5f', '#dbeeff'), 4: ('#166534', '#dcfce7'),
    5: ('#374151', '#f3f4f6'),
}
TIER_ICONS = {1: '🔴', 2: '🟠', 3: '🟡', 4: '🟢', 5: '⚪'}
TIER_DESCRIPTIONS = {
    1: 'Start, unblock, or make a close decision this sprint. No deferral.',
    2: 'High order count, stalled on external responses, or no triage started. Act this sprint.',
    3: 'Active and progressing — protect momentum.',
    4: 'Near done or low urgency. Confirm closure or queue after T1-T2 clears.',
    5: 'Backlog. Not started, low priority, or no urgency signal.',
}

FLAG_COLORS = {
    'sev3':    ('#7f1d1d', '#fef2f2', '🚨'),
    'blocker': ('#7c2d12', '#fff7ed', '🔴'),
    'blocked': ('#7c2d12', '#fff7ed', '🔴'),
    'cancel':  ('#374151', '#f3f4f6', '🗑'),
    'urgent':  ('#b45309', '#fef9c3', '⚡'),
    'release': ('#166534', '#f0fdf4', '✅'),
    'impact':  ('#1e3a5f', '#eff6ff', '📊'),
    'stalled': ('#6b21a8', '#faf5ff', '⏸'),
    'info':    ('#374151', '#f3f4f6', 'ℹ️'),
}

JIRA_BASE = 'https://tkts.sys.comcast.net'

# Workflow keyword detection (summary-based)
WORKFLOW_PATTERNS = [
    ('PrepaidBillingOrder', 'WkflPrepaidBillingOrder'),
    ('CancelOrder', 'WkflCancelOrder'),
    ('CancelResponseWait', 'WkflCancelOrder'),
    ('FraudReview', 'WkflFraudReview'),
    ('pollPaymentStatus', 'WkflFulfillment'),
    ('WkflFulfillment', 'WkflFulfillment'),
    ('BillingOrder', 'WkflBillingOrder'),
    ('Orchestrator', 'WkflOrchestrator'),
    ('Equipment', 'WkflEquipment'),
    ('Subscriber', 'WkflSubscriber'),
    ('Insurance', 'WkflInsurance'),
    ('Activation', 'WkflActivation'),
    ('ByonDel', 'WkflByonDel'),
    ('Buyflow', 'Buyflow'),
    ('BillerAccount', 'BillerAccount'),
    ('OrderService', 'OrderService'),
    ('CartService', 'CartService'),
]


# ═══════════════════════════════════════════════════════════════════════════════
# Scoring & Classification
# ═══════════════════════════════════════════════════════════════════════════════

def age_score(days):
    if days > 365: return 20
    if days > 180: return 15
    if days > 90:  return 10
    if days > 60:  return 7
    if days > 30:  return 4
    return 1


def detect_workflow(summary):
    for keyword, wf_name in WORKFLOW_PATTERNS:
        if keyword in summary:
            return wf_name
    return 'Other'


def compute_tier(score):
    for threshold, tier in TIER_THRESHOLDS:
        if score >= threshold:
            return tier
    return DEFAULT_TIER


def enrich_tickets(tickets, today, tier_overrides=None, special_flags=None):
    """Add computed fields (age, score, tier, workflow, flags) to each ticket."""
    tier_overrides = tier_overrides or {}
    special_flags = special_flags or {}

    for t in tickets:
        created = datetime.strptime(t['created'], '%Y-%m-%d').date()
        updated = datetime.strptime(t['updated'], '%Y-%m-%d').date()
        t['age_days'] = (today - created).days
        t['updated_days_ago'] = (today - updated).days

        ps = PRIO_SCORE.get(t['priority'], 0)
        ss = STATUS_SCORE.get(t['status'], 0)
        ag = age_score(t['age_days'])
        ua = -5 if t['assignee'] == 'Unassigned' else 0
        t['score'] = ps + ss + ag + ua
        t['workflow'] = detect_workflow(t['summary'])

        if t['key'] in tier_overrides:
            t['tier'] = tier_overrides[t['key']][0]
            t['tier_note'] = tier_overrides[t['key']][1]
        else:
            t['tier'] = compute_tier(t['score'])
            t['tier_note'] = ''

    return tickets


# ═══════════════════════════════════════════════════════════════════════════════
# HTML Badge Helpers
# ═══════════════════════════════════════════════════════════════════════════════

def status_badge(s):
    colors = {
        'In Progress': ('#1a6fb5', '#dbeeff'), 'Blocked': ('#b91c1c', '#fee2e2'),
        'Not Started': ('#6b7280', '#f3f4f6'), 'Test': ('#7c3aed', '#ede9fe'),
    }
    fg, bg = colors.get(s, ('#374151', '#f3f4f6'))
    return f'<span style="background:{bg};color:{fg};padding:2px 8px;border-radius:12px;font-size:11px;font-weight:600;white-space:nowrap">{s}</span>'


def prio_badge(p):
    colors = {
        'Critical': ('#7c2d12', '#fef3c7'), 'Highest': ('#9a3412', '#ffedd5'),
        'High': ('#b45309', '#fef9c3'), 'Medium': ('#1d4ed8', '#dbeafe'),
        'Low': ('#4b5563', '#f3f4f6'),
    }
    fg, bg = colors.get(p, ('#374151', '#f9fafb'))
    return f'<span style="background:{bg};color:{fg};padding:2px 8px;border-radius:12px;font-size:11px;font-weight:600">{p}</span>'


def tier_badge(t):
    fg, bg = TIER_COLORS.get(t, ('#374151', '#f9fafb'))
    label = TIER_LABELS.get(t, f'T{t}')
    return f'<span style="background:{bg};color:{fg};padding:2px 8px;border-radius:12px;font-size:11px;font-weight:700">{label}</span>'


def age_badge(days):
    if days > 300:   bg, fg = '#fca5a5', '#7f1d1d'
    elif days > 180: bg, fg = '#fdba74', '#7c2d12'
    elif days > 90:  bg, fg = '#fde68a', '#78350f'
    elif days > 30:  bg, fg = '#bfdbfe', '#1e3a8a'
    else:            bg, fg = '#f3f4f6', '#374151'
    return f'<span style="background:{bg};color:{fg};padding:2px 6px;border-radius:8px;font-size:11px;font-weight:600">{days}d</span>'


def jira_link(key):
    return f'<a href="{JIRA_BASE}/browse/{key}" target="_blank" style="color:#1a6fb5;font-weight:600;text-decoration:none">{key}</a>'


def flag_badge_html(key, special_flags):
    if key not in special_flags:
        return ''
    ftype, note = special_flags[key]
    fg, bg, icon = FLAG_COLORS.get(ftype, ('#374151', '#f9fafb', '•'))
    return f'<div style="display:inline-block;background:{bg};color:{fg};border-radius:6px;padding:2px 8px;font-size:10px;font-weight:700;margin-top:3px">{icon} {note}</div>'


def tier_note_html(t):
    if not t.get('tier_note'):
        return ''
    return f'<div style="font-size:10px;color:#6b21a8;font-style:italic;margin-top:2px">{t["tier_note"]}</div>'


def stat_box(value, label, color='#1a6fb5', bg='#eff6ff'):
    return f'''<div style="background:{bg};border-radius:10px;padding:18px 22px;text-align:center;min-width:100px">
      <div style="font-size:32px;font-weight:800;color:{color}">{value}</div>
      <div style="font-size:12px;color:#6b7280;margin-top:2px">{label}</div>
    </div>'''


# ═══════════════════════════════════════════════════════════════════════════════
# HTML Section Generators
# ═══════════════════════════════════════════════════════════════════════════════

def gen_tier_rows(tickets, tier_num, special_flags):
    rows = [t for t in tickets if t['tier'] == tier_num]
    if not rows:
        return ''
    html = ''
    for i, t in enumerate(rows):
        alt = 'background:#fafafa' if i % 2 == 0 else 'background:#fff'
        html += f'''
        <tr style="{alt}">
          <td style="padding:10px 8px;font-size:12px;font-weight:700;color:#6b7280;text-align:center">{i+1}</td>
          <td style="padding:10px 8px;white-space:nowrap">{jira_link(t["key"])}<br>{flag_badge_html(t["key"], special_flags)}</td>
          <td style="padding:10px 8px">{status_badge(t["status"])}</td>
          <td style="padding:10px 8px">{prio_badge(t["priority"])}</td>
          <td style="padding:10px 8px;text-align:center">{age_badge(t["age_days"])}</td>
          <td style="padding:10px 8px;font-size:12px;color:#374151">{t.get("assignee","Unassigned")}</td>
          <td style="padding:10px 8px;font-size:12px;color:#1f2937;max-width:380px">{t["summary"]}{tier_note_html(t)}</td>
        </tr>'''
    return html


def gen_tier_section(tickets, tier_num, special_flags, per_ticket_actions=None):
    count = sum(1 for t in tickets if t['tier'] == tier_num)
    fg, bg = TIER_COLORS.get(tier_num, ('#374151', '#f3f4f6'))
    icon = TIER_ICONS.get(tier_num, '⚪')
    label = TIER_LABELS.get(tier_num, f'Tier {tier_num}')
    desc = TIER_DESCRIPTIONS.get(tier_num, '')
    rows = gen_tier_rows(tickets, tier_num, special_flags)
    actions_html = gen_tier_actions(tier_num, per_ticket_actions or [])

    if count == 0:
        empty_msg = f'No {label.split("·")[1].strip()} tickets.'
        return f'''
    <div class="card" style="margin-bottom:24px">
      <div class="tier-header" style="background:{bg};border-left:5px solid {fg}">
        <div style="display:flex;align-items:center;gap:10px">
          <span style="font-size:24px">{icon}</span>
          <div>
            <h2 style="color:{fg};margin:0">{label} (0 tickets)</h2>
            <div style="font-size:12px;color:{fg};margin-top:2px;opacity:.8">{desc}</div>
          </div>
        </div>
      </div>
      <div style="font-size:13px;color:#6b7280;font-style:italic;padding:8px">{empty_msg}</div>
    </div>'''

    return f'''
    <div class="card" style="margin-bottom:24px">
      <div class="tier-header" style="background:{bg};border-left:5px solid {fg}">
        <div style="display:flex;align-items:center;gap:10px">
          <span style="font-size:24px">{icon}</span>
          <div>
            <h2 style="color:{fg};margin:0">{label} ({count} ticket{"s" if count != 1 else ""})</h2>
            <div style="font-size:12px;color:{fg};margin-top:2px;opacity:.8">{desc}</div>
          </div>
        </div>
      </div>
      <div class="overflow-x">
      <table>
        <thead><tr><th>#</th><th>Key</th><th>Status</th><th>Priority</th><th>Age</th><th>Assignee</th><th>Summary / Note</th></tr></thead>
        <tbody>{rows}</tbody>
      </table>
      </div>
{actions_html}
    </div>'''


def gen_assignee_section(actionable, assignee_callouts=None):
    assignee_map = defaultdict(list)
    for t in actionable:
        assignee_map[t['assignee']].append(t)

    rows_html = ''
    for a, ts in sorted(assignee_map.items(), key=lambda x: -len(x[1])):
        sc = Counter(t['status'] for t in ts)
        badges = ' '.join(
            f'<span style="font-size:11px;background:#f3f4f6;padding:1px 6px;border-radius:8px">{s}:{c}</span>'
            for s, c in sorted(sc.items(), key=lambda x: -x[1]))
        flags = []
        if sc.get('In Progress', 0) >= 3:
            flags.append('<span style="color:#b91c1c;font-size:11px;font-weight:700">⚠ 3+ concurrent</span>')
        if sc.get('Blocked', 0) >= 1:
            flags.append('<span style="color:#b91c1c;font-size:11px;font-weight:700">🔴 blocked</span>')
        stalled = [t for t in ts if t.get('tier_note', '').lower().startswith('stalled')]
        if stalled:
            flags.append('<span style="color:#6b21a8;font-size:11px;font-weight:700">⏸ stalled</span>')
        risk = ' &nbsp;'.join(flags) if flags else '<span style="color:#9ca3af;font-size:11px">OK</span>'
        rows_html += f'''
        <tr>
          <td style="padding:9px 10px;font-size:13px;font-weight:600;color:#1f2937">{a}</td>
          <td style="padding:9px 10px;text-align:center;font-weight:700;color:#374151">{len(ts)}</td>
          <td style="padding:9px 10px">{badges}</td>
          <td style="padding:9px 10px">{risk}</td>
        </tr>'''

    callouts_html = gen_assignee_callouts(assignee_callouts)

    return f'''
    <div class="card" style="margin-bottom:24px">
      <h2>Assignee Workload</h2>
      <div class="overflow-x">
      <table>
        <thead><tr><th>Assignee</th><th>Tickets</th><th>Status Mix</th><th>Risk Flag</th></tr></thead>
        <tbody>{rows_html}</tbody>
      </table>
      </div>
{callouts_html}
    </div>'''


def gen_distribution_section(actionable, workflow_insights=None):
    status_counts = Counter(t['status'] for t in actionable)
    prio_counts = Counter(t['priority'] for t in actionable)
    wf_counts = Counter(t['workflow'] for t in actionable)
    n = len(actionable)

    status_bars = ''
    for s, c in sorted(status_counts.items(), key=lambda x: -x[1]):
        pct = c / n * 100 if n else 0
        status_bars += f'''<div style="display:flex;align-items:center;margin-bottom:8px;gap:10px">
          {status_badge(s)}
          <div style="flex:1;background:#e5e7eb;border-radius:4px;height:8px">
            <div style="background:#1a6fb5;width:{pct:.1f}%;height:8px;border-radius:4px"></div>
          </div>
          <span style="font-size:12px;font-weight:700;min-width:20px;text-align:right">{c}</span>
        </div>'''

    prio_bars = ''
    for p, c in sorted(prio_counts.items(), key=lambda x: -x[1]):
        pct = c / n * 100 if n else 0
        prio_bars += f'''<div style="display:flex;align-items:center;margin-bottom:8px;gap:10px">
          {prio_badge(p)}
          <div style="flex:1;background:#e5e7eb;border-radius:4px;height:8px">
            <div style="background:#7c3aed;width:{pct:.1f}%;height:8px;border-radius:4px"></div>
          </div>
          <span style="font-size:12px;font-weight:700;min-width:20px;text-align:right">{c}</span>
        </div>'''

    wf_bars = ''
    wf_colors = ['#1a6fb5', '#7c3aed', '#0f766e', '#b45309', '#6b7280', '#be185d', '#059669', '#dc2626']
    for i, (wf, cnt) in enumerate(sorted(wf_counts.items(), key=lambda x: -x[1])):
        pct = cnt / n * 100 if n else 0
        c = wf_colors[i % len(wf_colors)]
        wf_bars += f'''<div style="margin-bottom:10px">
          <div style="display:flex;justify-content:space-between;margin-bottom:3px">
            <span style="font-size:12px;font-weight:600;color:#374151">{wf}</span>
            <span style="font-size:12px;color:#6b7280">{cnt} ({pct:.0f}%)</span>
          </div>
          <div style="background:#e5e7eb;border-radius:4px;height:8px">
            <div style="background:{c};width:{pct:.1f}%;height:8px;border-radius:4px"></div>
          </div>
        </div>'''

    wf_insight_html = ''
    if workflow_insights:
        for wi in workflow_insights:
            wf_insight_html += f'<div style="margin-top:8px;font-size:12px;color:#6b7280;padding:6px 8px;background:#f8fafc;border-radius:4px">{wi}</div>'

    return f'''
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;margin-bottom:24px">
      <div class="card"><h2>Status Distribution</h2>{status_bars}</div>
      <div class="card"><h2>Priority Distribution</h2>{prio_bars}</div>
      <div class="card"><h2>Workflow Concentration</h2>{wf_bars}{wf_insight_html}</div>
    </div>'''


def gen_raw_data_table(actionable, special_flags):
    rows = ''
    for i, t in enumerate(actionable):
        alt = 'background:#f9fafb' if i % 2 == 0 else 'background:#fff'
        sp_str = str(t.get('sp')) if t.get('sp') else '—'
        note = (f'<div style="font-size:10px;color:#6b21a8;margin-top:2px">{t["tier_note"]}</div>'
                if t.get('tier_note') else '')
        rows += f'''
        <tr style="{alt}">
          <td style="padding:7px 8px;font-size:11px;white-space:nowrap">{jira_link(t["key"])}</td>
          <td style="padding:7px 8px;font-size:11px;max-width:300px">{t["summary"]}{note}</td>
          <td style="padding:7px 8px">{status_badge(t["status"])}</td>
          <td style="padding:7px 8px">{prio_badge(t["priority"])}</td>
          <td style="padding:7px 8px;font-size:11px">{t.get("assignee","Unassigned")}</td>
          <td style="padding:7px 8px;font-size:11px;white-space:nowrap">{t["workflow"]}</td>
          <td style="padding:7px 8px;text-align:center">{age_badge(t["age_days"])}</td>
          <td style="padding:7px 8px;text-align:center;font-size:11px">{t["updated_days_ago"]}d ago</td>
          <td style="padding:7px 8px;text-align:center;font-size:12px;font-weight:700;color:#1a6fb5">{t["score"]}</td>
          <td style="padding:7px 8px">{tier_badge(t["tier"])}</td>
          <td style="padding:7px 8px;text-align:center;font-size:11px">{sp_str}</td>
          <td style="padding:7px 8px;font-size:11px;white-space:nowrap">{t["created"]}</td>
        </tr>'''

    return f'''
    <div class="card" style="margin-bottom:24px">
      <h2>Raw Data — All Actionable Tickets ({len(actionable)})</h2>
      <div style="font-size:12px;color:#6b7280;margin-bottom:12px">
        Sorted by base score descending. Tier column reflects manual overrides where present.
        Excluded: {", ".join(EXCLUDED_STATUSES)}.
      </div>
      <div class="overflow-x">
      <table>
        <thead><tr>
          <th>Key</th><th>Summary</th><th>Status</th><th>Priority</th>
          <th>Assignee</th><th>Workflow</th><th>Age</th><th>Updated</th>
          <th>Score</th><th>Tier</th><th>SP</th><th>Created</th>
        </tr></thead>
        <tbody>{rows}</tbody>
      </table>
      </div>
    </div>'''


def gen_scoring_model():
    return '''
    <div class="card" style="margin-bottom:24px">
      <h2>Scoring Model</h2>
      <div style="font-size:13px;color:#374151;margin-bottom:14px">
        Base score = Priority + Status + Age + Unassigned penalty.
        Manual overrides (from enrichment file) take precedence when ticket content
        reveals blocked/stalled/cancel state not reflected in Jira fields.
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;font-size:13px">
        <div><h3 style="font-size:14px;font-weight:700;color:#374151;margin-bottom:8px">Priority</h3>
          <table style="width:auto"><tbody>
            <tr><td style="padding:4px 8px">Critical</td><td style="padding:4px 8px;font-weight:700;color:#b91c1c">+50</td></tr>
            <tr><td style="padding:4px 8px">Highest</td><td style="padding:4px 8px;font-weight:700;color:#b91c1c">+40</td></tr>
            <tr><td style="padding:4px 8px">High</td><td style="padding:4px 8px;font-weight:700;color:#b45309">+30</td></tr>
            <tr><td style="padding:4px 8px">Medium</td><td style="padding:4px 8px;font-weight:700;color:#1d4ed8">+10</td></tr>
            <tr><td style="padding:4px 8px">Low</td><td style="padding:4px 8px;font-weight:700;color:#6b7280">+2</td></tr>
          </tbody></table></div>
        <div><h3 style="font-size:14px;font-weight:700;color:#374151;margin-bottom:8px">Status</h3>
          <table style="width:auto"><tbody>
            <tr><td style="padding:4px 8px">Blocked</td><td style="padding:4px 8px;font-weight:700;color:#b91c1c">+25</td></tr>
            <tr><td style="padding:4px 8px">In Progress</td><td style="padding:4px 8px;font-weight:700;color:#1d4ed8">+15</td></tr>
            <tr><td style="padding:4px 8px">Not Started</td><td style="padding:4px 8px;font-weight:700;color:#6b7280">+5</td></tr>
            <tr><td style="padding:4px 8px">Test</td><td style="padding:4px 8px;font-weight:700;color:#7c3aed">+3</td></tr>
          </tbody></table></div>
        <div><h3 style="font-size:14px;font-weight:700;color:#374151;margin-bottom:8px">Age + Modifiers</h3>
          <table style="width:auto"><tbody>
            <tr><td style="padding:4px 8px">&gt;365d</td><td style="padding:4px 8px;font-weight:700;color:#b91c1c">+20</td></tr>
            <tr><td style="padding:4px 8px">&gt;180d</td><td style="padding:4px 8px;font-weight:700;color:#b45309">+15</td></tr>
            <tr><td style="padding:4px 8px">&gt;90d</td><td style="padding:4px 8px;font-weight:700;color:#b45309">+10</td></tr>
            <tr><td style="padding:4px 8px">&gt;30d</td><td style="padding:4px 8px;font-weight:700;color:#1d4ed8">+4</td></tr>
            <tr><td style="padding:4px 8px">Unassigned</td><td style="padding:4px 8px;font-weight:700;color:#b91c1c">-5</td></tr>
          </tbody></table></div>
      </div>
    </div>'''


# ═══════════════════════════════════════════════════════════════════════════════
# Action Items per Tier + Weekly Action List + Extra Stats + Assignee Callouts
# ═══════════════════════════════════════════════════════════════════════════════

ACTION_COLOR_MAP = {
    'red': 'red', 'orange': 'orange', 'purple': 'purple',
    'green': 'green', 'gray': 'gray',
}
URGENCY_STYLE = {
    'immediate': ('🚨 Immediate', '#b91c1c', '#fef2f2'),
    'today':     ('🔴 Today',     '#b91c1c', '#fef2f2'),
    'escalate':  ('🟠 Today',     '#b45309', '#fff7ed'),
    'follow-up': ('⏸ Follow-up',  '#6b21a8', '#faf5ff'),
    'verify':    ('📊 Verify',    '#1d4ed8', '#eff6ff'),
    'close':     ('✅ Close',     '#166534', '#f0fdf4'),
    'cancel':    ('🗑 Today',     '#374151', '#f3f4f6'),
    'triage':    ('⚡ Today',     '#b45309', '#fff7ed'),
    'queue':     ('📋 Queue',     '#6b7280', '#f9fafb'),
}


def gen_tier_actions(tier_num, per_ticket_actions):
    """Render the 'Specific Actions' block below a tier table."""
    if not per_ticket_actions:
        return ''
    # Filter actions that belong to this tier
    tier_actions = [a for a in per_ticket_actions if a.get('tier') == tier_num]
    if not tier_actions:
        return ''
    items = ''
    for a in tier_actions:
        css_color = ACTION_COLOR_MAP.get(a.get('color', ''), '')
        cls = f' {css_color}' if css_color else ''
        items += f'''    <div class="action-item{cls}">
      <strong>{a["key"]}</strong> — {a["action"]}
    </div>\n'''

    return f'''  <div style="margin-top:16px">
    <h3>Specific Actions</h3>
{items}  </div>'''


def gen_weekly_action_list(weekly_actions):
    """Render the consolidated 'This Week's Action List' table."""
    if not weekly_actions:
        return ''
    rows = ''
    for a in weekly_actions:
        urgency = a.get('urgency', 'queue')
        label, fg, bg = URGENCY_STYLE.get(urgency, URGENCY_STYLE['queue'])
        ticket_keys = a.get('tickets', [a['ticket']]) if 'tickets' in a else [a.get('ticket', '')]
        links = ' + '.join(jira_link(k) for k in ticket_keys if k)
        owner = a.get('owner', '')
        rows += f'''      <tr style="background:{bg}"><td style="padding:10px;white-space:nowrap"><span style="color:{fg};font-weight:700">{label}</span></td>
        <td style="padding:10px;font-size:13px">{a["action"]}</td>
        <td style="padding:10px">{links}</td><td style="padding:10px;font-size:12px">{owner}</td></tr>\n'''

    return f'''
<!-- THIS WEEK ACTION LIST -->
<div class="card" style="margin-bottom:24px;border:2px solid #1a6fb5">
  <h2>This Week's Action List</h2>
  <table>
    <thead><tr><th>Priority</th><th>Action</th><th>Ticket</th><th>Owner</th></tr></thead>
    <tbody>
{rows}    </tbody>
  </table>
</div>'''


def gen_extra_stat_boxes(extra_stats):
    """Render additional stat boxes from enrichment signals."""
    if not extra_stats:
        return ''
    html = ''
    for s in extra_stats:
        html += stat_box(s['value'], s['label'], s.get('color', '#374151'), s.get('bg', '#f3f4f6'))
    return html


def gen_assignee_callouts(assignee_callouts):
    """Render named callout blocks for assignee overload / risk warnings."""
    if not assignee_callouts:
        return ''
    html = ''
    for c in assignee_callouts:
        bg = c.get('bg', '#faf5ff')
        fg = c.get('color', '#6b21a8')
        html += f'''  <div style="margin-top:12px;padding:10px 14px;background:{bg};border-radius:6px;font-size:12px;color:{fg}">
    {c["text"]}
  </div>\n'''
    return html


# ═══════════════════════════════════════════════════════════════════════════════
# Insights Section (from overrides file or auto-generated)
# ═══════════════════════════════════════════════════════════════════════════════

def gen_insights_section(insights):
    """Render key insights callout boxes if provided."""
    if not insights:
        return ''
    boxes = ''
    for insight in insights:
        # Color by first emoji
        if insight.startswith('🚨'):
            bg, border = '#fef2f2', '#fca5a5'
        elif insight.startswith('🗑'):
            bg, border = '#f3f4f6', '#9ca3af'
        elif insight.startswith('⏸'):
            bg, border = '#faf5ff', '#d8b4fe'
        elif insight.startswith('⚡'):
            bg, border = '#fef9c3', '#fde68a'
        elif insight.startswith('✅'):
            bg, border = '#f0fdf4', '#86efac'
        elif insight.startswith('📊'):
            bg, border = '#eff6ff', '#93c5fd'
        elif insight.startswith('🔴'):
            bg, border = '#fff7ed', '#fdba74'
        else:
            bg, border = '#f9fafb', '#d1d5db'
        boxes += f'<div class="insight" style="background:{bg};border-color:{border}">{insight}</div>\n'

    return f'''
    <div class="card" style="border-left:5px solid #f97316;margin-bottom:24px">
      <h2>Key Insights from Ticket Detail Review</h2>
      <div style="font-size:12px;color:#6b7280;margin-bottom:14px">
        Tiers were updated after reading descriptions, comments, and issue links.
        Several tickets have misleading statuses — actual state differs from Jira field.
      </div>
      {boxes}
    </div>'''


# ═══════════════════════════════════════════════════════════════════════════════
# Full Report Assembly
# ═══════════════════════════════════════════════════════════════════════════════

def gen_tableau_section(tableau_section):
    """Render raw-HTML tableau section string (already formatted HTML card)."""
    if not tableau_section:
        return ''
    return tableau_section


def generate_report(board, actionable, epic_key, today_str, special_flags, insights,
                    per_ticket_actions=None, weekly_actions=None, extra_stats=None,
                    assignee_callouts=None, workflow_insights=None, tableau_section=None):
    """Generate the full HTML report for a single board."""
    n = len(actionable)
    sorted_tickets = sorted(actionable, key=lambda x: -x['score'])

    tier_counts = Counter(t['tier'] for t in actionable)
    prio_counts = Counter(t['priority'] for t in actionable)
    n_unassigned = sum(1 for t in actionable if t['assignee'] == 'Unassigned')

    # ── Stat boxes ─────────────────────────────────────────────────────────────
    stat_boxes = ''
    stat_boxes += stat_box(tier_counts.get(1, 0), 'T1 · Do Now', '#b91c1c', '#fee2e2')
    stat_boxes += stat_box(tier_counts.get(2, 0), 'T2 · Escalate', '#b45309', '#fff7ed')
    stat_boxes += stat_box(tier_counts.get(3, 0), 'T3 · In Flight', '#1e3a5f', '#eff6ff')
    stat_boxes += stat_box(tier_counts.get(4, 0), 'T4 · Monitor', '#166534', '#f0fdf4')
    if tier_counts.get(5, 0) > 0:
        stat_boxes += stat_box(tier_counts.get(5, 0), 'T5 · Queue', '#374151', '#f3f4f6')
    stat_boxes += stat_box(prio_counts.get('Critical', 0), 'Critical', '#7f1d1d', '#fef2f2')
    stat_boxes += stat_box(prio_counts.get('High', 0) + prio_counts.get('Highest', 0), 'High+', '#b45309', '#fef9c3')
    stat_boxes += stat_box(n_unassigned, 'Unassigned', '#6b7280', '#f9fafb')
    stat_boxes += gen_extra_stat_boxes(extra_stats or [])

    # ── Tier sections ──────────────────────────────────────────────────────────
    tier_sections = ''
    for tier_num in range(1, 6):
        if tier_counts.get(tier_num, 0) > 0 or tier_num <= 4:
            tier_sections += gen_tier_section(sorted_tickets, tier_num, special_flags, per_ticket_actions)

    # ── Weekly action list ─────────────────────────────────────────────────────
    weekly_section = gen_weekly_action_list(weekly_actions or [])

    html = f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{board} Defect Prioritization | {today_str}</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #f1f5f9; color: #1f2937; }}
  h1 {{ font-size: 26px; font-weight: 800; }}
  h2 {{ font-size: 18px; font-weight: 700; margin-bottom: 14px; color: #1f2937; }}
  h3 {{ font-size: 14px; font-weight: 700; color: #374151; margin-bottom: 8px; }}
  table {{ border-collapse: collapse; width: 100%; }}
  th {{ background: #f8fafc; color: #374151; font-size: 11px; font-weight: 700; text-transform: uppercase;
        letter-spacing: .5px; padding: 10px 8px; text-align: left; border-bottom: 2px solid #e5e7eb; white-space: nowrap; }}
  .card {{ background: #fff; border-radius: 12px; box-shadow: 0 1px 4px rgba(0,0,0,.07); padding: 24px; margin-bottom: 24px; }}
  .tier-header {{ border-radius: 8px; padding: 12px 16px; margin-bottom: 16px; }}
  .insight {{ border-radius: 8px; padding: 12px 16px; margin-bottom: 10px; font-size: 13px; border: 1px solid; }}
  .action-item {{ background: #f8fafc; border-left: 4px solid #1a6fb5; border-radius: 0 6px 6px 0;
                  padding: 10px 14px; margin-bottom: 8px; font-size: 13px; }}
  .action-item.red    {{ border-color: #ef4444; }}
  .action-item.orange {{ border-color: #f97316; }}
  .action-item.purple {{ border-color: #7c3aed; }}
  .action-item.green  {{ border-color: #22c55e; }}
  .action-item.gray   {{ border-color: #9ca3af; }}
  a {{ color: #1a6fb5; text-decoration: none; }}
  a:hover {{ text-decoration: underline; }}
  .overflow-x {{ overflow-x: auto; }}
</style>
</head>
<body>
<div style="max-width:1400px;margin:0 auto;padding:24px 16px">

<!-- HEADER -->
<div class="card" style="background:linear-gradient(135deg,#1e3a5f 0%,#1a6fb5 100%);color:#fff;padding:32px;margin-bottom:24px">
  <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:16px">
    <div>
      <div style="font-size:12px;text-transform:uppercase;letter-spacing:1px;opacity:.7;margin-bottom:6px">
        {board} · Epic {epic_key} · OT_Fallout_DefectTracker_2026
      </div>
      <h1 style="color:#fff;margin-bottom:6px">Defect Prioritization Report</h1>
      <div style="opacity:.8;font-size:14px">
        Team {board} · Prioritization enriched with full ticket detail review (descriptions + comments) · {today_str}
      </div>
    </div>
    <div style="text-align:right">
      <div style="font-size:48px;font-weight:800">{n}</div>
      <div style="font-size:13px;opacity:.8">actionable tickets</div>
    </div>
  </div>
</div>

{gen_insights_section(insights)}

{weekly_section}

<!-- STAT BOXES -->
<div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:24px">
  {stat_boxes}
</div>

{gen_tableau_section(tableau_section)}
{gen_distribution_section(actionable, workflow_insights)}
{gen_assignee_section(actionable, assignee_callouts)}
{tier_sections}
{gen_scoring_model()}
{gen_raw_data_table(sorted_tickets, special_flags)}

<!-- FOOTER -->
<div style="text-align:center;font-size:11px;color:#9ca3af;padding:16px 0 32px">
  Generated from Jira Epic <a href="{JIRA_BASE}/browse/{epic_key}">{epic_key}</a>
  · {today_str} · {board}
</div>

</div></body></html>'''

    return html


# ═══════════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description='Generate per-board defect prioritization HTML report')
    parser.add_argument('--tickets', required=True, help='Path to epic-tickets.json')
    parser.add_argument('--board', help='Board prefix (e.g., CMXOTR). Omit with --all-boards.')
    parser.add_argument('--all-boards', action='store_true', help='Generate reports for ALL boards')
    parser.add_argument('--epic', required=True, help='Epic key (e.g., CMXOTD-3181)')
    parser.add_argument('--output', help='Output HTML path (single board mode)')
    parser.add_argument('--output-dir', help='Output directory (all-boards mode)')
    parser.add_argument('--overrides', help='Optional JSON file with tier overrides, flags, insights')
    parser.add_argument('--overrides-dir', help='Directory with per-board override files (board.json)')
    parser.add_argument('--date', help='Report date (YYYY-MM-DD). Default: today')
    parser.add_argument('--min-tickets', type=int, default=1,
                        help='Minimum actionable tickets to generate a report (default: 1)')
    args = parser.parse_args()

    # Load tickets
    with open(args.tickets, encoding="utf-8") as f:
        all_tickets = json.load(f)

    today = datetime.strptime(args.date, '%Y-%m-%d').date() if args.date else date.today()
    # %-d (no leading zero) is GNU/macOS only; %#d is Windows only.
    # Use .replace(' 0', ' ').lstrip('0') trick — or just strip leading zero portably.
    today_str = today.strftime('%B %d, %Y').replace(' 0', ' ')
    today_file = today.strftime('%Y-%m-%d')

    if args.all_boards:
        if not args.output_dir:
            print('ERROR: --output-dir required with --all-boards', file=sys.stderr)
            sys.exit(1)
        os.makedirs(args.output_dir, exist_ok=True)

        # Discover all board prefixes
        prefixes = sorted(set(t['prefix'] for t in all_tickets))
        generated = 0
        for prefix in prefixes:
            board_tickets = [t for t in all_tickets if t['prefix'] == prefix]
            board_tickets = enrich_tickets(board_tickets, today)
            actionable = [t for t in board_tickets if t['status'] not in EXCLUDED_STATUSES]

            if len(actionable) < args.min_tickets:
                print(f'[SKIP] {prefix}: {len(actionable)} actionable (below min {args.min_tickets})', file=sys.stderr)
                continue

            # Load per-board overrides if available
            overrides = _load_overrides(prefix, args.overrides_dir)
            tier_overrides = overrides.get('tier_overrides', {})
            special_flags = overrides.get('special_flags', {})
            insights = overrides.get('insights', [])
            per_ticket_actions = overrides.get('per_ticket_actions', [])
            weekly_actions = overrides.get('weekly_actions', [])
            extra_stats = overrides.get('extra_stats', [])
            assignee_callouts = overrides.get('assignee_callouts', [])
            workflow_insights = overrides.get('workflow_insights', [])
            tableau_section = overrides.get('tableau_section', None)

            # Re-enrich with overrides
            board_tickets = enrich_tickets(board_tickets, today, tier_overrides, special_flags)
            actionable = [t for t in board_tickets if t['status'] not in EXCLUDED_STATUSES]

            output_path = os.path.join(args.output_dir, f'{prefix.lower()}-priority-{today_file}.html')
            html = generate_report(prefix, actionable, args.epic, today_str, special_flags, insights,
                                   per_ticket_actions, weekly_actions, extra_stats,
                                   assignee_callouts, workflow_insights, tableau_section)
            with open(output_path, 'w', encoding="utf-8") as f:
                f.write(html)
            print(f'[OK]   {prefix}: {len(actionable)} actionable → {output_path} ({len(html):,} chars)', file=sys.stderr)
            generated += 1

        # Generate index page
        _generate_index(args.output_dir, prefixes, all_tickets, today_str, today_file, args.epic, args.min_tickets)
        print(f'\n[DONE] Generated {generated} board reports + index in {args.output_dir}', file=sys.stderr)

    else:
        if not args.board:
            print('ERROR: --board or --all-boards required', file=sys.stderr)
            sys.exit(1)
        if not args.output:
            print('ERROR: --output required in single-board mode', file=sys.stderr)
            sys.exit(1)

        board_tickets = [t for t in all_tickets if t['prefix'] == args.board]
        if not board_tickets:
            print(f'ERROR: No tickets found for board {args.board}', file=sys.stderr)
            sys.exit(1)

        # Load overrides
        overrides = {}
        if args.overrides and os.path.exists(args.overrides):
            with open(args.overrides, encoding="utf-8") as f:
                overrides = json.load(f)

        tier_overrides = overrides.get('tier_overrides', {})
        special_flags = overrides.get('special_flags', {})
        insights = overrides.get('insights', [])
        per_ticket_actions = overrides.get('per_ticket_actions', [])
        weekly_actions = overrides.get('weekly_actions', [])
        extra_stats = overrides.get('extra_stats', [])
        assignee_callouts = overrides.get('assignee_callouts', [])
        workflow_insights = overrides.get('workflow_insights', [])
        tableau_section = overrides.get('tableau_section', None)

        board_tickets = enrich_tickets(board_tickets, today, tier_overrides, special_flags)
        actionable = [t for t in board_tickets if t['status'] not in EXCLUDED_STATUSES]

        os.makedirs(os.path.dirname(args.output) or '.', exist_ok=True)
        html = generate_report(args.board, actionable, args.epic, today_str, special_flags, insights,
                               per_ticket_actions, weekly_actions, extra_stats,
                               assignee_callouts, workflow_insights, tableau_section)
        with open(args.output, 'w', encoding="utf-8") as f:
            f.write(html)
        print(f'Written: {args.output} ({len(html):,} chars, {len(actionable)} actionable tickets)')


def _load_overrides(prefix, overrides_dir):
    """Load per-board override JSON if it exists."""
    if not overrides_dir:
        return {}
    path = os.path.join(overrides_dir, f'{prefix.lower()}.json')
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    return {}


def _generate_index(output_dir, prefixes, all_tickets, today_str, today_file, epic_key, min_tickets):
    """Generate an index.html linking to all board reports with a summary dashboard."""
    rows = ''
    total_actionable = 0
    for prefix in sorted(prefixes):
        board_tickets = [t for t in all_tickets if t['prefix'] == prefix]
        actionable = [t for t in board_tickets if t['status'] not in EXCLUDED_STATUSES]
        n_act = len(actionable)
        total_actionable += n_act

        if n_act < min_tickets:
            rows += f'''<tr style="opacity:.5">
              <td style="padding:10px 12px;font-weight:600">{prefix}</td>
              <td style="padding:10px 12px;text-align:center">{len(board_tickets)}</td>
              <td style="padding:10px 12px;text-align:center">{n_act}</td>
              <td style="padding:10px 12px;color:#9ca3af;font-style:italic">Below threshold ({min_tickets})</td>
            </tr>'''
        else:
            status_counts = Counter(t['status'] for t in actionable)
            prio_counts = Counter(t['priority'] for t in actionable)
            blocked = status_counts.get('Blocked', 0)
            critical = prio_counts.get('Critical', 0)
            flags = []
            if blocked:
                flags.append(f'<span style="color:#b91c1c;font-weight:700">{blocked} blocked</span>')
            if critical:
                flags.append(f'<span style="color:#b91c1c;font-weight:700">{critical} critical</span>')
            flag_str = ' · '.join(flags) if flags else ''
            link = f'{prefix.lower()}-priority-{today_file}.html'
            rows += f'''<tr>
              <td style="padding:10px 12px"><a href="{link}" style="font-weight:700;font-size:14px">{prefix}</a></td>
              <td style="padding:10px 12px;text-align:center">{len(board_tickets)}</td>
              <td style="padding:10px 12px;text-align:center;font-weight:700">{n_act}</td>
              <td style="padding:10px 12px;font-size:12px">{flag_str}</td>
            </tr>'''

    index_html = f'''<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Defect Prioritization Dashboard | {today_str}</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #f1f5f9; color: #1f2937; }}
  table {{ border-collapse: collapse; width: 100%; }}
  th {{ background: #f8fafc; color: #374151; font-size: 11px; font-weight: 700; text-transform: uppercase;
        letter-spacing: .5px; padding: 10px 12px; text-align: left; border-bottom: 2px solid #e5e7eb; }}
  a {{ color: #1a6fb5; text-decoration: none; }} a:hover {{ text-decoration: underline; }}
</style></head><body>
<div style="max-width:900px;margin:0 auto;padding:32px 16px">
  <div style="background:linear-gradient(135deg,#1e3a5f,#1a6fb5);color:#fff;border-radius:12px;padding:32px;margin-bottom:24px">
    <div style="font-size:12px;text-transform:uppercase;letter-spacing:1px;opacity:.7;margin-bottom:6px">
      Epic <a href="{JIRA_BASE}/browse/{epic_key}" style="color:#fff">{epic_key}</a> · OT_Fallout_DefectTracker_2026
    </div>
    <h1 style="font-size:26px;font-weight:800;color:#fff;margin-bottom:4px">Defect Prioritization Dashboard</h1>
    <div style="opacity:.8;font-size:14px">{today_str} · {total_actionable} actionable tickets across {len(prefixes)} boards</div>
  </div>
  <div style="background:#fff;border-radius:12px;box-shadow:0 1px 4px rgba(0,0,0,.07);padding:24px">
    <table>
      <thead><tr><th>Board</th><th>Total</th><th>Actionable</th><th>Flags</th></tr></thead>
      <tbody>{rows}</tbody>
    </table>
  </div>
  <div style="text-align:center;font-size:11px;color:#9ca3af;padding:16px 0 32px">
    Generated from <a href="{JIRA_BASE}/browse/{epic_key}">{epic_key}</a> · {today_str}
  </div>
</div></body></html>'''

    index_path = os.path.join(output_dir, f'index-{today_file}.html')
    with open(index_path, 'w', encoding="utf-8") as f:
        f.write(index_html)
    print(f'[OK]   Index → {index_path}', file=sys.stderr)


if __name__ == '__main__':
    main()
