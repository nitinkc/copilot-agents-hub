#!/usr/bin/env bash
# ============================================================================
# fetch-epic-tickets.sh — Fetch all non-closed tickets from a Jira epic
#
# Usage:
#   bash .github/shared/scripts/defect-prioritization/fetch-epic-tickets.sh
#   bash .github/shared/scripts/defect-prioritization/fetch-epic-tickets.sh CMXOTD-3181 /tmp/epic-tickets.json
#
# Defaults: Epic=CMXOTD-3181, Output=/tmp/epic-tickets.json
# Requires: JIRA_PAT in environment or ~/.jira-reader.env
# Output:   JSON array of ticket objects (key, prefix, summary, status, etc.)
# ============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Source shared Jira auth library
source "$SCRIPT_DIR/../../../skills/jira-wiki-reader/scripts/_lib.sh"
validate_env

# ── Config ────────────────────────────────────────────────────────────────────
DEFAULT_EPIC="CMXOTD-3181"

# ── Args ──────────────────────────────────────────────────────────────────────
EPIC_KEY="${1:-$DEFAULT_EPIC}"
OUTPUT_FILE="${2:-/tmp/epic-tickets.json}"

JIRA_URL="$JIRA_BASE_URL"
PAGE_SIZE=100

# ── JQL: all non-closed tickets in the epic ───────────────────────────────────
JQL="\"Epic Link\" = ${EPIC_KEY} AND status NOT IN (Closed) ORDER BY key ASC"
FIELDS="key,summary,status,priority,issuetype,assignee,reporter,labels,customfield_10002,created,updated,resolution"

echo "[INFO]  Fetching tickets from epic ${EPIC_KEY}..." >&2

ALL_TICKETS="[]"
START_AT=0
TOTAL=999999  # will be replaced on first fetch

while [ "$START_AT" -lt "$TOTAL" ]; do
  RESPONSE=$(curl -s --max-time 30 \
    -H "Authorization: Bearer ${JIRA_PAT}" \
    -H "Content-Type: application/json" \
    "${JIRA_URL}/rest/api/2/search?jql=$(python3 -c "import urllib.parse; print(urllib.parse.quote('''${JQL}'''))")&fields=${FIELDS}&startAt=${START_AT}&maxResults=${PAGE_SIZE}")

  # Extract total on first page
  PAGE_TOTAL=$(echo "$RESPONSE" | python3 -c "import json,sys; print(json.load(sys.stdin).get('total',0))")
  TOTAL=$PAGE_TOTAL

  # Transform issues to compact format and append
  PAGE_TICKETS=$(echo "$RESPONSE" | python3 -c "
import json, sys
data = json.load(sys.stdin)
tickets = []
for issue in data.get('issues', []):
    f = issue['fields']
    key = issue['key']
    prefix = key.rsplit('-', 1)[0]
    assignee = (f.get('assignee') or {}).get('displayName', 'Unassigned')
    reporter = (f.get('reporter') or {}).get('displayName', 'Unknown')
    status = (f.get('status') or {}).get('name', 'Unknown')
    status_cat = ((f.get('status') or {}).get('statusCategory') or {}).get('name', 'Unknown')
    priority = (f.get('priority') or {}).get('name', 'None')
    issue_type = (f.get('issuetype') or {}).get('name', 'Unknown')
    labels = f.get('labels', [])
    sp = f.get('customfield_10002')
    created = (f.get('created') or '')[:10]
    updated = (f.get('updated') or '')[:10]
    resolution = (f.get('resolution') or {}).get('name') if f.get('resolution') else None
    tickets.append({
        'key': key, 'prefix': prefix, 'summary': f.get('summary',''),
        'status': status, 'status_cat': status_cat, 'priority': priority,
        'type': issue_type, 'assignee': assignee, 'reporter': reporter,
        'labels': labels, 'sp': sp, 'created': created, 'updated': updated,
        'resolution': resolution
    })
print(json.dumps(tickets))
")

  ALL_TICKETS=$(python3 -c "
import json, sys
existing = json.loads(sys.argv[1])
new_page = json.loads(sys.argv[2])
print(json.dumps(existing + new_page))
" "$ALL_TICKETS" "$PAGE_TICKETS")

  START_AT=$((START_AT + PAGE_SIZE))
  echo "[INFO]  Fetched ${START_AT}/${TOTAL}..." >&2
done

# Write output
echo "$ALL_TICKETS" | python3 -m json.tool > "$OUTPUT_FILE"

TICKET_COUNT=$(echo "$ALL_TICKETS" | python3 -c "import json,sys; print(len(json.load(sys.stdin)))")
echo "[INFO]  Wrote ${TICKET_COUNT} tickets to ${OUTPUT_FILE}" >&2
echo "$TICKET_COUNT"
