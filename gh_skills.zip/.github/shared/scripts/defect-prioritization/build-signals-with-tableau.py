#!/usr/bin/env python3
"""
Analyze tickets + Tableau fallout data, build priority signal files with Tableau sections.
Correlates Tableau error groupings with Jira tickets and identifies unmatched fallout patterns.
All analysis is derived exclusively from the 10-day fallout detail export (per-instance with EXCEPTION_MSG).
"""
import json, csv, glob, os, re, html
from collections import Counter, defaultdict
from datetime import datetime, date

# ─── Config ───
EPIC_FILE = "/tmp/epic-tickets.json"
CLOSED_FILE = "/tmp/epic-tickets-closed.json"  # recently-closed tickets (last 3 weeks); optional
DETAIL_DIR = "/tmp/priority-details"
FALLOUT_FILE = "/tmp/fallout-full.csv"
SIGNAL_DIR = "/tmp/priority-signals"
TODAY = date.today().strftime("%Y-%m-%d")

# APP → Board primary mapping (based on team ownership)
# Some APPs appear in tickets for multiple boards; primary owner listed first
APP_BOARD_MAP = {
    "BPM_BILLING_ORDER": "CMXOTB",
    "BPM_CSG_BILLING_ORDER": "CMXOTOS",
    "BPM_LEAN_ORCHESTRATOR": "CMXOT2",
    "BPM_ASCNDN_BILLING_ORDER": "CMXOTB",
    "BPM_PREPAID_BILLING_ORDER": "CMXOTR",
    "BPM_PROVISION": "CMXOTP",
    "BPM_FULFILLMENT": "CMXOTF",
    "BPM_HARDGOODS_FULFILLMENT": "CMXOTF",
    "BPM_OTT_FULFILLMENT": "CMXOTF",
    "CONVERGENCE": "CMXOTOS",
    "BPM_CANCEL_ORDER": "CMXOTOS",
    "BPM_ORDER_VERIFY": "CMXOTR",
    "BPM_RECON": "CMXOT2",
    "BPM_TRADEIN": "CMXOT3",
    "BPM_CREDIT_CHECK": "CMXOTR",
    "MDUCB": "CMXOTOS",
    "BPM_PAYMENT": "CMXOTR",
    "BPM_FRAUD_REVIEW": "CMXOTR",
 
}

# ─── Load data ───
with open(EPIC_FILE, encoding="utf-8") as _f:
    tickets_list = json.load(_f)
tickets_by_key = {}
for board_dir in glob.glob(f"{DETAIL_DIR}/*/"):
    for f in glob.glob(f"{board_dir}/*.json"):
        with open(f, encoding="utf-8") as _fh:
            data = json.load(_fh)
        for tk in data.get("tickets", []):
            tickets_by_key[tk["key"]] = tk

with open(FALLOUT_FILE, encoding="utf-8") as _f:
    fallout_rows = list(csv.DictReader(_f))

# Load recently-closed tickets (last 3 weeks) if available
closed_tickets_list = []
if os.path.exists(CLOSED_FILE):
    with open(CLOSED_FILE, encoding="utf-8") as _f:
        closed_tickets_list = json.load(_f)
    print(f"Loaded: {len(closed_tickets_list)} recently-closed tickets from {CLOSED_FILE}")
else:
    print(f"[INFO] No closed tickets file found at {CLOSED_FILE} — skipping closed-ticket analysis")

# Index closed tickets by board prefix
closed_by_board = defaultdict(list)
for ct in closed_tickets_list:
    closed_by_board[ct["prefix"]].append(ct)

print(f"Loaded: {len(tickets_by_key)} ticket details, {len(fallout_rows)} fallout detail rows")

# ─── Classify errors ───
def classify_error(msg):
    if not msg: return "Unknown"
    m = msg[:300].lower()
    if "ora-00060" in m or "deadlock" in m: return "DB Deadlock"
    if "ora-00001" in m or "unique constraint" in m: return "DB Duplicate Key"
    if "ora-" in m: return "DB Error"
    if "timeout" in m or "timed out" in m: return "Timeout"
    if "connection refused" in m or "connection reset" in m: return "Connection Error"
    if "503" in m or "service unavailable" in m: return "Service Unavailable"
    if "502" in m or "bad gateway" in m: return "Bad Gateway"
    if "500" in m or "internal server error" in m: return "Upstream 500"
    if "422" in m or "unprocessable" in m: return "Validation Error"
    if "400" in m or "bad request" in m: return "Bad Request"
    if "404" in m or "not found" in m: return "Not Found"
    if "feignexception" in m or "feign" in m: return "Feign Client Error"
    if "nullpointer" in m or "npe" in m: return "Null Pointer"
    if "illegalstate" in m: return "Illegal State"
    if "flowable" in m or "bpmn" in m or "sequence flow" in m: return "BPMN Engine Error"
    if "insurance" in m or "assurant" in m or "enrollment" in m: return "Insurance/Enrollment"
    if "subscription" in m: return "Subscription Error"
    return "Other"

def extract_downstream_service(msg):
    """Extract downstream service name from Feign/HTTP error messages."""
    m = re.search(r'to \[http://(\w+)/', msg or "")
    if m: return m.group(1)
    m = re.search(r'Error.*?(\w+(?:Service|Client|Gateway))', msg or "")
    if m: return m.group(1)
    return None

def extract_error_snippet(msg, max_len=120):
    """Get the most informative part of the error message."""
    if not msg: return ""
    # For Feign errors, try to get the reason
    m = re.search(r'"reason"\s*:\s*"([^"]+)"', msg)
    if m: return m.group(1)[:max_len]
    m = re.search(r'"errorMessage"\s*:\s*"([^"]+)"', msg)
    if m: return m.group(1)[:max_len]
    m = re.search(r'"message"\s*:\s*"([^"]+)"', msg)
    if m: return m.group(1)[:max_len]
    # For plain exceptions, get text after ":"
    parts = msg.split(":", 1)
    if len(parts) > 1:
        return parts[1].strip()[:max_len]
    return msg[:max_len]

# ─── Process fallout detail data (10-day raw) ───
# Derive ALL metrics from this single source: daily counts, trends, error groupings
fallout_by_app = defaultdict(list)
fallout_by_combo = defaultdict(list)
fallout_daily = defaultdict(lambda: defaultdict(int))  # app → day → count
fallout_daily_activity = defaultdict(lambda: defaultdict(int))  # (app,act) → day → count

all_days = set()
for r in fallout_rows:
    app = r.get("APP", "")
    act = r.get("ACTIVITY_ID", "")
    day = r.get("START_TIME", "")[:10]
    fallout_by_app[app].append(r)
    fallout_by_combo[(app, act)].append(r)
    if day:
        fallout_daily[app][day] += 1
        fallout_daily_activity[(app, act)][day] += 1
        all_days.add(day)

all_days_sorted = sorted(all_days)
data_window_days = len(all_days_sorted)
date_range_label = f"{all_days_sorted[0]} to {all_days_sorted[-1]}" if all_days_sorted else "N/A"
print(f"  Data window: {data_window_days} days ({date_range_label})")

# Derive stuck totals from fallout detail (same source, just summed)
stuck_by_app = {app: len(rows) for app, rows in fallout_by_app.items()}
stuck_total_all = sum(stuck_by_app.values())

# ─── Build error groupings from fallout ───
error_groups = defaultdict(lambda: {"count": 0, "apps": set(), "activities": set(), "sample_msg": "", "error_class": "", "today_count": 0, "daily": defaultdict(int)})

for r in fallout_rows:
    app = r.get("APP", "")
    act = r.get("ACTIVITY_ID", "")
    msg = r.get("EXCEPTION_MSG", "")
    day = r.get("START_TIME", "")[:10]
    err_class = classify_error(msg)
    snippet = extract_error_snippet(msg)
    # Group by (APP, ACTIVITY, error_class)
    key = (app, act, err_class)
    error_groups[key]["count"] += 1
    error_groups[key]["apps"].add(app)
    error_groups[key]["activities"].add(act)
    error_groups[key]["error_class"] = err_class
    if day == TODAY:
        error_groups[key]["today_count"] += 1
    if day:
        error_groups[key]["daily"][day] += 1
    if not error_groups[key]["sample_msg"]:
        error_groups[key]["sample_msg"] = snippet

# ─── Match ticket to Tableau error patterns ───
def ticket_matches_error(tk, app, activity, error_msg):
    """Check if a ticket's summary/description matches a Tableau error pattern."""
    summary = (tk.get("summary") or "").lower()
    desc = (tk.get("description") or "").lower()
    text = summary + " " + desc

    # Service name matching
    app_slug = app.lower().replace("bpm_", "").replace("_", "")
    activity_lower = activity.lower()

    # Check if ticket mentions the app and activity
    app_variants = [
        app_slug,
        app.lower().replace("_", " "),
        app.lower(),
    ]
    # Map BPM app names to service names used in tickets
    service_name_map = {
        "bpm_billing_order": ["billingorder", "wkflbillingorder", "billing order", "billing_order"],
        "bpm_lean_orchestrator": ["leanorchestrator", "wkflleanorchestrator", "lean orchestrator", "lean_orchestrator"],
        "bpm_ott_fulfillment": ["ottfulfillment", "wkflottfulfillment", "ott fulfillment", "ott_fulfillment"],
        "bpm_provision": ["provision", "wkflprovisioning", "provisioning"],
        "bpm_fulfillment": ["fulfillment", "wkflfulfillment", "mbosorderfulfillment"],
        "bpm_condor": ["condor", "wkflcondor"],
        "bpm_cancel_order": ["cancelorder", "cancel order", "cancel_order"],
        "convergence": ["convergence", "xomsorderreview", "order review"],
        "bpm_ascndn_billing_order": ["ascndn", "ascndnbillingorder"],
        "bpm_prepaid_billing_order": ["prepaid", "prepaidbillingorder"],
        "bpm_hardgoods_fulfillment": ["hardgoods", "hardgoodsfulfillment"],
        "bpm_recon": ["recon", "activationrecon"],
        "bpm_tradein": ["tradein", "trade-in", "trade_in"],
        "bpm_credit_check": ["creditcheck", "credit check"],
        "mducb": ["mducb"],
    }

    app_lower = app.lower()
    variants = service_name_map.get(app_lower, [app_slug])
    app_match = any(v in text for v in variants)
    activity_match = activity_lower in text

    if app_match and activity_match:
        return 3  # Strong match (app + activity)
    if app_match:
        # Check error message content — require exception class OR 2+ significant words
        err_snippet = extract_error_snippet(error_msg).lower()
        if err_snippet:
            # Extract exception class name (e.g., "illegalargumentexception", "nullpointerexception")
            exc_match = re.search(r'([a-z]*exception|[a-z]*error|[a-z]*fault)', err_snippet)
            if exc_match and exc_match.group(1) in text:
                return 2  # Medium match (app + exception class)
            # Require 2+ significant words (>6 chars, not common domain terms)
            common_words = {"service", "request", "response", "message", "comcast", "process",
                           "unknown", "general", "details", "timeout", "connect", "system"}
            err_words = [w for w in err_snippet.split()[:8]
                        if len(w) > 6 and w not in common_words and not w.startswith("com.")]
            matching_words = [w for w in err_words if w in text]
            if len(matching_words) >= 2:
                return 2  # Medium match (app + error content overlap)
        return 1  # Weak match (app only) — not used for correlation
    return 0

# ─── Build Tableau section HTML ───
def build_tableau_section(board, board_apps, fallout_by_app_b, fallout_total,
                          fallout_rows_b, error_groups_b, matched_groups, unmatched_groups,
                          fallout_daily_b, all_days_sorted, closed_by_gkey=None):
    """Build rich HTML Tableau section for a board's priority report."""
    # closed_by_gkey: {(app, act, err_cls): [(ct_key, events_after_close), ...]} — direct gkey→closed mapping
    closed_by_gkey = closed_by_gkey or {}

    def esc(s):
        return html.escape(str(s)) if s else ""

    parts = []
    window_label = f"{all_days_sorted[0]} to {all_days_sorted[-1]}" if all_days_sorted else "N/A"
    parts.append(f"""
<div style="margin-top:32px;padding:28px 32px;background:linear-gradient(135deg,#0f172a 0%,#1e293b 100%);border-radius:16px;border:1px solid #334155;">
  <h2 style="color:#f1f5f9;margin:0 0 6px 0;font-size:22px;">📊 Production Fallout — Tableau Live Data</h2>
  <p style="color:#94a3b8;margin:0 0 24px 0;font-size:13px;">
    Fallout detail: {len(all_days_sorted)}-day window ({window_label}) &nbsp;|&nbsp;
    Source: BPM Stuck Order Dashboard &nbsp;|&nbsp; Generated: {TODAY}
  </p>
""")
    fallout_count = len(fallout_rows_b)
    unmatched_count = sum(info["count"] for info in unmatched_groups.values())
    matched_count = fallout_count - unmatched_count
    # Today's count vs total for rate
    today_count = sum(1 for r in fallout_rows_b if r.get("START_TIME", "")[:10] == TODAY)

    parts.append(f"""
  <div style="display:flex;gap:16px;flex-wrap:wrap;margin-bottom:24px;">
    <div style="flex:1;min-width:140px;background:#1e293b;border:1px solid #475569;border-radius:12px;padding:16px;text-align:center;">
      <div style="font-size:28px;font-weight:700;color:#f1f5f9;">{fallout_count:,}</div>
      <div style="font-size:12px;color:#94a3b8;margin-top:4px;">Total Fallout ({len(all_days_sorted)}d)</div>
    </div>
    <div style="flex:1;min-width:140px;background:#1e293b;border:1px solid #475569;border-radius:12px;padding:16px;text-align:center;">
      <div style="font-size:28px;font-weight:700;color:#f87171;">{today_count}</div>
      <div style="font-size:12px;color:#94a3b8;margin-top:4px;">Fallout Today</div>
    </div>
    <div style="flex:1;min-width:140px;background:#1e293b;border:1px solid #475569;border-radius:12px;padding:16px;text-align:center;">
      <div style="font-size:28px;font-weight:700;color:#4ade80;">{matched_count}</div>
      <div style="font-size:12px;color:#94a3b8;margin-top:4px;">Covered by Ticket</div>
    </div>
    <div style="flex:1;min-width:140px;background:#1e293b;border:1px solid {'#dc2626' if unmatched_count > 0 else '#475569'};border-radius:12px;padding:16px;text-align:center;">
      <div style="font-size:28px;font-weight:700;color:{'#fbbf24' if unmatched_count > 0 else '#94a3b8'};">{unmatched_count}</div>
      <div style="font-size:12px;color:#94a3b8;margin-top:4px;">No Matching Ticket ⚠</div>
    </div>
  </div>
""")

    # Per-APP fallout breakdown with daily trend
    if fallout_by_app_b:
        parts.append(f"""
  <div style="margin-bottom:24px;">
    <h3 style="color:#e2e8f0;font-size:15px;margin:0 0 12px 0;">Fallout by BPM Application ({len(all_days_sorted)} days)</h3>
    <table style="width:100%;border-collapse:collapse;font-size:13px;">
      <tr style="border-bottom:1px solid #475569;">
        <th style="text-align:left;padding:8px 12px;color:#94a3b8;">Application</th>
        <th style="text-align:right;padding:8px 12px;color:#94a3b8;">Total</th>
        <th style="text-align:right;padding:8px 12px;color:#94a3b8;">Today</th>
        <th style="text-align:left;padding:8px 12px;color:#94a3b8;">Daily Trend</th>
      </tr>
""")
        for app, cnt in sorted(fallout_by_app_b.items(), key=lambda x: -x[1]):
            daily_vals = fallout_daily_b.get(app, {})
            today_app = daily_vals.get(TODAY, 0)
            if all_days_sorted:
                max_day_val = max(daily_vals.values()) if daily_vals else 1
                bars = ""
                for day in all_days_sorted:
                    v = daily_vals.get(day, 0)
                    h = max(2, int(20 * v / max_day_val)) if max_day_val > 0 else 2
                    color = "#ef4444" if day == TODAY else "#3b82f6"
                    bars += f'<div style="width:6px;height:{h}px;background:{color};border-radius:1px;display:inline-block;margin:0 1px;vertical-align:bottom;" title="{day}: {v}"></div>'
            else:
                bars = '<span style="color:#475569;">—</span>'
            parts.append(f"""
      <tr style="border-bottom:1px solid #334155;">
        <td style="padding:8px 12px;color:#e2e8f0;">{esc(app)}</td>
        <td style="text-align:right;padding:8px 12px;color:#f1f5f9;font-weight:600;">{cnt:,}</td>
        <td style="text-align:right;padding:8px 12px;color:{'#f87171' if today_app > 0 else '#475569'};font-weight:600;">{today_app}</td>
        <td style="padding:8px 12px;">{bars}</td>
      </tr>
""")
        parts.append("    </table>\n  </div>\n")

    # Error grouping table
    if error_groups_b:
        parts.append(f"""
  <div style="margin-bottom:24px;">
    <h3 style="color:#e2e8f0;font-size:15px;margin:0 0 6px 0;">Fallout Error Groupings ({len(all_days_sorted)}d window)</h3>
    <p style="color:#94a3b8;font-size:12px;margin:0 0 10px 0;">
      Row colors: <span style="color:#fb923c;font-weight:600;">■ orange</span> = ticket closed but fallout still active &nbsp;|&nbsp;
      <span style="color:#1c1917;background:#fbbf24;padding:0 4px;border-radius:2px;font-size:11px;">dark</span> = no ticket covers this pattern &nbsp;|&nbsp;
      default = covered and open
    </p>
    <table style="width:100%;border-collapse:collapse;font-size:12px;">
      <tr style="border-bottom:1px solid #475569;">
        <th style="text-align:left;padding:8px;color:#94a3b8;">Application</th>
        <th style="text-align:left;padding:8px;color:#94a3b8;">Activity</th>
        <th style="text-align:left;padding:8px;color:#94a3b8;">Error Class</th>
        <th style="text-align:right;padding:8px;color:#94a3b8;">Count</th>
        <th style="text-align:right;padding:8px;color:#94a3b8;">Today</th>
        <th style="text-align:left;padding:8px;color:#94a3b8;">Matching Ticket</th>
        <th style="text-align:left;padding:8px;color:#94a3b8;max-width:250px;">Error Snippet</th>
      </tr>
""")
        sorted_groups = sorted(error_groups_b.items(), key=lambda x: -x[1]["count"])
        for (app, act, err_cls), info in sorted_groups[:30]:
            cnt = info["count"]
            today_grp = info.get("today_count", 0)
            snippet = esc(info["sample_msg"][:100])
            gkey = (app, act, err_cls)

            # Closed tickets that directly match this error group (from reverse index)
            closed_matches = closed_by_gkey.get(gkey, [])  # [(ct_key, eac), ...]
            closed_with_fallout = [(k, e) for k, e in closed_matches if e > 0]
            closed_resolved = [k for k, e in closed_matches if e == 0]

            # Active ticket matches (may exist alongside closed matches)
            ticket_parts = []
            if gkey in matched_groups:
                for m_key, m_score in matched_groups[gkey][:2]:
                    ticket_parts.append(f'<span style="color:#4ade80;">{m_key}</span>')
            elif gkey in unmatched_groups and not closed_with_fallout and not closed_resolved:
                ticket_parts.append('<span style="color:#fbbf24;font-weight:600;">⚠ No ticket</span>')
            elif not matched_groups.get(gkey) and not closed_with_fallout and not closed_resolved:
                ticket_parts.append('<span style="color:#475569;">—</span>')

            # Closed ticket overlays (appended after active tickets)
            for ck, eac in closed_with_fallout[:2]:
                badge = (f'<span style="background:#92400e;color:#fef3c7;padding:1px 5px;'
                         f'border-radius:3px;font-size:10px;font-weight:700;margin-left:4px;">'
                         f'⚠ CLOSED · {eac} post-close</span>')
                ticket_parts.append(f'<span style="color:#fb923c;font-weight:600;">{ck}</span>{badge}')
            for ck in closed_resolved[:2]:
                badge = (f'<span style="background:#14532d;color:#bbf7d0;padding:1px 5px;'
                         f'border-radius:3px;font-size:10px;font-weight:600;margin-left:4px;">'
                         f'✓ CLOSED</span>')
                ticket_parts.append(f'<span style="color:#4ade80;">{ck}</span>{badge}')

            ticket_cell = ", ".join(ticket_parts)

            # Row background: amber when closed ticket still has active fallout, dark for truly unmatched
            if closed_with_fallout:
                row_bg = "background:#1c1407;"
                left_border = "border-left:3px solid #f97316;"
            elif gkey in unmatched_groups and not closed_resolved:
                row_bg = "background:#1c1917;"
                left_border = ""
            else:
                row_bg = ""
                left_border = ""

            parts.append(f"""
      <tr style="border-bottom:1px solid #334155;{row_bg}{left_border}">
        <td style="padding:6px 8px;color:#cbd5e1;">{esc(app)}</td>
        <td style="padding:6px 8px;color:#e2e8f0;font-family:monospace;font-size:11px;">{esc(act)}</td>
        <td style="padding:6px 8px;color:#fbbf24;">{esc(err_cls)}</td>
        <td style="text-align:right;padding:6px 8px;color:#f1f5f9;font-weight:600;">{cnt}</td>
        <td style="text-align:right;padding:6px 8px;color:{'#f87171' if today_grp > 0 else '#475569'};">{today_grp}</td>
        <td style="padding:6px 8px;">{ticket_cell}</td>
        <td style="padding:6px 8px;color:#94a3b8;max-width:250px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{snippet}</td>
      </tr>
""")
        parts.append("    </table>\n  </div>\n")

    # Unmatched fallout call to action — each (APP, ACTIVITY, ERROR_CLASS) gets its own row
    if unmatched_groups:
        parts.append(f"""
  <div style="margin-bottom:24px;padding:16px;background:#451a03;border:1px solid #92400e;border-radius:12px;">
    <h3 style="color:#fbbf24;font-size:14px;margin:0 0 10px 0;">⚠ Active Fallout Without Matching Ticket ({len(unmatched_groups)} groupings)</h3>
    <p style="color:#fde68a;font-size:12px;margin:0 0 12px 0;">
      These error patterns have active fallout in production but no defect ticket in {board} covers them.
      Each row is a distinct (Application + Activity + Error Category) combination requiring a ticket.
    </p>
    <table style="width:100%;border-collapse:collapse;font-size:12px;">
      <tr style="border-bottom:1px solid #92400e;">
        <th style="text-align:left;padding:6px 8px;color:#fde68a;">Application</th>
        <th style="text-align:left;padding:6px 8px;color:#fde68a;">Activity</th>
        <th style="text-align:left;padding:6px 8px;color:#fde68a;">Error Category</th>
        <th style="text-align:right;padding:6px 8px;color:#fde68a;">Count ({len(all_days_sorted)}d)</th>
        <th style="text-align:right;padding:6px 8px;color:#fde68a;">Today</th>
        <th style="text-align:left;padding:6px 8px;color:#fde68a;">Trend</th>
        <th style="text-align:left;padding:6px 8px;color:#fde68a;">Sample Error</th>
      </tr>
""")
        for (app, act, err_cls), info in sorted(unmatched_groups.items(), key=lambda x: -x[1]["count"]):
            snippet = esc(info["sample_msg"][:120])
            today_grp = info.get("today_count", 0)
            # Build mini trend for this grouping
            daily_g = info.get("daily", {})
            if all_days_sorted and daily_g:
                max_v = max(daily_g.values()) if daily_g else 1
                bars = ""
                for day in all_days_sorted[-7:]:  # Show last 7 days in trend
                    v = daily_g.get(day, 0)
                    h = max(2, int(14 * v / max_v)) if max_v > 0 else 2
                    color = "#fbbf24" if v > 0 else "#78350f"
                    bars += f'<div style="width:4px;height:{h}px;background:{color};border-radius:1px;display:inline-block;margin:0 1px;vertical-align:bottom;" title="{day}: {v}"></div>'
            else:
                bars = ""
            parts.append(f"""
      <tr style="border-bottom:1px solid #78350f;">
        <td style="padding:6px 8px;color:#fde68a;">{esc(app)}</td>
        <td style="padding:6px 8px;color:#fff;font-family:monospace;font-size:11px;">{esc(act)}</td>
        <td style="padding:6px 8px;color:#fbbf24;font-weight:600;">{esc(err_cls)}</td>
        <td style="text-align:right;padding:6px 8px;color:#fff;font-weight:600;">{info['count']}</td>
        <td style="text-align:right;padding:6px 8px;color:{'#f87171' if today_grp > 0 else '#78350f'};">{today_grp}</td>
        <td style="padding:6px 8px;">{bars}</td>
        <td style="padding:6px 8px;color:#fef3c7;font-size:11px;max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{snippet}</td>
      </tr>
""")
        parts.append("    </table>\n  </div>\n")

    # Ticket↔Fallout mapping
    if matched_groups:
        parts.append("""
  <div style="margin-bottom:16px;">
    <h3 style="color:#e2e8f0;font-size:15px;margin:0 0 12px 0;">🔗 Ticket ↔ Fallout Correlation</h3>
    <p style="color:#94a3b8;font-size:12px;margin:0 0 12px 0;">
      Tickets matched to active Tableau fallout patterns by service name, activity, and error content.
    </p>
    <table style="width:100%;border-collapse:collapse;font-size:12px;">
      <tr style="border-bottom:1px solid #475569;">
        <th style="text-align:left;padding:6px 8px;color:#94a3b8;">Ticket</th>
        <th style="text-align:left;padding:6px 8px;color:#94a3b8;">App → Activity</th>
        <th style="text-align:left;padding:6px 8px;color:#94a3b8;">Error Class</th>
        <th style="text-align:right;padding:6px 8px;color:#94a3b8;">Fallout Count</th>
        <th style="text-align:left;padding:6px 8px;color:#94a3b8;">Match</th>
      </tr>
""")
        shown = set()
        for (app, act, err_cls), matches in sorted(matched_groups.items(), key=lambda x: -error_groups_b[x[0]]["count"]):
            cnt = error_groups_b[(app, act, err_cls)]["count"]
            gkey = (app, act, err_cls)
            # Active ticket rows
            for tk_key, score in matches[:2]:
                row_key = (tk_key, app, act)
                if row_key in shown: continue
                shown.add(row_key)
                strength = "🟢 Strong" if score >= 3 else ("🟡 Medium" if score >= 2 else "⚪ Weak")
                parts.append(f"""
      <tr style="border-bottom:1px solid #334155;">
        <td style="padding:6px 8px;color:#60a5fa;font-weight:500;">{esc(tk_key)}</td>
        <td style="padding:6px 8px;color:#cbd5e1;font-family:monospace;font-size:11px;">{esc(app)} → {esc(act)}</td>
        <td style="padding:6px 8px;color:#fbbf24;">{esc(err_cls)}</td>
        <td style="text-align:right;padding:6px 8px;color:#f1f5f9;">{cnt}</td>
        <td style="padding:6px 8px;color:#94a3b8;font-size:11px;">{strength}</td>
      </tr>
""")
            # Closed ticket rows for this same error group (from direct gkey reverse index)
            for ck_key, eac in closed_by_gkey.get(gkey, [])[:2]:
                row_key = (ck_key, app, act, "closed")
                if row_key in shown: continue
                shown.add(row_key)
                if eac > 0:
                    badge = (f'<span style="background:#92400e;color:#fef3c7;padding:1px 6px;border-radius:4px;'
                             f'font-size:10px;font-weight:700;">⚠ CLOSED · {eac} post-close</span>')
                    row_style = "border-bottom:1px solid #334155;background:#1c1407;"
                    key_color = "#fb923c"
                else:
                    badge = '<span style="background:#14532d;color:#bbf7d0;padding:1px 6px;border-radius:4px;font-size:10px;font-weight:600;">✓ CLOSED</span>'
                    row_style = "border-bottom:1px solid #334155;"
                    key_color = "#4ade80"
                parts.append(f"""
      <tr style="{row_style}">
        <td style="padding:6px 8px;color:{key_color};font-weight:500;">{esc(ck_key)} &nbsp;{badge}</td>
        <td style="padding:6px 8px;color:#cbd5e1;font-family:monospace;font-size:11px;">{esc(app)} → {esc(act)}</td>
        <td style="padding:6px 8px;color:#fbbf24;">{esc(err_cls)}</td>
        <td style="text-align:right;padding:6px 8px;color:#f1f5f9;">{cnt}</td>
        <td style="padding:6px 8px;color:#94a3b8;font-size:11px;">🔴 Closed</td>
      </tr>
""")
        parts.append("    </table>\n  </div>\n")

    parts.append("</div>")
    return "\n".join(parts)


# ─── Closed-ticket section ───
def build_closed_section(board, board_closed_data):
    """Build HTML section for recently-closed tickets (last 3 weeks) with fallout status."""
    if not board_closed_data:
        return ""

    def esc(s):
        return html.escape(str(s)) if s else ""

    JIRA_BASE = "https://tkts.sys.comcast.net"
    still_active = [ct for ct in board_closed_data if ct["events_after_close"] > 0]

    parts = []
    parts.append(f"""
<div style="margin-top:32px;padding:28px 32px;background:#f8fafc;border-radius:16px;border:1px solid #e2e8f0;">
  <h2 style="color:#1f2937;margin:0 0 6px 0;font-size:20px;">🗂 Recently Closed Tickets (Last 3 Weeks)</h2>
  <p style="color:#6b7280;margin:0 0 16px 0;font-size:13px;">
    {len(board_closed_data)} tickets closed in the last 21 days &nbsp;|&nbsp;
    <span style="color:{'#dc2626' if still_active else '#166534'};font-weight:600;">{len(still_active)} still have active fallout after closure</span>
  </p>
""")

    if still_active:
        parts.append(f"""
  <div style="margin-bottom:16px;padding:12px 16px;background:#fef2f2;border:1px solid #fca5a5;border-radius:8px;">
    <strong style="color:#b91c1c;">⚠ Validation Required:</strong>
    <span style="color:#7f1d1d;font-size:13px;">
      {len(still_active)} closed ticket(s) still show active fallout in production.
      Verify the root cause was genuinely resolved or that fallout is attributable to a separate ticket.
    </span>
  </div>
""")

    parts.append("""
  <div style="overflow-x:auto;">
  <table style="width:100%;border-collapse:collapse;font-size:12px;">
    <tr style="border-bottom:2px solid #e5e7eb;">
      <th style="text-align:left;padding:8px 10px;color:#374151;font-size:11px;text-transform:uppercase;letter-spacing:.5px;">Ticket</th>
      <th style="text-align:left;padding:8px 10px;color:#374151;font-size:11px;text-transform:uppercase;letter-spacing:.5px;">Summary</th>
      <th style="text-align:left;padding:8px 10px;color:#374151;font-size:11px;text-transform:uppercase;letter-spacing:.5px;">Status</th>
      <th style="text-align:left;padding:8px 10px;color:#374151;font-size:11px;text-transform:uppercase;letter-spacing:.5px;">Resolution</th>
      <th style="text-align:left;padding:8px 10px;color:#374151;font-size:11px;text-transform:uppercase;letter-spacing:.5px;">Assignee</th>
      <th style="text-align:left;padding:8px 10px;color:#374151;font-size:11px;text-transform:uppercase;letter-spacing:.5px;">Closed</th>
      <th style="text-align:right;padding:8px 10px;color:#374151;font-size:11px;text-transform:uppercase;letter-spacing:.5px;">Events After Close</th>
      <th style="text-align:left;padding:8px 10px;color:#374151;font-size:11px;text-transform:uppercase;letter-spacing:.5px;">Fallout Status</th>
    </tr>
""")

    for ct in sorted(board_closed_data, key=lambda x: (-x["events_after_close"], x["updated"] or "")):
        has_post_close = ct["events_after_close"] > 0
        row_bg = "background:#fff7ed;" if has_post_close else "background:#f0fdf4;"

        if has_post_close:
            fallout_cell = f'<span style="color:#dc2626;font-weight:700;">⚠ {ct["events_after_close"]} events post-close</span>'
        elif ct["has_fallout_match"]:
            fallout_cell = '<span style="color:#166534;">✅ Resolved (no post-close fallout)</span>'
        else:
            fallout_cell = '<span style="color:#6b7280;">— No fallout match</span>'

        res = ct.get("resolution") or "—"
        wont_fix_resolutions = {"won't fix", "wont fix", "won't do", "wontdo", "duplicate", "not a bug"}
        wont_fix = res.lower() in wont_fix_resolutions
        res_color = "#dc2626" if wont_fix else "#374151"

        status_color = "#166534" if ct["status"] in ("Closed", "Resolved", "Accepted", "Released") else "#9ca3af"

        jira_key = esc(ct["key"])
        jira_url = f"{JIRA_BASE}/browse/{ct['key']}"
        events_cell = str(ct["events_after_close"]) if has_post_close else "—"

        parts.append(f"""    <tr style="border-bottom:1px solid #e5e7eb;{row_bg}">
      <td style="padding:8px 10px;white-space:nowrap"><a href="{jira_url}" target="_blank" style="color:#1a6fb5;font-weight:600;">{jira_key}</a></td>
      <td style="padding:8px 10px;color:#1f2937;max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{esc((ct['summary'] or '')[:100])}</td>
      <td style="padding:8px 10px"><span style="color:{status_color};font-weight:600;">{esc(ct['status'])}</span></td>
      <td style="padding:8px 10px;color:{res_color};">{esc(res)}</td>
      <td style="padding:8px 10px;color:#374151;">{esc(ct['assignee'])}</td>
      <td style="padding:8px 10px;color:#6b7280;white-space:nowrap;">{esc(ct['updated'])}</td>
      <td style="text-align:right;padding:8px 10px;font-weight:700;color:{'#dc2626' if has_post_close else '#6b7280'};">{events_cell}</td>
      <td style="padding:8px 10px;">{fallout_cell}</td>
    </tr>
""")

    parts.append("  </table>\n  </div>\n</div>\n")
    return "\n".join(parts)


# ─── Ticket clustering helpers ───
def extract_bpm_task(text):
    """Extract BPM task name from ticket summary/description."""
    if not text:
        return None
    m = re.search(r'\b([A-Za-z]+(?:Task|Activity|Event|Gateway|Call))\b', text)
    if m:
        return m.group(1)
    # Try activity patterns like "invokeBoCapability*"
    m = re.search(r'\b(invoke\w+|check\w+|submit\w+|send\w+|create\w+|process\w+|notify\w+|request\w+|cancel\w+|complete\w+)\b', text, re.IGNORECASE)
    if m:
        return m.group(1)
    return None

def extract_error_type_from_ticket(text):
    """Extract exception/error type from ticket summary/description."""
    if not text:
        return None
    m = re.search(r'\b(\w*Exception|\w*Error|NPE|NullPointer|Timeout|FeignException|IllegalState\w*|ResourceException)\b', text, re.IGNORECASE)
    if m:
        return m.group(1)
    return None

def find_ticket_clusters(board_tickets):
    """Group tickets by shared error pattern / BPM activity to identify clusters."""
    clusters = defaultdict(list)
    for tk_key, tk in board_tickets.items():
        summary = tk.get("summary", "")
        desc = (tk.get("description", "") or "")[:500]
        text = summary + " " + desc

        # Cluster by BPM task
        task = extract_bpm_task(summary)
        error = extract_error_type_from_ticket(summary)

        # Extract the service | task | error pattern from summary (common format: "Service | Task | Error")
        parts = [p.strip() for p in summary.split("|")]
        if len(parts) >= 2:
            cluster_key = parts[1].strip()  # BPM task name
            clusters[cluster_key].append(tk_key)
        elif task:
            clusters[task].append(tk_key)

        # Also cluster by error type
        if error:
            clusters[f"error:{error}"].append(tk_key)

    # Filter to clusters with 2+ tickets and deduplicate
    real_clusters = {}
    for key, tks in clusters.items():
        if len(tks) >= 2:
            tks_frozen = frozenset(tks)
            # Don't add if this is a subset of an existing cluster
            is_subset = any(tks_frozen <= existing for existing in real_clusters.values())
            if not is_subset:
                real_clusters[key] = tks_frozen

    # Merge clusters that share >50% of tickets
    merged = {}
    used = set()
    for k1, tks1 in sorted(real_clusters.items(), key=lambda x: -len(x[1])):
        if k1 in used:
            continue
        merged_tks = set(tks1)
        merged_name = k1
        for k2, tks2 in real_clusters.items():
            if k2 == k1 or k2 in used:
                continue
            overlap = len(tks1 & tks2)
            if overlap >= len(tks2) * 0.5:
                merged_tks |= tks2
                used.add(k2)
        used.add(k1)
        merged[merged_name] = merged_tks

    return merged


# ─── Build per-board analysis ───
os.makedirs(SIGNAL_DIR, exist_ok=True)
boards = sorted(set(t["prefix"] for t in tickets_list if t["prefix"] not in ("BPWB", "CMXOTD")))

for board in boards:
    board_tickets = {k: v for k, v in tickets_by_key.items() if k.startswith(board)}
    board_ticket_list = [t for t in tickets_list if t["prefix"] == board]

    if len(board_ticket_list) < 2:
        continue

    print(f"\n{'='*60}")
    print(f"Processing {board}: {len(board_ticket_list)} tickets")

    # Get APPs that belong to this board
    board_apps = [app for app, b in APP_BOARD_MAP.items() if b == board]

    # ─── Fallout data for this board (derived from detail) ───
    board_fallout = []
    for app in board_apps:
        board_fallout.extend(fallout_by_app.get(app, []))

    # Per-app totals and daily trends (all from fallout detail)
    board_fallout_by_app = {app: len(fallout_by_app.get(app, [])) for app in board_apps if fallout_by_app.get(app)}
    board_fallout_total = sum(board_fallout_by_app.values())
    board_fallout_daily = {app: dict(fallout_daily.get(app, {})) for app in board_apps if fallout_daily.get(app)}

    # ─── Error groups for this board ───
    board_error_groups = {}
    for (app, act, err_cls), info in error_groups.items():
        if app in board_apps:
            board_error_groups[(app, act, err_cls)] = info

    # ─── Match tickets to error groups ───
    matched_groups = {}   # error_group_key → list of matching ticket keys
    unmatched_groups = {} # error_group_key → info (no ticket covers this)

    for gkey, ginfo in sorted(board_error_groups.items(), key=lambda x: -x[1]["count"]):
        app, act, err_cls = gkey
        sample_msg = ginfo.get("sample_msg", "")
        matches = []
        for tk_key, tk in board_tickets.items():
            score = ticket_matches_error(tk, app, act, sample_msg)
            if score >= 2:
                matches.append((tk_key, score))
        matches.sort(key=lambda x: -x[1])
        if matches:
            matched_groups[gkey] = matches
        else:
            unmatched_groups[gkey] = ginfo

    print(f"  Fallout ({data_window_days}d): {board_fallout_total:,} instances across {len(board_fallout_by_app)} apps")
    print(f"  Error groups: {len(board_error_groups)} total, {len(matched_groups)} matched, {len(unmatched_groups)} unmatched")

    # ─── Closed ticket analysis for this board ───
    board_closed = closed_by_board.get(board, [])
    board_closed_keys = {t["key"] for t in board_closed}
    board_closed_data = []  # detailed per-ticket analysis
    # Reverse index: gkey → [(ct_key, events_after_close)] for ALL matching closed tickets
    # Used by error groupings table to show closed-ticket status per error group
    closed_by_gkey = defaultdict(list)

    for ct in board_closed:
        ct_key = ct["key"]
        ct_summary = ct.get("summary", "")
        ct_status = ct.get("status", "")
        ct_resolution = ct.get("resolution")
        ct_assignee = ct.get("assignee", "Unassigned")
        closed_date = ct.get("updated", "")[:10]  # last updated = proxy for close date

        # Match this closed ticket to fallout error groups
        best_match = None
        events_after_close = 0
        for gkey, ginfo in board_error_groups.items():
            app, act, err_cls = gkey
            score = ticket_matches_error({"summary": ct_summary, "description": ""}, app, act, ginfo.get("sample_msg", ""))
            if score >= 2:
                # Count fallout events that occurred AFTER the ticket close date
                after_events = 0
                if closed_date:
                    after_events = sum(
                        1 for r in fallout_by_combo.get((app, act), [])
                        if r.get("START_TIME", "")[:10] > closed_date
                    )
                # Always record in reverse index (ALL matching groups, not just best)
                closed_by_gkey[gkey].append((ct_key, after_events))
                # Track best match per ticket (for the per-ticket summary card)
                if best_match is None or ginfo["count"] > best_match["total_events"]:
                    best_match = {
                        "gkey": gkey, "total_events": ginfo["count"],
                        "app": app, "act": act, "err_cls": err_cls,
                    }
                    events_after_close = after_events

        board_closed_data.append({
            "key": ct_key,
            "status": ct_status,
            "resolution": ct_resolution,
            "summary": ct_summary,
            "assignee": ct_assignee,
            "updated": closed_date,
            "has_fallout_match": best_match is not None,
            "fallout_app": best_match["app"] if best_match else None,
            "fallout_act": best_match["act"] if best_match else None,
            "fallout_total": best_match["total_events"] if best_match else 0,
            "events_after_close": events_after_close,
        })

    # Closed-ticket insights (deferred to after insights=[] is initialized below)
    _closed_insights_prepend = []  # goes at front (post-close fallout alert)
    _closed_insights_append = []   # goes at end (Won't Fix, summary count)
    if board_closed_data:
        closed_still_active = [ct for ct in board_closed_data if ct["events_after_close"] > 0]
        closed_count_board = len(board_closed_data)
        if closed_still_active:
            top_3 = sorted(closed_still_active, key=lambda x: -x["events_after_close"])[:3]
            top_str = ", ".join(f"{ct['key']} ({ct['events_after_close']} events post-close)" for ct in top_3)
            _closed_insights_prepend.append(
                f"🔴 <strong>Closed Tickets w/ Active Fallout ({len(closed_still_active)}):</strong> "
                f"{top_str}. Verify root cause was actually resolved — production fallout is still occurring."
            )
        wont_fix_keys = [
            ct for ct in board_closed_data
            if (ct.get("resolution") or "").lower() in
               ("won't fix", "wont fix", "won't do", "wontdo", "duplicate", "not a bug")
        ]
        if wont_fix_keys:
            wf_str = ", ".join(ct["key"] for ct in wont_fix_keys[:3])
            _closed_insights_append.append(
                f"🗑 <strong>Won't Fix / Duplicate ({len(wont_fix_keys)}):</strong> "
                f"{wf_str} closed as Won't Fix or Duplicate. "
                f"Confirm no active fallout is attributable to these patterns."
            )
        _closed_insights_append.append(
            f"✅ <strong>Closed (Last 3 Weeks):</strong> {closed_count_board} ticket(s) recently closed "
            f"({'⚠ ' + str(len(closed_still_active)) + ' still have post-close fallout' if closed_still_active else 'no post-close fallout detected'})."
        )

    # ─── Ticket analysis: detect stalled, blocked, clusters, etc. ───
    tier_overrides = {}
    special_flags = {}
    insights = []
    per_ticket_actions = []
    weekly_actions = []
    extra_stats = []
    assignee_callouts = []
    workflow_insights = []

    # Analyze each ticket — collect signals
    stalled_tickets = []
    blocked_tickets = []
    unassigned_high = []
    unassigned_count = 0
    needs_triage = 0
    recommend_cancel_count = 0
    in_test_tickets = []
    incident_linked = []
    old_not_started = []

    for tk_key, tk in board_tickets.items():
        status = tk.get("status", "")
        priority = tk.get("priority", "Medium")
        assignee = tk.get("assignee", "Unassigned")
        summary = tk.get("summary", "")
        desc = (tk.get("description", "") or "")
        created = tk.get("created", "")
        updated = tk.get("updated", "")
        comments = tk.get("recent_comments", [])
        linked = tk.get("linked_issues", [])

        # Age calculation
        age_days = 0
        if created:
            try:
                created_dt = datetime.strptime(created[:10], "%Y-%m-%d")
                age_days = (datetime.now() - created_dt).days
            except: pass

        last_update_days = 0
        if updated:
            try:
                updated_dt = datetime.strptime(updated[:10], "%Y-%m-%d")
                last_update_days = (datetime.now() - updated_dt).days
            except: pass

        # Comment count and last comment age
        comment_count = len(comments) if isinstance(comments, list) else 0

        # Stalled detection: In Progress but no update in 14+ days and zero/few comments
        if status == "In Progress" and last_update_days > 14:
            stalled_tickets.append({
                "key": tk_key, "assignee": assignee, "age": age_days,
                "last_update": last_update_days, "comments": comment_count,
                "summary": summary
            })
            special_flags[tk_key] = ["stalled", f"In Progress but no update for {last_update_days}d"]

        # Blocked detection
        if status == "Blocked":
            blocked_tickets.append({
                "key": tk_key, "assignee": assignee, "age": age_days,
                "summary": summary
            })
            special_flags.setdefault(tk_key, ["blocked", "Status: Blocked"])
            # Blocked tickets with specific owners get T1 action
            per_ticket_actions.append({
                "key": tk_key, "tier": 1,
                "action": f"Document blocker for {summary.split('|')[1].strip() if '|' in summary else summary[:60]} — Blocked {age_days}d. {assignee} to identify blocking dependency or recommend cancellation.",
                "color": "red"
            })
            tier_overrides[tk_key] = [1, f"Blocked for {age_days} days"]
            weekly_actions.append({
                "urgency": "today",
                "action": f"Document blocker for {tk_key} ({summary[:60]}) or recommend cancellation",
                "ticket": tk_key,
                "owner": assignee if assignee != "Unassigned" else "Team Lead"
            })

        # Unassigned tracking
        if assignee == "Unassigned":
            unassigned_count += 1
            if priority in ("Critical", "Highest", "High"):
                unassigned_high.append(tk_key)
                needs_triage += 1
                if priority in ("Critical", "Highest"):
                    per_ticket_actions.append({
                        "key": tk_key, "tier": 1,
                        "action": f"{priority} priority but unassigned — assign immediately.",
                        "color": "red"
                    })
                    tier_overrides[tk_key] = [1, f"{priority} priority, unassigned"]

        # Old tickets not progressing → recommend cancel
        if age_days > 180 and status in ("Not Started", "Open") and priority in ("Medium", "Low"):
            recommend_cancel_count += 1
        if age_days > 90 and status in ("Not Started", "Open"):
            old_not_started.append({"key": tk_key, "age": age_days, "priority": priority, "summary": summary})

        # In Test status
        if status == "Test":
            in_test_tickets.append({"key": tk_key, "assignee": assignee, "summary": summary})
            per_ticket_actions.append({
                "key": tk_key, "tier": 3,
                "action": f"Verify test results and track to release.",
                "color": "green"
            })

        # Check for incident linkage in description/comments/summary
        inc_match = re.search(r'(INC\d{8,}|CAS\d{7,}|Sev[123])', desc + " " + summary)
        if inc_match:
            incident_linked.append({"key": tk_key, "incident": inc_match.group(1)})
            special_flags[tk_key] = ["sev3", f"Incident ref: {inc_match.group(1)}"]
            tier_overrides[tk_key] = [1, f"Incident linkage: {inc_match.group(1)}"]

        # Ticket→Tableau correlation: check if this ticket has matching fallout
        best_fallout_match = None
        for gkey in board_error_groups:
            app, act, err_cls = gkey
            score = ticket_matches_error(tk, app, act, board_error_groups[gkey].get("sample_msg", ""))
            fallout_count = board_error_groups[gkey]["count"]
            if score >= 3 and fallout_count >= 3:
                if best_fallout_match is None or fallout_count > best_fallout_match[1]:
                    best_fallout_match = (gkey, fallout_count, score)
            elif score >= 2 and fallout_count >= 5:
                if best_fallout_match is None or fallout_count > best_fallout_match[1]:
                    best_fallout_match = (gkey, fallout_count, score)

        if best_fallout_match:
            gkey, fallout_count, score = best_fallout_match
            app, act, err_cls = gkey
            # Promote medium/low tickets with active high-volume fallout
            if priority in ("Medium", "Low") and fallout_count >= 5:
                tier_overrides.setdefault(tk_key, [2, f"Active fallout: {fallout_count} events today at {act}"])
                per_ticket_actions.append({
                    "key": tk_key, "tier": 2,
                    "action": f"Has {fallout_count} active fallout events in prod today ({app} → {act}). Consider escalating.",
                    "color": "orange"
                })

    # ─── Stalled ticket actions (for T2 tier) ───
    for st in stalled_tickets:
        per_ticket_actions.append({
            "key": st["key"], "tier": 2,
            "action": f"De-facto stalled — In Progress {st['last_update']}d, {st['comments']} comments. {st['assignee']} to update or move to Not Started for reassignment.",
            "color": "purple"
        })
        tier_overrides.setdefault(st["key"], [2, f"Stalled {st['last_update']}d — no update"])
        weekly_actions.append({
            "urgency": "today",
            "action": f"Update stalled ticket {st['key']} ({st['last_update']}d no update) — either resume or reassign",
            "ticket": st["key"],
            "owner": st["assignee"] if st["assignee"] != "Unassigned" else "Team Lead"
        })

    # ─── Ticket clustering ───
    clusters = find_ticket_clusters(board_tickets)
    for cluster_name, cluster_tks in sorted(clusters.items(), key=lambda x: -len(x[1])):
        if cluster_name.startswith("error:"):
            error_type = cluster_name.split(":", 1)[1]
            tks_str = ", ".join(sorted(cluster_tks)[:5])
            if len(cluster_tks) > 5:
                tks_str += f" (+{len(cluster_tks) - 5} more)"
            insights.append(
                f"📊 <strong>{error_type} Cluster ({len(cluster_tks)} tickets):</strong> "
                f"{tks_str} share the same error pattern. "
                f"Investigate shared root cause."
            )
        else:
            tks_str = ", ".join(sorted(cluster_tks)[:5])
            if len(cluster_tks) > 5:
                tks_str += f" (+{len(cluster_tks) - 5} more)"
            # Get the dominant error type from the cluster
            cluster_errors = set()
            for tk_key in cluster_tks:
                if tk_key in board_tickets:
                    err = extract_error_type_from_ticket(board_tickets[tk_key].get("summary", ""))
                    if err:
                        cluster_errors.add(err)
            err_desc = f" — {', '.join(cluster_errors)}" if cluster_errors else ""
            insights.append(
                f"📊 <strong>{cluster_name} Sub-cluster ({len(cluster_tks)} tickets):</strong> "
                f"{tks_str}{err_desc}. "
                f"These likely share a common root cause."
            )
            # Add weekly action for large clusters
            if len(cluster_tks) >= 3:
                weekly_actions.append({
                    "urgency": "follow-up",
                    "action": f"Investigate {cluster_name} cluster — {len(cluster_tks)} tickets with shared root cause",
                    "ticket": sorted(cluster_tks)[0],
                    "owner": "Team Lead"
                })

    # ─── Build insights ───
    total_tks = len(board_tickets)

    # Unassigned count insight
    if unassigned_count > 0:
        pct = 100 * unassigned_count // total_tks if total_tks > 0 else 0
        if pct >= 40:
            insights.insert(0,
                f"🔴 <strong>{unassigned_count} of {total_tks} tickets are Unassigned ({pct}%):</strong> "
                f"{'The majority' if pct >= 60 else 'A large portion'} of {board} fallout has no owner. "
                f"Without assignment, these tickets will age indefinitely. "
                f"Batch-assign the T2/T3 tickets first."
            )
            weekly_actions.insert(0, {
                "urgency": "today",
                "action": f"Assign {unassigned_count} Unassigned tickets — prioritize T2/T3 and high-fallout tickets first",
                "ticket": unassigned_high[0] if unassigned_high else sorted(board_tickets.keys())[0],
                "owner": "Team Lead"
            })

    # Stalled insight
    if stalled_tickets:
        stalled_names = ", ".join(f"{s['key']} ({s['assignee']})" for s in stalled_tickets[:3])
        if len(stalled_tickets) > 3:
            stalled_names += f" (+{len(stalled_tickets) - 3} more)"
        insights.insert(0 if not unassigned_count else 1,
            f"⏸ <strong>De-facto stalled ({len(stalled_tickets)} tickets):</strong> "
            f"{stalled_names} have been In Progress with no updates. "
            f"These are effectively abandoned and should be actively worked or reassigned."
        )

    # Blocked insight
    if blocked_tickets:
        blocked_str = ", ".join(f"{b['key']} ({b['assignee']}, {b['age']}d)" for b in blocked_tickets)
        insights.insert(0,
            f"🚨 <strong>Blocked ({len(blocked_tickets)} tickets):</strong> "
            f"{blocked_str}. "
            f"Identify blocking dependencies or recommend cancellation."
        )

    # In Test insight
    if in_test_tickets:
        test_str = ", ".join(f"{t['key']} ({t['assignee']})" for t in in_test_tickets)
        insights.append(
            f"✅ <strong>In Test ({len(in_test_tickets)}):</strong> "
            f"{test_str}. Verify test completion and track to release."
        )

    # Incident linkage insight
    if incident_linked:
        inc_str = ", ".join(f"{il['key']} → {il['incident']}" for il in incident_linked)
        insights.insert(0,
            f"🚨 <strong>Incident-linked ({len(incident_linked)} tickets):</strong> "
            f"{inc_str}. These require immediate attention."
        )

    # Tableau summary insights (placed after ticket-specific insights)
    if board_fallout_total > 0:
        today_board = sum(1 for r in board_fallout if r.get("START_TIME", "")[:10] == TODAY)
        insights.append(f"📊 <strong>Fallout ({data_window_days}d window):</strong> {board_fallout_total:,} total fallout instances across {len(board_fallout_by_app)} BPM apps")
        if today_board > 0:
            insights.append(f"🔴 <strong>Active Fallout (today):</strong> {today_board} failure events currently in prod")

    # Unmatched fallout insights and actions
    if unmatched_groups:
        top_unmatched = sorted(unmatched_groups.items(), key=lambda x: -x[1]["count"])[:3]
        for (app, act, err_cls), info in top_unmatched:
            today_u = info.get("today_count", 0)
            today_note = f", {today_u} today" if today_u > 0 else ""
            insights.append(
                f"🚨 <strong>No Ticket for {app} → {act}:</strong> "
                f"{info['count']} fallout events ({err_cls}{today_note}). Sample: {info['sample_msg'][:80]}"
            )
            weekly_actions.append({
                "urgency": "triage",
                "action": f"Create ticket for {app} → {act} ({err_cls}, {info['count']} events in {data_window_days}d)",
                "ticket": "NEW",
                "owner": "Team Lead"
            })

    # ─── Merge closed-ticket insights (deferred from above) ───
    # Prepend high-urgency closed insights, append informational ones
    insights = _closed_insights_prepend + insights + _closed_insights_append

    # ─── Workflow insights ───
    status_dist = Counter(tk.get("status", "") for tk in board_tickets.values())
    if total_tks > 0:
        in_prog = status_dist.get("In Progress", 0)
        not_started = status_dist.get("Not Started", 0) + status_dist.get("Open", 0)
        if not_started / total_tks > 0.6:
            workflow_insights.append(f"{not_started}/{total_tks} tickets ({100*not_started//total_tks}%) are Not Started — consider a triage session to prioritize")
        if in_prog / total_tks > 0.4:
            workflow_insights.append(f"{in_prog}/{total_tks} tickets ({100*in_prog//total_tks}%) are In Progress — check for WIP limit violations")

    # ─── Extra stats ───
    if stalled_tickets:
        extra_stats.append({"value": len(stalled_tickets), "label": "De-facto Stalled", "color": "#6b21a8", "bg": "#faf5ff"})
    if blocked_tickets:
        extra_stats.append({"value": len(blocked_tickets), "label": "Blocked", "color": "#7c2d12", "bg": "#fff7ed"})
    if needs_triage > 0:
        extra_stats.append({"value": needs_triage, "label": "Needs Triage", "color": "#b45309", "bg": "#fffbeb"})
    if recommend_cancel_count > 0:
        extra_stats.append({"value": recommend_cancel_count, "label": "Recommend Cancel/Defer", "color": "#374151", "bg": "#f3f4f6"})
    if unmatched_groups:
        extra_stats.append({"value": len(unmatched_groups), "label": "Fallout w/o Ticket", "color": "#dc2626", "bg": "#fef2f2"})
    if unassigned_count > 0:
        extra_stats.append({"value": unassigned_count, "label": "Unassigned", "color": "#b45309", "bg": "#fffbeb"})

    # ─── Assignee workload analysis ───
    assignee_tickets = defaultdict(list)
    for tk_key, tk in board_tickets.items():
        a = tk.get("assignee", "Unassigned")
        assignee_tickets[a].append(tk_key)

    for assignee, tks in assignee_tickets.items():
        if assignee == "Unassigned": continue
        if len(tks) >= 4:
            stalled_tks = [k for k in tks if k in special_flags and special_flags[k][0] == "stalled"]
            if stalled_tks:
                assignee_callouts.append({
                    "text": f"⚠ <strong>{assignee}</strong> has {len(tks)} tickets, {len(stalled_tks)} stalled ({', '.join(stalled_tks[:3])}). Consider redistributing.",
                    "color": "#6b21a8", "bg": "#faf5ff"
                })
            elif len(tks) >= 5:
                assignee_callouts.append({
                    "text": f"⚠ <strong>{assignee}</strong> has {len(tks)} tickets. Monitor workload.",
                    "color": "#b45309", "bg": "#fffbeb"
                })

    # ─── Deduplicate weekly_actions ───
    seen_actions = set()
    deduped_actions = []
    urgency_order = {"immediate": 0, "today": 1, "escalate": 2, "follow-up": 3, "verify": 4, "close": 5, "cancel": 6, "triage": 7, "queue": 8}
    for wa in sorted(weekly_actions, key=lambda x: urgency_order.get(x.get("urgency", "queue"), 9)):
        action_key = (wa.get("ticket", ""), wa.get("urgency", ""))
        if action_key not in seen_actions:
            seen_actions.add(action_key)
            deduped_actions.append(wa)
    weekly_actions = deduped_actions[:12]  # Cap at 12 entries

    # ─── Extra stat for closed tickets ───
    if board_closed_data:
        still_active_count = sum(1 for ct in board_closed_data if ct["events_after_close"] > 0)
        label = f"Closed (3 wks){f' ⚠ {still_active_count} w/fallout' if still_active_count else ''}"
        extra_stats.append({
            "value": len(board_closed_data),
            "label": label,
            "color": "#dc2626" if still_active_count else "#166534",
            "bg": "#fef2f2" if still_active_count else "#f0fdf4",
        })

    # ─── Build Tableau section HTML ───
    tableau_html = build_tableau_section(
        board, board_apps, board_fallout_by_app, board_fallout_total,
        board_fallout, board_error_groups, matched_groups, unmatched_groups,
        board_fallout_daily, all_days_sorted,
        closed_by_gkey=closed_by_gkey,
    )
    closed_html = build_closed_section(board, board_closed_data)
    combined_tableau_html = tableau_html + closed_html

    # ─── Write signal file ───
    signal = {
        "tier_overrides": tier_overrides,
        "special_flags": special_flags,
        "insights": insights,
        "per_ticket_actions": per_ticket_actions,
        "weekly_actions": weekly_actions,
        "extra_stats": extra_stats,
        "assignee_callouts": assignee_callouts,
        "workflow_insights": workflow_insights,
        "tableau_section": combined_tableau_html,
        "closed_tickets": board_closed_data,
        "closed_count": len(board_closed_data),
    }

    outfile = os.path.join(SIGNAL_DIR, f"{board.lower()}.json")
    with open(outfile, "w", encoding="utf-8") as f:
        json.dump(signal, f, indent=2, default=str)
    print(f"  Signal file: {outfile} ({os.path.getsize(outfile):,} bytes)")


# ─── Run ───
if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("All signal files generated. Run the report generator next.")
    print("Signal dir:", SIGNAL_DIR)
    for f in sorted(glob.glob(SIGNAL_DIR + "/*.json")):
        print(f"  {f} ({os.path.getsize(f):,} bytes)")
