#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# AI Adoption PR Collector
# Collects all PRs with activity (created, merged, reviewed, commented) in the
# last 24h across comcast-modesto org. All statuses (open, closed, merged) are
# included. Output: pipe-delimited rows to stdout; diagnostics to stderr.
# Ends with "# COMPLETE" sentinel when all PRs are processed.
#
# Usage:
#   bash collect-prs.sh 2>/tmp/pr-report-errors.log | tee /tmp/pr-report-output.txt
#
# Requirements: gh (GitHub CLI) authenticated, jq, python3|python|date -v
# Bash 3.2+ compatible (no associative arrays).
# ─────────────────────────────────────────────────────────────────────────────
set -o pipefail

# ── File-based name cache (works on bash 3.2+ — no associative arrays) ──
NAME_CACHE_FILE="/tmp/pr-report-name-cache.txt"
> "$NAME_CACHE_FILE"

# ── Error log (captures gh failures instead of hiding them) ──
ERROR_LOG="/tmp/pr-report-errors.log"
> "$ERROR_LOG"

get_team() {
  local title="$1"
  # Extract Jira ticket prefix dynamically — catches any CMXOT* or BPWB pattern
  if [[ "$title" =~ (CMXOT[A-Z0-9]+|BPWB)-[0-9]+ ]]; then
    echo "${BASH_REMATCH[1]}"
  else
    echo "—"
  fi
}

get_name() {
  local login="$1"
  if [[ -z "$login" || "$login" == "null" ]]; then echo ""; return; fi
  if [[ "$login" == *"[bot]"* ]]; then echo "$login"; return; fi
  # Guard: API error JSON bled in as a login value — skip it
  if [[ "$login" == "{"* ]]; then echo ""; return; fi
  # Check file cache
  local cached
  cached=$(grep "^${login}	" "$NAME_CACHE_FILE" 2>/dev/null | head -1 | cut -f2-)
  if [[ -n "$cached" ]]; then echo "$cached"; return; fi
  local name
  name=$(gh api "users/$login" --jq '.name // .login' 2>/dev/null || echo "$login")
  if [[ -z "$name" || "$name" == "null" ]]; then name="$login"; fi
  printf '%s\t%s\n' "$login" "$name" >> "$NAME_CACHE_FILE"
  echo "$name"
}

# ── Compute 24h-ago timestamp (cross-platform) ──
SINCE=$(python3 -c "from datetime import datetime,timedelta; print((datetime.utcnow()-timedelta(hours=24)).strftime('%Y-%m-%dT%H:%M:%S'))" 2>/dev/null \
  || python -c "from datetime import datetime,timedelta; print((datetime.utcnow()-timedelta(hours=24)).strftime('%Y-%m-%dT%H:%M:%S'))" 2>/dev/null \
  || date -v-24H '+%Y-%m-%dT%H:%M:%S' 2>/dev/null)
if [[ -z "$SINCE" ]]; then
  echo "ERROR: Could not compute SINCE timestamp. Need python3, python, or macOS date." >&2
  exit 1
fi
# SINCE_UTC: precise 24h-ago ISO timestamp for the per-PR time guard.
# SINCE_DATE: date-only (YYYY-MM-DD) for --updated search (slightly wider net).
# Single search with --updated catches both new and recently-merged PRs because
# creation and merge both update the PR. The per-PR guard below filters precisely
# using the authoritative created_at and merged_at from the REST API.
SINCE_UTC="${SINCE}Z"
SINCE_DATE="${SINCE:0:10}"
echo "# SINCE=$SINCE SINCE_UTC=$SINCE_UTC SINCE_DATE=$SINCE_DATE" >&2

# ── Search: all PRs updated (created, merged, reviewed) in the window ──
prs_json=$(gh search prs --owner comcast-modesto --updated ">=$SINCE_DATE" --limit 1000 --json number,title,repository,author,createdAt,url --sort updated --order desc 2>>"$ERROR_LOG")
if [[ $? -ne 0 || -z "$prs_json" ]]; then
  echo "WARN: gh search prs --updated failed or empty. Check $ERROR_LOG" >&2
  prs_json="[]"
fi

# Diagnostic: log count so silent zero-result queries are detectable
pr_count=$(echo "$prs_json" | jq 'length')
echo "# search_count=$pr_count" >&2

# Pre-filter BEFORE per-PR API calls: exclude infra/config repos and PRs with no
# Jira ticket in the title. This avoids unnecessary gh api calls for PRs that
# generate-report.py would discard anyway (~40-50% of search results).
EXCLUDED_REPOS_JSON='["MobileBackOfficeConfig","MspRuleConfig","OT-Automation-BDD","OrderDynamicsBPM","concourse-pipelines","deployments","ot-data-pool","ot-vector","release-manifests","xm-ordertech-service-docs"]'
prs=$(echo "$prs_json" | jq -c --argjson excl "$EXCLUDED_REPOS_JSON" \
  '[.[] | (.repository.nameWithOwner | split("/")[1]) as $rn
    | select(($excl | index($rn)) == null)
    | select(.title | test("(CMXOT[A-Z0-9]+|BPWB)-[0-9]+"))
  ] | sort_by(.createdAt) | reverse | .[]')
filtered_count=$(echo "$prs" | grep -c '^{' 2>/dev/null || echo 0)
echo "# filtered_count=$filtered_count (after pre-filtering infra repos + no-ticket PRs)" >&2

echo "REPO|PR_NUM|TITLE|AUTHOR_LOGIN|AUTHOR_NAME|STATE|REVIEWERS|HAS_DOCS|TEAM|URL"

while IFS= read -r pr; do
  repo=$(echo "$pr" | jq -r '.repository.nameWithOwner')
  num=$(echo "$pr" | jq -r '.number')
  title=$(echo "$pr" | jq -r '.title' | tr '|' '-')
  author_login=$(echo "$pr" | jq -r '.author.login // empty')
  url=$(echo "$pr" | jq -r '.url')

  pr_data=$(gh api "repos/$repo/pulls/$num" --jq '{state: .state, merged: .merged_at, user: .user.login}' 2>>"$ERROR_LOG")
  if [[ -z "$pr_data" ]]; then
    echo "WARN: gh api repos/$repo/pulls/$num returned empty — PR skipped. See $ERROR_LOG" >&2
    echo "$repo|$num|$title|$author_login||FETCH_FAILED|||$(get_team "$title")|$url"
    continue
  fi
  state=$(echo "$pr_data" | jq -r '.state')
  merged=$(echo "$pr_data" | jq -r '.merged')

  # Set state to "merged" if the PR has a merged_at timestamp
  if [[ "$merged" != "null" && -n "$merged" ]]; then state="merged"; fi

  # If author_login is empty or "null", use .user.login from the PR detail
  if [[ -z "$author_login" || "$author_login" == "null" ]]; then
    author_login=$(echo "$pr_data" | jq -r '.user // empty')
  fi

  author_name=$(get_name "$author_login")

  # Reviewers
  reviewer_logins=""
  reviewer_raw=$(gh api "repos/$repo/pulls/$num/reviews" --jq '[.[].user.login] | unique | .[]' 2>>"$ERROR_LOG")
  if [[ $? -eq 0 && -n "$reviewer_raw" ]]; then
    reviewer_logins="$reviewer_raw"
  else
    reviewer_raw=$(gh api "repos/$repo/pulls/$num/requested_reviewers" --jq '.users[].login' 2>>"$ERROR_LOG")
    if [[ $? -eq 0 && -n "$reviewer_raw" ]]; then
      reviewer_logins="$reviewer_raw"
    fi
  fi

  # Separator is '; ' — NOT comma — because names contain commas (Last, First)
  reviewer_names=""
  while IFS= read -r rl; do
    if [[ -n "$rl" && "$rl" != "null" ]]; then
      rn=$(get_name "$rl")
      if [[ -n "$rn" ]]; then
        if [[ -n "$reviewer_names" ]]; then reviewer_names="$reviewer_names; $rn"; else reviewer_names="$rn"; fi
      fi
    fi
  done <<< "$reviewer_logins"

  has_docs=$(gh api "repos/$repo/pulls/$num/files" --jq '[.[].filename] | map(select(startswith("docs/generated/"))) | length' 2>>"$ERROR_LOG" || echo "0")
  # Guard: if API 404'd or jq produced empty/non-numeric output, default to 0
  if ! [[ "$has_docs" =~ ^[0-9]+$ ]]; then has_docs=0; fi
  if [ "$has_docs" -gt 0 ]; then docs_flag="YES"; else docs_flag="NO"; fi

  team=$(get_team "$title")

  echo "$repo|$num|$title|$author_login|$author_name|$state|$reviewer_names|$docs_flag|$team|$url"
done <<< "$prs"

# ── Completion sentinel — signals that all PRs have been processed ──
echo "# COMPLETE"
