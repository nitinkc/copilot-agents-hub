#!/usr/bin/env python3
"""
AI Adoption Report Generator
Reads pipe-delimited PR data from collect-prs.sh output, filters, computes stats,
and generates a self-contained HTML report.

Usage:
  python3 generate-report.py --input /tmp/pr-report-output.txt --output-dir docs/generated

The output file will be named ai-adoption-report-YYYY-MM-DD.html using today's date.
"""
import argparse
import csv
import html as html_mod
import json
import os
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone


# ─────────────────────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────────────────────

EXCLUDED_REPOS = {
    "MobileBackOfficeConfig",
    "MspRuleConfig",
    "OT-Automation-BDD",
    "OrderDynamicsBPM",
    "concourse-pipelines",
    "deployments",
    "ot-data-pool",
    "ot-vector",
    "release-manifests",
    "xm-ordertech-service-docs",
}


# ─────────────────────────────────────────────────────────────────────────────
# Parsing
# ─────────────────────────────────────────────────────────────────────────────

def parse_input(input_path):
    """Parse pipe-delimited PR data file. Skip comment lines and header."""
    prs = []
    with open(input_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\n")
            # Skip comments (diagnostics, sentinel) and empty lines
            if not line or line.startswith("#"):
                continue
            # Skip header row
            if line.startswith("REPO|PR_NUM|"):
                continue
            parts = line.split("|")
            if len(parts) < 10:
                continue
            repo_full = parts[0]  # e.g. comcast-modesto/RepoName
            repo_name = repo_full.split("/", 1)[1] if "/" in repo_full else repo_full
            prs.append({
                "repo_full": repo_full,
                "repo": repo_name,
                "num": int(parts[1]),
                "title": parts[2],
                "author_login": parts[3],
                "author_name": parts[4],
                "state": parts[5],
                "reviewers": parts[6],
                "has_docs": parts[7].strip().upper() == "YES",
                "team": parts[8],
                "url": parts[9],
            })
    return prs


def filter_prs(prs):
    """Apply exclusion rules: excluded repos, no-ticket PRs."""
    filtered = []
    for p in prs:
        if p["repo"] in EXCLUDED_REPOS:
            continue
        if p["team"] == "\u2014":  # em-dash = no ticket
            continue
        filtered.append(p)
    return filtered


# ─────────────────────────────────────────────────────────────────────────────
# Statistics
# ─────────────────────────────────────────────────────────────────────────────

def compute_stats(prs):
    """Compute all report statistics from filtered PRs."""
    total = len(prs)
    ai_prs = sum(1 for p in prs if p["has_docs"])
    merged = sum(1 for p in prs if p["state"] == "merged")
    open_ = sum(1 for p in prs if p["state"] == "open")
    closed = sum(1 for p in prs if p["state"] == "closed")
    adopt_pct = round(ai_prs / total * 100, 1) if total else 0

    # Team breakdown
    team_stats = defaultdict(lambda: {"total": 0, "ai": 0, "repos": set()})
    for p in prs:
        t = p["team"]
        team_stats[t]["total"] += 1
        if p["has_docs"]:
            team_stats[t]["ai"] += 1
        team_stats[t]["repos"].add(p["repo"])
    teams_sorted = sorted(
        team_stats.items(),
        key=lambda x: (
            -round(x[1]["ai"] / x[1]["total"] * 100 if x[1]["total"] else 0),
            -x[1]["total"],
        ),
    )

    # Author stats
    author_stats = defaultdict(
        lambda: {"name": "", "total": 0, "ai": 0, "merged": 0, "open": 0, "closed": 0, "teams": []}
    )
    for p in prs:
        a = p["author_login"]
        author_stats[a]["name"] = p.get("author_name") or a
        author_stats[a]["total"] += 1
        if p["has_docs"]:
            author_stats[a]["ai"] += 1
        if p["state"] == "merged":
            author_stats[a]["merged"] += 1
        elif p["state"] == "open":
            author_stats[a]["open"] += 1
        else:
            author_stats[a]["closed"] += 1
        author_stats[a]["teams"].append(p["team"])
    authors_sorted = sorted(author_stats.items(), key=lambda x: -x[1]["total"])

    # Reviewer stats (split on '; ')
    reviewer_stats = defaultdict(lambda: {"total": 0, "ai": 0, "teams": []})
    for p in prs:
        if not p.get("reviewers"):
            continue
        for rv in [r.strip() for r in p["reviewers"].split(";") if r.strip()]:
            if "[bot]" in rv:
                continue
            reviewer_stats[rv]["total"] += 1
            if p["has_docs"]:
                reviewer_stats[rv]["ai"] += 1
            reviewer_stats[rv]["teams"].append(p["team"])
    reviewers_sorted = sorted(reviewer_stats.items(), key=lambda x: -x[1]["total"])

    return {
        "total": total,
        "ai_prs": ai_prs,
        "merged": merged,
        "open": open_,
        "closed": closed,
        "adopt_pct": adopt_pct,
        "teams_sorted": teams_sorted,
        "team_stats": team_stats,
        "authors_sorted": authors_sorted,
        "reviewers_sorted": reviewers_sorted,
    }


# ─────────────────────────────────────────────────────────────────────────────
# HTML Generation
# ─────────────────────────────────────────────────────────────────────────────

CSS = """
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;background:#f8fafc;color:#1e293b;line-height:1.5}
.page{max-width:1280px;margin:0 auto;padding:24px 16px}
header{background:linear-gradient(135deg,#1e40af 0%,#3b82f6 100%);color:#fff;padding:32px 36px;border-radius:12px;margin-bottom:28px;box-shadow:0 4px 20px rgba(59,130,246,.25)}
header h1{font-size:1.75rem;font-weight:700;margin-bottom:6px}
header p{opacity:.85;font-size:.95rem}
.badge-period{display:inline-block;background:rgba(255,255,255,.2);padding:3px 12px;border-radius:20px;font-size:.8rem;margin-top:10px}
h2{font-size:1.1rem;font-weight:700;color:#1e40af;margin:28px 0 14px;border-bottom:2px solid #dbeafe;padding-bottom:6px}
.kpi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(155px,1fr));gap:14px;margin-bottom:8px}
.kpi-card{background:#fff;border-radius:10px;padding:18px 16px;box-shadow:0 1px 6px rgba(0,0,0,.07);text-align:center}
.kpi-card .val{font-size:2rem;font-weight:800;line-height:1.1}
.kpi-card .lbl{font-size:.75rem;color:#64748b;margin-top:4px;text-transform:uppercase;letter-spacing:.04em}
.blue .val{color:#2563eb}
.green .val{color:#16a34a}
.merged-c .val{color:#059669}
.open-c .val{color:#d97706}
.closed-c .val{color:#dc2626}
table{width:100%;border-collapse:collapse;background:#fff;border-radius:10px;overflow:hidden;box-shadow:0 1px 6px rgba(0,0,0,.07);margin-bottom:24px;font-size:.86rem}
thead th{background:#1e40af;color:#fff;padding:10px 12px;text-align:left;font-weight:600;font-size:.78rem;text-transform:uppercase;letter-spacing:.04em}
tbody tr:nth-child(even){background:#f8fafc}
tbody tr:hover{background:#eff6ff}
td{padding:9px 12px;border-bottom:1px solid #e2e8f0;vertical-align:middle}
.badge{display:inline-block;padding:2px 9px;border-radius:12px;font-size:.74rem;font-weight:600}
.badge-merged{background:#dcfce7;color:#166534}
.badge-open{background:#fef9c3;color:#854d0e}
.badge-closed{background:#fee2e2;color:#991b1b}
.badge-team{background:#e0e7ff;color:#3730a3}
.badge-ai{background:#dbeafe;color:#1e40af}
.badge-no{background:#f1f5f9;color:#64748b}
.progress-wrap{display:flex;align-items:center;gap:8px;min-width:120px}
.progress-bar{height:7px;border-radius:4px}
.progress-label{font-size:.8rem;color:#374151;white-space:nowrap}
a{color:#2563eb;text-decoration:none}
a:hover{text-decoration:underline}
.login{font-size:.74rem;color:#94a3b8}
footer{text-align:center;color:#94a3b8;font-size:.8rem;margin-top:36px;padding-top:16px;border-top:1px solid #e2e8f0}
.filter-bar{background:#fff;border-radius:10px;padding:14px 20px;margin-bottom:20px;box-shadow:0 1px 6px rgba(0,0,0,.07);display:flex;align-items:center;gap:12px;flex-wrap:wrap}
.filter-bar label{font-size:.9rem;color:#1e293b}
.filter-bar select{padding:6px 12px;border:1px solid #cbd5e1;border-radius:6px;font-size:.88rem;color:#1e293b;background:#f8fafc;cursor:pointer}
.filter-bar select:focus{outline:none;border-color:#3b82f6;box-shadow:0 0 0 2px rgba(59,130,246,.2)}
.filter-count{font-size:.82rem;color:#64748b;margin-left:auto}
"""


def pct(a, b):
    return round(a / b * 100, 1) if b else 0


def esc(s):
    return html_mod.escape(str(s or ""))


def state_badge(s):
    cls = {"merged": "badge-merged", "open": "badge-open", "closed": "badge-closed"}.get(s, "badge-open")
    return f'<span class="badge {cls}">{esc(s)}</span>'


def team_badge(t):
    return f'<span class="badge badge-team">{esc(t)}</span>'


def ai_badge(has):
    if has:
        return '<span class="badge badge-ai">YES</span>'
    return '<span class="badge badge-no">NO</span>'


def progress_bar(pct_val):
    color = "#22c55e" if pct_val >= 50 else "#f59e0b" if pct_val >= 25 else "#ef4444"
    return (
        f'<div class="progress-wrap">'
        f'<div class="progress-bar" style="width:{pct_val}%;background:{color}"></div>'
        f'<span class="progress-label">{pct_val}%</span></div>'
    )


def generate_html(prs, stats, date_display, date_slug, period):
    """Generate the full HTML report string."""
    out = []
    out.append(f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>OrderTech AI-Agent Adoption Report \u2014 {date_display}</title>
<style>{CSS}</style>
</head>
<body>
<div class="page">
<header>
  <h1>OrderTech AI-Agent Adoption Report \u2014 {date_display}</h1>
  <p>PR activity across the comcast-modesto org</p>
  <span class="badge-period">&#128197; {period}</span>
</header>""")

    # Team filter dropdown
    teams = sorted(set(p["team"] for p in prs))
    team_options = ''.join(f'<option value="{esc(t)}">{esc(t)}</option>' for t in teams)
    pr_data_json = json.dumps([{"team": p["team"], "ai": p["has_docs"], "state": p["state"]} for p in prs])
    out.append(
        f'<div class="filter-bar">'
        f'<label for="team-filter"><strong>Filter by Team:</strong></label>'
        f'<select id="team-filter">'  # onchange wired via addEventListener — CSP-safe for Teams/SharePoint
        f'<option value="ALL" selected>All Teams</option>'
        f'{team_options}'
        f'</select>'
        f'<span id="filter-count" class="filter-count"></span>'
        f'</div>'
        f'<noscript><div style="background:#fef3c7;border:1px solid #f59e0b;border-radius:8px;padding:10px 16px;margin-bottom:16px;font-size:.88rem">'
        f'&#9888;&#65039; Team filter requires JavaScript. To use it, download and open this file in a browser (Chrome, Edge, or Firefox).'
        f'</div></noscript>'
    )

    # Section 1 - KPIs
    out.append('<h2>&#128202; Executive Summary</h2>')
    out.append('<div class="kpi-grid">')
    out.append(f'<div class="kpi-card blue"><div class="val" id="kpi-total">{stats["total"]}</div><div class="lbl">Total PRs</div></div>')
    out.append(f'<div class="kpi-card blue"><div class="val" id="kpi-ai">{stats["ai_prs"]}</div><div class="lbl">AI-Agent PRs</div></div>')
    out.append(f'<div class="kpi-card green"><div class="val" id="kpi-adopt">{stats["adopt_pct"]}%</div><div class="lbl">AI Adoption</div></div>')
    out.append(f'<div class="kpi-card merged-c"><div class="val" id="kpi-merged">{stats["merged"]}</div><div class="lbl">Merged</div></div>')
    out.append(f'<div class="kpi-card open-c"><div class="val" id="kpi-open">{stats["open"]}</div><div class="lbl">Open</div></div>')
    out.append(f'<div class="kpi-card closed-c"><div class="val" id="kpi-closed">{stats["closed"]}</div><div class="lbl">Closed</div></div>')
    out.append("</div>")

    # Section 2 - Team Breakdown
    out.append('<h2>&#128101; Team Breakdown</h2>')
    out.append(
        '<table id="team-table"><thead><tr>'
        "<th>Team</th><th>Total PRs</th><th>AI PRs</th><th>Adoption %</th>"
        '<th>Repos</th><th style="min-width:150px">Progress</th>'
        "</tr></thead><tbody>"
    )
    for team, s in stats["teams_sorted"]:
        ap = pct(s["ai"], s["total"])
        repos_str = ", ".join(sorted(s["repos"]))
        out.append(
            f'<tr data-team="{esc(team)}">'
            f"<td>{team_badge(team)}</td>"
            f'<td style="text-align:center">{s["total"]}</td>'
            f'<td style="text-align:center">{s["ai"]}</td>'
            f'<td style="text-align:center"><strong>{ap}%</strong></td>'
            f'<td style="font-size:.78rem;color:#475569">{esc(repos_str)}</td>'
            f"<td>{progress_bar(ap)}</td>"
            f"</tr>"
        )
    out.append("</tbody></table>")

    # Section 3 - Author Stats
    out.append('<h2>&#128110; Author Stats</h2>')
    out.append(
        '<table id="author-table"><thead><tr>'
        "<th>Author</th><th>Team</th><th>Total PRs</th><th>AI PRs</th>"
        "<th>Adoption %</th><th>Merged</th><th>Open</th><th>Closed</th>"
        "</tr></thead><tbody>"
    )
    for login, s in stats["authors_sorted"]:
        ap = pct(s["ai"], s["total"])
        top_team = Counter(s["teams"]).most_common(1)[0][0] if s["teams"] else "\u2014"
        all_teams = " ".join(sorted(set(s["teams"])))
        name = s["name"] or login
        out.append(
            f'<tr data-teams="{esc(all_teams)}">'
            f'<td><strong>{esc(name)}</strong><br><span class="login">{esc(login)}</span></td>'
            f"<td>{team_badge(top_team)}</td>"
            f'<td style="text-align:center">{s["total"]}</td>'
            f'<td style="text-align:center">{s["ai"]}</td>'
            f'<td style="text-align:center">{ap}%</td>'
            f'<td style="text-align:center">{s["merged"]}</td>'
            f'<td style="text-align:center">{s["open"]}</td>'
            f'<td style="text-align:center">{s["closed"]}</td>'
            f"</tr>"
        )
    out.append("</tbody></table>")

    # Section 4 - Reviewer Stats
    out.append('<h2>&#128269; Reviewer Stats</h2>')
    if stats["reviewers_sorted"]:
        out.append(
            '<table id="reviewer-table"><thead><tr>'
            "<th>Reviewer</th><th>Team</th><th>PRs Reviewed</th>"
            "<th>AI PRs Reviewed</th><th>AI Review %</th>"
            "</tr></thead><tbody>"
        )
        for rv, s in stats["reviewers_sorted"]:
            ap = pct(s["ai"], s["total"])
            top_team = Counter(s["teams"]).most_common(1)[0][0] if s["teams"] else "\u2014"
            all_teams = " ".join(sorted(set(s["teams"])))
            out.append(
                f'<tr data-teams="{esc(all_teams)}">'
                f"<td><strong>{esc(rv)}</strong></td>"
                f"<td>{team_badge(top_team)}</td>"
                f'<td style="text-align:center">{s["total"]}</td>'
                f'<td style="text-align:center">{s["ai"]}</td>'
                f'<td style="text-align:center">{ap}%</td>'
                f"</tr>"
            )
        out.append("</tbody></table>")
    else:
        out.append('<p style="color:#64748b;margin-bottom:24px">No reviewer data available.</p>')

    # Section 5 - All PRs
    out.append('<h2>&#128203; All PRs</h2>')
    out.append(
        '<table id="pr-table"><thead><tr>'
        "<th>Repo</th><th>PR #</th><th>Title</th><th>Author</th>"
        "<th>State</th><th>Team</th><th>AI-Agent</th><th>Reviewers</th>"
        "</tr></thead><tbody>"
    )
    prs_sorted = sorted(prs, key=lambda p: (p["repo"].lower(), p["num"]))
    for p in prs_sorted:
        url = esc(p["url"])
        repo = esc(p["repo"])
        num = p["num"]
        title_text = p["title"][:85] + ("\u2026" if len(p["title"]) > 85 else "")
        title = esc(title_text)
        author = esc(p.get("author_name") or p["author_login"])
        revs = esc(p.get("reviewers") or "\u2014")
        out.append(
            f'<tr data-team="{esc(p["team"])}">'
            f'<td><a href="{url}" target="_blank">{repo}</a></td>'
            f'<td><a href="{url}" target="_blank">#{num}</a></td>'
            f'<td><a href="{url}" target="_blank">{title}</a></td>'
            f'<td style="white-space:nowrap">{author}</td>'
            f"<td>{state_badge(p['state'])}</td>"
            f"<td>{team_badge(p['team'])}</td>"
            f"<td>{ai_badge(p['has_docs'])}</td>"
            f'<td style="font-size:.78rem;color:#475569">{revs}</td>'
            f"</tr>"
        )
    out.append("</tbody></table>")

    out.append(f'<footer>Generated on {date_display} | Data source: GitHub API ({period})</footer>')
    js = """<script>
const prData = """ + pr_data_json + """;
function filterReport(team) {
  var filtered = team === 'ALL' ? prData : prData.filter(function(p) { return p.team === team; });
  var total = filtered.length;
  var ai = filtered.filter(function(p) { return p.ai; }).length;
  var merged = filtered.filter(function(p) { return p.state === 'merged'; }).length;
  var open_ = filtered.filter(function(p) { return p.state === 'open'; }).length;
  var closed = total - merged - open_;
  var adopt = total ? Math.round(ai / total * 1000) / 10 : 0;
  document.getElementById('kpi-total').textContent = total;
  document.getElementById('kpi-ai').textContent = ai;
  document.getElementById('kpi-adopt').textContent = adopt + '%';
  document.getElementById('kpi-merged').textContent = merged;
  document.getElementById('kpi-open').textContent = open_;
  document.getElementById('kpi-closed').textContent = closed;
  var rows, i, teams;
  rows = document.querySelectorAll('#team-table tbody tr');
  for (i = 0; i < rows.length; i++) {
    rows[i].style.display = (team === 'ALL' || rows[i].getAttribute('data-team') === team) ? '' : 'none';
  }
  rows = document.querySelectorAll('#author-table tbody tr, #reviewer-table tbody tr');
  for (i = 0; i < rows.length; i++) {
    if (team === 'ALL') { rows[i].style.display = ''; continue; }
    teams = (rows[i].getAttribute('data-teams') || '').split(' ');
    rows[i].style.display = teams.indexOf(team) >= 0 ? '' : 'none';
  }
  rows = document.querySelectorAll('#pr-table tbody tr');
  for (i = 0; i < rows.length; i++) {
    rows[i].style.display = (team === 'ALL' || rows[i].getAttribute('data-team') === team) ? '' : 'none';
  }
  var c = document.getElementById('filter-count');
  c.textContent = team === 'ALL' ? '' : 'Showing ' + total + ' of ' + prData.length + ' PRs';
}
// Wire dropdown via addEventListener — inline onchange is blocked by SharePoint/Teams CSP
document.addEventListener('DOMContentLoaded', function() {
  var el = document.getElementById('team-filter');
  if (el) { el.addEventListener('change', function() { filterReport(this.value); }); }
});
</script>"""
    out.append(js)
    out.append("</div></body></html>")

    return "\n".join(out)


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Generate AI Adoption HTML report")
    parser.add_argument("--input", default="/tmp/pr-report-output.txt",
                        help="Path to pipe-delimited PR data file (default: /tmp/pr-report-output.txt)")
    parser.add_argument("--output-dir", default="docs/generated",
                        help="Output directory for the HTML report (default: docs/generated)")
    parser.add_argument("--date", default=None,
                        help="Report date as YYYY-MM-DD (default: today)")
    parser.add_argument("--period", default=None,
                        help="Period description (default: 'last 24 hours')")
    args = parser.parse_args()

    # Validate input exists and has COMPLETE sentinel
    if not os.path.exists(args.input):
        print(f"ERROR: Input file not found: {args.input}", file=sys.stderr)
        sys.exit(1)

    with open(args.input, "r", encoding="utf-8") as f:
        content = f.read()
    if "# COMPLETE" not in content:
        print(f"ERROR: Input file missing '# COMPLETE' sentinel. Data may be incomplete.", file=sys.stderr)
        sys.exit(1)

    # Date
    if args.date:
        date_slug = args.date
        dt = datetime.strptime(date_slug, "%Y-%m-%d")
        date_display = dt.strftime("%B ") + str(dt.day) + dt.strftime(", %Y")
    else:
        now = datetime.now(timezone.utc)
        date_slug = now.strftime("%Y-%m-%d")
        date_display = now.strftime("%B ") + str(now.day) + now.strftime(", %Y")

    period = args.period or "last 24 hours"

    # Parse and filter
    prs_raw = parse_input(args.input)
    prs = filter_prs(prs_raw)

    if not prs:
        print("WARNING: No PRs remaining after filtering.", file=sys.stderr)

    # Compute and generate
    stats = compute_stats(prs)
    html_content = generate_html(prs, stats, date_display, date_slug, period)

    # Write output
    os.makedirs(args.output_dir, exist_ok=True)
    out_path = os.path.join(args.output_dir, f"ai-adoption-report-{date_slug}.html")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html_content)

    # Summary to stdout
    print(f"Written: {out_path}  ({len(html_content) // 1024} KB)")
    print()
    print("=== REPORT SUMMARY ===")
    print(f"File:       {out_path}")
    print(f"Total PRs:  {stats['total']}  |  AI PRs: {stats['ai_prs']}  |  Adoption: {stats['adopt_pct']}%")
    print(f"State:      {stats['merged']} merged / {stats['open']} open / {stats['closed']} closed")
    print()
    print("Top 3 teams by adoption:")
    for i, (team, s) in enumerate(stats["teams_sorted"][:3], 1):
        print(f"  {i}. {team:<12}  {pct(s['ai'], s['total'])}%  ({s['ai']}/{s['total']} PRs)")
    zero = [t for t, s in stats["team_stats"].items() if s["ai"] == 0]
    if zero:
        print(f"\nTeams with 0% adoption: {', '.join(sorted(zero))}")
    else:
        print("\nNo teams with 0% adoption")


if __name__ == "__main__":
    main()
