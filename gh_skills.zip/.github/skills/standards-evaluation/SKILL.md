---
name: standards-evaluation
description: Industry standards quick-reference checklists for codebase audits including OWASP Top 10, 12-Factor App, ISO 25010, and Spring Boot production readiness.
---

# Skill: Standards Evaluation

## Goal
Provide quick-reference checklists for industry standards used during codebase health audits. These checklists are consumed by other evaluation skills.

## Inputs
- Target codebase (Spring Boot microservice)
- Specific standard(s) to evaluate against

## OWASP Top 10 (2021) — Spring Boot Checklist

| # | Category | Spring Boot Check Points |
|---|---|---|
| A01 | Broken Access Control | @PreAuthorize on endpoints, IDOR checks, CORS config, method security |
| A02 | Cryptographic Failures | BCrypt/Argon2 passwords, TLS enforcement, no secrets in code/config |
| A03 | Injection | Parameterized queries (JPA), input validation (@Valid), no string concat SQL |
| A04 | Insecure Design | Threat modeling, rate limiting, account lockout, secure defaults |
| A05 | Security Misconfiguration | Actuator security, error handling (no stack traces), security headers |
| A06 | Vulnerable Components | Dependency scanning, BOM usage, no end-of-life libraries |
| A07 | Auth Failures | Session management, JWT validation (expiry, algorithm), brute-force protection |
| A08 | Data Integrity Failures | Dependency verification, CI/CD pipeline security, signed artifacts |
| A09 | Logging Failures | Auth event logging, sanitized log inputs, audit trail, no PII in logs |
| A10 | SSRF | URL validation, allowlists for external calls, no user-controlled URLs in fetches |

## 12-Factor App — Spring Boot Compliance

| Factor | Principle | Spring Boot Implementation | Audit Check |
|---|---|---|---|
| I | One codebase | Single repo per service | Separate repos ✅ |
| II | Dependencies | Gradle/Maven declares all deps | No undeclared system deps? |
| III | Config | Externalized config | All via @ConfigurationProperties? |
| IV | Backing Services | Attached resources via config | DB/broker/cache swappable? |
| V | Build, Release, Run | Strict separation | Immutable Docker images? |
| VI | Processes | Stateless | No in-memory sessions/state? |
| VII | Port Binding | Self-contained | Embedded Tomcat/Netty ✅ |
| VIII | Concurrency | Scale out via processes | Horizontally scalable? |
| IX | Disposability | Fast startup, graceful shutdown | @PreDestroy hooks? |
| X | Dev/Prod Parity | Minimize gaps | Testcontainers in tests? |
| XI | Logs | Event streams | stdout/stderr, not file writes? |
| XII | Admin Processes | First-class code | Flyway migrations, CLI tasks? |

## ISO 25010 — Software Quality Model

Use these quality characteristics as evaluation dimensions:

| Characteristic | Sub-characteristics | Audit Focus |
|---|---|---|
| Functional Suitability | Completeness, Correctness, Appropriateness | Business logic coverage |
| Performance Efficiency | Time behavior, Resource utilization, Capacity | Response times, DB queries |
| Compatibility | Co-existence, Interoperability | API contracts, data formats |
| Usability | Operability, Error protection, Accessibility | API design, error messages |
| Reliability | Maturity, Availability, Fault tolerance, Recoverability | Resilience patterns |
| Security | Confidentiality, Integrity, Non-repudiation, Accountability | OWASP compliance |
| Maintainability | Modularity, Reusability, Analysability, Modifiability, Testability | Architecture, tests |
| Portability | Adaptability, Installability, Replaceability | 12-Factor, containerization |

## Spring Boot Production Readiness Checklist

| Category | Check | Status |
|---|---|---|
| **Health** | Actuator health endpoint enabled | |
| | Custom health indicators for all dependencies | |
| | Cloud Foundry health check type configured (http preferred) | |
| | Spring Boot Actuator readiness/liveness health groups enabled | |
| **Metrics** | Micrometer metrics enabled | |
| | Custom business metrics exposed | |
| | @Timed on critical service methods | |
| **Logging** | Structured logging (JSON format) | |
| | MDC correlation IDs propagated | |
| | No PII in log output | |
| **Security** | Actuator endpoints secured | |
| | Spring Security properly configured | |
| | HTTPS enforced in production | |
| **Config** | All config externalized | |
| | Secrets in Vault/secrets manager | |
| | Profile-specific configs tested | |
| **Database** | Connection pool properly sized | |
| | Flyway migrations versioned | |
| | Slow query logging enabled | |
| **Error Handling** | @ControllerAdvice centralized | |
| | RFC 7807 ProblemDetail responses | |
| | No stack traces in production responses | |
| **Resilience** | Circuit breakers on external calls | |
| | Timeouts on all external calls | |
| | Retry with backoff configured | |
| **Deployment** | Graceful shutdown enabled | |
| | Fast startup (<30s) | |
| | Docker image optimized (layered) | |

## IEEE 1028 — Review Classification

This audit follows IEEE 1028 principles for software reviews:
- **Inspection**: Detailed examination of work products against standards
- **Walkthrough**: Step-through of code to find defects
- **Technical Review**: Evaluation against specifications and standards
- **Audit**: Independent assessment of compliance with standards

The codebase audit agent combines elements of all four review types,
with emphasis on Technical Review and Audit.
