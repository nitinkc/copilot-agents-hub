---
name: dev-requirements-intake
description: Convert business needs into testable acceptance criteria and constraints for mission-critical Spring Boot microservices.
---

# Skill: Requirements Intake

## Goal
Turn a business need into crisp acceptance criteria (Given/When/Then), explicit constraints (compatibility, idempotency, bounds, error codes), and a thin-slice implementation order.

## Inputs
- Business goal description from the developer
- Actor/user information
- Trigger (API call/event)
- Success outcome expectation

## Steps

### Step 1: Restate Business Goal
Restate the business goal in one sentence.

### Step 2: Identify Actor + Entrypoint
Identify actor and entrypoint (REST endpoint(s) usually).

### Step 3: Normalize Acceptance Criteria
Each AC must be deterministic and testable, in Given/When/Then format.

### Step 4: Identify Constraints
- **Backward compatibility**: what must not break?
- **Idempotency**: what is the idempotency key? what is "duplicate"?
- **Bounds**: max payload, max pageSize, max batch size, max string lengths.
- **Error taxonomy**: expected HTTP status + stable errorCode for each failure class.

### Step 5: Identify Dependencies
- **DB**: tables/records affected, uniqueness/constraints, transaction expectations.
- **Outbound**: which backend systems, timeout/retry expectations, fallback behavior.

### Step 6: Extract Business Dimensions
Capture structured dimensions for documentation (see `dimension-extraction.instructions.md`):
- **Capability ID**: stable identifier (e.g., `CAP-ORDER-CREATE`)
- **Business goal**: what outcome this achieves
- **Actor / persona**: who triggers or benefits
- **Trigger**: what initiates the flow
- **Outcome**: observable success result
- **Business value**: why the business cares
- **Business rule IDs**: preliminary rule identifiers for rules discovered during intake (e.g., `RULE-VALIDATE-001`)
- **Key entities**: domain objects involved, with logic-bearing attributes noted
- **Requirement keywords**: phrases that should trigger impact analysis for this capability

### Step 7: Produce Thin-Slice Ordering
Implement one AC at a time, starting with the smallest slice.

## Output
- AC list (AC1..ACn) in Given/When/Then format
- Constraints list (C1..Cn)
- Business dimensions (capability ID, goal, actor, trigger, outcome, value, preliminary rule IDs, key entities, requirement keywords)
- Thin-slice recommendation (which AC to implement first and why)
- Open questions that block implementation

## Developer Gate (MANDATORY)

After producing the output above, present it to the developer with the following explicit action block. Do NOT proceed until the developer responds.

### Present to Developer

Include this action block at the end of the requirements intake output:

```
---
## Developer Action Required

Please review the acceptance criteria, constraints, business dimensions, thin-slice order, and open questions above and choose one:

1. **Approve** — ACs and constraints are correct; proceed to DESIGN (step 2)
2. **Request changes** — specify corrections to ACs, constraints, or thin-slice order (I will update and re-present)
3. **Approve with answers** — provide answers to open questions and approve (I will incorporate and proceed to DESIGN)

Optional:
- Identify any acceptance criteria you want added or removed
- Flag constraints that need different values or bounds
- Provide answers to open questions listed above

> Waiting for your response before continuing.
```

### After Developer Responds

| Developer action | Agent behavior |
|---|---|
| **Approve** | Incorporate any final notes, mark intake as `completed`, and proceed to DESIGN (step 2). |
| **Request changes** | Update ACs/constraints/thin-slice order per feedback, re-present the updated output, and wait for approval again. |
| **Approve with answers** | Incorporate answers into ACs and constraints, mark intake as `completed`, and proceed to DESIGN (step 2). |
| **Flag additions/removals** | Adjust the AC list or constraints accordingly, re-present if material changes were made, then proceed to DESIGN (step 2). |
