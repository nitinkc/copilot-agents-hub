---
name: dev-critical-review
description: Final code and test review with mission-critical introspection. Cross-check implementation against requirements, identify gaps, and regenerate any missing tests or code.
---

# Skill: Critical Review

## Goal
Before marking work as review-ready, perform rigorous introspection on both the generated code and tests. Use mission-critical application requirements as the forcing function to identify any gaps and regenerate missing pieces.

## Inputs
- All generated code and test files
- Test execution results from VERIFY phases
- Acceptance criteria from Requirements Intake
- Design blueprint

## Steps

### Step 0: Project Context Map

Before reviewing code, compare changes against existing project patterns:
- Similar controllers/endpoints and DTO conventions
- Existing error envelope + errorCode taxonomy
- CorrelationId propagation conventions
- Outbound client configuration pattern (central factory/config vs ad hoc)
- Repository query patterns (pagination/caps, uniqueness, rollback)
- Documentation patterns and existing docs levels
- Existing test conventions (base classes, naming, stubbing approach, contract testing)

Flag deviations from project patterns. Accept deviations only when they clearly reduce risk.

### Step 1: Code Review Introspection

#### Anti-Pattern Scan
Scan all changed files against the anti-patterns list in `.github/instructions/mission-critical-checklists.instructions.md` under "Code quality anti-patterns". Flag any match as a finding. Report using the "Anti-Pattern Findings" table format from "Outcome presentation rules" in the same file. Include the table in the output even if empty (state "Anti-pattern scan: 0 findings").

#### Correctness Check
- [ ] Implementation matches all acceptance criteria exactly
- [ ] No dead code or unused branches introduced
- [ ] All code paths are reachable and tested
- [ ] Error handling is explicit, not swallowed or generic

#### Mission-Critical Code Patterns
- [ ] All outbound calls have explicit timeouts configured
- [ ] Retry logic has bounded caps (no infinite retries)
- [ ] Circuit breakers present where appropriate
- [ ] Transactions scoped correctly (not too wide, not too narrow)
- [ ] Idempotency keys/dedupe logic where side effects exist

#### Defensive Coding
- [ ] Input validation at entry points (size, format, nulls)
- [ ] Bounds checking on all collections/strings
- [ ] Safe defaults for missing/optional data
- [ ] No string concatenation for SQL/commands (use parameterized)
- [ ] All non-negotiable C rules enforced: cascade validation, constraint propagation, doc-code invariant consistency
- [ ] All non-negotiable H rules enforced: boundary symmetry, defensive defaults, error chain integrity, resource acquisition symmetry, singleton safety
- [ ] See `copilot-instructions.md` non-negotiables C and H for full definitions

#### Security Surface
- [ ] No sensitive data logged (PII, credentials, tokens)
- [ ] Auth/authz checks present and tested
- [ ] Input sanitization where user data is processed
- [ ] No SSRF vectors (URL inputs validated against allowlist)

#### Backward Compatibility
- [ ] No public API fields removed without versioning
- [ ] No endpoint paths changed without versioning
- [ ] Error codes preserve existing semantics
- [ ] No breaking changes to contract schemas

#### Dependency Governance
- [ ] Zero new dependencies unless developer explicitly requested the addition
- [ ] Every new or changed dependency has a third-party risk register entry (see `dependency-known-issues-gates.instructions.md`)
- [ ] Vulnerability scanning covers the new artifact/version
- [ ] Build-time or code-time guardrail added for risky functionality
- [ ] No SNAPSHOT/LATEST/RELEASE versions in non-development builds

### Step 1b: Whole-Project Invariant Checklist

Verify the change respects cross-cutting invariants.
The full expanded checklist (including all contracts/defensive-checks and code-generation-discipline items) is in `mission-critical-quality-gate` Step 3.
At critical-review time, verify at minimum:
- [ ] **Backward compatibility**: no removed/renamed params/fields unless versioned; stable errorCode meanings
- [ ] **Boundedness**: pagination capped; batch/list/string size caps; no unbounded loops/retries
- [ ] **IO safety**: outbound timeouts (connect/read/deadline); bounded retries for safe operations only
- [ ] **Error safety**: consistent safe error envelope (no stack traces, no raw exception text)
- [ ] **Idempotency**: side-effecting operations are replay-safe
- [ ] **Layering**: controller thin; business logic in service; persistence in repo; outbound in client/adapter
- [ ] **Security hygiene**: no secrets logged; SSRF allowlist if URL inputs; strict boundary validation

The quality gate (Step 3) additionally verifies: cascade validation, constraint propagation, doc-code invariant consistency, dependency governance, boundary symmetry, defensive defaults, error chain integrity, resource closure, singleton safety, and API surface stability.

### Step 1c: Documentation Review

#### Documentation Adequacy Matrix
Build: **Change area / risk -> required doc levels/artifacts -> current state -> gaps**.
- [ ] Business capabilities docs updated when business-visible behavior changed
- [ ] Service context docs updated when dependencies/boundaries changed
- [ ] Runtime flows docs updated when rules/errors/flows changed
- [ ] Technical map docs updated when components/config/testing changed
- [ ] Machine manifests updated when APIs/dependencies/rules changed

### Step 2: Test Review Introspection

#### Test Adequacy Matrix
Build: **Change area / risk -> required scenarios -> existing tests -> missing tests**.

#### Coverage Verification
For each AC, verify explicit test coverage exists:
- [ ] Happy path tested
- [ ] Error/failure path tested
- [ ] Boundary values tested (0, 1, max, max+1)
- [ ] Edge cases tested (empty, null, unicode, special chars)

#### Mission-Critical Test Scenarios
- [ ] **Timeout tests**: Outbound calls timeout appropriately
- [ ] **Retry cap tests**: Retries don't exceed configured max
- [ ] **Failure isolation tests**: One failure doesn't cascade
- [ ] **Partial success tests**: Batch operations handle mixed results
- [ ] **Rollback tests**: Failed transactions clean up properly
- [ ] **Dedupe tests**: Duplicate requests are handled correctly

#### Code Generation Discipline Test Scenarios
- [ ] **Boundary symmetry**: every `@Min` has a matching `@Max`; tests exist at both limits
- [ ] **Defensive defaults**: default/fallback values pass validation (no default that violates its own constraint)
- [ ] **Resource closure**: resources closed on both success and exception paths
- [ ] **Error chain integrity**: wrapped exceptions preserve original cause
- [ ] **Test completeness symmetry**: every positive assertion has a negative counterpart; every constraint has a violation test

#### Test Quality Check
- [ ] No `Thread.sleep` (deterministic timing only)
- [ ] All waits are bounded with hard timeouts
- [ ] No flaky dependencies (time, order, external state)
- [ ] Assertions are meaningful (not just "no exception")
- [ ] Test names clearly describe what is being tested

#### Missing Scenario Detection
1. "What would happen if the database is slow/unreachable?"
2. "What would happen if the downstream service returns garbage?"
3. "What would happen if we receive 10x expected load?"
4. "What would happen if the request is malformed?"
5. "What would happen if auth is missing/invalid?"

### Step 3: Gap Regeneration

#### For Code Gaps
1. Identify the missing defensive code/validation
2. Add implementation following existing patterns
3. Ensure corresponding test is added

#### For Test Gaps
1. Identify the missing scenario
2. Choose appropriate test type (unit/MockMvc/stub/integration)
3. Generate test with clear documentation

#### Regeneration Loop
Repeat until:
- All AC have verified test coverage
- All introspection questions answered
- All checklist items satisfied or explicitly justified as out of scope

### Step 3b: Socratic Self-Check (before decision)
Execute the 11-question Socratic Self-Check from `.github/instructions/mission-critical-checklists.instructions.md` under "Socratic self-check". If any answer reveals an uncaptured risk, add it as a gap and loop back to regeneration. Report using the "Socratic-Revealed Risks" table format from "Outcome presentation rules" in the same file. Include the table in the output even if empty (state "Socratic self-check: 0 new risks surfaced").

### Step 4: Decision

- **REGENERATE**: If critical gaps found -> return to appropriate phase (RED/GREEN/INTEGRATE)
- **COMPLETE**: If all checks pass -> proceed to REVIEW-READY

Never mark as complete with known critical gaps in mission-critical scenarios.

## Output

### Code Review Summary
- Potential issues found and addressed
- Defensive code added
- Security considerations addressed

### Test Review Summary
- Gap analysis (what was missing, what was added)
- Final scenario matrix per test file
- Mission-critical behaviors verified

### Completeness Statement
```
Acceptance Criteria Coverage:
- AC1: [x] Happy path + error path + boundary
- AC2: [x] Happy path + validation failure
- AC3: [x] Timeout + retry cap + rollback

Mission-Critical Verification:
- Timeouts: [x] All outbound calls have timeout tests
- Retries: [x] Retry caps tested
- Errors: [x] Safe error envelope verified
- Idempotency: [x] Dedupe behavior tested
- Security: [x] Auth/validation tested

Confidence: HIGH/MEDIUM/LOW with justification
```

### Remaining Risks
- Any known gaps that cannot be addressed (with justification)

## Developer Gate (MANDATORY)

After producing the output above, present it to the developer with the following explicit action block. Do NOT proceed until the developer responds.

### Present to Developer

Include this action block at the end of the critical review summary:

```
---
## Developer Action Required

Please review the critical review findings above and choose one:

1. **Approve** — no critical gaps remain; proceed to Review-Ready Draft (step 7)
2. **Request fixes** — specify which gaps need addressing (I will loop back to BUILD/INTEGRATE to fix, re-verify, and return here)
3. **Approve with accepted risks** — acknowledge listed risks and proceed to Review-Ready Draft with risks documented

Optional:
- Identify any gaps you consider out of scope for this change
- Flag additional areas of concern not covered in the review

> Waiting for your response before continuing.
```

### After Developer Responds

| Developer action | Agent behavior |
|---|---|
| **Approve** | Proceed to Review-Ready Draft (step 7). |
| **Request fixes** | Loop back to the appropriate phase (RED/GREEN/INTEGRATE) to address the specified gaps. After fixes are applied and verified, return to this step and re-present the updated review. |
| **Approve with accepted risks** | Document accepted risks in the Review-Ready Draft. Proceed to step 7. |
| **Flag additional concerns** | Add to the gap report and address if within scope, or document as known risks. Then proceed to step 7. |
- Any assumptions that should be validated in higher environments
- Any manual testing recommendations
