---
name: pr-deployment-readiness
description: Assess whether a PR is safe to deploy in a rolling-update microservice environment. Evaluates migration safety, rollback paths, feature flags, coordinated deployment needs, and operational impact.
user-invocable: true
disable-model-invocation: true
---
# PR Deployment Readiness Assessment

Evaluate deployment safety for a PR in a rolling-update microservice environment.

## Assessment dimensions

### 1. Rolling Deployment Safety
- Can old code and new code run simultaneously during deployment?
- Are new API fields optional/nullable so old consumers aren't broken?
- Are removed fields still accepted (ignored) by new code during transition?
- Do database changes work with both old and new code versions?

### 2. Database Migration Safety
- Are schema migrations backward-compatible (additive only)?
- Can the migration be rolled back without data loss?
- Is there a separate data migration that could fail independently?
- Are migrations idempotent (safe to re-run)?
- Is the migration fast enough for zero-downtime deployment?

### 3. Rollback Path
- If this PR is reverted, what breaks?
- Are there data migrations that make reverting destructive?
- Are there published API contracts that consumers have adopted?
- Are there BPMN process instances in-flight that depend on new behavior?
- Rollback blast radius: self-contained | requires consumer coordination | non-revertible

### 4. Feature Flag Assessment
- Does this change need a feature flag for safe rollout?
- If yes: is the flag implemented with clean on/off behavior?
- Is the flag removable after rollout completes?
- Is default-off safe? Is default-on safe?

### 5. Coordinated Deployment
- Does this change require other services to deploy simultaneously?
- Are there contract/schema changes that need consumer-side updates?
- Is there a deployment order dependency?
- Are there shared library version bumps that affect other services?

### 6. Operational Impact
- Are health check endpoints still valid?
- Are readiness/liveness probes still appropriate?
- Do monitoring dashboards need updates?
- Are alerting thresholds still correct?
- Will this change affect p50/p95/p99 latency?
- Will this change affect error rate baselines?
- Are SLOs/SLAs at risk?

### 7. In-Flight Request Safety
- What happens to requests in progress during deployment?
- Are long-running BPMN processes affected?
- Are async message consumers affected by message format changes?
- Are scheduled jobs/cron tasks affected?

## Output
- Deployment readiness verdict: READY | READY WITH PRECAUTIONS | NOT READY
- Required precautions (if any)
- Rollback risk level: LOW | MEDIUM | HIGH | NON-REVERTIBLE
- Coordinated deployment plan (if needed)
- Feature flag recommendation (if needed)

## Risk Score Contribution
This skill feeds into `pr-risk-scoring` across two dimensions:
- **Operational risk** (10%) ← rolling deployment safety, monitoring gaps, SLO impact, in-flight request safety
- **Data/state management risk** (10%) ← migration safety, rollback blast, transaction boundaries

### When invoked as Phase 4 of `pr-code-review` agent
Produce the same assessment but format as the **Deployment Readiness** section of the Change Fit Report.
The deployment verdict and rollback risk level feed directly into the Phase 5 risk scoring.

## Constraints
- Assess ALL 7 dimensions in order. Never skip a dimension.
- Every NON-READY or READY WITH PRECAUTIONS verdict must cite specific file-level evidence.
- If no database migrations exist, score Dimension 2 as "N/A — no migrations" and move on.
- If the PR is purely test/doc changes with no production code, return READY with rationale and skip detailed assessment.
- Do not recommend feature flags for trivial changes. Reserve for behavioral changes with rollback complexity.
- Maximum 3 precautions per dimension to keep actionable.

## Integration with PR review
This skill feeds into:
- `pr-risk-scoring`: Operational risk (10%), data/state management risk (10%)
- `pr-code-review` Phase 4 output: becomes the "Deployment Readiness" section of the Change Fit Report

When invoked standalone, produce the deployment readiness assessment as a self-contained report.
When invoked as part of the `pr-code-review` agent, the verdict and risk levels feed the composite risk score.
