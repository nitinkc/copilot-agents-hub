---
name: documentation-impact-triage
description: Generate or update change-impact patterns so humans and LLMs can map requirement phrases to likely impacted capabilities, endpoints, dependencies, components, and docs.
---
# Documentation Impact Triage

## Use this when
- a feature changes business capabilities, endpoints, or integrations
- you want faster requirement impact analysis for humans or machines
- the repo lacks a useful impact map

## Files to create/update
- `docs/generated/change-impact-patterns.md`
- `docs/generated/machine/change-impact-map.yaml`

## Goal
Create a practical map from requirement language to likely impact areas.
This should help:
- business analysts decide whether the repo is relevant
- developers know where to start
- LLM/automation identify likely touched code/docs/tests/dependencies

Leverage traceability dimensions from `dimension-extraction.instructions.md`:
- map requirement keywords/aliases to capability IDs
- link impacted capabilities to their related docs, tests, code areas, rules, and entities
- cross-reference business rule IDs and entity names so impact chains are complete

## Procedure
1) Identify new or changed capabilities, endpoints, or integrations.
2) Extract traceability dimensions per capability:
   - related docs
   - related tests
   - likely code areas
   - requirement keywords / aliases
3) Map requirement phrases to impacted capabilities → APIs → components → dependencies → docs → tests.
4) Update human-readable patterns in `docs/generated/change-impact-patterns.md`.
5) Update machine-readable map in `docs/generated/machine/change-impact-map.yaml`.
6) Cross-reference: ensure capability IDs, rule IDs, and entity names are consistent with `docs/generated/14-rule-inventory.md` and `docs/generated/15-entity-attribute-catalog.md`.

## Output
- patterns added/updated
- requirement phrases/tags mapped to impacted areas
- rationale for high-value patterns
