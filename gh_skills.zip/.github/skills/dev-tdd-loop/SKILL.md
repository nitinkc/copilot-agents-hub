---
name: dev-tdd-loop
description: Drive development using TDD per thin slice: RED tests first, then minimal GREEN implementation, then REFACTOR. Enforces mission-critical constraints and deterministic tests.
user-invocable: true
disable-model-invocation: true
---

# Skill: TDD Loop

## Goal
Implement each thin slice using a strict RED -> GREEN -> REFACTOR cycle, enforcing mission-critical constraints at every step.

## Inputs
- Test plan and thin-slice order from Test Plan
- Design blueprint from Design Blueprint

## Hard Constraints
- Tests must be deterministic: no `Thread.sleep`, bounded waits only.
- No real external network calls in tests (use mocks/stubs).
- The calling agent controls the RED -> GREEN transition. This skill completes the RED phase and yields control back to the agent. Do not proceed to GREEN unless the agent (or developer) explicitly requests it.

## Steps

### RED (tests first)
- Write the smallest failing test(s) for the next AC.
- Include required negative/boundary scenarios that correspond to explicit constraints.
- For outbound calls: use stub server tests (no real network).
- For DB invariants: use repository integration tests.

### GREEN (minimal code)
- Implement smallest safe code to pass tests.
- Enforce ALL non-negotiables (A through H) from `copilot-instructions.md` — especially:
  - zero new dependencies, boundary symmetry, defensive defaults, error chain integrity, resource acquisition symmetry, singleton safety, cascade validation, constraint propagation, doc-code invariant consistency
- Preserve layering:
  - Controller thin
  - Logic in service
  - Persistence in repo
  - Outbound calls in client/adapter
- Enforce constraints in code:
  - Explicit bounds/validation
  - Explicit timeouts
  - Bounded retry caps if present
  - Safe error mapping
  - Idempotency (dedupe + deterministic duplicate behavior)

### REFACTOR (safe cleanup)
- Remove duplication, improve readability without changing behavior.
- Preserve compatibility:
  - No breaking changes unless versioned
  - errorCode semantics unchanged
- Add guard tests only when they prevent drift (layering/forbidden APIs/test pairing).

## Output
- What AC was implemented
- Tests added/updated and what they prove
- What remains (next slice)
