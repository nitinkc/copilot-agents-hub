---
name: ltg-test-execution-loop
description: Execute generated tests via Maven, classify failures into actionable categories, and produce a diagnostic report recommending ALL_PASS, LOOP_BACK, or ESCALATE.
---

# Skill: Test Execution & Diagnosis

## Goal
Execute generated/updated tests, classify any failures into actionable categories, and produce a diagnostic report recommending whether to proceed, loop back, or escalate.

## Inputs
- List of test classes/files to execute (from `ltg-validation` or from a previous fix iteration)
- Project build tool configuration (Maven assumed: `mvn test -Dtest=<TestClass>`)
- Previous iteration context (if in a fix loop): which tests failed, what was changed

## Hard Constraints
- Execute tests in the developer's actual project environment (not in isolation).
- Never modify test files or production code during execution -- this skill only observes and reports.
- Never skip, disable, or mark tests as `@Disabled` to achieve a green result.
- Classify every failure -- do not lump failures into a generic "failed" bucket.
- Respect iteration caps set by the calling agent -- this skill does not decide whether to loop (the agent does).

## Steps

### Step 1: Execute Tests
- Run all specified test classes via Maven: `mvn test -Dtest=<TestClass1>,<TestClass2>,...`
- If running a full suite: `mvn test`
- Capture:
  - Exit code (0 = all pass, non-zero = failures)
  - Full test output (stdout + stderr)
  - Surefire reports if available (`target/surefire-reports/*.xml`)

### Step 2: Classify Failures
For each failing test, classify into exactly one category:

| Category | Indicators | Auto-fixable? |
|----------|-----------|---------------|
| **COMPILE** | `cannot find symbol`, `incompatible types`, `package does not exist` | Yes |
| **MOCK_WIRING** | `Wanted but not invoked`, `Unnecessary stubbings`, `No qualifying bean`, NPE on mocked dependency | Yes |
| **ASSERTION** | `AssertionError`, `expected:<X> but was:<Y>`, status code mismatch | Yes -- but verify the test expectation is correct before changing it. If the assertion aligns with requirements, the failure may be a PRODUCTION_BUG instead. |
| **SCHEMA** | `Table not found`, `Column not found`, `Bad SQL grammar`, constraint violation in test setup | Yes |
| **ENVIRONMENT** | Port conflict, file not found, classpath issue, timeout during test infrastructure setup | No -- escalate |
| **PRODUCTION_BUG** | Test correctly asserts expected behavior but production code does the wrong thing | No -- escalate |

**Distinguishing ASSERTION from PRODUCTION_BUG:**
- If the test expectation aligns with the AC/requirements and production code violates it -> PRODUCTION_BUG
- If the test expectation is wrong (wrong status code, wrong field name) -> ASSERTION

### Step 3: Produce Diagnostic Report

```
## Test Execution Report

### Summary
- Tests executed: <count>
- Passed: <count>
- Failed: <count>
- Iteration: <N> of <max>

### Recommendation: <ALL_PASS | LOOP_BACK | ESCALATE>

### Failures (if any)
| Test Class | Test Method | Category | Root Cause Hypothesis | Suggested Fix |
|-----------|-------------|----------|----------------------|---------------|
| ... | ... | COMPILE | Missing import for X | Add import statement |

### Production Bugs Discovered (if any)
| Test | Expected Behavior | Actual Behavior | Severity |
|------|-------------------|-----------------|----------|
| ... | Returns 400 for invalid input | Returns 200 with null body | HIGH |

### Environment Issues (if any)
| Issue | Impact | Developer Action Required |
|-------|--------|--------------------------|
| ... | ... | ... |
```

**Recommendation logic:**
- **ALL_PASS**: Every test passed. Proceed to next phase.
- **LOOP_BACK**: At least one failure is auto-fixable (COMPILE, MOCK_WIRING, ASSERTION, SCHEMA) AND no ENVIRONMENT/PRODUCTION_BUG failures exist.
- **ESCALATE**: Any ENVIRONMENT or PRODUCTION_BUG failure exists, OR iteration cap reached with remaining failures.

## Output
A structured diagnostic report containing:
1. Pass/fail counts
2. Recommendation (ALL_PASS, LOOP_BACK, or ESCALATE)
3. Per-failure classification with root-cause hypothesis and suggested fix
4. Production bugs discovered (if any)
5. Environment issues (if any)

The **calling agent** (not this skill) decides what to do with the recommendation.
