---
name: documentation-business-functional-views
description: Generate or update business-first and functionality-first documentation views for a service or capability. Uses business language, user journeys, flowcharts, requirement diagrams, and context maps rather than code-centric explanations.
---
# Documentation Business & Functional Views

## Use this when
- a feature changed business-visible behavior
- a business stakeholder needs to understand the service
- a requirement needs to be translated into repo impact clues
- Level 0 or Level 1 documentation is weak or stale

## Goal
Explain what the codebase does without forcing readers to understand code.

## Outputs
- `docs/generated/01-business-capabilities.md`
- `docs/generated/02-service-context.md`
- `docs/generated/glossary.md` (if terms changed)
- `docs/generated/change-impact-patterns.md` (if new requirement phrases surfaced)
- `docs/generated/14-rule-inventory.md` (if business rules changed, created, or need formal cataloging)
- `docs/generated/15-entity-attribute-catalog.md` (if entities with logic-bearing attributes changed)
- relevant machine docs if capabilities/dependencies changed

## Mandatory Document Structure — `docs/generated/01-business-capabilities.md`

When generating or updating this file, produce ALL of the following sections in order.
Never generate only the capabilities section without the preceding context sections.
When updating (not bootstrapping), read the existing file first and merge — do not overwrite sections that exist with less content.

| # | Section | Purpose | Source |
|---|---------|---------|--------|
| 1 | **Service Overview** | 1–2 paragraphs explaining what the service does in business language. No code names. | Codebase analysis, existing README, stakeholder context |
| 2 | **Actors & Stakeholders** | Who uses, triggers, or benefits from this service. List each actor/persona with their role, goal, and primary interaction. | Controllers, API consumers, upstream callers, business context |
| 3 | **Core Business Capabilities** | Capabilities grouped by business function. Each capability has: trigger, actor, outcome, key business rules (by Rule ID), important failure outcomes. | Procedure steps 1–3 below |
| 4 | **Business Rules Summary** | Key rules governing capabilities, with Rule IDs referencing `docs/generated/14-rule-inventory.md`. | Rule extraction (procedure step 7) |
| 5 | **Business Process Diagrams** | Journey, flowchart, mindmap, requirementDiagram as appropriate for the capabilities. | Procedure step 4 |
| 6 | **Key Business Outcomes** | Concrete examples of what success and failure look like from a business perspective. Not code internals. | Capability analysis |

**Override prevention rule**: When an existing `docs/generated/01-business-capabilities.md` has content in sections 1–2 (Service Overview, Actors), NEVER replace those sections with less content or omit them. If the current codebase provides richer information, merge the richer content into the existing section structure.

## Mandatory Document Structure — `docs/generated/02-service-context.md`

| # | Section | Purpose |
|---|---------|---------|
| 1 | **Service Boundary & Responsibilities** | What this service owns and what it delegates |
| 2 | **Upstream Callers** | Who calls this service, via what protocol, for what purpose |
| 3 | **Downstream Dependencies** | Services, datastores, queues this service calls, with purpose and criticality |
| 4 | **Capability-to-Backend Mapping** | Which capabilities touch which backends |
| 5 | **Ownership & Team** | Who owns this service and critical interfaces |
| 6 | **Context Diagrams** | C4 context/container, architecture, or dependency graph diagrams |

## Procedure
1) Identify capabilities and actors.
2) Extract business dimensions per capability (see `dimension-extraction.instructions.md`):
- capability ID (stable identifier, e.g., `CAP-ORDER-CREATE`)
- business goal
- actor / persona
- trigger
- outcome
- business value (revenue, compliance, risk reduction, efficiency)
- business rule IDs (references to entries in `docs/generated/14-rule-inventory.md`)
3) Describe each capability in business terms:
- trigger
- actor
- outcome
- key business rules (referenced by rule ID)
- important failure outcomes
4) Create/update business diagrams:
- journey for actor-centric steps
- flowchart for functional decision flow
- mindmap for capability/domain concepts
- requirementDiagram for explicit rules/constraints when useful
5) Create/update context view:
- service boundary
- upstream callers
- downstream systems/datastores
- owners and boundaries
6) Add requirement-impact clues:
- phrases/keywords that should make a reviewer or LLM inspect this repo
7) Update rule inventory if new business rules are identified:
- add entries to `docs/generated/14-rule-inventory.md` using the rule template from `dimension-extraction.instructions.md`
- cross-reference rule IDs in business capabilities documentation
8) Update entity/attribute catalog if capabilities interact with entities whose logic-bearing attributes changed:
- add/update entries in `docs/generated/15-entity-attribute-catalog.md`
- ensure entities reference their related capabilities and rules
9) Keep wording stable with the glossary.

## Rules
- Avoid code-level names in Level 0 unless there is no better business term.
- Prefer outcomes and rules over class names.
- Include dependencies/backends in capability language, not just technical labels.
- Reference business rules by their Rule ID from the rule inventory.
- Reference entities by name from the entity/attribute catalog when they carry logic-bearing attributes.
- When a machine-readable contract spec exists (OpenAPI, WSDL, .proto, AsyncAPI), reference it for contract details rather than duplicating them. When no spec exists, use the API Contract Catalog.
