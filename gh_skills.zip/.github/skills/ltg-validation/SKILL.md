---
name: ltg-validation
description: Validate generated tests for compilation sanity, determinism, no duplication, and mission-critical assertion presence before execution.
---

# Skill: Validation

## Goal
Verify that all generated tests are deterministic, non-redundant, compilable, and include required mission-critical assertions before passing to execution.

## Inputs
- Generated test files from `ltg-test-generation`
- Existing test files in the repo

## Steps

### Step 1: Compilation Sanity
- Imports correct for JUnit 5 and Mockito.
- No mixed JUnit 4 runner usage unless repo already uses it.
- Annotations (`@Test`, `@MockBean`, `@WebMvcTest`, etc.) used correctly.

### Step 2: Determinism Check
- NO `Thread.sleep` anywhere.
- Any polling uses a hard timeout and descriptive failure messages.
- Time-dependent logic uses injected/fixed `Clock`.

### Step 3: No Duplication
- Do not generate redundant tests that assert the same behavior.
- If an existing test already covers a scenario, extend it rather than duplicating.

### Step 4: Mission-Critical Assertions Present
- Boundary tests exist where bounds were added/changed.
- Error envelope assertions exist where error mapping changed.
- Timeout and retry cap tests exist where outbound client behavior changed.
- Dedupe/idempotency tests exist where side effects are present.

## Output
- Report any non-determinism risks.
- List what was validated and any assumptions.
