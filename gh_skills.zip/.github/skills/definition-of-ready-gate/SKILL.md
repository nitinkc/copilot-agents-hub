---
name: definition-of-ready-gate
description: Apply a mission-critical definition-of-ready gate to a groomed requirement and decide whether development should start.
---

# Skill: Definition of Ready Gate

## Goal
Evaluate a groomed requirement against mission-critical definition-of-ready criteria and produce a clear Ready / Needs Clarification / Not Ready decision with blocking items and ownership.

## Inputs
- Requirement summary, user stories, and acceptance criteria (from prior grooming steps)
- Story quality assessment (INVEST evaluation)
- Open questions and assumptions
- Implementation impact preview
- Critical feedback / concerns

## Hard Constraints
- Never mark "Ready" if any RISKY assumption is unresolved.
- Never mark "Ready" if failure behavior is undefined for any AC that involves a side effect or dependency.
- Every "Needs Clarification" or "Not Ready" must list concrete blocking items.
- Every blocking item must have a suggested owner.
- Do not weaken criteria to force a "Ready" decision.

## Steps

### Step 1: Evaluate Completeness
Check whether the groomed requirement has:
- **Clear business goal**: Is the "why" explicit?
- **Identified actors/use cases**: Is it clear who does what?
- **Testable acceptance criteria**: Can each AC be turned into a test?
- **Key business rules**: Are decision criteria, thresholds, and limits defined?
- **Explicit constraints and assumptions**: Are compatibility, idempotency, and bounds stated?
- **Dependency/ownership clarity**: Are upstream/downstream owners identified?
- **Rollout/compatibility awareness**: Is backward compatibility addressed?
- **Implementation preview**: Is there enough context to start design safely?

### Step 2: Classify Gaps
For each gap found in step 1:
- **Blocker**: Cannot start development without resolving this
- **Risk**: Development could start but may need to pause or rework
- **Acceptable gap**: Can be resolved during development without significant rework

### Step 3: Decide
Based on the evaluation:
- **Ready**: All checklist items pass, no blockers, risks are manageable
- **Needs Clarification**: One or more items need stakeholder input before development, but the core requirement is understood
- **Not Ready**: Fundamental gaps exist — business goal unclear, actors undefined, or critical business rules missing

### Step 4: Document Blocking Items
For each blocker or risk:
- State the item clearly
- Explain why it blocks or risks development
- Suggest an owner: **Business**, **PM**, **Lead**, **Architect**, or **Developer**

## Output
- **Decision**: Ready / Needs Clarification / Not Ready
- **Reasons**: Concise explanation of the decision
- **Checklist Results**: Pass/fail per evaluation criterion from step 1
- **Blocking Items**: Each with description, severity (blocker/risk), and suggested owner
- **Acceptable Gaps**: Items that can be resolved during development