---
name: stakeholder-review-pack
description: Produce a grooming review pack for business, PMs, leads, and architects with open questions, decisions needed, trade-offs, and recommended next steps.
---

# Skill: Stakeholder Review Pack

## Goal
Compile a self-contained review pack that business stakeholders, PMs, engineering leads, and architects can use to make decisions and unblock development.

## Inputs
- Requirement summary and core elements (from requirements-intake-clarify)
- User stories and acceptance criteria (from acceptance-criteria-gherkin)
- Story quality assessment (from story-quality-invest)
- Critical feedback / concerns (from grooming agent step 4)
- Implementation impact preview (from grooming agent step 5)
- Open questions and assumptions accumulated across prior steps

## Hard Constraints
- Write for a mixed audience — use business language, not code-level jargon.
- Do not exceed 2 pages of content (excluding ACs, which can be appended).
- Every open question must have a suggested owner (business, PM, lead, architect, developer).
- Every decision needed must state the trade-off and recommended default.
- Do not include implementation details that only developers need.

## Steps

### Step 1: Write Concise Summary
One paragraph summarizing:
- What is being asked
- Who benefits and how
- Why it matters (business value / risk reduction)

### Step 2: Compile Stakeholder-Relevant Sections
Assemble:
- **User/customer value**: What the end user or customer gains
- **User stories**: From step 2 output (summarized, full ACs in appendix)
- **Key acceptance criteria**: Top 3–5 most important ACs highlighted
- **Assumptions**: List with SAFE/RISKY labels from intake
- **Risks and concerns**: From critical feedback (customer, operational, compat, observability)

### Step 3: List Open Questions
For each open question:
- State the question clearly
- Explain why it matters (what changes if answered differently)
- Suggest an owner: **Business**, **PM**, **Lead**, **Architect**, or **Developer**

### Step 4: List Decisions Needed
For each decision:
- State the decision clearly
- Describe the trade-off (option A vs option B)
- Recommend a default if one is safer
- Suggest an owner

### Step 5: Recommend Next Steps
Based on the Definition of Ready assessment (or anticipating it):
- If likely Ready: recommend proceeding to design/development
- If Needs Clarification: list the specific items that must be resolved first
- If Not Ready: explain why and suggest what needs to happen

## Output
- **Summary** (1 paragraph)
- **User/Customer Value**
- **User Stories** (summarized)
- **Key Acceptance Criteria** (top 3–5)
- **Assumptions** (SAFE/RISKY)
- **Risks and Concerns**
- **Open Questions** (with owners)
- **Decisions Needed** (with trade-offs and owners)
- **Recommended Next Steps**

### Output Audience
- Business stakeholders
- PMs
- Engineering leads
- Architects