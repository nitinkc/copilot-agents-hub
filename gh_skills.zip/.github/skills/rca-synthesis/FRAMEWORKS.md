# RCA Frameworks Reference — OrderTech

## Purpose

Detailed methodology for each RCA framework used by the `rca-synthesis` skill.
Every framework has been selected for applicability to distributed microservice
architectures. Apply ALL frameworks — each provides a different analytical lens.

---

## 1. Five Whys — Iterative Causal Chain Analysis

Ask "Why?" iteratively until you reach a root cause that, if addressed, prevents recurrence.

### Rules for Distributed Systems
1. Each "Why" must cross **at most one service boundary**. If you jump from A to C, you skipped B.
2. **Evidence required at every level** — log entry, code line, config value, or commit reference.
3. Stop when you reach an **actionable cause**. Don't go beyond system boundaries unless relevant.
4. **Fork when multiple causes exist.** Real systems have multi-causal failures.
5. Minimum 3, maximum 7 levels. <3 = stopped at symptom. >7 = going in circles.

### Evidence Search Priority
1. Direct log evidence (strongest) — ELK log entry with timestamp and service
2. Traversal evidence — cross-service propagation edge
3. Code evidence — file:line from the deployed commit (via configLabel → Artifactory → commit)
4. Configuration evidence — application.yml key, DRL rule, feature flag

### Anti-patterns
- **Blame chain**: Never blame individuals. Focus on system failures.
- **Assumption chain**: No "probably." Evidence or mark as `HYPOTHESIS`.
- **Single-path bias**: Follow ALL contributing cause branches.

### Stopping Criteria
A root cause is **actionable** if fixing it prevents recurrence:
- Specific code defect ("Null check missing at line 142")
- Specific config error ("Timeout set to 100ms, should be 5000ms")
- Specific design flaw ("No circuit breaker on payment-service call")
- Specific process gap ("No integration test for low-inventory path")

---

## 2. Ishikawa (Fishbone) — 6M Categorization

| Dimension | Software Equivalent | Questions |
|-----------|-------------------|-----------|
| **Technology** | Infrastructure, hardware, cloud | Infrastructure event? Resource limits hit? |
| **Process** | Dev/deploy process, CI/CD | Change reviewed? Rollback plan? Tests adequate? |
| **Data** | Input data, configurations, dependencies | Data valid? Configs correct? Schema matched? |
| **People** | Developer/ops actions (no blame — systemic) | Manual action? Training gap? |
| **Measurement** | Observability, alerting, testing | Did we detect it? Were tests sufficient? |
| **Environment** | External factors, timing, load | Unusual load? External outage? Time-of-day? |

Rate each: **Not a factor** / **Contributing factor** / **Primary factor** with evidence.

---

## 3. Fault Tree Analysis (FTA)

Build a top-down boolean logic tree from observable failure to basic events.

### Gates
- **AND gate**: ALL child events must occur for parent to occur.
- **OR gate**: ANY single child event can cause parent.

### Node Types
- **Top Event**: User-visible failure (e.g., "Order API returns 500")
- **Intermediate Event**: Failure within the system (e.g., "inventory-service timeout")
- **Basic Event**: Specific identifiable fault (e.g., "DB lock from batch job")
- **External Event**: Fault outside system boundary (e.g., "vendor API outage")

### Key Outputs
- **Minimal Cut Sets**: Smallest combinations of basic events causing the top event.
- **Single Points of Failure**: Basic events in ALL cut sets.
- **Common Cause Failures**: Single issue manifesting as multiple basic events.

---

## 4. FMEA — Failure Mode and Effects Analysis

See `FMEA-SCORING.md` for detailed scoring calibration.

**RPN = Severity (S) × Occurrence (O) × Detection (D)**

| RPN | Priority |
|-----|----------|
| > 200 | CRITICAL — immediate action |
| 100–200 | HIGH — fix this sprint |
| 50–100 | MEDIUM — fix next sprint |
| < 50 | LOW — backlog |

---

## 5. Kepner-Tregoe IS / IS NOT Analysis

Structured problem boundary analysis:

```yaml
analysis:
  what:
    is: "NullPointerException in OrderHandler.processOrder()"
    is_not: "No errors in OrderHandler.cancelOrder() or getOrder()"
    distinction: "processOrder calls inventoryService.reserve()"
  where:
    is: "Production, wc-g2 and po-g2 datacenters"
    is_not: "Not in as-g7, not in lower environments"
    distinction: "wc-g2/po-g2 have higher traffic volume"
  when:
    is: "Started 2026-04-12 14:00 UTC"
    is_not: "Not present before 14:00, not on 2026-04-11"
    distinction: "New configLabel deployed at 13:45"
  extent:
    is: "100% of requests for product category X"
    is_not: "Not affecting product category Y"
    distinction: "Category X path has different code branch"
```

---

## 6. Cynefin Framework — Problem Domain Classification

| Domain | Characteristics | Approach |
|--------|----------------|----------|
| **Clear** | Obvious cause-effect, known fix | Sense → Categorize → Respond |
| **Complicated** | Discoverable with expertise, multiple possible fixes | Sense → Analyze → Respond |
| **Complex** | Emergent, visible only in retrospect | Probe → Sense → Respond |
| **Chaotic** | No clear cause-effect, novel situation | Act → Sense → Respond (stabilize first) |

### Investigation Impact
- **Clear**: Fix it. No deep RCA needed. (Config typo, known bug)
- **Complicated**: Full RCA, expect definitive root cause. (Performance under specific conditions)
- **Complex**: Run experiments, focus on resilience. (Cascading failure under novel load)
- **Chaotic**: Stabilize first, RCA later. (Multi-failure system outage)

---

## 7. Swiss Cheese Model — Defense Layer Analysis

Standard defense layers for OrderTech microservices:

| # | Layer | What to Check |
|---|-------|---------------|
| 1 | **Input Validation** | @Valid on controllers, boundary checks, size limits |
| 2 | **Unit Tests** | Test coverage of the failure path |
| 3 | **Integration Tests** | Contract tests, MockMvc tests for the error scenario |
| 4 | **Code Review** | PR reviewed? Concerns raised? Self-merge? |
| 5 | **Static Analysis** | SonarQube, FindBugs flagged this class of error? |
| 6 | **Circuit Breakers** | Resilience4j engaged? Config correct? |
| 7 | **Retry/Fallback** | Retries configured? Fallback activated? |
| 8 | **Health Checks** | K8s probes detected unhealthy state? |
| 9 | **Monitoring/Alerting** | Dashboards/alerts detected the anomaly? |
| 10 | **Graceful Degradation** | Service degraded gracefully or failed hard? |
| 11 | **Runbook** | Documented response procedure exists? |
| 12 | **Rollback Capability** | Fast rollback possible? Tested? |

Mark each: **HELD** (worked) / **BREACHED** (failed to catch) / **ABSENT** (not implemented).
The aligned "holes in the cheese" are your prevention targets.

## Cross-Validation Checklist

After applying all frameworks:
1. Does Five Whys root cause match the Fault Tree minimal cut set?
2. Does Ishikawa primary factor align with Cynefin classification?
3. Does Swiss Cheese breach pattern explain why this failure wasn't caught?
4. Are there contradictions? If so, document and resolve.
5. Does IS/IS NOT analysis narrow the scope consistently with all other findings?
