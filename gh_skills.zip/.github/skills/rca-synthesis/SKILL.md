---
name: rca-synthesis
description: >
  Combine evidence from log analysis, service traversal, and code investigation
  into a structured Root Cause Analysis using 7 industry-standard frameworks
  (Five Whys, Ishikawa, Fault Tree, FMEA, Event Timeline, Cynefin, Swiss Cheese)
  plus hypothesis elimination (ACH Matrix), forward verification (Abductive),
  and cognitive debiasing. For Tier 2+ investigations.
---

# Skill: RCA Synthesis

## Goal

Combine collected evidence into a structured root cause analysis using
multiple industry-standard frameworks, eliminate alternative hypotheses,
and produce a validated, debiased RCA with confidence scoring.

## When to Use

- Produce a structured root cause analysis from collected evidence
- Apply multiple analytical frameworks to find and validate root cause
- Cross-validate findings for consistency
- Generate a complete RCA report
- Any time a full investigation has gathered log, traversal, and code evidence

## Step 0 — Load Dependencies

```
read_file .github/skills/rca-synthesis/FRAMEWORKS.md
read_file .github/skills/rca-synthesis/FMEA-SCORING.md
read_file .github/skills/error-taxonomy/SKILL.md
```

For Tier 2+ investigations, also load:
```
read_file .github/skills/rca-synthesis/ACH-MATRIX.md
read_file .github/skills/rca-synthesis/ABDUCTIVE-VERIFICATION.md
read_file .github/skills/rca-synthesis/COGNITIVE-BIASES.md
read_file .github/skills/rca-synthesis/ROOT-CAUSE-PATTERNS.md
```

ROOT-CAUSE-PATTERNS.md contains root cause classification (DATA vs CODE
vs ARCHITECTURE), decision tree, five mandatory root cause questions,
common patterns table, and elk-deep-trace.py root cause algorithms G–L.

## Input

This skill expects evidence collected from:
- **elk-log-search**: Error logs, patterns, frequencies
- **service-traversal**: Error propagation chain, patterns, origin service
- **code-forensics**: Code-level root cause, suspicious commits, config drift
- **blast-radius**: Impact scope, customer-facing assessment
- **error-taxonomy**: Error classification

## Workflow

### Step 0b: Extract Framework Versions (MANDATORY when root cause involves framework code)

When the error involves a framework or library (Flowable, Spring, Jackson, Hibernate,
Oracle JDBC, etc.), the exact deployed version is **required evidence** — not optional
context. Different versions have different bugs, behaviors, and fixes.

**Procedure**:
1. From the cloned repo at the deployed commit (code-forensics Step 2), extract versions:
   ```bash
   # In the cloned repo directory at the deployed commit
   grep -A1 '<artifactId>flowable' pom.xml | grep version
   grep -A1 '<artifactId>spring-boot' pom.xml | grep version
   # Or for managed versions:
   grep -E '(flowable|spring-boot|jackson|hibernate|ojdbc).*version' pom.xml
   ```

2. If the repo uses a parent POM, resolve the effective version:
   ```bash
   # Check parent POM for version properties
   gh api repos/comcast-modesto/<parent-repo>/contents/pom.xml?ref=<parent-version-tag> \
     --jq '.content' | base64 -d | grep -A1 '<artifactId>flowable'
   ```

3. Record in the RCA evidence as a "Framework Versions" table:
   ```
   | Framework | Version | Relevant? | Known issues at this version |
   |-----------|---------|-----------|------------------------------|
   | Flowable  | 6.5.0   | YES       | ACT-4xxx: NPE in cascadeDelete |
   | Spring Boot | 2.2.x | NO        | — |
   ```

4. Check the framework's issue tracker for known bugs at the deployed version:
   ```bash
   # Example for Flowable on GitHub
   gh api "search/issues?q=NullPointerException+repo:flowable/flowable-engine+label:bug" \
     --jq '.items[:5] | .[] | "#\(.number) \(.title) [\(.state)]"'
   ```

**BLOCKING**: If the root cause hypothesis involves a framework bug but the framework
version is unknown, the hypothesis confidence MUST be capped at 0.50 in Step 12
(Cross-Validation / confidence scoring). Resolve the version before finalizing.
If unresolvable, record `framework_version: "UNRESOLVED"` in the output contract
and propagate the 0.50 cap to the final RCA report confidence field.

### Step 1: Five Whys Analysis

Reference: `FRAMEWORKS.md` Section 1.

Execute evidence-based Five Whys:

```
WHY 1: Why did [observable symptom] occur?
→ Because [cause], as evidenced by [ELK log @ timestamp + serviceName].

WHY 2: Why did [cause from Why 1] occur?
→ Because [deeper cause], as evidenced by [traversal: service X → service Y edge].

WHY 3: Why did [cause from Why 2] occur?
→ Because [code cause], as evidenced by [code: File.java:142 — null check missing].

WHY 4: Why did [code cause] occur?
→ Because [design/process cause], as evidenced by [commit SHA / PR # / configLabel].

WHY 5: Why did [design cause] exist?
→ Because [architectural/organizational root], as evidenced by [evidence].
```

**Rules**:
- Each "Why" MUST cite specific evidence (ELK log entry, code file:line, config key, commit SHA).
- If evidence is insufficient, mark as `HYPOTHESIS` with confidence score.
- If the chain forks (multiple contributing causes), follow BOTH branches.
- Stop at 3–7 levels.

### Step 2: Ishikawa (Fishbone) Categorization

Reference: `FRAMEWORKS.md` Section 2.

Evaluate each dimension:

| Dimension | Assessment | Evidence |
|-----------|-----------|---------|
| **Technology** | Not a factor / Contributing / Primary | {{infrastructure, platform}} |
| **Process** | Not a factor / Contributing / Primary | {{CI/CD, review, deployment}} |
| **Data** | Not a factor / Contributing / Primary | {{input data, configs}} |
| **People** | Not a factor / Contributing / Primary | {{systemic view, no blame}} |
| **Measurement** | Not a factor / Contributing / Primary | {{alerting, testing}} |
| **Environment** | Not a factor / Contributing / Primary | {{load, timing, external}} |

### Step 3: Fault Tree Construction

Reference: `FRAMEWORKS.md` Section 3.

Build from the top event (user-visible failure) down to basic events:

```
TOP EVENT: [Customer-visible failure — e.g., "Order API returns 500"]
├── OR
│   ├── INTERMEDIATE: [Service failure]
│   │   ├── AND
│   │   │   ├── BASIC: [Specific code defect]
│   │   │   └── BASIC: [Missing null check]
│   │   └── BASIC: [Config misconfiguration]
│   └── CONDITION: [Load above threshold]
```

Identify:
- **Minimal Cut Sets**
- **Single Points of Failure**
- **Common Cause Failures**

### Step 4: FMEA Scoring

Reference: `FMEA-SCORING.md`.

Score using OrderTech-calibrated scales:

| Dimension | Score (1-10) | Justification |
|-----------|-------------|---------------|
| Severity (S) | | Based on customer impact and blast radius |
| Occurrence (O) | | Based on ELK error frequency (24h, 7d) |
| Detection (D) | | Based on time-to-detect and auto-remediation |

**RPN = S × O × D**

Use ELK queries to validate occurrence:
```bash
ELK=".github/skills/elk-log-search/scripts/elk-query.sh"
$ELK errors --service <service> --hours 24
$ELK errors --service <service> --hours 168
```

### Step 5: Event Timeline

Build a millisecond-precision timeline from ELK logs:

```yaml
event_timeline:
  - timestamp: "2026-04-12T14:23:45.123Z"
    service: "customer-gateway"
    configLabel: "mbos-customer-gateway-1.0.1682"
    event: "Received POST /api/orders"
    type: "normal"
  - timestamp: "2026-04-12T14:23:45.456Z"
    service: "customer-gateway"
    event: "FEIGN_REQUEST to biller-account"
    type: "normal"
  - timestamp: "2026-04-12T14:23:50.789Z"
    service: "biller-account"
    configLabel: "mbos-biller-account-1.0.817"
    event: "Database query timeout after 5000ms"
    type: "error_origin"
```

Use the **inner** `@timestamp` from `message` JSON for accurate sequencing
(see INVESTIGATION-BRAIN.md Section 3 — two timestamps).

Identify:
- **Inception point** — first abnormal event
- **Propagation speed** — how fast errors spread
- **Detection gap** — time between inception and alert/report

### Step 6: Cynefin Classification

Reference: `FRAMEWORKS.md` Section 6.

Classify the problem domain:

| Domain | Evidence Pattern |
|--------|-----------------|
| **Clear** | Known exception, documented fix, single service | 
| **Complicated** | Multi-service, requires expert analysis, discoverable root cause |
| **Complex** | Emergent behavior, multiple interacting factors, only visible in retrospect |
| **Chaotic** | Multiple simultaneous failures, novel situation, no clear cause-effect |

### Step 7: Swiss Cheese Defense Layer Analysis

Reference: `FRAMEWORKS.md` Section 7.

For each of the 12 defense layers, assess HELD / BREACHED / ABSENT:

1. Input Validation
2. Unit Tests
3. Integration Tests
4. Code Review
5. Static Analysis
6. Circuit Breakers
7. Retry/Fallback
8. Health Checks
9. Monitoring/Alerting
10. Graceful Degradation
11. Runbook
12. Rollback Capability

The BREACHED and ABSENT layers are the prevention targets.

### Step 8: Hypothesis Elimination — ACH Matrix (Tier 2+)

Reference: `ACH-MATRIX.md`.

After Five Whys produces a proposed root cause, evaluate ALL plausible
hypotheses against ALL evidence simultaneously:

1. Generate minimum 3 hypotheses (including the Five Whys result).
2. For each hypothesis, generate alternatives from different Ishikawa dimensions.
3. Build the evidence-hypothesis matrix — rate each evidence item against each
   hypothesis (CC/C/N/S/SS).
4. Identify **diagnostic evidence** — items that differentiate between hypotheses.
5. Rank hypotheses by **least contradicted** (not most supported).
6. Run sensitivity analysis — if removing one piece of evidence changes the
   winner, that evidence is **pivotal** and needs extra verification.

Compare ACH winner with Five Whys:
- Same → **REINFORCED** confidence
- Different → **FLAG** discrepancy, investigate gap
- No clear winner → **INSUFFICIENT** evidence

### Step 9: Forward Verification — Abductive (Tier 3 only)

Reference: `ABDUCTIVE-VERIFICATION.md`.

Given the proposed root cause, predict what additional symptoms SHOULD be
observable, then check against ELK:

1. **Direct consequences**: Connected services should show correlated errors.
2. **Temporal patterns**: Error onset should align with trigger event.
3. **Absence predictions**: Things that should NOT be present if cause is correct.

Check each prediction via `elk-log-search` queries. Score:
- **CONFIRMED** (≥ 75% match rate, no contradictions) → strengthen root cause
- **PARTIALLY_CONFIRMED** → note unmatched predictions for critic attention
- **CONTRADICTED** (any contradicting prediction) → refine root cause before continuing

### Step 10: Cognitive Debiasing (Tier 2+)

Reference: `COGNITIVE-BIASES.md`.

Apply mandatory debiasing probes:

1. **Dual-goal prompt**: For each evidence item, state how it both SUPPORTS and
   CONTRADICTS the proposed root cause.
2. **Think-in-opposites**: Assume the proposed root cause is WRONG — what is the
   strongest alternative?
3. **Narrative bias check**: Is the Five Whys chain TOO clean? List evidence
   items that don't fit the narrative.
4. **Anchoring check**: Would we reach the same conclusion if we started the
   investigation from a different service?

### Step 11: Cross-Validation

**Mandatory consistency checks**:
1. Does Five Whys root cause match the Fault Tree minimal cut set?
2. Does Ishikawa primary factor align with Cynefin classification?
3. Does Swiss Cheese breach pattern explain why the failure wasn't caught?
4. Is the FMEA score consistent with the observed blast radius?
5. Does the event timeline support the causal ordering in Five Whys?
6. Does ACH winner agree with Five Whys root cause? (Tier 2+)
7. Is abductive verification CONFIRMED or PARTIALLY_CONFIRMED? (Tier 3)

If contradictions exist, document them and resolve with evidence.

### Step 12: Generate RCA Report

Use the template at `.github/shared/templates/rca-report.md`.
Fill all 13 sections from the framework outputs above.

## Output Contract

```yaml
rca_synthesis_result:
  root_cause:
    summary: string               # One-paragraph root cause statement
    confidence: float             # 0.0-1.0
    category: string              # From Ishikawa primary factor
    cynefin_domain: string
    error_category: string        # From error-taxonomy
  framework_versions:             # MANDATORY when framework code is involved
    - name: string                # e.g., "Flowable", "Spring Boot"
      version: string             # e.g., "6.5.0"
      relevant: boolean
      known_issues: string[]      # Issue tracker references at this version
  five_whys: FiveWhysChain
  ishikawa: IshikawaAnalysis
  fault_tree: FaultTree
  fmea:
    severity: int
    occurrence: int
    detection: int
    rpn: int
    priority: string
  event_timeline: EventTimeline
  swiss_cheese: DefenseLayerAnalysis
  ach_result:                     # Tier 2+ only
    winning_hypothesis: string
    runner_up: string
    gap_strength: string
    five_whys_agreement: string   # REINFORCED | DIVERGENT | INSUFFICIENT
    diagnostic_evidence: Evidence[]
  abductive_verification:         # Tier 3 only
    verification_result: string   # CONFIRMED | PARTIALLY_CONFIRMED | CONTRADICTED
    match_rate: float
    contradicted_predictions: string[]
  debiasing_applied:              # Tier 2+ only
    anchoring_check: string
    confirmation_check: string
    narrative_check: string
    think_in_opposites_result: string
  cross_validation:
    consistent: boolean
    contradictions: string[]
    resolution: string
  alternative_hypotheses:
    - hypothesis: string
      evidence_for: string[]
      evidence_against: string[]
      confidence: float
```

## Quality Rules

- **Every claim needs evidence**: No conclusion without a log entry, code line, or config value.
- **Confidence scoring**: Every conclusion gets a 0.0-1.0 confidence with justification.
- **Counter-hypothesis**: For every root cause, consider at least one alternative.
- **Synthesize, don't summarize**: Derive insight, don't just repeat findings.
