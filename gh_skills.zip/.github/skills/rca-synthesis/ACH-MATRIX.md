# Analysis of Competing Hypotheses (ACH) — Elimination Reasoning

> Adapted from CIA intelligence analyst Richard Heuer's ACH methodology.
> Core principle: **proceed by eliminating hypotheses, not confirming them.**
> The correct root cause is the one with the LEAST inconsistent evidence.

## Why ACH Is Critical for RCA

Standard Five Whys builds ONE causal chain. ACH forces you to evaluate ALL
plausible hypotheses against ALL evidence simultaneously. This directly counters
**confirmation bias** — the tendency to seek evidence supporting your first guess.

## Algorithm

```
ALGORITHM: AnalysisOfCompetingHypotheses
INPUT:
  evidence_set: Evidence[]        # All evidence collected during investigation
  initial_hypothesis: string      # Proposed root cause from Five Whys
  traversal_dag: DAG              # Error propagation graph
OUTPUT:
  ranked_hypotheses: Hypothesis[] # Ordered by consistency with evidence
  winning_hypothesis: Hypothesis
  diagnostic_evidence: Evidence[] # Evidence that distinguishes between top hypotheses

FUNCTION execute_ach(evidence_set, initial_hypothesis, traversal_dag):

  # ── STEP 1: Generate Hypotheses (min 3, max 7) ──
  hypotheses = [initial_hypothesis]

  # Generate alternatives by challenging each major assumption
  FOR EACH assumption IN extract_assumptions(initial_hypothesis):
    alternative = negate_assumption(assumption)
    IF alternative.is_plausible():
      hypotheses.append(alternative)

  # Add "wild card" — orthogonal hypothesis from different Ishikawa dimension
  hypotheses.append(generate_orthogonal_hypothesis(traversal_dag))

  ASSERT 3 <= len(hypotheses) <= 7

  # ── STEP 2: Build Evidence-Hypothesis Matrix ──
  # Rate EACH piece of evidence against EACH hypothesis
  # Work ACROSS rows (evidence first), not down columns
  matrix = Matrix(rows=evidence_set, columns=hypotheses)

  FOR EACH evidence IN evidence_set:
    FOR EACH hypothesis IN hypotheses:
      matrix[evidence][hypothesis] = rate_consistency(evidence, hypothesis)
      # Rating scale:
      #   CC = Strongly Contradicts
      #   C  = Contradicts
      #   N  = Neutral
      #   S  = Supports
      #   SS = Strongly Supports

  # ── STEP 3: Identify Diagnostic Evidence ──
  # Diagnostic = items that rate DIFFERENTLY for different hypotheses
  diagnostic_evidence = []
  FOR EACH evidence IN evidence_set:
    ratings = matrix[evidence].values()
    IF variance(ratings) > THRESHOLD:
      diagnostic_evidence.append(evidence)
      evidence.mark_as_diagnostic()

  # ── STEP 4: Eliminate Hypotheses ──
  # Focus on CONTRADICTING evidence (not supporting)
  FOR EACH hypothesis IN hypotheses:
    contradiction_count = count(matrix.column(hypothesis), where=CC or C)
    contradiction_weight = weighted_sum(
      matrix.column(hypothesis),
      weights={CC: -2, C: -1, N: 0, S: +0.5, SS: +1}
      # Contradictions weighted MORE than support
    )
    hypothesis.contradiction_score = contradiction_count
    hypothesis.weighted_score = contradiction_weight

  # Rank by LEAST contradicted (not most supported)
  ranked = hypotheses.sort_by(
    h => h.contradiction_score ASC, h.weighted_score DESC
  )

  # ── STEP 5: Sensitivity Analysis ──
  # What if key evidence items were wrong?
  FOR EACH diagnostic_item IN diagnostic_evidence:
    sensitivity = re_rank_without(diagnostic_item, matrix, hypotheses)
    IF sensitivity.changes_winner:
      diagnostic_item.mark_as_pivotal()
      # The conclusion HINGES on this evidence being correct

  RETURN ACHResult(
    hypotheses=ranked,
    winning_hypothesis=ranked[0],
    runner_up=ranked[1],
    diagnostic_evidence=diagnostic_evidence,
    pivotal_evidence=filter(diagnostic_evidence, is_pivotal),
    confidence=compute_confidence(ranked),
    matrix=matrix
  )
```

## Confidence Computation

```
FUNCTION compute_confidence(ranked_hypotheses):
  winner = ranked_hypotheses[0]
  runner_up = ranked_hypotheses[1]
  gap = winner.weighted_score - runner_up.weighted_score

  IF gap > 5.0:   RETURN 0.95  # Clear winner
  IF gap > 3.0:   RETURN 0.80  # Strong winner
  IF gap > 1.5:   RETURN 0.65  # Moderate — actionable but note alternatives
  IF gap > 0.5:   RETURN 0.45  # Weak — may need more evidence
  RETURN 0.30                   # Too close to call — investigate further
```

## OrderTech Application

When applying ACH to OrderTech incidents:

### Evidence Sources (mapped to ELK fields)

| Evidence Type | ELK Source | Matrix Column Weight |
|---|---|---|
| Error log with stack trace | `level:ERROR`, `message`, `LogEventMessage` | HIGH — direct observation |
| Cross-service correlation | `GlobalTrackingId`, `threadContextId` traversal | HIGH — causal chain |
| Timing correlation | `@timestamp` ordering, `duration` fields | MEDIUM — necessary but not sufficient |
| Historical frequency | `logType:API_RESPONSE`, `status` aggregations | MEDIUM — pattern detection |
| Config at deploy time | `configLabel` → MobileBackOfficeConfig branch | HIGH — rules out config cause |
| Code change at version | `configLabel` → Artifactory → git commit → PR diff | HIGH — rules out code cause |
| DC distribution | `datacenter.keyword` aggregation | MEDIUM — infrastructure signal |
| External service state | `logType:DOWNSTREAM_RESPONSE`, `status:5xx` | HIGH — rules in/out external |

### Hypothesis Generation from Ishikawa

For each incident, generate at least one hypothesis per dimension:

| Dimension | Example Hypothesis Template |
|---|---|
| Technology | "Service X code defect introduced in configLabel Y" |
| Process | "Missing validation in deployment pipeline allowed bad config" |
| Data | "Unexpected input data pattern not covered by validation" |
| Environment | "Infrastructure issue in datacenter Z affecting network/CPU/memory" |
| External | "Downstream dependency Y changed behavior or degraded" |
| Design | "Architectural limitation (missing circuit breaker, no fallback)" |

## Integration with Five Whys

ACH runs AFTER Five Whys to validate or challenge the root cause:
1. Five Whys produces a proposed root cause.
2. ACH generates alternatives and evaluates ALL hypotheses against ALL evidence.
3. If ACH winner matches Five Whys → **REINFORCED** confidence.
4. If ACH winner differs → **FLAG** discrepancy, investigate the gap.
5. If no clear winner → **INSUFFICIENT** evidence, need more investigation.

## Output Format

```yaml
ach_result:
  hypotheses_evaluated: int
  matrix_summary:
    - hypothesis: "Description"
      contradictions: int
      supports: int
      weighted_score: float
      rank: int
  winning_hypothesis: string
  runner_up: string
  gap_strength: "CLEAR" | "STRONG" | "MODERATE" | "WEAK" | "TOO_CLOSE"
  diagnostic_evidence:
    - evidence: "Description"
      elk_reference: "serviceName + @timestamp"
      distinguishes: "How it differentiates hypotheses"
      pivotal: boolean
  confidence: float
  five_whys_agreement: "REINFORCED" | "DIVERGENT" | "INSUFFICIENT"
```
