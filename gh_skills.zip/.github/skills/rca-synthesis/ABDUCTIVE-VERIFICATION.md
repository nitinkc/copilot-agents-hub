# Abductive Forward Verification Algorithm

> Given a hypothesized root cause, predict what symptoms SHOULD be observable,
> then check against actual observations. Catches false root causes that explain
> the primary symptom but are inconsistent with broader evidence.

## Why This Matters

Standard RCA reasons BACKWARD: "symptom X → cause must be Y."
Forward verification reasons FORWARD: "IF cause Y is correct → we should ALSO
see symptoms A, B, C. Do we?" This catches false positives.

## Algorithm

```
ALGORITHM: AbductiveForwardVerification
INPUT:
  hypothesized_cause: string
  observed_symptoms: Symptom[]     # What we actually see
  service_topology: ServiceTopology
  elk_access: ELKQueryInterface    # Uses elk-log-search skill
OUTPUT:
  verification_result: "CONFIRMED" | "PARTIALLY_CONFIRMED" | "CONTRADICTED"
  predicted_symptoms: PredictedSymptom[]
  match_rate: float

FUNCTION verify_forward(hypothesized_cause, observed_symptoms):

  # ── STEP 1: Generate Predictions ──
  predicted_symptoms = []

  # Category 1: Direct consequences on connected services
  direct = predict_direct_consequences(hypothesized_cause, service_topology)
  predicted_symptoms.extend(direct)

  # Category 2: Temporal patterns
  temporal = predict_temporal_patterns(hypothesized_cause)
  predicted_symptoms.extend(temporal)

  # Category 3: Absence predictions (what should NOT be present)
  absences = predict_absences(hypothesized_cause, service_topology)
  predicted_symptoms.extend(absences)

  # ── STEP 2: Check Each Prediction Against ELK ──
  FOR EACH prediction IN predicted_symptoms:
    actual = check_prediction_via_elk(prediction, elk_access)
    prediction.status = actual.status  # OBSERVED | NOT_OBSERVED | CONTRADICTED
    prediction.actual_value = actual.value
    prediction.evidence_ref = actual.elk_reference

  # ── STEP 3: Score ──
  observed_count = count(predicted_symptoms, status=OBSERVED)
  not_observed_count = count(predicted_symptoms, status=NOT_OBSERVED)
  contradicted_count = count(predicted_symptoms, status=CONTRADICTED)
  total = len(predicted_symptoms)

  match_rate = observed_count / total

  IF contradicted_count > 0:
    verification_result = "CONTRADICTED"
  ELSE IF match_rate >= 0.75:
    verification_result = "CONFIRMED"
  ELSE:
    verification_result = "PARTIALLY_CONFIRMED"

  RETURN VerificationResult(
    verification_result=verification_result,
    predicted_symptoms=predicted_symptoms,
    match_rate=match_rate,
    contradicted_predictions=filter(predicted_symptoms, status=CONTRADICTED)
  )
```

## Prediction Categories

### Category 1: Direct Consequence Predictions

Given root cause, predict effects on connected OrderTech services:

```yaml
# Example: Root cause = "Database timeout on order table"
direct_consequences:
  - prediction: "All services querying the order table should show increased latency"
    elk_query: |
      logType:API_RESPONSE AND serviceName.keyword:*order*
      AND @timestamp within incident window
      Sort by duration DESC
    type: "PRESENCE"

  - prediction: "Services NOT using the order table should be unaffected"
    elk_query: |
      level:ERROR AND serviceName.keyword:*payment*
      AND @timestamp within incident window
      Expected: zero results
    type: "ABSENCE"

  - prediction: "Downstream FEIGN callers should show timeout errors"
    elk_query: |
      logType:FEIGN_RESPONSE AND status:(502 OR 504)
      AND message:*order* AND @timestamp within window
    type: "PRESENCE"
```

### Category 2: Temporal Pattern Predictions

```yaml
temporal_predictions:
  - prediction: "Error onset should align with the suspected trigger event"
    elk_query: |
      First ERROR timestamp for affected service within ±30 seconds
      of trigger (deployment, batch job, config change)
    type: "TIMING"

  - prediction: "Error rate should decline when trigger condition resolves"
    elk_query: |
      level:ERROR aggregation over 5-minute buckets showing decline
    type: "TIMING"

  - prediction: "If recurrent, same pattern should appear at same trigger"
    elk_query: |
      Same error class, same time window, last 7 days
    type: "RECURRENCE"
```

### Category 3: Absence Predictions

```yaml
absence_predictions:
  - prediction: "If cause is DB timeout (not network), no ConnectException errors"
    elk_query: |
      message:*ConnectException* AND serviceName.keyword:*affected-service*
      Expected: zero results
    type: "ABSENCE"

  - prediction: "If cause is specific to one table, health checks should pass"
    elk_query: |
      uri:*/health* AND serviceName.keyword:*affected-service*
      AND status:200 — should have results
    type: "ABSENCE"

  - prediction: "Unrelated DCs should be unaffected (if cause is localized)"
    elk_query: |
      level:ERROR AND serviceName.keyword:*affected-service*
      AND datacenter.keyword:<unaffected-dc>
      Expected: zero or baseline rate
    type: "ABSENCE"
```

## Integration Point

Abductive verification runs AFTER Five Whys and BEFORE the critic review:
1. Five Whys produces a root cause.
2. Forward verification generates predictions and checks them via ELK.
3. If **CONTRADICTED** → refine the root cause BEFORE sending to critics.
4. If **CONFIRMED** → root cause is strengthened before critic review.
5. If **PARTIALLY_CONFIRMED** → note which predictions didn't match for critic attention.

## Output Format

```yaml
abductive_verification:
  hypothesized_cause: string
  predictions_made: int
  predictions_observed: int
  predictions_not_observed: int
  predictions_contradicted: int
  match_rate: float
  verification_result: "CONFIRMED" | "PARTIALLY_CONFIRMED" | "CONTRADICTED"

  details:
    - prediction: "Description"
      type: "PRESENCE" | "ABSENCE" | "TIMING" | "RECURRENCE"
      status: "OBSERVED" | "NOT_OBSERVED" | "CONTRADICTED"
      elk_query_used: "query summary"
      evidence: "what was found"
      implication: "what this means for the root cause"

  root_cause_adjustment:
    original: string
    refined: string?          # Only if CONTRADICTED and refinement possible
    confidence_change: string # e.g., "+0.15 (more specific, better fits evidence)"
```
