# FMEA Scoring — OrderTech Calibration

## Formula

**RPN = Severity (S) × Occurrence (O) × Detection (D)**

Range: 1 (minimal risk) to 1,000 (maximum risk)

## Severity Scale (S) — Calibrated for OrderTech

| Score | Label | Criteria | OrderTech Examples |
|-------|-------|----------|-------------------|
| 1 | None | No effect on customers or operations | Cosmetic log formatting issue |
| 2 | Very Minor | Negligible impact, no user awareness | Minor metric inaccuracy in internal dashboard |
| 3 | Minor | Slight inconvenience, easy workaround | Non-critical field missing in API response, UI handles gracefully |
| 4 | Low | Some users notice, workaround available | Account details page slow, retry works |
| 5 | Moderate | Feature degraded for subset of users | Order creation slow (>5s) for RETAIL channel only |
| 6 | Significant | Core feature impaired, partial workaround | Order creation fails intermittently, retry works |
| 7 | Major | Core feature unavailable for subset | All orders fail for PREPAID tenants |
| 8 | Critical | Core feature unavailable for all users | Order creation down for all SalesChannels |
| 9 | Severe | Data integrity risk or financial impact | Duplicate charges, provisioning state mismatch, inventory incorrect |
| 10 | Catastrophic | Data loss, compliance, total platform outage | Customer data exposed, regulatory breach, all DCs down |

## Occurrence Scale (O) — Calibrated for OrderTech Volume

OrderTech processes ~1.8B log entries/day across 592 services.

| Score | Label | Frequency | OrderTech Calibration |
|-------|-------|-----------|----------------------|
| 1 | Nearly Impossible | < 1 per year | Never seen in production |
| 2 | Very Rare | 1–2 per year | Seen once under extreme conditions |
| 3 | Rare | 3–6 per year | Quarterly occurrence |
| 4 | Low | Monthly | Happens once a month |
| 5 | Occasional | 2–4 per month | Every week or two |
| 6 | Moderate | Weekly | Multiple times per week |
| 7 | Frequent | 2–3 per week | Every few days |
| 8 | High | Daily | Daily occurrence (check `last_24h` error count) |
| 9 | Very High | Multiple daily | Multiple times per day |
| 10 | Certain | Every request | Affects every single request |

## Detection Scale (D) — INVERTED (low = easy to detect)

| Score | Label | Criteria | OrderTech Calibration |
|-------|-------|----------|----------------------|
| 1 | Certain | Auto-detected + auto-remediated | Circuit breaker opens + auto-healing |
| 2 | Very High | Auto-detected, alert <2 min, clear runbook | PagerDuty fires <2 min, runbook linked |
| 3 | High | Auto-detected, alert <10 min | Monitoring alert, dashboard anomaly visible |
| 4 | Moderately High | Auto-checks within 30 min | Health check failures, synthetic monitoring |
| 5 | Moderate | Team detects within 1 hour via monitoring | Requires human to check dashboard, ELK search |
| 6 | Low | Detected within hours, investigation needed | Shows up in daily review, error rate charts |
| 7 | Very Low | Detected by customer report | Customer/agent support ticket triggers investigation |
| 8 | Remote | Found by chance or periodic audit | Discovered during routine code review or audit |
| 9 | Very Remote | Requires deep investigation | Only discoverable through detailed ELK log forensics |
| 10 | Undetectable | Cannot detect until major impact | Silent data corruption, gradual degradation |

## Scoring Procedure

```
FUNCTION score_fmea(incident, evidence):

  # ── SEVERITY (S) ──
  IF evidence.data_integrity_risk == HIGH:
    S = 9
  ELSE IF evidence.customer_facing AND evidence.affected_services > 5:
    S = 8
  ELSE IF evidence.customer_facing:
    S = 7
  ELSE IF evidence.affected_services > 3:
    S = 6
  ELSE:
    S = calibrate_manually_with_justification()

  # ── OCCURRENCE (O) ──
  # Use elk-query.sh to check error frequency:
  #   elk-query.sh errors --service <svc> --hours 24  → count
  #   elk-query.sh errors --service <svc> --hours 168 → count (7d)
  freq_24h = evidence.error_frequency.last_24h
  freq_7d  = evidence.error_frequency.last_7d

  IF freq_24h > 100: O = 10
  ELSE IF freq_24h > 10: O = 9
  ELSE IF freq_24h > 1: O = 8
  ELSE IF freq_7d > 10: O = 7
  ELSE IF freq_7d > 3: O = 6
  ELSE IF freq_7d > 0: O = 5
  ELSE: O = estimate_from_conditions()

  # ── DETECTION (D) ──
  detection_gap = time_between(first_error, first_alert_or_report)
  IF no_alert_exists: D = 8
  ELSE IF detection_gap < 2min: D = 2
  ELSE IF detection_gap < 10min: D = 3
  ELSE IF detection_gap < 30min: D = 4
  ELSE IF detection_gap < 1hour: D = 5
  ELSE IF detection_gap < 4hours: D = 6
  ELSE: D = 7

  # Adjust for auto-remediation
  IF auto_remediation_triggered: D = max(1, D - 2)

  RPN = S * O * D
  RETURN FMEAScore(S, O, D, RPN, classify_rpn(RPN))

FUNCTION classify_rpn(rpn):
  IF rpn > 200: RETURN "CRITICAL — immediate action required"
  IF rpn > 100: RETURN "HIGH — fix this sprint"
  IF rpn > 50:  RETURN "MEDIUM — fix next sprint"
  RETURN "LOW — backlog"
```

## Output Format

```yaml
fmea_score:
  severity:
    score: 7
    justification: "Core order creation unavailable for PREPAID tenants. Customer-facing. Confirmed via ELK status.keyword=500 filtered by TenantId.keyword=PREPAID."
  occurrence:
    score: 6
    justification: "42 errors in last 24h, 156 in last 7d. Occurs every weekday during peak hours."
  detection:
    score: 5
    justification: "Error rate alert fires within 15 min, but requires manual ELK investigation to diagnose. No auto-remediation."
  rpn: 210
  priority: "CRITICAL — immediate action required"
  comparison_note: "RPN of 210 exceeds critical threshold (200). Primary risk driver: customer-facing severity + weekly recurrence."
```
