# Root Cause Patterns & Classification

> Practical root cause classification framework for OrderTech investigations.
> Use alongside the 7 formal frameworks in `FRAMEWORKS.md`. This file provides
> the operational decision tree, algorithmic commands, and pattern recognition
> tables that bridge ELK evidence to root cause classification.

---

## The "What vs Why" Distinction

The investigation playbook and trace algorithms answer **WHAT happened**.
Without root cause analysis, you have observation, not diagnosis.

| Investigation phase | Answers | Key technique |
|---|---|---|
| 1. Trace | What services are involved, what's the call chain | `error-origin` → `single-trace` |
| 2. Compare | What's different about failing inputs | `compare`, `input-diff` |
| 3. Classify | Is this DATA, CODE, or ARCHITECTURE? | Classification table below |
| 4. Temporality | When did it start, is it getting worse? | `onset`, `deploy-correlate` |
| 5. Persistence | Will retrying fix it? | `permanence` |
| 6. Origin | Where did the bad data enter? | `data-lineage` |

---

## Root Cause Classification

```
┌─────────────────────────────────────────────────────────────────┐
│                    ROOT CAUSE CLASSIFICATION                     │
├────────────────────┬────────────────────────────────────────────┤
│ DATA issue         │ - Error varies by input value (MDN, acct)  │
│                    │ - Same code path works for other inputs    │
│                    │ - External system rejects specific values  │
│                    │ - Fix: data correction, not code change    │
├────────────────────┼────────────────────────────────────────────┤
│ CODE issue         │ - Missing guard for known permanent error  │
│                    │ - Infinite retry on non-transient failure  │
│                    │ - Hardcoded test value reachable in prod   │
│                    │ - Error not propagated with correct status │
│                    │ - Fix: code change required                │
├────────────────────┼────────────────────────────────────────────┤
│ ARCHITECTURE issue │ - Error amplified across many services     │
│                    │ - No circuit breaker for external failures │
│                    │ - BPMN retry with no max-attempts bound    │
│                    │ - Multiple paths to same backend (fragile) │
│                    │ - Fix: design/config change required       │
└────────────────────┴────────────────────────────────────────────┘
```

---

## Root Cause Decision Tree

```
Start with a failing request
│
├─ Run `compare` (success vs failure diff)
│   ├─ URI path segments differ
│   │   └─ The variable segment IS the discriminating input
│   │       ├─ Is it an entity ID? → DATA issue (bad data for this entity)
│   │       ├─ Is it a test/hardcoded value? → CODE issue (missing guard)
│   │       └─ Is it a valid value that should work? → EXTERNAL issue
│   ├─ Request body differs
│   │   └─ Specific body field causes failure → DATA or VALIDATION issue
│   └─ Same inputs, still fails
│       └─ TIME-dependent or INFRA issue → check `onset` and `deploy-correlate`
│
├─ Run `permanence` (same entity retried)
│   ├─ PERMANENT (identical error every time)
│   │   ├─ External system rejects it → DATA issue at external boundary
│   │   └─ Internal validation fails → CODE issue (missing validation upstream)
│   ├─ INTERMITTENT (sometimes succeeds)
│   │   └─ INFRA issue (capacity, timeout, network) → check DC distribution
│   └─ TRANSIENT (error changes each time)
│       └─ Race condition or concurrent modification → CODE/ARCHITECTURE issue
│
├─ Run `onset` (when did it start?)
│   ├─ NEW (appeared recently with single configLabel)
│   │   └─ DEPLOYMENT-CAUSED → the new version introduced a regression
│   ├─ STABLE (constant rate across versions)
│   │   └─ CHRONIC data or external issue → not code, not deployment
│   └─ INCREASING (getting worse over time)
│       └─ Data accumulation problem or resource leak → ARCHITECTURE issue
│
└─ Run `data-lineage` (where did the bad input originate?)
    ├─ External entry point (no X-Feign-Origin)
    │   └─ Bad data from API consumer, UI, or batch job
    ├─ Internal entry point (X-Feign-Origin present)
    │   └─ Trace the calling service — it may be transforming data incorrectly
    └─ No API_REQUEST found
        └─ Internal event-driven flow (message queue, BPMN timer)
```

---

## Five Root Cause Questions (Mandatory)

Every investigation MUST answer these before declaring root cause:

| # | Question | Algorithm | Verdict if skipped |
|---|---|---|---|
| 1 | What's DIFFERENT about failing vs succeeding requests? | `compare` | You don't know what triggers the failure |
| 2 | Is the error PERMANENT for this entity? | `permanence` | You don't know if retrying is wasteful |
| 3 | WHEN did this start happening? | `onset` | You don't know if it's a regression or chronic |
| 4 | Did a DEPLOYMENT cause it? | `deploy-correlate` | You don't know if rolling back would fix it |
| 5 | WHERE did the bad data enter? | `data-lineage` | You don't know who to fix (upstream vs downstream) |

---

## Root Cause Algorithms (via `elk-deep-trace.py`)

These commands implement the root cause layer. Run `elk-deep-trace.py <command> --help` for usage.

| Algo | Command | Input | Queries | Answers |
|---|---|---|---|---|
| G | `compare` | URI or error text | 3-5 | Why does THIS request fail when SIMILAR ones succeed? |
| H | `onset` | error text | 1 | WHEN did this error first appear? What deployed? |
| I | `input-diff` | URI pattern | 2 | What specific input values trigger failure? |
| J | `permanence` | globalTrackingId | 2 | Is retrying wasteful (permanent) or useful (transient)? |
| K | `data-lineage` | globalTrackingId | 1 | Where did the bad data ENTER the system? |
| L | `deploy-correlate` | error text | 1 | Did a new deployment introduce this error? |

### Algorithm Details

**G — Success vs Failure Comparison** (3-5 queries)
- Pull 1 FAILURE + 1 SUCCESS `API_RESPONSE` matching same URI
- Fetch the `API_REQUEST` for each (same threadContextId) to see inputs
- Diff URI path segments, request body, and caller (X-Feign-Origin)
- Diverging segment = the input that determines success vs failure

**H — Onset Detection** (1 query)
- 15-minute histogram of ERROR count for the error text over 24h
- Identifies: first-seen time, peak, trend (NEW/INCREASING/DECREASING/STABLE)
- Aggregates by `configLabel.keyword` — single version = possibly deployment-caused,
  multiple versions = data/external issue

**I — Input Divergence** (2 queries)
- Sample 20 failure URIs + 20 success URIs for the same endpoint
- Extract variable path segments (segments that differ across URIs)
- Show FAIL-ONLY values vs SUCC-ONLY values per segment position

**J — Permanence Test** (2 queries)
- Collect all ERROR/WARN logs for a globalTrackingId
- Extract error signatures (service + logType + status + message)
- 1 unique signature repeated N times = **PERMANENT** (data/external issue)
- Multiple varying signatures = **POSSIBLY TRANSIENT** (retry may help)
- Second query checks for any SUCCESS responses — if found, error is INTERMITTENT

**K — Data Lineage** (1 query)
- Find EARLIEST logs for a globalTrackingId (sort ascending)
- The first `API_REQUEST` is the ENTRY POINT
- X-Feign-Origin present = came from internal service (trace further)
- X-Feign-Origin absent = came from external source (system boundary)

**L — Deployment Correlation** (1 query)
- 1-hour histogram of ERRORs with sub-aggregation by `configLabel.keyword`
- Identifies version first-seen times — spike aligned with new version = deployment-caused
- Single version → check if new. Multiple versions → DATA/EXTERNAL issue.

---

## Common Root Cause Patterns

| Pattern | Indicators | Root cause type | Fix |
|---|---|---|---|
| Specific entity IDs always fail | `permanence` = PERMANENT, `compare` shows entity in URI | DATA — external system rejects this entity | Data correction in external system |
| Error appeared with new version | `onset` = NEW, `deploy-correlate` shows 1 configLabel | CODE — deployment regression | Rollback or hotfix |
| Retry loop on permanent error | `retry-detect` = loop, `permanence` = PERMANENT | ARCHITECTURE — no circuit breaker / max-retries | Add max-attempts bound, classify permanent errors |
| Same endpoint always fails | `compare` finds no success | CODE — endpoint is broken | Code fix required |
| Error rate uniform across DCs | `error-origin` DC distribution is even | SYSTEMIC — not DC-specific | Not an infrastructure issue |
| Error rate skewed to one DC | `error-origin` DC distribution is uneven | INFRA — possible DC-specific issue | Check DC health, routing, capacity |
| Multiple call paths to same backend | `call-topo` shows >1 caller | ARCHITECTURE — fragile coupling | Consolidate to single gateway |
| Test values reaching production | `test-in-prod` finds hits | CODE — missing environment guard | Add guard clause or remove test code |
| Error spans multiple configLabels | `deploy-correlate` shows >1 version | DATA or EXTERNAL — not code-related | Fix data source, not code |
| Entry point has no X-Feign-Origin | `data-lineage` shows external entry | EXTERNAL INPUT — bad data from consumer | Fix consumer or add input validation |

---

## Running the Full Pipeline

```bash
# Complete investigation: what → why → permanence → onset
elk-deep-trace.py full-investigate "error message or code" --hours 2

# For a specific entity already identified:
elk-deep-trace.py compare "/api/path/that/fails" --hours 2
elk-deep-trace.py permanence "<globalTrackingId>" --hours 24
elk-deep-trace.py onset "error text" --hours 24
elk-deep-trace.py data-lineage "<globalTrackingId>" --hours 24
elk-deep-trace.py deploy-correlate "error text" --hours 24
elk-deep-trace.py input-diff "/api/endpoint/pattern" --hours 2
```

## When the Pipeline is NOT Enough

The automated pipeline handles common cases. Human judgment still needed for:

1. **Code review**: The pipeline identifies WHICH service and WHICH error, but the
   actual source code must be read via `code-forensics` to understand WHY.
2. **Cross-system issues**: When `data-lineage` points to an external boundary.
3. **Race conditions**: Require analyzing CONCURRENT transactions to the same entity.
4. **Configuration issues**: Errors from wrong config values need MobileBackOfficeConfig review.
5. **BPMN process logic**: Timer-based retries and process decisions are in BPMN XML
   and Java delegates, not visible in ELK logs alone.
