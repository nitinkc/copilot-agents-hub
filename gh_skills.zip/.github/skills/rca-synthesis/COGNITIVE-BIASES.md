# Cognitive Biases in RCA — Detection & Mitigation

> Catalog of cognitive biases that systematically corrupt root cause analysis,
> with specific debiasing probes to apply at each investigation phase.
> Based on Kahneman's cognitive bias framework, CIA/Heuer's intelligence analysis
> debiasing, and 2023-2025 research on LLM confirmation bias.

## Phase-Based Debiasing Schedule

| Phase | Primary Bias Risk | Debiasing Mechanism |
|-------|------------------|---------------------|
| 0. Intake | Availability | Force 3 differences from recent similar incidents |
| 1. Log Retrieval | Anchoring | Query multiple services, not just the reported one |
| 2. Traversal | Anchoring | Attempt traversal from alternate starting point |
| 3. Code Investigation | Confirmation | Check for counter-evidence in git history |
| 4. Synthesis | Confirmation, Narrative | ACH matrix, dual-goal prompts, think-in-opposites |
| 4b. Critics | All biases | Devil's advocate + evidence critic + framework critic |
| 5. Recommendations | Hindsight | "Would this have been prioritized before the incident?" |
| 6. Validation | Automation | Human review checklist, suggested verification steps |

---

## 1. Anchoring Bias

**Definition**: Over-relying on the first piece of information encountered.

**RCA Manifestation**: The first error log becomes the assumed root cause. The first
hypothesis dominates all subsequent analysis.

**Debiasing probe (apply at Phase 1-2)**:
```
BEFORE proceeding with traversal from the initial error:
- "If we discovered this error LAST instead of FIRST, would we still prioritize it?"
- "What if the initial error is a SYMPTOM, not the cause?"
- "Start traversal from a DIFFERENT service in the blast radius."
```

**OrderTech implementation**: When investigating errors in any service, ALWAYS
query at least one additional service's errors in the same time window. Use
`elk-query.sh top-errors --hours N` for the broader view.

---

## 2. Confirmation Bias

**Definition**: Seeking evidence that supports existing beliefs while ignoring
contradictory evidence.

**RCA Manifestation**: Once a hypothesis is formed, the investigator searches for
logs that confirm it and stops looking for alternatives. Research shows LLMs
exhibit 16-93% reduced detection rates when primed with confirming framing.

**Debiasing probes (apply at Phase 4)**:
```
MANDATORY dual-goal instruction:
"For each piece of evidence:
 1. How does this SUPPORT the proposed root cause?
 2. How does this CONTRADICT the proposed root cause?
 3. What ALTERNATIVE root cause would this evidence also support?"

MANDATORY think-in-opposites:
"Assume the proposed root cause is WRONG. What is the strongest alternative?
 What evidence would you need to DISPROVE the current hypothesis?"
```

**OrderTech implementation**: The ACH matrix (`ACH-MATRIX.md`) is the primary
structural defense. It forces evaluation of ALL hypotheses vs ALL evidence.

---

## 3. Availability Bias

**Definition**: Overweighting information that comes to mind easily (recent, vivid).

**RCA Manifestation**: "We had a database issue last week, so this must be one too."

**Debiasing probe (apply at Phase 0)**:
```
"Has a similar incident occurred recently? If yes:
 - List 3 ways this incident DIFFERS from the previous one.
 - What root cause would NEVER be considered if we assume similarity?
 - Force at least one hypothesis from a completely different error category."
```

**OrderTech implementation**: When similar services or patterns appear, use
`elk-query.sh errors --service X --hours 168` to check whether the historical
pattern actually matches.

---

## 4. Hindsight Bias

**Definition**: Seeing past events as predictable after knowing the outcome.

**RCA Manifestation**: After finding root cause, the Five Whys chain seems "obvious."
Prevention recommendations are framed as "we should have known."

**Debiasing probe (apply at Phase 5)**:
```
"Given ONLY information available BEFORE the incident:
 - Would this root cause have been predictable?
 - Is the recommended prevention action something that would have been
   prioritized in normal sprint planning?
 - Are we recommending action because it's genuinely high-value, or because
   we now know the outcome?"
```

---

## 5. Narrative Bias

**Definition**: Constructing coherent stories from incomplete data.

**RCA Manifestation**: The Five Whys chain tells a clean, linear story. Real
failures are messy with multiple interacting causes. A "too clean" story is suspect.

**Debiasing probe (apply at Phase 4)**:
```
"Review the Five Whys chain:
 - Is the story TOO clean? Real incidents rarely have a single linear cause.
 - Are there pieces of evidence that DON'T fit the narrative? List them.
 - Would removing any single Why collapse the story? If yes, that Why needs
   stronger evidence."
```

---

## 6. Automation Bias

**Definition**: Over-trusting automated/AI output without verification.

**RCA Manifestation**: Engineers accept the AI-generated RCA without critical review.

**Mitigation (built into every RCA output)**:
```yaml
# Every RCA report MUST include:
confidence_and_limitations:
  composite_confidence: float
  key_assumptions: string[]
  evidence_gaps: string[]
  alternative_hypotheses: string[]
  human_review_required: boolean   # Always true for P1/P2
  suggested_verification_steps: string[]
```

---

## 7. Sunk Cost Bias

**Definition**: Continuing a course of action due to already invested effort.

**RCA Manifestation**: After hours pursuing one hypothesis, reluctance to pivot.

**Mitigation**: The adaptive depth algorithm's maximum revision cycle (3 rounds)
and the meta-reviewer's convergence detection prevent infinite loops. ACH provides
a structured pivot mechanism.

---

## LLM-Specific Debiasing Techniques

### Dual-Goal Prompt
```
"For each hypothesis, provide:
 1. The three strongest pieces of evidence FOR this hypothesis.
 2. The three strongest pieces of evidence AGAINST this hypothesis.
 3. What evidence would DEFINITIVELY prove this hypothesis wrong?"
```

### Think-in-Opposites
```
"Assume the opposite of the proposed root cause is true.
 What evidence supports this opposite conclusion?
 What would you need to see to believe the opposite?"
```

### Multi-Sample Consistency
Generate the Five Whys analysis 3 times independently. If all 3 converge on
the same root cause, confidence is HIGH. If they diverge, the evidence is
ambiguous. This is more reliable than self-reported confidence.
