---
name: pr-cognitive-debiasing
description: Counteract the 12 cognitive biases that degrade PR review quality. Based on ICSE 2020 field study findings and Kahneman dual-process theory. Forces System 2 engagement through structured interventions.
user-invocable: true
disable-model-invocation: true
---
# PR Cognitive Debiasing

Structured interventions to counteract biases that cause missed defects in code review.

## Biases and countermeasures

### 1. Anchoring Bias
**Risk**: PR title/description frames reviewer's expectations, reducing scrutiny.
**Counter**: Read diff before description. Compare independent assessment to stated intent. Flag divergences.

### 2. Confirmation Bias
**Risk**: Once initial impression forms, reviewer seeks confirming evidence only.
**Counter**: After forming impression, explicitly search for ONE counter-example that would invalidate it.

### 3. Halo Effect
**Risk**: Trusted/senior author's code gets reduced scrutiny.
**Counter**: Evaluate code on merit only. If catching yourself relaxing standards, note it.

### 4. Authority Bias
**Risk**: Junior reviewers defer to senior author's code.
**Counter**: Every finding is evidence-based regardless of author.

### 5. Status Quo Bias
**Risk**: "Matches existing patterns" accepted without evaluating if patterns are correct.
**Counter**: Existing patterns may be wrong. Evaluate pattern fitness, not just pattern match.

### 6. Decision Fatigue
**Risk**: Review quality degrades after 60 minutes or 400+ LOC.
**Counter**: Flag large PRs. Recommend splitting. Note reduced confidence on later files.

### 7. Bandwagon Effect
**Risk**: Seeing earlier "LGTM" reduces independent review depth.
**Counter**: Form verdict before reading other reviewers' comments.

### 8. IKEA Effect
**Risk**: Reviewer who helped design the approach under-scrutinizes implementation.
**Counter**: If reviewer participated in design, explicitly note potential bias.

### 9. Availability Bias
**Risk**: Recent bugs in similar code over-weights that area; areas without recent bugs get ignored.
**Counter**: Use structured checklist to ensure all dimensions are covered.

### 10. Dunning-Kruger Effect
**Risk**: Reviewer overestimates ability to evaluate unfamiliar code areas.
**Counter**: If reviewing unfamiliar domain, explicitly note confidence level.

### 11. Survivorship Bias
**Risk**: "This pattern has worked before" ignores cases where similar patterns caused incidents.
**Counter**: Check project history and past incidents for similar patterns.

### 12. Optimism Bias
**Risk**: "This probably won't happen" for edge cases and failure modes.
**Counter**: For each "unlikely" scenario, ask: "What is the blast radius if it does happen?"

## Output
- **Cognitive Bias Flags**: list of biases detected during this review (e.g., "Anchoring: PR description diverges from diff intent", "Decision Fatigue: PR exceeds 400 LOC")
- **Confidence adjustments**: areas where reviewer confidence is reduced (unfamiliar domain, large PR, dual-role reviewer)
- **Counter-example notes**: the one counter-example deliberately sought per Bias #2

When invoked as Phase 0 of `pr-code-review`, these outputs feed the "Cognitive Bias Flags" section of the Change Fit Report.

## Constraints
- Execute silently — do not produce a visible "Phase 0 report" in the chat unless a bias is detected that the lead must know about.
- Never skip this phase, even for small PRs. Small PRs are where halo effect and optimism bias are strongest.
- Do not let this phase take more than 2 minutes of wall-clock effort. If more than 3 biases are flagged, focus on the highest-impact ones.
- This phase does not produce findings with severity classifications — it produces awareness flags that sharpen the remaining phases.

## When to use
- Before every PR verdict (silently, as part of the review protocol)
- When a lead suspects rubber-stamping in the team
- During review retrospectives to identify which biases affected past reviews
- When training new reviewers on mission-critical review standards

## Integration with PR review
This skill is Phase 0 of the `pr-code-review` agent workflow.
It must execute **before** any code review begins (Phases 1–6).
It also feeds into the Change Fit Report: findings from the anchoring prevention and overload guard appear in the "Cognitive Bias Flags" output section.

The Socratic post-review check is embedded in `pr-risk-scoring` (Step 6) as a mandatory pre-verdict gate.
The shared checklist file `.github/instructions/mission-critical-checklists.instructions.md` is the single source of truth for the questions.
