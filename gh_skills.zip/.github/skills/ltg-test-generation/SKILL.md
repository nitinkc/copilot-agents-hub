---
name: ltg-test-generation
description: Generate deterministic mission-critical tests (JUnit5/Mockito/MockMvc/WireMock/embedded DB/ArchUnit/Spring Cloud Contract) from templates with happy/error/boundary/timeout coverage.
user-invocable: true
disable-model-invocation: true
---

# Skill: Test Generation

## Goal
Generate test classes using repo conventions and templates, covering all mandatory scenarios identified in the test plan.

## Inputs
- Test type assignments from `ltg-test-type-determination`
- Test gap report from `ltg-code-analysis`
- Best-practice checklist from `ltg-best-practice-context`
- Existing test files in the repo (for pattern matching)

## Hard Constraints
- Use JUnit 5.
- Use Mockito for mocks (avoid PowerMock).
- No sleeps. If waiting is required: bounded waits only.
- Tests must clearly document what they prove.
- Prefer Arrange/Act/Assert or Given/When/Then structure.

## Steps

### Step 1: Controller Tests (MockMvc)
- Use `@WebMvcTest(Controller.class)` + `@MockBean` for service dependencies.
- Required assertions:
  - Status codes
  - Response schema fields (key fields only)
  - Error envelope for failures (status + errorCode + correlationId)
  - Validation errors are deterministic (field -> code/message)

### Step 2: Service Unit Tests
- Test:
  - Happy path
  - Invalid input or precondition failures
  - Boundary values (max sizes, empty)
  - Domain exception mapping
  - Idempotency behavior if service performs side effects (via dedupe component)

### Step 3: Outbound Client Stub Tests
- Use WireMock/MockWebServer:
  - Simulate delayed response to prove timeout is enforced
  - Simulate 5xx burst to prove retry cap is enforced
  - Simulate malformed JSON to prove safe parsing behavior
- Assert:
  - Number of attempts does not exceed cap
  - Safe error handling (no raw parsing exceptions leaking)

### Step 4: Repository Tests
- Use `@JdbcTest` (JdbcTemplate) or `@DataJpaTest` (JPA).
- Include schema setup and verify:
  - Unique constraint behavior (duplicate insert triggers duplicate handling path)
  - Rollback behavior for failing transactions
  - Bounded queries (caps/pagination)
- Keep assertions on invariants, not DB vendor quirks.

### Step 5: Contract Tests (if repo uses Spring Cloud Contract)
- Place contracts under `src/test/resources/contracts/**`.
- Generate:
  - At least one contract for happy path
  - One contract for validation failure (400) if endpoint is public
  - Optionally one contract for domain error mapping
- Ensure provider verification base class uses MockMvc and stubs service layer appropriately.

### Step 6: ArchUnit Guard Tests (if needed)
- Add/update ArchitectureTest to enforce:
  - Controller does not depend on repository
  - Repository does not depend on outbound client
  - Outbound client creation is centralized (no `new RestTemplate` scattered)

## Output
Created/updated test files with:
- Happy + error + boundary coverage
- Deterministic time control (`Clock`) where needed
- Minimal but meaningful assertions
