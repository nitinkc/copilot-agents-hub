---
name: documentation-operations-governance
description: Generate or update governance and operations docs for a mission-critical service: glossary, ADRs, ownership rules, non-functional rules, observability, failure modes, threat model, data lifecycle, operations runbook, release/rollback, and data controls.
---
# Documentation Operations and Governance

## Use this when
- major behavior, dependency, release, observability, security, or operational rules changed
- the service lacks usable ops/governance documentation
- a feature introduces new business terms, decisions, or operating constraints

## Files to create/update (MANDATORY in Full Regeneration)

In **Full Regeneration** mode, ALL files below MUST be created. None are optional or lower-priority.
In **Change-Driven** mode, update only files affected by the current change — but if a file does not exist and its content category is relevant, bootstrap it.

- `docs/generated/glossary.md`
- `docs/generated/adr/README.md` and ADR records
- `docs/generated/ownership-and-operating-rules.md`
- `docs/generated/non-functional-rules.md`
- `docs/generated/06-operations-runbook.md`
- `docs/generated/07-release-readiness-and-rollback.md`
- `docs/generated/08-data-classification-and-controls.md`
- `docs/generated/09-slos-alerts-and-observability.md`
- `docs/generated/10-known-failure-modes.md`
- `docs/generated/11-security-threat-model.md`
- `docs/generated/12-data-lifecycle.md`
- `docs/generated/13-documentation-validation-and-coverage.md`
- `docs/generated/14-rule-inventory.md` (when operational or non-functional rules change)
- `docs/generated/15-entity-attribute-catalog.md` (when entities with data classification or lifecycle implications change)

## Goals
- make vocabulary stable for business + engineering
- preserve architectural decisions and why they were made
- make operational ownership and escalation obvious
- document cross-cutting rules (timeouts, retries, idempotency, compatibility, logging, security)
- catalog operational and non-functional rules in the rule inventory with stable IDs (see `dimension-extraction.instructions.md`)
- make observability, release, rollback, and failure handling safer
- make data-handling obligations explicit
- maintain entity/attribute catalog entries for entities with data classification or lifecycle significance
- validate the documentation system itself for mission-critical use

## Output
- files created/updated
- governance/ops deltas captured
- assumptions or missing inputs called out clearly

## Completion Gate (MANDATORY)

Before marking this step complete, verify file existence:

**Full Regeneration mode**: ALL 14 files listed above MUST exist. Count the files created/updated. If any are missing, generate them before proceeding. Report: `[Governance: N/14 files present]`.

**Change-Driven mode**: All files affected by the current change MUST be updated. If the total governance file count is below 10, treat as bootstrap and generate all missing files. Report which files were updated and which were skipped (with justification).

**Never categorize required files as "lower-priority" or "optional"**. Every file in the list serves a distinct audience or compliance need. Skipping any file defeats the purpose of mission-critical documentation.
