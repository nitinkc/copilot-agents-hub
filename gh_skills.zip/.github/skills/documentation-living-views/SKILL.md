---
name: documentation-living-views
description: Create or update living documentation for the repository after code or tests change. Maintain 4 audience-specific levels, governance/operations overlays, and machine-readable manifests/graphs. Use this when asked to update docs, document a change, refresh architecture docs, or explain what the service does to business, technical, or machine audiences.
---
# Documentation Living Views

## Goal
Maintain documentation that is useful to:
- business/product stakeholders
- architects/developers/operators
- machines/automation/LLMs

## Required documentation set (MANDATORY)
All files listed below MUST exist after Full Regeneration mode completes. In Change-Driven mode, update only affected files — but if a required file does not exist, it MUST be bootstrapped.
Create or update:
- `docs/generated/README.md`
- `docs/generated/01-business-capabilities.md`
- `docs/generated/02-service-context.md`
- `docs/generated/03-runtime-flows.md`
- `docs/generated/04-technical-map.md`
- `docs/generated/glossary.md`
- `docs/generated/05-dependency-catalog.md`
- `docs/generated/ownership-and-operating-rules.md`
- `docs/generated/change-impact-patterns.md`
- `docs/generated/non-functional-rules.md`
- `docs/generated/06-operations-runbook.md`
- `docs/generated/07-release-readiness-and-rollback.md`
- `docs/generated/08-data-classification-and-controls.md`
- `docs/generated/09-slos-alerts-and-observability.md`
- `docs/generated/10-known-failure-modes.md`
- `docs/generated/11-security-threat-model.md`
- `docs/generated/12-data-lifecycle.md`
- `docs/generated/13-documentation-validation-and-coverage.md`
- `docs/generated/14-rule-inventory.md`
- `docs/generated/15-entity-attribute-catalog.md`
- `docs/generated/adr/README.md` and ADR records when decisions change
- `docs/generated/examples/` when example diagrams or usage snippets would materially improve understanding
- `docs/generated/machine/service-manifest.yaml`
- `docs/generated/machine/dependency-graph.mmd`
- `docs/generated/machine/change-impact-map.yaml`
- `docs/generated/machine/doc-index.yaml`
- `docs/generated/machine/rule-inventory.yaml`
- `docs/generated/machine/entity-catalog.yaml`
- `docs/generated/machine/api-contract-catalog.yaml`

All `docs/generated/` paths are relative to the project root, not the workspace root.
In multi-project workspaces, each project maintains its own `docs/generated/` folder under its own root directory.

When a machine-readable contract spec exists for an API (OpenAPI, WSDL, .proto, AsyncAPI, BPMN XML), it is the authoritative source of truth for that interface's contract. Documentation should reference or derive from it rather than duplicating contract details inline. When no spec exists, document the API fully in the machine API contract catalog (`docs/generated/machine/api-contract-catalog.yaml`). See `dimension-extraction.instructions.md` for the full contract hierarchy.

## Audience/outcome model
### Level 0 — Business capabilities
- what the service does in business language
- who uses it
- major capabilities grouped by business function
- important business rules and constraints
- examples of outcomes, not code internals
- preferred diagrams: flowchart, journey, mindmap, requirementDiagram

### Level 1 — Service context
- service boundaries and responsibilities
- upstream callers and downstream systems/datastores
- ownership/team and critical interfaces
- high-level capability-to-backend mapping
- preferred diagrams: C4 context/container, architecture, dependency graph

### Level 2 — Runtime flows
- key flows per API/capability
- dependency interactions and sequence of operations
- validation, dedupe/idempotency, retries/timeouts, failure paths
- preferred diagrams: flowchart, sequenceDiagram, stateDiagram-v2

### Level 3 — Technical map
- component/package map
- controller/service/repository/client structure
- config points, exception mapping, security hooks, observability notes
- testing strategy and important guard rails
- preferred diagrams: dependency graph, erDiagram, focused technical flowcharts

### Governance/operations overlays
- glossary for business terms and synonyms
- ADRs for major decisions and tradeoffs
- dependency catalog for endpoint/capability -> backend detail
- ownership + operating rules for support/escalation
- change-impact patterns for requirement triage
- non-functional rules for cross-cutting engineering policies
- operations runbook and release/rollback guidance
- data classification and controls
- SLOs/alerts/observability
- known failure modes
- security threat model
- data lifecycle
- documentation validation/coverage

### Machine dimension
- endpoints, capabilities, dependencies, data stores, invariants, ownership, impact keywords, documentation coverage, change-impact mapping, rule inventories, entity catalogs, and API contract catalogs
- designed so a machine/LLM can decide whether a new requirement likely touches this repo
- machine-readable contract specs (OpenAPI, WSDL, .proto, AsyncAPI, BPMN XML) are the source of truth for their respective API contracts; when no spec exists, document the API fully in the machine API contract catalog (`docs/generated/machine/api-contract-catalog.yaml`)

## Procedure
1) Determine the documentation delta from the current change:
- business-visible behavior changed?
- dependencies/backends changed?
- rules/errors/bounds changed?
- internal technical structure changed?
- operations/release/data-handling/security/observability changed?
- entities/data model changed?
2) If docs do not exist, bootstrap the full set.
3) Update only the impacted artifacts unless the repo lacks a coherent baseline.
4) Keep docs audience-specific and concise.
5) Link the levels to each other.
6) Use diagrams intentionally by audience.
7) Update machine-readable docs whenever APIs, dependencies, rules, or ownership change.
8) Update examples when a new diagram pattern or flow type is introduced.
9) Apply the dimension extraction framework (`dimension-extraction.instructions.md`):
- extract business, logic, data, integration, risk/operability, and traceability dimensions
- create/update rule inventory (`docs/generated/14-rule-inventory.md` + `docs/generated/machine/rule-inventory.yaml`) when rules change
- create/update entity/attribute catalog (`docs/generated/15-entity-attribute-catalog.md` + `docs/generated/machine/entity-catalog.yaml`) when entities change
- create/update machine API contract catalog (`docs/generated/machine/api-contract-catalog.yaml`) when API endpoints change
- cross-reference rule IDs in capabilities, entities, and tests

## Mandatory Document Structure Templates

When generating or updating documentation files, follow these section templates to ensure every file is complete and deterministic. Never produce a file that omits required sections. When **updating** an existing file, read it first and **merge** — do not replace existing content with less content.

### `docs/generated/01-business-capabilities.md` (Level 0)
See `documentation-business-functional-views/SKILL.md` for the authoritative section template. Must include:
1. Service Overview, 2. Actors & Stakeholders, 3. Core Business Capabilities, 4. Business Rules Summary, 5. Business Process Diagrams, 6. Key Business Outcomes.

### `docs/generated/02-service-context.md` (Level 1)
See `documentation-business-functional-views/SKILL.md` for the authoritative section template. Must include:
1. Service Boundary & Responsibilities, 2. Upstream Callers, 3. Downstream Dependencies, 4. Capability-to-Backend Mapping, 5. Ownership & Team, 6. Context Diagrams.

### `docs/generated/03-runtime-flows.md` (Level 2)
| # | Section | Purpose |
|---|---------|---------|
| 1 | **Overview** | Which runtime flows are documented and scope of this document |
| 2 | **Per-API / Per-Capability Flows** | For each key API or capability: sequence of operations, validations applied, business rules enforced, dependencies called (in order), error/failure paths, retry/timeout behavior. Use sequenceDiagram or flowchart per flow. |
| 3 | **Cross-Cutting Runtime Behaviors** | Idempotency/deduplication strategy, common validation patterns, error handling and error envelope, retry/timeout policies, circuit breaker behavior (if applicable) |
| 4 | **Runtime Diagrams** | Sequence diagrams per flow, flowcharts for decision paths, stateDiagram-v2 for entity state transitions |

### `docs/generated/04-technical-map.md` (Level 3)
| # | Section | Purpose |
|---|---------|---------|
| 1 | **Package & Component Structure** | What packages exist, what each owns, layer boundaries |
| 2 | **Controller / Service / Repository / Client Map** | Which classes implement which capabilities, organized by layer |
| 3 | **Configuration** | Key config properties, profiles, environment-specific settings |
| 4 | **Exception & Error Mapping** | How exceptions are caught, classified, and mapped to API error responses |
| 5 | **Security Hooks** | Authentication, authorization, input validation entry points |
| 6 | **Observability** | Logging conventions, metrics, distributed tracing setup |
| 7 | **Testing Strategy & Guard Rails** | Test types in use, guard tests (ArchUnit etc.), coverage expectations |
| 8 | **Technical Diagrams** | Component dependency graph, erDiagram for data model, focused technical flowcharts |

### Override Prevention Rule (applies to ALL files)

When updating any existing documentation file:
1. **Read first**: Always read the existing file before generating new content.
2. **Section completeness check**: Verify the new output has at least the same sections as the existing file. If the existing file has sections not in the template, preserve them.
3. **Content richness check**: If an existing section has more detail than the generated replacement, merge the richer content into the generated structure — do not replace rich content with thin content.
4. **Never drop sections**: If a template section has no new content to add, keep the existing content unchanged for that section rather than omitting it.

## Output
- files created/updated
- which levels changed and why
- which diagrams were added/updated and for which audience
- any assumptions or missing context

## File-Existence Verification Gate (MANDATORY for Full Regeneration)

After all documentation steps complete, verify that every file in the Required documentation set exists on disk.

**Required files checklist** (all must exist after Full Regeneration):

| Category | Files |
|----------|-------|
| Primary (4) | `01-business-capabilities.md`, `02-service-context.md`, `03-runtime-flows.md`, `04-technical-map.md` |
| Governance (15) | `glossary.md`, `05-dependency-catalog.md`, `06-operations-runbook.md`, `07-release-readiness-and-rollback.md`, `08-data-classification-and-controls.md`, `09-slos-alerts-and-observability.md`, `10-known-failure-modes.md`, `11-security-threat-model.md`, `12-data-lifecycle.md`, `13-documentation-validation-and-coverage.md`, `14-rule-inventory.md`, `15-entity-attribute-catalog.md`, `ownership-and-operating-rules.md`, `non-functional-rules.md`, `change-impact-patterns.md` |
| Index (1) | `README.md` |
| ADR (1) | `adr/README.md` |
| Machine (7) | `machine/service-manifest.yaml`, `machine/dependency-graph.mmd`, `machine/change-impact-map.yaml`, `machine/doc-index.yaml`, `machine/rule-inventory.yaml`, `machine/entity-catalog.yaml`, `machine/api-contract-catalog.yaml` |

**Verification procedure:**
1. List all files in the docs directory.
2. Compare against the checklist above.
3. Any missing file is a **blocking gap** — generate it before marking documentation complete.
4. Report the verification result: `[All N/28 required files present]` or `[MISSING: file1, file2, ...]`.

In Change-Driven mode, this gate applies only to files that already existed or were expected to be created by the current change. However, if the docs directory has fewer than 20 of the 28 required files, treat this as a bootstrap scenario and generate all missing files.
