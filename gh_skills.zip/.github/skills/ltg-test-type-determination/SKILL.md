---
name: ltg-test-type-determination
description: Determine which test types to generate based on changed code category (Controller, Service, Client, Repository, Error/Security) and mission-critical standards.
---

# Skill: Test Type Determination

## Goal
Choose the correct test type for each changed production file using a decision matrix that maps file categories to test strategies.

## Inputs
- Test gap report from `ltg-code-analysis`
- Best-practice checklist from `ltg-best-practice-context`

## Decision Matrix

### Controllers (Spring MVC)
Generate:
- **MockMvc web-slice tests** (`@WebMvcTest`):
  - Happy path (2xx)
  - Validation failures (400)
  - Auth failures (401/403) if applicable
  - Error mapping (5xx safe envelope; stable errorCode)
- **Provider contract verification** (if repo uses Spring Cloud Contract):
  - Contract files for stable endpoint behavior
  - OR OpenAPI-based verification if repo uses that
  - **When to add contracts:** Add contract tests when the endpoint is consumed by another service and the response schema is part of a cross-service contract. Skip if the endpoint is internal-only or the repo does not already use Spring Cloud Contract.

### Services
Generate:
- **Unit tests** (JUnit 5 + Mockito):
  - Happy path
  - Business error path
  - Boundary/cap behavior
  - Idempotency behavior if side effects occur via service entrypoint
- **Integration tests** ONLY when needed:
  - Transaction semantics, serialization, or DB constraint behavior that cannot be validated in unit tests

### Outbound Clients (HTTP)
Generate:
- **Stub-server tests** (WireMock/MockWebServer):
  - Correct request shape (method/path/headers)
  - Timeout enforced (delayed stub)
  - Retry cap enforced (sequence of 5xx then success; verify attempt count)
  - Malformed/partial response handling

### Repositories/DAOs (JDBC/JPA)
Generate:
- **Embedded DB integration tests** (`@JdbcTest` / `@DataJpaTest`):
  - Unique constraints for dedupe
  - Rollback behavior where relevant
  - Bounded query behavior (caps/pagination)
- Note: Acknowledge embedded DB != Oracle; tests should focus on invariants and bounded behavior.

### Error Handling (ControllerAdvice)
Generate:
- **MockMvc tests** asserting:
  - Stable error envelope shape
  - Stable errorCode mapping
  - No stack trace exposure

### Security Configs / Filters
Generate:
- **MockMvc tests** asserting:
  - Protected endpoints require auth (401/403)
  - Role-based access if applicable

### Cross-Cutting Architecture Drift
Generate (only if missing or drift detected):
- **ArchUnit guard tests**:
  - Layering rules
  - Forbid dangerous APIs if repository enforces them
  - Optional "test pairing" convention enforcement

## Output
For each changed production file:
- List of test files to create/update
- Scenario checklist per test file
