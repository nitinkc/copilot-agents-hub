---
name: acceptance-criteria-gherkin
description: Generate mission-critical acceptance criteria in Given/When/Then form, including happy path, alternate paths, error cases, boundaries, and business rules.
---

# Skill: Acceptance Criteria (Gherkin)

## Goal
Convert requirements and use cases into testable acceptance criteria in Given/When/Then form, covering happy path, alternate paths, error cases, boundaries, and business rules.

## Inputs
- Structured requirement summary (from requirements-intake-clarify or similar)
- Use-case list with actors and triggers
- Known business rules and constraints
- Assumptions (to be reflected in ACs where relevant)

## Hard Constraints
- Every AC must be deterministic and testable — no vague language like "should work properly".
- Always include failure/error ACs alongside happy-path ACs.
- Do not assume business rules that are flagged as unclear — write the AC with the assumption noted.
- Group ACs by use case or business rule for traceability.
- Cap at 20 ACs per grooming session unless scope justifies more.

## Steps

### Step 1: Identify AC Categories
For each use case or business rule, determine which AC categories apply:
- **Happy path**: Normal successful flow
- **Invalid input / boundary**: Malformed, missing, or out-of-range inputs
- **Business rule rejection**: Valid input that violates a business rule
- **Duplicate / idempotency**: Replay of a previously processed request
- **Dependency failure**: Upstream/downstream system unavailable or returning errors
- **Backward compatibility**: Existing consumers continue to work unchanged
- **Safe user-visible errors**: Error responses are consistent and do not leak internals

### Step 2: Write Given/When/Then ACs
For each identified category, write one or more ACs:
- **Given**: Preconditions and context (state, data, configuration)
- **When**: Action or trigger (API call, event, user action)
- **Then**: Observable outcome (response, state change, side effect, error envelope)

Use concrete example values where possible (specific IDs, amounts, timestamps).

### Step 3: Note Unclear or Assumed Behavior
For each AC where the behavior was assumed (not explicitly stated in the requirement):
- Add a note: `[ASSUMPTION: <what was assumed and why>]`
- These become clarification items for stakeholder review.

### Step 4: Group and Number
- Group ACs by use case or rule.
- Number sequentially: AC1, AC2, ... ACn.
- Ensure traceability: each AC should trace back to a requirement or use case.

## Output
- **AC1..ACn** in Given/When/Then format
- Grouped by use case or business rule
- Each AC numbered for traceability
- Assumption notes on any AC based on inferred behavior
- Summary count: total ACs, happy-path count, error/boundary count