---
name: business-perspective-review
description: Evaluate business, customer, and operations perspectives including API consumer experience, business logic coherence, operational readiness, documentation, privacy, and disaster recovery.
---

# Skill: Business Perspective Review

## Goal
Identify issues that are technically correct but problematic from a user, business, or operational perspective. Produce scored findings bridging the gap between implementation and business outcomes.

## Inputs
- Target codebase (Spring Boot microservice source)
- Repository standards from `.github/instructions/`
- Playbook defaults from `.github/shared/playbook-defaults.yaml`
- Output format rules from `audit-output.instructions.md`

## Rule Sources (MANDATORY — load before auditing)

Load these instruction files with `read_file`. They define the rules; this skill defines the AUDIT METHODOLOGY (what to search for, how to score).

| Instruction file | Rules used in |
|-----------------|---------------|
| `copilot-instructions.md` non-negotiable G (observability) | Step 3 (operational readiness) |
| `security-and-data-handling.instructions.md` | Step 7 (data privacy) |
| `documentation-living-views.instructions.md` | Step 5 (documentation completeness) |
| `spring-boot-22-mvc-rest.instructions.md` | Step 1 (API consumer experience, error envelope) |
| `mission-critical-checklists.instructions.md` | Step 8 (anti-pattern scan + Socratic) |

The instruction files are the single source of truth for what the rules ARE. This skill defines HOW to check compliance — the search patterns, diagnostic procedures, and scoring criteria.

## Steps

### Step 1: API Consumer Experience

**Error Response Quality**:
- Are error responses helpful to API consumers? Check for:
  - Machine-readable error codes (not just HTTP status)
  - Human-readable error messages (not stack traces or generic "Internal Server Error")
  - Guidance on how to fix the issue (e.g., "field 'email' must be a valid email address")
  - Consistent error envelope across all endpoints
  - Correlation/request IDs in error responses for support debugging
- Standard: RFC 7807 (Problem Details), Microsoft API Guidelines

**API Discoverability**:
- Is OpenAPI/Swagger documentation available and accurate?
- Are endpoints self-documenting (descriptive names, consistent patterns)?
- Are request/response examples provided in the spec?
- Is there a Postman collection or API client SDK?
- Are deprecation notices clear with migration guides?

**Response Consistency**:
- Consistent date/time formats across all endpoints (ISO 8601)
- Consistent pagination format (offset/limit vs cursor-based, consistent wrapper)
- Consistent null handling (omit null fields vs include as null)
- Consistent field naming convention (camelCase vs snake_case — pick one)
- Consistent collection response format (wrapped vs bare array)

**Rate Limiting & Throttling**:
- Are rate limits documented?
- Do responses include rate limit headers (X-RateLimit-*)?
- Are rate limit error responses informative (retry-after, limit info)?

### Step 2: Business Logic Coherence

**Business Rule Centralization**:
- Are business rules scattered across controllers, services, and validators?
  → should be centralized in domain services or domain entities
- Are there duplicate business rules in different classes?
- Are business rules documented (inline comments, ADRs, or wiki links)?
- Are business rules testable in isolation (without Spring context)?
- Standard: Domain-Driven Design, Clean Architecture

**Domain Model Expressiveness**:
- Does the code use domain-specific language? (ubiquitous language)
- Are there generic names that should be domain-specific?
  - "processData()" → should be "calculatePremium()" or "validateClaim()"
  - "handleRequest()" → should be "submitOrder()" or "initiateTransfer()"
- Are domain concepts modeled explicitly?
  - Money amounts as BigDecimal (not double/float)?
  - Dates with proper types (LocalDate vs LocalDateTime vs Instant)?
  - Status fields as enums (not String)?
  - IDs as value objects (not raw Long/String)?
- Standard: Ubiquitous Language (DDD), Value Object pattern

**BPMN Process Business Alignment**:
- Do process definition names match business terminology?
- Do task names match what business stakeholders would understand?
- Are decision points (gateways) aligned with documented business rules?
- Are process SLAs defined and measurable?
- Is the process hierarchy (main process, subprocesses, call activities)
  aligned with business process hierarchy?

**Feature Flag / Toggle Management**:
- Are incomplete features protected by feature flags?
- Are there stale feature flags that should be cleaned up?
- Is there a consistent feature flag implementation pattern?
- Standard: Feature Toggles (Martin Fowler)

### Step 3: Operational Readiness

**Health & Readiness**:
- Are Spring Boot Actuator health endpoints configured?
- Are there custom health indicators for:
  - Database connectivity
  - External service availability
  - Flowable engine status
  - Message broker connectivity
  - Cache availability
- Is Cloud Foundry health check type set to `http` with the Actuator health endpoint?
- Are Spring Boot Actuator readiness/liveness health groups configured?
- Is there a sufficient health-check-invocation-timeout for slow-starting services?
- Standard: Cloud Foundry Health Check Patterns, Spring Boot Actuator Health Groups

**Graceful Degradation**:
- What happens when an external dependency is down?
  - Does the service crash? Return 500? Serve cached/stale data?
- Are there fallback behaviors defined for each external dependency?
- Is there a circuit breaker dashboard/monitoring?
- Can the service operate in a degraded mode?
- Standard: Resilience Engineering, Graceful Degradation Patterns

**Deployment & Rollback**:
- Are database migrations backward-compatible? (Can you rollback the deployment
  without rolling back the migration?)
- Are API changes backward-compatible?
- Is there a canary/blue-green deployment strategy?
- Are there deployment-time health checks?
- Is there a documented rollback procedure?
- Standard: Zero-Downtime Deployment Patterns

**Runbook & Incident Response**:
- Is there a runbook documenting:
  - How to restart/recover the service
  - Common failure modes and their resolutions
  - How to check service health
  - How to access logs and metrics
  - Escalation procedures
  - On-call contact information
- Are there documented SLAs/SLOs for the service?
- Standard: Google SRE Book, PagerDuty Incident Response

### Step 4: Customer-Facing Impact Assessment

For each technical issue found in other audit categories, assess:
- **Customer Impact**: Does this issue affect end users? How?
- **Business Impact**: Does this affect revenue, compliance, or reputation?
- **Frequency**: How often would this issue manifest?
- **Blast Radius**: How many users/transactions are affected?

Produce an impact matrix:
```markdown
## Customer Impact Assessment

| Finding ID | Technical Issue | Customer Impact | Business Impact | Frequency | Blast Radius | Priority |
|---|---|---|---|---|---|---|
| TD-001 | {issue} | {impact} | {impact} | {freq} | {radius} | {priority} |
```

### Step 5: Documentation Completeness

**Code Documentation**:
- Public API Javadoc/KDoc coverage (% of public methods documented)
- Domain model documentation (are entities, value objects, aggregates documented?)
- Complex algorithm documentation (are non-obvious implementations explained?)
- Decision documentation (ADRs for significant choices)

**Operational Documentation**:
- README completeness (setup, build, run, test, deploy instructions)
- API documentation (OpenAPI spec present and accurate?)
- Architecture documentation (C4 diagrams or equivalent?)
- Runbook/operational guide present?
- Onboarding guide for new developers?

**BPMN Documentation**:
- Process definitions with documentation elements
- Process start conditions and input variables documented
- Process SLAs and business rules documented
- Process monitoring/alerting thresholds documented

**Documentation Freshness**:
- README last updated date vs last code change date
- OpenAPI spec matches current implementation?
- ADRs marked as superseded when decisions changed?
- Standard: Documentation as Code, C4 Model (Simon Brown)

### Step 6: Accessibility of API Responses (WCAG considerations)

Even for APIs (not UIs), evaluate:
- Error messages suitable for display to end users (clear, non-technical language)
- Response data includes enough context for accessible UI rendering
- Date/time responses include timezone information
- Monetary values include currency code
- Enum values have human-readable labels (not just codes)
- Standard: WCAG 2.2 (relevant for API responses consumed by accessible UIs)

### Step 7: Data Privacy & Compliance

- PII handling: Is personal data identified and protected?
- Data retention: Are there cleanup/purging mechanisms for old data?
- Audit trail: Are data modifications tracked (who, when, what changed)?
- Consent management: If applicable, is user consent tracked?
- Right to deletion: Can user data be fully purged?
- Data classification: Are data sensitivity levels defined?
- Flowable process history: Is PII in process variables subject to retention policies?
- Standard: GDPR/CCPA principles (even if not directly applicable, good practice)

### Step 8: Disaster Recovery & Business Continuity

**Recovery Objectives**:
- Are RTO (Recovery Time Objective) and RPO (Recovery Point Objective) defined?
- Do database backups exist with a tested restore procedure?
- Are backups stored in geographically separate locations?
- Is there an automated restore verification process?
- Standard: ISO 22301 (Business Continuity Management)

**Failover & High Availability**:
- Is there a documented failover procedure for each critical component?
- Are database replicas configured (read replicas, standby)?
- Is there automatic failover for the primary database?
- Are Flowable process instances recoverable after a failover?
- Are message brokers (Kafka/RabbitMQ) configured for HA?

**Data Protection**:
- Is there a data replication strategy (sync vs async)?
- Are critical configuration/secret backups maintained outside the cluster?
- Is there a point-in-time recovery capability for the database?
- Are Flowable process history tables included in backup scope?

**Chaos Engineering Readiness**:
- Has the team conducted failure injection exercises?
- Are there automated chaos experiments (Chaos Monkey, Litmus)?
- Has the service been tested under: network partition, dependency failure, resource exhaustion?
- Is there a game day / disaster recovery drill cadence?
- Standard: Principles of Chaos Engineering (Netflix)

## Output

Write your findings to `docs/generated/audit/05-BUSINESS-PERSPECTIVE.md` immediately upon completing this phase. Do NOT defer writing to a later consolidation phase — the file must be written now to survive context compaction.

The file must follow the finding format defined in `audit-output.instructions.md`.
Use finding IDs prefixed with `BP-` (e.g., BP-001, BP-002).

Include a business readiness matrix at the top:
```markdown
## Business & Operational Readiness

| Dimension | Status | Score (1-5) | Key Concerns |
|---|---|---|---|
| API Consumer Experience | {✅/⚠️/🛑} | {n}/5 | {summary} |
| Business Logic Coherence | {✅/⚠️/🛑} | {n}/5 | {summary} |
| Operational Readiness | {✅/⚠️/🛑} | {n}/5 | {summary} |
| Documentation | {✅/⚠️/🛑} | {n}/5 | {summary} |
| Customer Impact | {✅/⚠️/🛑} | {n}/5 | {summary} |
| Data Privacy | {✅/⚠️/🛑} | {n}/5 | {summary} |
| Disaster Recovery | {✅/⚠️/🛑} | {n}/5 | {summary} |
```
