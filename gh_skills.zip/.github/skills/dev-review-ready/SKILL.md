---
name: dev-review-ready
description: Produce a review-ready summary: what changed, what tests prove, how compatibility is preserved, and what risks remain.
user-invocable: true
disable-model-invocation: true
---

# Skill: Review-Ready Output

## Goal
Produce the final review summary with execution proof, making developer review and commit easy and safe.

## Inputs
- All generated code and test files
- Test execution results from all VERIFY phases
- Critical Review output

## Steps

### Step 1: Collect Artifacts
- Gather all created/updated production code and test files.
- Collect VERIFY phase results: iteration counts, fixes applied, final pass/fail status per phase.
- Collect Critical Review output: cross-check matrix, gap list, confidence statement.

### Step 2: Build Feature Summary
- Summarize what was built in 1-3 bullets.
- Map each acceptance criterion to the tests that prove it.

### Step 3: Assess Compatibility
- Confirm no fields/endpoints removed/renamed unless versioned.
- Confirm stable errorCode meanings preserved.
- If any breaking change exists, document it with justification.

### Step 4: Compile Test Inventory
- List every test file added/updated.
- For each, state what it proves (happy/error/boundary/timeout/idempotency/security).

### Step 5: Summarize Execution Proof
- For each VERIFY phase: iteration count, what was fixed, final status.
- Full suite regression result.
- Production bugs discovered (if any) and how they were fixed.

### Step 6: Document Risks and Next Steps
- List assumptions (e.g., embedded DB vs Oracle differences).
- List remaining risks and manual testing recommendations.
- List remaining AC if more slices are needed.

## Output

### Required Sections
1. **Feature summary** (1-3 bullets)
2. **Acceptance criteria addressed** (AC1..ACn)
3. **Compatibility note**:
   - No fields/endpoints removed/renamed unless versioned
   - Stable errorCode meanings preserved
4. **Test inventory**:
   - List test files added/updated
   - What each proves (happy/error/boundary/timeout/idempotency/security)
5. **Execution proof**:
   - All VERIFY phases summarized: iteration counts, fixes applied, final status
   - Full suite regression result
   - Production bugs discovered (if any)
6. **Assumptions and known limitations** (e.g., embedded DB vs Oracle)
7. **Remaining risks** and manual testing recommendations
8. **Next steps** (if more AC remain)

## Developer Gate (MANDATORY)

After producing the output above, present it to the developer with the following explicit action block. Do NOT proceed until the developer responds.

### Present to Developer

Include this action block at the end of the review-ready summary:

```
---
## Developer Action Required

Please review the preliminary summary above and choose one:

1. **Approve** — proceed to Test Verification (steps 8–14)
2. **Request changes** — specify what needs fixing (I will loop back to the appropriate BUILD/INTEGRATE phase, apply fixes, and return here)
3. **Approve with notes** — proceed to Test Verification but carry your notes as additional verification focus areas

Optional:
- Flag any concerns about compatibility, missing scenarios, or risk items you want prioritized during Test Verification
- Request specific manual testing recommendations be added

> Waiting for your response before continuing.
```

### After Developer Responds

| Developer action | Agent behavior |
|---|---|
| **Approve** | Proceed to Test Verification (step 8). |
| **Request changes** | Loop back to the appropriate phase (RED/GREEN/INTEGRATE) to address the requested changes. After changes are applied and verified, return to this step and re-present the updated summary. |
| **Approve with notes** | Carry the developer's notes as additional focus areas into Test Verification (step 8). Document them in the gap report input. |
| **Flag concerns** | Add flagged concerns to the "Remaining risks" section and to the Test Verification input as priority areas. Then proceed to step 8. |
