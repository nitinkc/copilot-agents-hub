---
name: pr-change-fit-analysis
description: >
  Change-fit analysis for pull requests. Evaluates pattern consistency,
  architectural alignment, API contract impact, dependency ripple effects,
  cross-service ecosystem impact, test ecosystem fit, documentation staleness,
  and ticket/requirement traceability — all in one pass.
user-invocable: true
disable-model-invocation: true
---
# PR Change Fit Analysis

Evaluate a PR's changes against the whole repository AND the requirements to determine
architectural fit, ecosystem impact, and requirement alignment. Produces dimension-level
scores, file-level evidence for every deviation, and actionable recommendations that
feed directly into the composite risk score.

## Inputs
- PR diff (parsed change inventory from Phase 1 of `pr-code-review`, or standalone diff)
- Full repository access (for pattern comparison)
- Optional: ticket/AC context (improves intent classification and enables Dimension H)

## Procedure (deterministic — execute all 8 dimensions in order)

### Dimension A — Pattern Consistency
Evaluate against existing project conventions. For each file changed, compare:
1. Controller patterns: thin controllers, validation approach, error envelope shape
2. Service patterns: orchestration vs. domain logic separation, DI style
3. Repository/DAO patterns: query style, naming, null handling
4. Client patterns: timeout config, retry config, circuit breaker usage
5. Error handling: exception hierarchy, error codes, RFC 7807 compliance
6. Logging: structured log format, correlationId/traceId presence, log levels
7. Configuration: property naming, profile usage, externalization
8. BPMN (if applicable): delegate patterns, variable naming, error boundary events

**Score 1–5.** For each deviation: cite `file:line`, state the existing pattern, state the deviation.

### Dimension B — Architectural Alignment
1. Layer boundary violations (controller → repo direct, service → controller import)
2. Dependency direction (domain must not depend on infrastructure)
3. Hexagonal boundary compliance (ports/adapters separation)
4. Cross-cutting concern placement (security, logging, metrics — correct layer?)
5. Package structure consistency with existing modules
6. Need for new ADR? Flag if the PR introduces a novel pattern or tech choice.

**Score 1–5.** Evidence required for every finding.

### Dimension C — API Contract Impact
1. Backward compatibility: removed/renamed fields, changed types, new required params
2. Naming consistency: endpoint naming vs. existing API surface
3. Response shape alignment: envelope structure, pagination, error format
4. Versioning compliance: is the change versioned if breaking?
5. TM Forum Open API alignment (if applicable to this repo)
6. OpenAPI/Swagger spec sync: does the spec match the implementation?

**Score 1–5.** Any breaking change without versioning = automatic Critical finding.

### Dimension D — Runtime Integration Impact
Evaluate every outbound integration point that is new or modified in this PR.
Rule sources — load and cross-check compliance for each integration type:
- `outbound-http-resttemplate.instructions.md` — for HTTP client changes
- `jdbc-oracle.instructions.md` — for database/repository changes
- `flowable-bpmn-java-missioncritical.instructions.md` + `flowable-java-delegates.instructions.md` — for BPMN integration changes

#### D.1 — Outbound HTTP / REST Calls
For every new or changed RestTemplate/WebClient/HTTP client call:
1. Timeouts: connect, read, and overall deadline explicitly configured?
2. Retries: bounded count, backoff, idempotency-safe (GET/PUT only, or idempotency key)?
3. Circuit breaker / fallback: configured for non-critical calls?
4. Error mapping: HTTP errors mapped to typed domain exceptions (not raw HttpClientErrorException)?
5. Trace propagation: correlationId/traceId forwarded in outbound headers?
6. Response validation: response body validated before use (null checks, expected shape)?
7. Logging: outbound call logged with endpoint, outcome, latency, correlationId?

#### D.2 — Database / Repository Interactions
For every new or changed query/repository method:
1. Prepared statements only (no string concatenation for SQL)?
2. Result set bounded (pagination, LIMIT, FETCH FIRST)?
3. Index coverage: new WHERE/JOIN clauses have supporting indexes (or flagged)?
4. Connection lifecycle: connections acquired via pool, released promptly (try-with-resources)?
5. Transaction scope: minimal, no long-running transactions holding locks?
6. Null handling: nullable columns handled explicitly (Optional or null-safe checks)?

#### D.3 — BPMN / Process Integration
For every new or changed delegate, listener, or process definition:
1. Process variable contracts: names and types documented and consistent?
2. Service task error boundaries: JavaDelegate failures caught by boundary error events?
3. Delegate state: no mutable instance fields in singleton delegates?
4. Timer/async behavior: async continuations at appropriate boundaries?
5. Signal/message contracts: preserved for external consumers?

#### D.4 — Messaging (Kafka, JMS, RabbitMQ)
For every new or changed producer/consumer:
1. Message schema: backward-compatible changes (additive fields only)?
2. Consumer error handling: DLQ strategy, poison pill handling, bounded retries?
3. Producer idempotency: deduplication key or idempotent producer config?
4. Ordering guarantees: partition key strategy preserved?

#### D.5 — Cache Interactions
For every new or changed cache operation:
1. Cache key: deterministic, bounded length, no PII?
2. TTL: explicitly set, appropriate for data freshness needs?
3. Invalidation: correct triggers, no stale reads after writes?
4. Shared cache risk: keys/namespaces scoped to avoid cross-service collision?

#### D.6 — Configuration Dependencies
1. New required properties: have defaults, documented, no secret in code?
2. Changed defaults: backward-compatible with existing deployments?
3. Environment-specific scoping: profiles correctly configured?

**Score 1–5.** Any outbound call without timeouts = minimum Medium. Any new integration point without logging/tracing = Medium. Any SQL concatenation = Critical.

### Dimension E — Cross-Service Ecosystem Impact
Evaluate the PR's ripple effects across the microservice ecosystem.
This is the deep analysis — score based on cumulative risk across all 6 categories.

#### E.1 — API Consumer Impact
- Which services consume the APIs modified in this PR?
- Are endpoint signatures (URL, method, params, response shape) preserved?
- Are error codes and error envelope structures preserved?
- Are new required fields backward-compatible (nullable or with defaults)?
- Are deprecated fields still returned during transition period?
- Are pagination contracts preserved?

#### E.2 — BPMN Process Chain Impact
- Does this PR modify Flowable process definitions?
- Are process variable names/types preserved for downstream service tasks?
- Are signal/message event contracts preserved?
- Do boundary event changes affect the orchestration flow?
- Are there in-flight process instances that would be affected?
- Is process version migration needed?

#### E.3 — Shared Library Impact
- Does this PR modify code in a shared library or common module?
- Which downstream services depend on the modified library code?
- Are the changes backward-compatible at the binary level?
- Do consumers need to rebuild or update their dependency version?
- Is a phased rollout needed (library first, then consumers)?

#### E.4 — Event/Message Contract Impact
- Are message schemas (Kafka, RabbitMQ, etc.) modified?
- Are consumer groups affected?
- Is the schema change backward-compatible (Avro, Protobuf rules)?
- Are there dead-letter queue implications?

#### E.5 — Configuration Impact
- Do shared config changes (config server, vault) affect other services?
- Are environment-specific profiles correctly scoped?
- Are feature flags shared across services?

#### E.6 — Data Contract Impact
- Are database schema changes visible to other services (shared schema)?
- Are there read replicas or materialized views affected?
- Are cache keys/TTLs shared across services?

**Score 1–5.** Produce:
- Affected services list with impact type and severity
- Contract compatibility assessment per consumer
- Coordinated deployment requirements (feeds Dimension D of `pr-deployment-readiness`)
- Risk classification: self-contained | ripple-low | ripple-medium | ripple-high | ecosystem-wide

### Dimension F — Test Ecosystem Fit
1. Test structure: follows existing naming and package conventions?
2. Test type appropriateness: unit for logic, MockMvc for HTTP, integration for DB
3. Fixture/helper reuse: using existing test utilities vs. creating duplicates?
4. Coverage on changed lines: are new/modified code paths tested?
5. Missing test categories: boundary, negative, timeout, idempotency, security
6. Test determinism: no sleep-based waits, no order-dependent tests

**Score 1–5.** Missing test coverage on new code paths = minimum High finding.

### Dimension G — Documentation Staleness
1. API docs (OpenAPI, README) reflect changes?
2. Machine manifests (service-manifest.yaml) updated?
3. Impact intelligence artifacts (change-impact-map) updated?
4. Operational runbooks reflect new failure modes?
5. ADRs created for new architectural decisions?
6. Living documentation levels (L0–L3) affected but not updated?

**Score 1–5.** Stale docs on public API changes = High finding.

### Dimension H — Ticket / Requirement Traceability
If ticket/AC details are provided, evaluate requirement alignment.
If no ticket is provided: infer intent from the diff, produce an inferred traceability
assessment with explicit confidence markers, and note `[Dimension H: no ticket provided, intent inferred from diff]`.
If ticket fetch failed (Jira unavailable / HTTP 401 / HTTP 403): produce inferred traceability
from the diff only, cap score at 2 (reduced confidence), and note:
`[Dimension H: Jira unavailable — <error reason>. Intent inferred from diff only. Score capped at 2. Say "retry Jira" at the next checkpoint if token updated.]`
This is semantically different from "no ticket" — a ticket key exists but context could not be retrieved.
If the lead later says "retry Jira" and the fetch succeeds, re-run Dimension H with full ticket context and update the score.

1. **AC → Code mapping** — which code changes implement which AC?
2. **Gap detection** — ACs with no corresponding code change
3. **Scope creep detection** — code changes not traced to any AC
4. **Behavioral drift** — changed behavior not described in any AC
5. **Definition of Ready check** — was the ticket ready before coding started?
6. **Implicit requirements** — behaviors the code implements that should become explicit ACs
7. **Test coverage per AC** — does each AC have at least one test validating it?
8. **Regulatory traceability** — can the change chain be traced from requirement → code → test → deployment for audit?

**Score 1–5.** Produce:
- Traceability matrix: AC → files → tests → status
- Gap list (unaddressed ACs)
- Scope creep list (untraced changes)
- Behavioral drift warnings
- Suggested AC refinements
- Definition of Ready assessment

**Scoring rules for Dimension H:**
- ACs with no code changes = High finding per gap
- Code changes with no AC trace and no justification = Medium finding
- All ACs mapped with tests = score 1
- No ticket provided but intent clearly inferable = score 2 max (reduced confidence)
- Ticket fetch failed (Jira unavailable / 401 / 403) = score 2 max (reduced confidence). Semantically different from "no ticket" — a ticket key exists but context could not be retrieved. Log `[Dimension H: Jira unavailable]` and offer "retry Jira" at checkpoint.

## Output Format

### When standalone (self-contained report)
```markdown
# Change Fit Analysis — PR #{number}

## Summary
One paragraph: overall fit assessment, key risks, recommendation.

## Dimension Scores
| Dimension | Score (1–5) | Key Findings |
|-----------|-------------|-------------|
| A. Pattern Consistency | X | ... |
| B. Architectural Alignment | X | ... |
| C. API Contract Impact | X | ... |
| D. Dependency/Integration | X | ... |
| E. Cross-Service Ecosystem | X | ... |
| F. Test Ecosystem Fit | X | ... |
| G. Documentation Staleness | X | ... |
| H. Ticket/Requirement Traceability | X | ... |

## Detailed Findings
For each finding: dimension, severity, file:line evidence, existing pattern, deviation, recommendation.

## Cross-Service Blast Radius Map
Affected services, interfaces, and coordination needs (from Dimension E).

## Traceability Matrix
AC → files → tests → status (from Dimension H).

## Recommendations
- Align to existing pattern (cite which pattern)
- Propose pattern evolution via ADR (if justified)
- Accept deviation with documented rationale
```

### When invoked as Phase 3 of `pr-code-review` agent
Produce the same analysis but format as the **Change Fit Assessment** + **Ticket Alignment**
+ **Cross-Service Impact** sections of the Change Fit Report.

## Risk Score Contribution
This skill feeds into `pr-risk-scoring` across five dimensions:
- **Pattern deviation** → 5% weight (Dimensions A, B)
- **Backward compatibility** → 15% weight (Dimension C)
- **Cross-service impact** → 10% weight (Dimension E)
- **Correctness risk** → 20% weight (Dimension H — unaddressed ACs)
- **Test confidence gap** → 15% weight (Dimensions F, H — ACs without tests)

## Constraints
- Score EVERY dimension 1–5. Never skip a dimension.
- Every score < 4 MUST have at least one file-level evidence citation.
- Do not produce generic findings. Every finding must reference specific files in THIS PR.
- If a dimension is not applicable (e.g., no API changes for Dimension C), score 5 and state "N/A — no changes in this dimension."
- Maximum 3 recommendations per dimension to keep actionable.
- For Dimension H without ticket: always produce inferred traceability, never skip.
