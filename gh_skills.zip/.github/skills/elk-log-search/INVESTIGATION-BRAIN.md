# ELK Investigation Brain

> Operational knowledge for ELK log analysis: index quirks, field semantics,
> message parsing, query building, and investigation anti-patterns.
>
> **Scope**: ELK-specific knowledge only. For:
> - Traceability chain (configLabel → code) → `code-forensics/NAMING-AND-RESOLUTION.md`
> - Cross-service deep trace → `service-traversal/SKILL.md` + `DAG-ALGORITHM.md`
> - Root cause classification & decision tree → `rca-synthesis/ROOT-CAUSE-PATTERNS.md`

---

## 1. ELK Indexes — Prod vs Lower

**Prod** (`--env prod`, default):
- `order-tech-*`: service logs. URL → `wildcard` on `uri.keyword`. Status → `status.keyword` (string). Trace → strip hyphens from nginx `vcap_request_id`.
- `nginx-prod-*`: access logs. URL → `query_string` on `message` only (wildcard on `request_uri` fails). Status → `http_status` (string).
- Other: `bis-prod-*`, `vendor-proxy-prod-*`, `bom-prod-*`

**Lower** (`--env lower`):
- `order-tech-lower-*` — **NOT** `order-tech-*`. This is the #1 gotcha.
- `nginx-lower-*`: same fields as prod nginx. `request_uri` field exists (may work with wildcard — differs from prod).
- Other: `bis-lower-*`, `vendor-proxy-lower*` (no hyphen before `*`), `cdr-lower-*`, `jaeger-span-*`

| Dimension | Prod | Lower |
|---|---|---|
| Service log index | `order-tech-*` | `order-tech-lower-*` |
| Nginx index | `nginx-prod-*` | `nginx-lower-*` |
| Datacenters | `wc-g2`, `po-g2`, `as-g7`, `as-g6` | `ch2-g2`, `g1`, `ch2h-d1`, `ch2-g4`, `pob-d1` |
| Environments | `mbosProd` (1.8B/day) | `mbosStage` (3.1M/hr), `mbosPreprod` (1.4M/hr), `otInt`, `mbosPerf`, `otQa`, `mbosDemo`, `otDev` |
| Volume (1hr) | ~90M docs | ~5.8M docs |
| Multiple versions | Rare (hotfix only) | Common (stage/QA/preprod each run different builds) |
| Broken fields | None | `%{[parsed_message][field]}` appears in ~2.7K docs (parsing failures) |

---

## 2. Key ELK Fields and What They Mean

### `serviceName` — which instance is running

Format: `{dc-prefix}-{service-slug}-production`

| DC Prefix | Datacenter |
|---|---|
| `g2wc-` | `wc-g2` (West Coast) |
| `g2po-` | `po-g2` (Portland/East) |
| `g7as-` | `as-g7` (Ashburn) |
| `g6as-` | `as-g6` (Ashburn legacy) |
| `g3-` | `g3` (Legacy) |

Examples:
- `g2wc-biller-account-production` — the biller-account service running in wc-g2
- `g7as-customer-gateway-production` — customer-gateway in as-g7

The **service-slug** in serviceName may differ from the configLabel slug:
- serviceName slug: `biller-account` (no prefix)
- configLabel slug: `mbos-biller-account` (has prefix)

**Always use wildcard** for serviceName queries to match across DCs:
```json
{ "wildcard": { "serviceName.keyword": "*biller-account*" } }
```

### `configLabel` — exact build artifact version

Format: `{prefix}-{service-name}-{major}.{minor}.{build}[.{hotfix}]`

Examples:
- `mbos-biller-account-1.0.817` — base build 817
- `mbos-customer-gateway-1.0.1682.3` — hotfix 3 off base 1682
- `bo-account-1.0.276` — different prefix, same pattern

**Known prefixes**: `mbos-`, `ds-`, `bo-`, `wkfl-`, `xoms-`, `mbo-`, `nxg-`, `sik-`, `xm-`, `bis-`, `taxes-`, `om-`

**Version format**:
- 3 segments `{major}.{minor}.{build}` = base build
- 4 segments `{major}.{minor}.{build}.{hotfix}` = hotfix off the base branch

**configLabel IS the gateway to everything**: config branch, source code, commit, PR, Jira ticket. See Section 4.

### Both fields in the same log entry

Every `order-tech-*` document contains BOTH fields:
- `serviceName`: identifies WHERE it's running (which DC, which instance)
- `configLabel`: identifies WHAT code is running (which exact build)

Use case: if errors spike, check configLabel first — was there a new deploy?

---

## 3. `order-tech-*` Message Field

The `message` field is nested JSON. Top-level `_source` has structured fields,
but deep details hide inside `message`:

```python
inner = json.loads(doc["message"])
inner["context"]    # headers, body, uri, duration, guid — all here
inner["exception"]  # stack trace (when present)
```

### Traps
- `duration` is sometimes a list: `v[0] if isinstance(v, list) else v`
- `GlobalTrackingId` has two spellings: query both `GlobalTrackingId` (match) and `globaltrackingid.keyword` (term)

### Two timestamps — know which to use

There are TWO `@timestamp` values with different meanings:

| Timestamp | Where | What it represents | Use for |
|---|---|---|---|
| Top-level `@timestamp` | `doc["@timestamp"]` | ELK event processing time (when Logstash/ELK ingested the log) | **Time range filters** (`gte: now-1h`) — fast, indexed |
| Inner `@timestamp` | `json.loads(doc["message"])["@timestamp"]` | Actual application log time (when the code emitted the log) | **Sequencing events**, display order, latency analysis |

**Rule:** Use top-level `@timestamp` for search range filters (it's indexed
and fast). Use the inner `@timestamp` from the `message` JSON when you need
to understand the actual sequence of events or display a timeline — it's
more accurate for ordering because it reflects when the application actually
logged, not when ELK processed it.

```python
# Sequencing example: sort by actual application time
inner = json.loads(hit["_source"]["message"])
app_timestamp = inner.get("@timestamp")  # actual log time — use this for ordering
elk_timestamp = hit["_source"]["@timestamp"]  # ingestion time — may differ by seconds
```

The difference is usually small (milliseconds to seconds), but when
reconstructing a call chain across services or understanding the exact order
of events within a transaction, the inner timestamp is the ground truth.

---

## 4. Investigation Playbook — Universal Troubleshooting Workflow

> **Design principle: classify input first, minimize round trips, maximize parallel work.**
> Investigations start from MANY different inputs — not just a service name.
> This workflow handles all entry points and converges them into the same
> code resolution pipeline.

### STEP 0: Classify the input — what did the user give you?

**This is the most critical step.** The input determines which ELK fields
to query and whether you can pre-resolve anything locally.

```
Input the user provides             ELK field(s) to use                        Pre-resolve locally?
───────────────────────────────     ──────────────────────────────────────      ────────────────────
A) Service name                     configLabel.keyword (wildcard)              YES — slug → repo → group
B) Error message / stack trace      message (query_string), logger_name.keyword NO — search first
C) Order ID (OMS_*, business key)   message (query_string on ID)                NO — search first
D) Account number                   comcastAccountNumber.keyword (term)          NO — search first
E) GlobalTrackingId                 GlobalTrackingId (match) + globaltrackingid.keyword (term)  NO
F) ThreadContextId                  threadContextId.keyword (term)              NO — search first
G) Session ID                       message (query_string on session value)      NO — search first
H) URI / API path                   uri.keyword (wildcard)                      NO — search first
I) HTTP status codes (5xx, 4xx)     status.keyword (terms)                      NO — search first
J) Combination of above             Combine with bool.must                      Partial (if service included)
K) Free-form text                   message (query_string)                      NO — search first
```

#### Domain context: what these IDs mean in the transaction lifecycle

These are general guidelines — if they don't fit the data you see, fall back
to exploration and let the ELK results guide you.

```
 ┌──────────────────────── BUYFLOW / SHOPPING ────────────────────────┐  ┌──── ORDER MANAGEMENT ────┐
 │                                                                     │  │                           │
 │  Consumer → nginx/gateway → services                                │  │  BPMNs / workflows        │
 │                                                                     │  │                           │
 │  GlobalTrackingId ─────────────────────────────────────────────────────────────────────────────────│
 │  (unique per session, tracks ALL transactions in that session)      │  │  (may carry through)      │
 │                                                                     │  │                           │
 │  SessionId ─────────────────────────────────────┐                   │  │                           │
 │  (generated at buyflow start, traced until       │                   │  │                           │
 │   order submit — buyflow context only)           │                   │  │                           │
 │                                                  │                   │  │                           │
 │  ThreadContextId (per API/service call)          │                   │  │  ThreadContextId          │
 │  (tracks all logs within ONE transaction         │                   │  │  (per API/service call)   │
 │   in one service — request + response)           │                   │  │                           │
 │                                                  ▼                   │  │                           │
 │                                          ┌──── ORDER SUBMIT ────┐   │  │                           │
 │                                          │  OrderId created     │───┼──│→ OrderId used everywhere  │
 │                                          └──────────────────────┘   │  │  (OMS_*, order-related)   │
 └─────────────────────────────────────────────────────────────────────┘  └───────────────────────────┘
```

**Practical rules for choosing which ID to search:**

| User's problem domain | Best ID to search | Why | Scope |
|---|---|---|---|
| Shopping / cart / buyflow issue | **SessionId** | Covers entire buyflow from start to submit | One buyflow session |
| Broad session tracing (all activity) | **GlobalTrackingId** | Unique per session across most apps | All transactions in session |
| One specific API call failing | **ThreadContextId** | Correlates request + response + downstream in one service | One transaction, one service |
| Post-submit order issue (fulfillment, provisioning, billing) | **OrderId** (e.g. OMS_*) | Created at submit, used across all order management | All BPMN/workflow services |
| Customer-level investigation | **Account number** | Spans all sessions and orders for one customer | All activity for account |

**Traffic flow** (helps understand where to look):
- Consumer traffic enters through **nginx/gateways** → routed to **services**
- For buyflow issues, start at gateway logs and trace inward
- For order management issues, start at the BPMN/workflow service logs

**logType semantics — understanding the request lifecycle within one service:**

```
              ┌─── Service A ──────────────────────────────────────────────────┐
              │                                                                 │
  inbound     │  API_REQUEST ──→ STANDARD (business logic) ──→ API_RESPONSE    │
  request ───▶│                       │                                         │
              │                       ├── FEIGN_REQUEST ──→ (Service B) ──→ FEIGN_RESPONSE
              │                       │                                         │
              │                       └── STANDARD (more processing)            │
              └─────────────────────────────────────────────────────────────────┘
                         ▲ all share the same threadContextId ▲
```

| logType | What it represents | When to filter on it |
|---|---|---|
| `API_REQUEST` | Inbound request received by this service | See what was sent TO this service |
| `API_RESPONSE` | Outbound response returned by this service | See response code, duration, what was returned |
| `FEIGN_REQUEST` | Outbound call this service makes to a downstream service | Trace downstream dependencies |
| `FEIGN_RESPONSE` | Response received from a downstream service | Check downstream errors, latency |
| `STANDARD` | Regular application logs (business logic, exceptions, debug) | Stack traces, business rule violations, processing details |
| `DOWNSTREAM_REQUEST` / `DOWNSTREAM_RESPONSE` | Alternative naming for outbound calls (some services use this instead of FEIGN) | Same as FEIGN — check both |

**Tracing within one transaction:** Filter by `threadContextId.keyword` to get
ALL log entries (API_REQUEST + STANDARD + FEIGN_REQUEST + FEIGN_RESPONSE +
API_RESPONSE) for one API call. This shows the complete picture of what
happened inside one service for one request. If distributed tracing is
available, use traceId/spanId to follow the request across service boundaries.

**Workflow/BPMN/OMS tracing — IDs that span multiple workflows:**

| ID | Scope | Where to search | Use case |
|---|---|---|---|
| `businessKey` | Across ALL workflows/BPMNs for one order | `message` (query_string) | Trace an order through its entire OMS lifecycle |
| `mboOrderId` | Across ALL workflows/BPMNs for one order | `message` (query_string) | Same as businessKey — some services use this name |
| `processInstanceId` | ONE specific workflow/BPMN execution | `message` (query_string) | Debug a specific workflow run (e.g. why did this provisioning instance fail?) |
| `OrderId` (OMS_*) | All order management processing | `message` (query_string) | Broad order investigation post-submit |

**Guideline:** For order issues, start with `businessKey` or `mboOrderId` to
see the full picture across workflows, then narrow to `processInstanceId` for
the specific failing workflow instance. These are general patterns — if a
particular service uses different field names, fall back to free-text search
in the `message` field.

**Key rule:** If the input includes a service name (even partial), ALWAYS
pre-resolve it first (Step 1). If no service is mentioned, go straight to
Step 2 with the appropriate ELK query — the results will GIVE you the
configLabel/service.

### STEP 1: Pre-resolve service (ONLY if service name is in the input)

Skip this step if the user gave you an order ID, tracking ID, error message,
etc. without mentioning a specific service — you'll discover the service
from the ELK results.

```bash
SERVICE_INPUT="<what-user-said>"   # e.g. "biller-account", "mbos-customer-gateway", "provisioning"

# Exact match
SLUG="$SERVICE_INPUT"
REPO=$(jq -r --arg s "$SLUG" '.services[] | select(.service==$s) | .repo_name' \
  .github/shared/service_mappings.json)

# Partial match if exact fails
if [[ -z "$REPO" || "$REPO" == "null" ]]; then
  MATCHES=$(jq -r --arg s "$SERVICE_INPUT" \
    '.services[] | select(.service | contains($s)) | "\(.service)|\(.repo_name)"' \
    .github/shared/service_mappings.json)
  # If ambiguous (multiple matches), ask user or pick most likely
fi

# Pre-compute group path for Artifactory (needed in Step 3)
GROUP=$(grep "^service:${SLUG}=" .github/shared/artifactory-path-map.conf | cut -d= -f2)
[[ -z "$GROUP" ]] && GROUP=$(grep "^prefix:${SLUG%%-*}=" .github/shared/artifactory-path-map.conf | cut -d= -f2)
```

### STEP 2: Build the ELK query based on input type

**Write a Python script to `/tmp/` for anything beyond trivial queries.**
Inline zsh + JSON + jq is fragile with nested quotes.

The query structure is always the same — `bool.must` with the input-specific
filter(s) plus standard aggs. Swap the filter clause based on input type:

#### Input-type → ELK filter clause mapping:

```python
# A) Service name (from Step 1)
{"wildcard": {"configLabel.keyword": f"{SLUG}-*"}}

# B) Error message or stack trace text
# Quote exact phrases, use AND for multi-term:
{"query_string": {"query": "\"NullPointerException\" AND \"AccountService\"", "default_field": "message"}}

# C) Order ID (OMS_*, or any business key)
{"query_string": {"query": "\"OMS_852289720\"", "default_field": "message"}}
# Also try: {"match": {"message": "OMS_852289720"}}

# D) Account number
{"term": {"comcastAccountNumber.keyword": "8495100123456789"}}

# E) GlobalTrackingId — MUST search BOTH spellings (critical!)
{"bool": {"should": [
    {"match": {"GlobalTrackingId": "<tracking-id>"}},
    {"term": {"globaltrackingid.keyword": "<tracking-id>"}},
    {"match": {"threadContextId": "<tracking-id>"}}
], "minimum_should_match": 1}}

# F) ThreadContextId
{"term": {"threadContextId.keyword": "<thread-context-id>"}}

# G) Session ID (not a dedicated field — lives inside message)
{"query_string": {"query": "\"<session-id>\"", "default_field": "message"}}

# H) URI / API path
{"wildcard": {"uri.keyword": "/api/customer/*/orders"}}

# I) HTTP status codes
{"terms": {"status.keyword": ["500", "502", "503", "504"]}}
# Combine with logType for API responses:
# {"term": {"logType.keyword": "API_RESPONSE"}}

# J) Combination — put multiple clauses in bool.must:
# {"bool": {"must": [clause_A, clause_B, clause_C, ...]}}
# Example: 5xx errors for a specific account:
# {"bool": {"must": [
#     {"term": {"comcastAccountNumber.keyword": "8495100123456789"}},
#     {"terms": {"status.keyword": ["500","502","503","504"]}},
#     {"term": {"logType.keyword": "API_RESPONSE"}}
# ]}}

# K) Free-form text (last resort — expensive, may be slow)
{"query_string": {"query": "<user's exact words>", "default_field": "message"}}
```

#### The standard aggs block (same for ALL input types):

Always include these aggregations — they tell you everything in one query:

```python
STANDARD_AGGS = {
    "by_configLabel": {"terms": {"field": "configLabel.keyword", "size": 10}},
    "by_logger": {
        "terms": {"field": "logger_name.keyword", "size": 15},
        "aggs": {"sample": {"top_hits": {
            "size": 1,
            "_source": ["@timestamp", "configLabel", "serviceName", "datacenter",
                         "logger_name", "LogEventMessage", "message",
                         "threadContextId", "globaltrackingid",
                         "logType", "status", "uri", "comcastAccountNumber"],
            "sort": [{"@timestamp": "desc"}]
        }}}
    },
    "by_dc": {"terms": {"field": "datacenter.keyword", "size": 10}},
    "by_level": {"terms": {"field": "level.keyword", "size": 5}},
    "by_service": {"terms": {"field": "serviceName.keyword", "size": 10}},
    "by_logType": {"terms": {"field": "logType.keyword", "size": 10}}
}
```

**Why `by_service` and `by_configLabel`**: When the input is NOT a service name
(e.g. order ID, tracking ID), these aggs tell you WHICH services are involved.
This is how you discover the service from a non-service input.

**Why `by_logType`**: Shows whether the hits are requests, responses, downstream
calls, or standard logs. Crucial for understanding the request flow.

#### Full query template (Python):

```python
import subprocess, json, sys

WORKSPACE = "/Volumes/MyDrive/git-modesto/ordertech-copilot-playbook"

# Build the filter clause based on input type (see mapping above)
input_filter = ...  # one of the clauses from the mapping

# Optional: add level filter if investigating errors specifically
# Omit for trace/all-levels investigation
level_filter = {"term": {"level.keyword": "ERROR"}}

# Time range: default 1h for errors, 24h for traces, 7d for rare events
time_range = {"range": {"@timestamp": {"gte": "now-1h"}}}

# Combine filters — only include non-None
must_clauses = [f for f in [input_filter, level_filter, time_range] if f]

query = json.dumps({
    "size": 5,  # also get raw hits for full message/stack trace
    "sort": [{"@timestamp": "desc"}],
    "query": {"bool": {"must": must_clauses}},
    "_source": ["@timestamp", "configLabel", "serviceName", "datacenter",
                "logger_name", "LogEventMessage", "message",
                "threadContextId", "globaltrackingid", "logType", "status",
                "uri", "comcastAccountNumber", "code"],
    "aggs": STANDARD_AGGS
})

# Execute via elk-query.sh (handles auth, cookie refresh, env selection)
ELK = f"{WORKSPACE}/.github/skills/elk-log-search/scripts/elk-query.sh"
r = subprocess.run(
    [ELK, "raw", "--body", query],
    capture_output=True, text=True, timeout=30)
data = json.loads(r.stdout)
raw = data.get("rawResponse", data)  # ALWAYS unwrap .rawResponse

# --- Parse results ---
total = raw["hits"]["total"]
if isinstance(total, dict): total = total["value"]

# Which services are involved? (critical for non-service-name inputs)
services = [(b["key"], b["doc_count"]) for b in raw["aggregations"]["by_service"]["buckets"]]
labels = [(b["key"], b["doc_count"]) for b in raw["aggregations"]["by_configLabel"]["buckets"]]
loggers = raw["aggregations"]["by_logger"]["buckets"]
dcs = [(b["key"], b["doc_count"]) for b in raw["aggregations"]["by_dc"]["buckets"]]
levels = [(b["key"], b["doc_count"]) for b in raw["aggregations"]["by_level"]["buckets"]]
log_types = [(b["key"], b["doc_count"]) for b in raw["aggregations"]["by_logType"]["buckets"]]

# Print summary
print(f"Total hits: {total}")
print(f"Services: {services}")
print(f"ConfigLabels: {labels}")
print(f"LogTypes: {log_types}")
print(f"Levels: {levels}")
print(f"DCs: {dcs}")
print(f"Top loggers:")
for b in loggers:
    hit = b["sample"]["hits"]["hits"][0]["_source"]
    msg = hit.get("LogEventMessage") or "(in message field)"
    print(f"  [{b['doc_count']:>5}] {b['key']}: {msg[:120]}")

# Extract stack trace / context from first raw hit
for hit in raw["hits"]["hits"]:
    src = hit["_source"]
    try:
        inner = json.loads(src.get("message", "{}"))
        st = inner.get("stack_trace", "")
        if st:
            print(f"\nStack trace ({src.get('configLabel')}):")
            print(st[:2000])
            break
        ctx = inner.get("context")
        if ctx:
            print(f"\nContext ({src.get('configLabel')}):")
            print(json.dumps(ctx, indent=2)[:1500])
            break
    except: pass
```

### STEP 3: Extract configLabel from results → resolve to code

The ELK results from Step 2 always contain `configLabel`. Use it to resolve
to the exact source code commit via the `code-forensics` skill:

```
read_file .github/skills/code-forensics/NAMING-AND-RESOLUTION.md
```

Quick reference — the resolution chain:
1. Parse configLabel → slug + version
2. Resolve slug → repo via `service_mappings.json` (done in Step 1 if service was given)
3. Slug + version → Artifactory → commit SHA
4. Commit → PR → Jira ticket
5. Clone + checkout exact commit: `git fetch origin $SHA && git checkout $SHA`

The full resolution commands, naming traps, version-to-branch mapping,
and hotfix clone patterns are in `NAMING-AND-RESOLUTION.md`.

**If multiple services are involved** (e.g. tracing a request across services),
repeat Step 3 for each configLabel. The call chain order is visible from:
- `X-Feign-Origin` header (comma-separated configLabels)
- Timestamps (earliest → latest)
- `logType` (API_REQUEST on service A → FEIGN_REQUEST on service A → API_REQUEST on service B)

### STEP 4: Analyze (with code checked out + ELK data)

**Choose analysis path based on what Step 2 revealed:**

| What Step 2 shows | Analysis action |
|---|---|
| **Stack trace in message** | Find file + line in checked-out code: `find /tmp/$REPO -name "ClassName.java" -path "*/main/*"`, read the line, check PR diff |
| **Feign error (4xx/5xx from downstream)** | Extract downstream service from Feign URL → repeat Step 3 for that service |
| **Multiple services in results** | Map the call chain via configLabel timestamps, investigate the service with the root ERROR |
| **No stack trace, just error code** | Check config: `gh api repos/comcast-modesto/MobileBackOfficeConfig/git/trees/${LABEL} --jq '.tree[].path'` |
| **Data validation / business logic** | Check DRL rules: `gh api repos/comcast-modesto/MspRuleConfig/git/ref/heads/${SLUG}` |
| **Timeout / circuit breaker** | Check config branch for timeout values, retry settings |
| **BPM JOB_EXECUTION_FAILURE** | Search same `threadContextId` for the underlying task error |
| **Kafka / stream error** | Check config branch for consumer settings, DLQ config |
| **Wrong value / unexpected behavior (200 OK)** | Value-derivation analysis — see below |

#### Value-derivation analysis (behavioral investigation)

When the transaction returned 200 OK but a field value is wrong:

1. **Pull ALL logs** for the transaction (not just ERROR):
   ```bash
   elk-query.sh trace <GlobalTrackingId>
   # Or for broader context (all levels, all logTypes):
   # custom query filtering on GlobalTrackingId with NO level filter
   ```

2. **Parse response bodies** at each service hop. The `message` JSON →
   `context` → `response.body` (or `request.body`) may contain the value.
   Trace the value backward through the chain:
   ```python
   # For each hit in chronological order:
   inner = json.loads(hit["_source"]["message"])
   ctx = inner.get("context", {})
   body = ctx.get("response", {}).get("body", "")
   # Search for the flagged value in the body
   ```

3. **Identify the source service** — the service that FIRST produced or
   CHANGED the value. It may have:
   - Computed it from business logic (Java code)
   - Fetched it from a downstream service or DB
   - Applied a DRL rule that transformed it
   - Read it from config

4. **Checkout and read the code** (use Step 3 to resolve configLabel → commit):
   - Find the controller/service method handling the URI
   - Trace the code path to where the value is set/computed
   - Check DRL rules if the service uses Drools
   - Check config YAML if the value is configurable

5. **Verdict**: Is the value correct per current code+config+rules, or is there
   a bug? If correct, explain the business rule. If wrong, classify as
   DATA / CODE / CONFIG / DRL root cause.

**Cross-service tracing options:**
```bash
# A) GlobalTrackingId — traces one request across ALL services
elk-query.sh trace <tracking-id>

# B) ThreadContextId — correlates request/response within one service
#    Use term on threadContextId.keyword

# C) X-Feign-Origin header (inside message JSON → context.request.headers)
#    Shows upstream call chain as comma-separated configLabels

# D) nginx → order-tech trace
#    nginx text search → vcap_request_id → strip hyphens → search order-tech-*
```

### Quick reference tables

**Input type → optimal query cost:**
```
Input type                 ELK queries   Pre-resolve?   Notes
─────────────────────────  ───────────   ────────────   ─────────────────────────────
Service name               1             YES            Filter by configLabel.keyword
Error message/stack trace  1             NO             query_string on message
Order ID                   1             NO             query_string on message
Account number             1             NO             term on comcastAccountNumber.keyword
GlobalTrackingId           1 (trace)     NO             elk-query.sh trace <id>
ThreadContextId            1             NO             term on threadContextId.keyword
URI / API path             1             NO             wildcard on uri.keyword
HTTP status + service      1             YES            Combine filters in bool.must
Free-form text             1             NO             query_string on message (expensive)
Combination                1             Partial        bool.must with multiple clauses
```

**Version pattern → branch where commit lives:**
```
Version format          Branch                        Example
─────────────────────   ──────────────────────────    ─────────────────────────────
X.Y.Z (3 segments)      main                          mbos-biller-account-1.0.817 → main
X.Y.Z.N (4 segments)    <slug>-X.Y.Z (hotfix branch)  mbos-customer-gateway-1.0.350.1 → mbos-customer-gateway-1.0.350
Special: *-adapter2     main-2.0                      mbos-async-amdocs-adapter2-2.0.26 → main-2.0
```

**Error type → analysis path:**
```
Error type                    What to check                           Brain section
─────────────────────────     ────────────────────────────────────    ─────────────
FeignException (4xx/5xx)      Downstream service code + contract      Step 4 → Feign
NullPointerException          Exact line in checked-out code          Step 4 → Stack trace
Data validation error         Config YAML, DRL rules, data state      Step 4 → Config
BPM JOB_EXECUTION_FAILURE     Underlying task error (search same      Step 2 (check other loggers)
                              threadContextId for root cause)
Kafka/stream error            Consumer config, DLQ, message format    Config branch + stream setup
Timeout / circuit breaker     Downstream latency, retry config        Config branch → timeouts
Database error                Connection pool, query, schema drift    Config → datasource, Oracle logs
Wrong value (200 OK)          Full call chain, response bodies,       Step 4 → Value-derivation
                              code + config + DRL that computed it
```

**Always use the commit SHA to checkout** — it's the ground truth regardless of branch.

### Named Recipe: configLabel-Change Regression Detector

**Use case**: Confirm whether a new deploy introduced a regression. Given a service
slug, show error rate **before** vs **after** the configLabel changed, broken by DC.
This is the single most useful Phase 1 query — it can confirm a deploy regression
without needing Phase 4 code forensics.

**When to use**: Any time errors spike and a configLabel change is suspected.
Run this FIRST in Phase 1 after identifying the service slug and current configLabel.

**Step 1** — Find when the new configLabel first appeared (deployment timestamp):
```bash
elk-query.sh first-occurrence --service <slug> --hours 168
# Or with configLabel filter using raw:
ELK=".github/skills/elk-log-search/scripts/elk-query.sh"
$ELK raw --body '{"size":1,"query":{"bool":{"filter":[{"range":{"@timestamp":{"gte":"now-168h"}}},{"wildcard":{"configLabel.keyword":"<slug>-<new-version>*"}}]}},"sort":[{"@timestamp":{"order":"asc"}}],"_source":["@timestamp","configLabel","datacenter"]}'
# → This gives you DEPLOY_TIMESTAMP and which DC got it first
```

**Step 2** — Compare error rates: 1h before vs 1h after the deploy, per DC:
```bash
# Replace DEPLOY_TIMESTAMP with the ISO8601 value from Step 1
# Replace <slug> with the service slug
ELK=".github/skills/elk-log-search/scripts/elk-query.sh"
$ELK raw --body '{"size":0,"query":{"bool":{"filter":[{"range":{"@timestamp":{"gte":"<DEPLOY_TIMESTAMP minus 1h>","lte":"<DEPLOY_TIMESTAMP plus 1h>"}}},{"wildcard":{"configLabel.keyword":"<slug>-*"}},{"term":{"level.keyword":"ERROR"}}]}},"aggs":{"by_dc":{"terms":{"field":"datacenter.keyword","size":10},"aggs":{"before_after":{"range":{"field":"@timestamp","ranges":[{"key":"BEFORE","to":"<DEPLOY_TIMESTAMP>"},{"key":"AFTER","from":"<DEPLOY_TIMESTAMP>"}]}}}}}}'
```

**Step 3** — Also compare configLabels in the error window (confirms which build is erroring):
```bash
$ELK raw --body '{"size":0,"query":{"bool":{"filter":[{"range":{"@timestamp":{"gte":"<DEPLOY_TIMESTAMP minus 1h>","lte":"<DEPLOY_TIMESTAMP plus 1h>"}}},{"wildcard":{"configLabel.keyword":"<slug>-*"}},{"term":{"level.keyword":"ERROR"}}]}},"aggs":{"by_configLabel":{"terms":{"field":"configLabel.keyword","size":10},"aggs":{"by_dc":{"terms":{"field":"datacenter.keyword","size":10}}}}}}' \
  }
}'
```

**Interpretation**:
- BEFORE=low, AFTER=high across ALL DCs → deploy regression (simultaneous rollout)
- BEFORE=low, AFTER=high in ONE DC → DC-specific issue or staggered rollout (check if other DCs got the deploy later)
- Error only on new configLabel, not old → confirms regression in the new build
- Error on both old and new configLabel → pre-existing issue, not a deploy regression

**Shortcut** (using elk-deep-trace.py if available):
```bash
python3 .github/skills/elk-log-search/scripts/elk-deep-trace.py deploy-correlate "<error text>" --hours 24
```

---

## 5. serviceName ↔ configLabel Mapping (verified from live logs)

The slug in `serviceName` and the slug in `configLabel` refer to the **same
service** but use **different naming**. Verified from actual log entries:

| serviceName (in ELK) | configLabel (in ELK) | serviceName slug | configLabel slug |
|---|---|---|---|
| `g7as-mvno-account-production` | `ds-mvno-account-1.0.708.2` | `mvno-account` | `ds-mvno-account` |
| `g2wc-biller-account-production` | `mbos-biller-account-1.0.817` | `biller-account` | `mbos-biller-account` |
| `g2po-bo-account-production` | `bo-account-1.0.276` | `bo-account` | `bo-account` |
| `g2wc-customer-gateway-production` | `mbos-customer-gateway-1.0.1682` | `customer-gateway` | `mbos-customer-gateway` |

**Rule**: serviceName strips the artifact prefix (ds-, mbos-, etc.) → just the functional name.
configLabel keeps the **full** artifact name including prefix.
EXCEPT for `bo-*` services where both use the same slug.

**Bonus**: the `X-Feign-Origin` header (inside `message` JSON → `context.request.headers`)
shows the upstream call chain as comma-separated configLabels:
```
"X-Feign-Origin": "xoms-activation-journey-1.0.395,mbos-biller-account-1.0.817"
```
This reveals the full service call chain for a given request!

When querying ELK, use whichever field fits:
- "Which build is erroring?" → aggregate by `configLabel.keyword`
- "Is the error DC-specific?" → aggregate by `serviceName.keyword`
- "Show me errors for biller-account" → `wildcard` on `serviceName.keyword: *biller-account*`

---

## 6. Scripting Notes and Operational Pitfalls

### Script execution
- Write Python scripts to `/tmp/`, run with `python3`. Inline `-c` with nested quotes breaks in zsh.
- For field discovery, text search first: `{ "query_string": { "query": "\"exact-value\"" } }`
- For complex ELK queries with jq, always use a script file — inline `bash -c` with JSON + jq is fragile.

### elk-query.sh response format (CRITICAL — causes silent jq failures)
- **ALL elk-query.sh responses are wrapped in `.rawResponse`** — you must unwrap:
  ```python
  raw = data.get("rawResponse", data)  # handle both wrapped/unwrapped
  ```
  ```bash
  | jq '.rawResponse.hits.total'   # NOT '.hits.total'
  ```
- Forgetting this produces `null` with no error — extremely easy to miss.

### Clone + checkout protocol (ALL clones)
- **Never use `--depth=N`** for code forensics — it truncates blame (99% boundary)
  and cannot reach hotfix-branch SHAs.
- Use `--no-checkout` + `git fetch origin $SHA` + `git checkout $SHA` for ALL versions.
- Resolve SHA from Artifactory BEFORE cloning.
- See `code-forensics/NAMING-AND-RESOLUTION.md` §7 for the full protocol.

### ELK query precision
- `elk-query.sh --service X` wildcards on `serviceName.keyword: *X*` — this
  matches multiple services (e.g. `--service account` matches `biller-account`,
  `mvno-account`, `mbo-accountservice`, etc.).
- **For investigation, always filter by `configLabel.keyword`** with wildcard on
  the slug: `"wildcard": {"configLabel.keyword": "<SLUG>-*"}`
- `elk-query.sh --service` is fine for broad exploration; precise investigation
  needs configLabel.

### Combined aggregation queries
- One query can do multiple aggregations. Never make separate queries for:
  - error counts by logger (use `terms` agg on `logger_name.keyword`)
  - sample messages per logger (use `top_hits` sub-agg with `_source`)
  - DC distribution (use `terms` agg on `datacenter.keyword`)
  - configLabel version (use `terms` agg on `configLabel.keyword`)
- A single combined query replaces 4-5 individual queries.

### Message field parsing
- `LogEventMessage` is the quick summary — may be truncated or generic.
- `message` field contains the full nested JSON with stack trace, context, headers.
- Always parse `message` as JSON to get `stack_trace` and `context`:
  ```python
  inner = json.loads(hit["message"])
  st = inner.get("stack_trace", "")
  ctx = inner.get("context", {})
  ```

---

## 7. Anti-Patterns — What NOT to Do During Investigation

These are mistakes that waste time. Each was learned from real troubleshooting.

| Anti-pattern | Why it's bad | What to do instead |
|---|---|---|
| Query ELK before resolving service slug | Broad wildcard matches wrong services, waste 2-3 queries narrowing down | Phase 1: resolve slug from `service_mappings.json` FIRST, then filter ELK by `configLabel.keyword` |
| Multiple ELK round trips | Each query costs 1-5s network + jq parsing. 5 queries = 25s+ | One combined agg query with `by_logger` + `by_dc` + `configLabel` + `top_hits` |
| Use `serviceName.keyword` for service filtering | `*provisioning*` matches 5+ services | Use `configLabel.keyword: <slug>-*` for single-service precision |
| Clone with `--depth=N` for code forensics | Shallow clones truncate blame (99% boundary lines) and cannot reach hotfix-branch SHAs | `--no-checkout` + `git fetch origin $SHA` + `git checkout $SHA` for ALL clones |
| Forget `.rawResponse` wrapper | jq returns `null` silently, looks like empty data | Always unwrap: `data.get("rawResponse", data)` or `jq '.rawResponse.hits'` |
| Read `LogEventMessage` and stop | It's often truncated or generic like "(no message)" | Parse `message` field as JSON → extract `stack_trace`, `context`, `exception` |
| Run `elk-query.sh top-errors` for investigation | Returns aggregated counts but no stack traces or context | Use custom agg query with `top_hits` sub-agg for full sample messages |
| Sequential: ELK → wait → resolve → wait → clone | 4 serial round-trip chains, each waiting for prior | Phase 1 (local, instant) → Phase 2 (ELK, 1 query) → Phase 3 (resolve+clone, parallel with analysis) |
| Resolve things you already know | Re-resolving slug→repo when `service_mappings.json` has it locally | Pre-resolve from local files in Phase 1 before any API call |
| Chase surface error, ignore root cause | `JOB_EXECUTION_FAILURE` is a symptom; the task that failed is the cause | Look at ALL logger buckets — the root cause is usually a different logger in the same time window |
| Stop at first service with error | The error may be relayed from downstream — you haven't found root cause | Trace `logType=API_RESPONSE` across services: who GENERATES vs who RELAYS the error |
| Declare "data issue" without evidence | A recurring error can mask a code issue (retry loops, missing guard) | Check unique entity count, retry frequency, timer configs, guard clauses |
| Ignore hardcoded test values in code | They may appear in production unexpectedly | Search ELK for hardcoded values to verify they're not hit in prod (`test-in-prod` command) |
| Accept "same error" at face value | Same error message can have multiple distinct root causes (code path, data, caller) | Segment by: input type (test vs real), caller (X-Feign-Origin), call path, DC |
| Establish "what" chain but skip "why" | Knowing the error traversal path is not root cause — it's just observation | After tracing, always run `compare` (success vs fail diff) and `permanence` (data vs transient) |
| Assume retry is useful without checking | Retrying a permanent data error wastes resources indefinitely | Run `permanence` to verify; if PERMANENT → the retry loop is the architecture issue, not the error |

---

## 8. elk-deep-trace.py — Trace Algorithms (A–F)

All algorithms below are implemented in `elk-deep-trace.py`.
Run `elk-deep-trace.py <command> --help` for usage.

### Trace Layer (WHAT happened) — Algorithms A-F

| Algo | Command | Input | Queries | Answers |
|---|---|---|---|---|
| A | `error-origin` | error text | 1 | Which service GENERATES vs RELAYS this error? |
| B | `single-trace` | threadContextId | 1 | What are ALL logs for this one request? |
| C | `order-trace` | globalTrackingId | 1 | What services touched this order/entity? |
| D | `retry-detect` | globalTrackingId | 1 | Is this entity stuck in a retry loop? |
| E | `test-in-prod` | test value | 1 | Does this hardcoded value appear in production? |
| F | `call-topo` | URI pattern | 2 | Who calls whom for this API path? |

### Root Cause Layer (WHY it happened) — Algorithms G-L

| Algo | Command | Input | Queries | Answers |
|---|---|---|---|---|
| G | `compare` | URI or error text | 3-5 | Why does THIS request fail when SIMILAR ones succeed? |
| H | `onset` | error text | 1 | WHEN did this error first appear? What deployed? |
| I | `input-diff` | URI pattern | 2 | What specific input values trigger failure? |
| J | `permanence` | globalTrackingId | 2 | Is retrying wasteful (permanent) or useful (transient)? |
| K | `data-lineage` | globalTrackingId | 1 | Where did the bad data ENTER the system? |
| L | `deploy-correlate` | error text | 1 | Did a new deployment introduce this error? |

### Combined Pipeline

| Command | Chains | Purpose |
|---|---|---|
| `full-investigate` | A → B → G → D → J → H | Complete what-then-why pipeline |

### Algorithm details

**A — Error Origin Detection** (1 query)
- Search `message` for error text, aggregate by `serviceName.keyword` + sub-aggregate by `logType.keyword`
- Service with `API_RESPONSE` = **ORIGIN** (generated the error)
- Service with only `FEIGN_RESPONSE` = **RELAY** (received from downstream)

**B — Single-Transaction Trace** (1 query)
- Filter by `threadContextId.keyword`, sort by `@timestamp` ascending
- Shows full request lifecycle: API_REQUEST → FEIGN_REQUEST → FEIGN_RESPONSE → API_RESPONSE
- Cross service boundaries via FEIGN_REQUEST URL and X-Feign-Origin header

**C — Order Trace** (1 query)
- Search `message` for globalTrackingId (covers both field spellings)
- Shows all services that touched this entity, ordered chronologically

**D — Retry Loop Detection** (1 query)
- `date_histogram` with 1h interval for a globalTrackingId over 24h
- Computes coefficient of variation (CV): CV < 0.3 with 3+ hours = timer-based retry
- Regular spacing = BPMN timer; irregular = user-driven or intermittent

**E — Test-Value-in-Prod** (1 query)
- Search for known constants in `message`, filter `environment.keyword = mbosProd`
- Any hits = potential issue (test guard may be bypassed)

**F — Call Topology** (2 queries)
- Query 1: `FEIGN_REQUEST` for URI → all CALLERS
- Query 2: `API_REQUEST` for URI → the TARGET service
- X-Feign-Origin header shows multi-hop call chains

**Algorithms G–L (Root Cause Layer)** are in `rca-synthesis/ROOT-CAUSE-PATTERNS.md`.
