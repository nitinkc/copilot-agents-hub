---
name: elk-log-search
description: >
  Translate natural language into Elasticsearch queries against OrderTech ELK
  (Kibana 7.17.9). Contains full index schemas, field reference, service name
  conventions, query templates, and analysis playbooks. Use when asked to search
  logs, investigate errors, trace requests, compare datacenters, or analyze
  production behavior.
---

# Skill: ELK Log Search

## Step 0 — MANDATORY: Load both reference files before ANY query work

```
read_file .github/skills/elk-log-search/FIELD-REFERENCE.md
read_file .github/skills/elk-log-search/INVESTIGATION-BRAIN.md
```

`FIELD-REFERENCE.md` — authoritative field names, all enum values with live
production counts, serviceName wildcard mappings, and 7 ready-to-use query
recipes. **Do not guess field names or values — the reference has them.**

`INVESTIGATION-BRAIN.md` — hard-won operational knowledge: index differences,
nginx vs order-tech quirks, nested JSON parsing, trace linking, investigation
order, and proven patterns for comparing traces. **Load this for any
investigation deeper than a single-field count query.**

Skipping either file will produce wrong queries and missed evidence.

## Goal

Translate a user's natural language request into an Elasticsearch query, execute
it via the skill's scripts, and return structured, actionable results.

## Inputs

| Input | Source | Required |
|---|---|---|
| Natural language query or investigation request | User | Yes |
| Service name or alias | User (mapped via FIELD-REFERENCE.md) | No |
| Time range | User (default depends on query type — see below) | No |
| Environment | User (default: `mbosProd`) | No |
| Index pattern | User (default: `order-tech-*`) | No |

### Time Range Defaults (by query type)

| Query type | Default | Max |
|---|---|---|
| Transaction/ID search (order ID, tracking ID, account, threadContextId) | `168h` (7 days) | 168h |
| `elk-query.sh trace <id>` | `168h` (hardcoded) | 168h |
| Service error search (`errors --service X`) | `1h` | 168h |
| Top errors / aggregation | `1h` | 168h |
| Deployment comparison | `24h` | 168h |

**Rule**: When searching for specific transactions, IDs, or error traces from a ticket,
ALWAYS use 168h. Only aggregation and "current state" queries should use short windows.

## File Layout

```
.github/skills/elk-log-search/
├── SKILL.md                    # This file — workflow + execution guide
├── FIELD-REFERENCE.md          # ← Field names, enum values, query recipes (ALWAYS load)
├── INVESTIGATION-BRAIN.md      # ← Operational patterns, index quirks, proven techniques
│                               #   (ALWAYS load for investigations)
└── scripts/
    ├── elk-lib.sh              # Shared library (env loading, curl wrappers)
    ├── elk-query.sh            # Main query CLI (search, trace, top-errors, etc.)
    ├── elk-setup.sh            # Bootstrap ~/.ordertech-elk config
    └── elk-sso-login.py        # Automated SSO cookie refresh via Playwright
```

> **MANDATORY:** Before composing any query, read `FIELD-REFERENCE.md`.  
> It contains the decision tree, all known enum values, query recipes, and  
> serviceName wildcard mappings. Never guess field names — the reference has them.

**User config** (outside the repo, in the user's home directory):
```
~/.ordertech-elk/
├── environments.yaml           # Environment definitions (name, URL, cookie path)
├── cookies/                    # Cookie files per env (mode 600, gitignored)
│   ├── prod.cookie
│   └── lower.cookie            # (when configured)
└── browser-state/              # Playwright persistent sessions (for SSO login)
    ├── prod/                   # Azure AD session data (auto-managed)
    └── lower/
```

## Prerequisites

**Required tools**: `curl`, `jq`, `python3` (all pre-installed on macOS).

> **Windows users**: The shell scripts (`elk-setup.sh`, `elk-query.sh`,
> `elk-lib.sh`) require bash. Use **WSL** (recommended) or **Git Bash**.
> The SSO login script (`elk-sso-login.py`) runs natively on Windows:
> `python elk-sso-login.py --env prod lower --headed`

### New computer setup (step-by-step)

Follow these 5 steps in order. Total time: ~5 minutes.

**Step 1 — Connect to VPN**

Both ELK endpoints (`ot-logs-prod`, `ot-logs-lower`) are internal.
You must be on the Comcast corporate VPN before proceeding.

**Step 2 — Create config directory**

```bash
.github/skills/elk-log-search/scripts/elk-setup.sh
```

This creates `~/.ordertech-elk/` with `environments.yaml` (prod + lower
pre-configured) and a `cookies/` directory. If you already have the
config, it will not overwrite it.

**Step 3 — Install browser automation (one-time)**

```bash
.github/skills/elk-log-search/scripts/elk-setup.sh --install-sso
```

Installs Playwright + Chromium (~250 MB). This enables automated SSO
cookie refresh without manual copy-paste from DevTools.

**Step 4 — SSO login for both environments**

```bash
# Production
.github/skills/elk-log-search/scripts/elk-setup.sh --sso-login --headed

# Lower (stage/QA/dev/preprod)
.github/skills/elk-log-search/scripts/elk-setup.sh --sso-login --env lower --headed
```

Each command opens a Chromium window. Complete the Azure AD SSO + MFA
in the browser. The window closes automatically after login.

On subsequent runs, drop `--headed` — the saved Azure AD session allows
headless (automatic) cookie refresh:

```bash
# Headless refresh (no browser window)
.github/skills/elk-log-search/scripts/elk-setup.sh --sso-login --env prod lower
```

**Step 5 — Verify**

```bash
# Check both envs are configured and cookies are present
.github/skills/elk-log-search/scripts/elk-query.sh envs

# Quick prod query
.github/skills/elk-log-search/scripts/elk-query.sh search --size 1 --hours 1

# Quick lower query
.github/skills/elk-log-search/scripts/elk-query.sh --env lower search --size 1 --hours 1
```

You should see data in the response JSON. If you get a 302 or empty
response, your cookie has expired — re-run Step 4.

### Day-to-day cookie refresh

Cookies expire after 4-8 hours. When `elk-lib.sh` detects a stale
cookie (≥4h old), it prints a warning. Refresh:

```bash
# Both envs at once (headless if session is still valid)
.github/skills/elk-log-search/scripts/elk-setup.sh --sso-login --env prod lower
```

If the Azure AD session has expired (~14-90 days), it falls back to an
interactive browser automatically.

### Alternative: manual cookie paste (no install needed)

If you cannot install Playwright, paste cookies manually:

```bash
.github/skills/elk-log-search/scripts/elk-setup.sh --set-cookie prod
.github/skills/elk-log-search/scripts/elk-setup.sh --set-cookie lower
```

Or from the browser: log in → DevTools → Application → Cookies → copy
`ccssession` value → `echo '<value>' > ~/.ordertech-elk/cookies/prod.cookie`

### Adding custom environments

```bash
.github/skills/elk-log-search/scripts/elk-setup.sh --add-env myenv https://ot-logs-myenv.sys.comcast.net
```

### Selecting environment at query time

```bash
# Per-command flag (recommended)
elk-query.sh --env lower search --service bo-account

# Or via env var
export ELK_ENV=lower
elk-query.sh search --service bo-account
```

### Backward compatibility

If `ELK_URL` + `ELK_COOKIE` env vars are set, they override the config
file. Useful for CI or one-off scripts.

---

## Connection Reference

| Detail | Value |
|---|---|
| Prod URL | `https://ot-logs-prod.sys.comcast.net` |
| Lower URL | `https://ot-logs-lower.sys.comcast.net` |
| Kibana Version | 7.17.9 (Elasticsearch 7.x) |
| Auth | Azure AD OIDC via openresty proxy (separate cookies per cluster) |
| Cookie name | `ccssession` |
| Required headers | `User-Agent` (browser-like), `Referer`, `kbn-xsrf: true` |
| Search endpoint | `POST /internal/search/es` |
| Response path | `.rawResponse.hits.hits[]._source` |
| Aggregation path | `.rawResponse.aggregations.<agg_name>.buckets[]` |

---

## Index Patterns

| Index Pattern | Docs | Description | Key Fields |
|---|---|---|---|
| `order-tech-*` | ~15B | **Main OrderTech service logs** | `serviceName`, `level`, `logType`, `LogEventMessage`, `GlobalTrackingId`, `statusCode`, `duration`, `uri`, `method`, `SalesChannel`, `datacenter`, `environment`, `configLabel` |
| `bis-prod-*` | ~700M | BIS prod logs | `message`, `tags` |
| `nginx-prod-*` | ~2.3B | Nginx proxy logs | `hostname`, `http_method`, `http_status`, `url` |
| `vendor-proxy-prod-*` | ~26M | Vendor proxy logs | `client_ip`, `http_method`, `http_status`, `url`, `request_time`, `datacenter` |
| `bom-prod-*` | ~2M | BOM service logs | `accountNumber`, `operation`, `status`, `traceId`, `url` |

**Lower environment indexes** (available on `ot-logs-lower`):

| Index Pattern | Description |
|---|---|
| `order-tech-*` | OrderTech service logs (stage/QA/dev/preprod) |
| `nginx-lower-*` | Nginx proxy logs (lower envs) |

> **Note:** Lower env index patterns may differ from prod. On first use, run
> `elk-query.sh --env lower indices` to discover available patterns.
> The `environment.keyword` field distinguishes envs within the index:
> `mbosStage`, `mbosQa`, `mbosDev`, `mbosPreprod`, `mbosCi`, `mbosPerf`.

**Default index**: `order-tech-*` (use for all service log queries unless the
user explicitly asks about nginx, vendor proxy, BIS, or BOM).

---

## `order-tech-*` Complete Field Reference

### Identity & Context Fields
| Field | ES Type | Description | Example Values |
|---|---|---|---|
| `serviceName` | text+keyword | Service instance with DC prefix | `g2wc-subscriber-production` |
| `service_name` | text | Alternate service name (rare) | |
| `configLabel` | keyword | Service build name — exact deployed artifact version. The value IS the config branch/tag name; use directly for git checkout. Prefixes vary: `mbos-`, `ds-`, `bo-`, `wkfl-`, `xoms-`, `mbo-`. | `mbos-biller-account-1.0.817` |
| `environment` | keyword | Deployment env | `mbosProd`, `ot-ops-prod`, `mpa-prod` |
| `datacenter` | keyword | Datacenter code | `wc-g2`, `po-g2`, `as-g7`, `as-g6`, `g3` |
| `tags` | keyword[] | Log tags | `["mbo", "standard_logs"]` |

### Log Metadata Fields
| Field | ES Type | Description | Example Values |
|---|---|---|---|
| `@timestamp` | date | Event time (ISO 8601 UTC) | `2026-04-08T16:14:53.402Z` |
| `level` | keyword | Log level | `INFO`, `WARN`, `ERROR`, `DEBUG`, `TRACE` |
| `logType` | keyword | Log category | `STANDARD`, `API_REQUEST`, `API_RESPONSE`, `DOWNSTREAM_REQUEST`, `DOWNSTREAM_RESPONSE`, `FEIGN_REQUEST`, `FEIGN_RESPONSE` |
| `logger_name` | text | Java logger (abbreviated) | `c.c.x.m.c.l.web.LoggingServletFilter` |
| `message` | text | Full JSON log line | (large, contains nested context) |
| `LogEventMessage` | text+keyword | Short human-readable message | `Exception on cache GET` |

### Request Tracking Fields
| Field | ES Type | Description | Example Values |
|---|---|---|---|
| `GlobalTrackingId` | text+keyword | Cross-service correlation ID | UUID or `MBOS_<uuid>` |
| `globaltrackingid` | text | Lowercase variant | |
| `threadContextId` | text | Per-request in-service ID | UUID |
| `SessionId` | text+keyword | User session | UUID |
| `requestId` | text+keyword | Individual request ID | |

### HTTP / API Fields (populated on API_REQUEST, API_RESPONSE, DOWNSTREAM_*, FEIGN_*)
| Field | ES Type | Description | Example Values |
|---|---|---|---|
| `method` | keyword | HTTP method | `GET`, `POST`, `PUT`, `DELETE` |
| `uri` | text+keyword | Request URI path | `/api/domain/mvnoaccounts/...` |
| `url` | text+keyword | Full URL | |
| `url_path` | text | URL path component | |
| `statusCode` | keyword | Response status | `NOT_FOUND`, `OK`, `INTERNAL_SERVER_ERROR` |
| `status` | keyword | Status code/label | |
| `code` | keyword | Error/status code | |
| `duration` | text | Latency in ms (string) | `"70"` |
| `http_protocol` | keyword | Protocol version | |

### Business Context Fields
| Field | ES Type | Description | Example Values |
|---|---|---|---|
| `SalesChannel` | keyword | Channel | `WEB`, `TELESALES`, `RETAIL`, `XFINITY_APP`, `ONLINE`, `MOBILE`, `XM360`, `CCAI_XM` |
| `comcastAccountNumber` | text | Customer account | |
| `TenantId` | text+keyword | Multi-tenant ID | |
| `domain` | keyword | Domain/service area | |
| `Origin` | keyword | Origin header | |
| `Client-Id` | keyword | Client identifier | |

---

## Service Name Resolution

Service naming pattern, DC prefix table, repo-to-ELK mapping, and alias
resolution are defined authoritatively in **FIELD-REFERENCE.md** (loaded in
Step 0). Do not duplicate mappings here.

Quick rule: `wildcard: "*{service-slug}*"` matches all DCs.

### Resolution Algorithm (when user mentions a service by informal name)

1. Resolve informal name → ELK slug via `service_mappings.json`:
   ```bash
   jq -r --arg s "<user-input>" '.services[] | select(.service | contains($s)) | "\(.service)|\(.cf_app_name)|\(.repo_name)"' .github/shared/service_mappings.json
   ```
2. If zero matches: try `elk-query.sh field-values --field serviceName --top 50` and grep.
3. If ambiguous (multiple matches): ask user to clarify.
4. Emit confirmation: `Resolved: "<user said>" → slug=<slug>, cf_app_name=<cf_app_name>, repo=<repo>`
5. Use the resolved slug for ALL subsequent ELK queries (wildcard on cf_app_name).

---

## logType Field Controls Available Fields

| logType | Extra Fields Present |
|---|---|
| `STANDARD` | Base fields only: level, message, LogEventMessage, logger_name |
| `API_REQUEST` | + method, uri, url, headers (in message JSON) |
| `API_RESPONSE` | + method, uri, statusCode, duration, request/response bodies (in message JSON) |
| `DOWNSTREAM_REQUEST` | + url, method, headers (in message JSON) |
| `DOWNSTREAM_RESPONSE` | + url, statusCode, duration (in message JSON) |
| `FEIGN_REQUEST` | + url, method, target service (in message JSON) |
| `FEIGN_RESPONSE` | + url, statusCode, duration (in message JSON) |

---

## Query Building Rules

### Query Precision Rules (MANDATORY — filter at source, not in post-processing)

1. **Use `configLabel.keyword` when investigating a specific deployment version.**
   Instead of broad `serviceName` wildcards, filter by the exact configLabel:
   ```json
   {"term": {"configLabel.keyword": "wkfl-lean-orchestrator-3.0.611.12"}}
   ```
   This is more precise than `{"wildcard": {"serviceName.keyword": "*lean-orchestrator*"}}`,
   which matches ALL versions across ALL DCs. Use configLabel when you know the
   deployed version; use serviceName wildcard only for discovery/aggregation queries.

2. **Push all filters into the ELK query, never filter in jq/python post-processing.**
   ELK evaluates filter clauses at the shard level before returning data. Fetching
   broad results and filtering client-side wastes bandwidth, context window, and
   risks hitting the output cap with irrelevant data.

3. **Use `_source` to select only needed fields.** Never fetch full documents when
   you only need timestamps, service names, and error messages.

### Step 1: Choose the Index
- Default: `order-tech-*`
- Use `nginx-prod-*` for nginx/proxy layer questions (prod)
- Use `nginx-lower-*` for nginx/proxy layer questions (lower)
- Use `vendor-proxy-prod-*` for vendor/external call questions
- Use `bom-prod-*` for BOM operations
- Use `bis-prod-*` for BIS logs
- **Lower env?** Add `--env lower` flag and filter by `environment.keyword`
  (e.g., `mbosStage`, `mbosQa`)

### Step 2: Build the Bool Query

**Template structure:**
```json
{
  "params": {
    "index": "<index-pattern>",
    "body": {
      "size": <N>,
      "query": {
        "bool": {
          "must": [ <field matches> ],
          "filter": [ <time range, exact terms> ],
          "must_not": [ <exclusions> ]
        }
      },
      "sort": [{ "@timestamp": { "order": "desc" } }],
      "_source": [ <fields to return> ]
    }
  }
}
```

### Step 3: Map Natural Language → Query Clauses

| User says | Query clause |
|---|---|
| "errors for bo-account" | `{"match":{"serviceName":"bo-account"}}` + `{"term":{"level.keyword":"ERROR"}}` |
| "last 2 hours" | `{"range":{"@timestamp":{"gte":"now-2h"}}}` |
| "tracking ID abc-123" | `{"match_phrase":{"GlobalTrackingId":"abc-123"}}` |
| "404 on subscriber" | `{"match":{"serviceName":"subscriber"}}` + `{"term":{"statusCode.keyword":"NOT_FOUND"}}` |
| "slow calls > 5000ms" | Use `script` filter: `"script":{"script":"Integer.parseInt(doc['duration.keyword'].value) > 5000"}` OR search in message text |
| "NullPointerException" | `{"match_phrase":{"message":"NullPointerException"}}` |
| "all services in wc-g2" | `{"term":{"datacenter.keyword":"wc-g2"}}` |
| "TELESALES channel errors" | `{"term":{"SalesChannel.keyword":"TELESALES"}}` + `{"term":{"level.keyword":"ERROR"}}` |
| "compare error rates across DCs" | Use aggregation with `terms` on `datacenter.keyword` + sub-agg on `level.keyword` |
| "top 10 erroring services" | Aggregation: `terms` on `serviceName.keyword` with filter `level:ERROR` |
| "feign calls to subscriber" | `{"term":{"logType.keyword":"FEIGN_REQUEST"}}` + `{"match":{"message":"subscriber"}}` |

### Step 4: Choose _source Fields

| Query type | Recommended _source |
|---|---|
| Error investigation | `@timestamp`, `serviceName`, `level`, `LogEventMessage`, `message`, `logger_name`, `GlobalTrackingId`, `configLabel`, `datacenter` |
| API response analysis | `@timestamp`, `serviceName`, `method`, `uri`, `statusCode`, `duration`, `LogEventMessage`, `GlobalTrackingId` |
| Request tracing | `@timestamp`, `serviceName`, `logType`, `LogEventMessage`, `GlobalTrackingId`, `threadContextId`, `method`, `uri`, `statusCode`, `duration` |
| Service overview | `@timestamp`, `serviceName`, `level`, `logType`, `LogEventMessage` |

### Step 5: Use Aggregations for Analytics

**Error rate per service (last 1h):**
```json
{
  "size": 0,
  "query": { "bool": { "filter": [
    {"range": {"@timestamp": {"gte": "now-1h"}}},
    {"term": {"level.keyword": "ERROR"}}
  ]}},
  "aggs": {
    "by_service": {
      "terms": {"field": "serviceName.keyword", "size": 20, "order": {"_count": "desc"}}
    }
  }
}
```

**Latency percentiles for a service:**
```json
{
  "size": 0,
  "query": { "bool": { "must": [
    {"match": {"serviceName": "bo-account"}},
    {"term": {"logType.keyword": "API_RESPONSE"}}
  ], "filter": [
    {"range": {"@timestamp": {"gte": "now-1h"}}}
  ]}},
  "aggs": {
    "duration_stats": {
      "extended_stats": {"field": "duration.keyword"}
    }
  }
}
```

**Error breakdown by datacenter:**
```json
{
  "size": 0,
  "query": { "bool": { "filter": [
    {"range": {"@timestamp": {"gte": "now-1h"}}},
    {"term": {"level.keyword": "ERROR"}}
  ]}},
  "aggs": {
    "by_dc": {
      "terms": {"field": "datacenter.keyword"},
      "aggs": {
        "by_service": {
          "terms": {"field": "serviceName.keyword", "size": 10}
        }
      }
    }
  }
}
```

---

## Execution

### Query Method Selection (MANDATORY — choose before composing any query)

Always prefer the simplest method that can express the query. Creating tmp scripts
for queries expressible as named commands wastes ~1-2 min per query (create_file +
bash invocation + output parsing overhead).

| Need | Method | Example |
|------|--------|---------|
| Error sample + DC/env/source aggs for a service | A: `phase1-triage` | `elk-query.sh phase1-triage --service <slug> --hours 4` |
| Full Phase 1 BPMN triage (errors + context + variables + trend) | A: `phase1-bpmn` | `elk-query.sh phase1-bpmn --service <slug> --hours 24` |
| BPMN process variable extraction (fail vs control) | A: `bpmn-variables` | `elk-query.sh bpmn-variables --service <slug> --compare-control` |
| ERROR logs for a service | A: `errors` | `elk-query.sh errors --service <slug> --hours 4` |
| Filtered search (service + level + text) | A: `search` | `elk-query.sh search --service <slug> --level ERROR --query "timeout" --hours 2` |
| Trace a request across services | A: `trace` | `elk-query.sh trace <trackingId>` |
| Top erroring services (global or per-service) | A: `top-errors` | `elk-query.sh top-errors --hours 2 --top 30` |
| First occurrence of an error pattern (7-day max) | A: `first-occurrence` | `elk-query.sh first-occurrence --service <slug> --query "<pattern>" --hours 168` |
| Discover field values | A: `field-values` | `elk-query.sh field-values --field datacenter` |
| Named command + field extraction | A + `jq` | `elk-query.sh errors --service X --hours 2 \| jq '.rawResponse.hits.hits[]._source.message'` |
| Custom aggs (date_histogram, nested sub-aggs) | C: tmp script | `create_file` → `bash /tmp/query.sh` |
| Python post-processing (regex, cross-record) | C: tmp script | `create_file` with Python parser |
| Multi-query batch | C: tmp script | `_msearch` or sequential `elk_search` calls |

**Rule**: If `elk-query.sh search/errors/trace/top-errors/phase1-triage/bpmn-context/bpmn-variables/phase1-bpmn/raw` can express the query
(even with `| jq` for output filtering), do NOT create a tmp script. The `raw` command
accepts arbitrary ES JSON, so the ONLY remaining reason for a tmp script is multi-query
sequences or scripts that need inter-query logic (loops, conditionals, variable passing).
When a script IS needed, it MUST call `elk-query.sh raw` — never `source elk-lib.sh`.

#### Anti-Pattern Decision Table (prevents Method C overuse)

Use this table when deciding whether a query needs a tmp script. If the "Correct Method"
column shows Method A, creating a script is an anti-pattern — use the one-liner instead.

| Query Need | Correct Method | Anti-Pattern Example (DO NOT) |
|---|---|---|
| Error count and sample for a service | A: `elk-query.sh phase1-triage --service <slug> --hours N` | Writing `/tmp/triage.sh` that sources `elk-lib.sh` and runs `elk_search` with a filter + size query |
| ERROR logs filtered by service | A: `elk-query.sh errors --service <slug> --hours N` | Writing `/tmp/errors.sh` with a `level.keyword=ERROR` + wildcard filter — identical to the built-in |
| Search with service + level + text filter | A: `elk-query.sh search --service <slug> --level ERROR --query "text" --hours N` | Writing `/tmp/search.sh` with `must` + `filter` clauses that match `search` flags exactly |
| Search excluding a level (e.g. non-INFO) | A: `elk-query.sh search --service <slug> --query "text" --exclude-level INFO` | Writing `/tmp/search.sh` with `must_not` for level — `--exclude-level` handles this |
| Search with custom _source fields | A: `elk-query.sh search --service <slug> --source 'field1,field2'` | Writing `/tmp/search.sh` with a custom `_source` array — `--source` handles this |
| Single terms aggregation (e.g. by DC) | A: `elk-query.sh search --service <slug> --level ERROR --agg datacenter:6` | Writing `/tmp/agg.sh` with a `terms` agg — `--agg` handles this |
| Trace a request by GlobalTrackingId | A: `elk-query.sh trace <id>` | Writing `/tmp/trace.sh` with a `should` block for both trackingId spellings — identical to built-in |
| Top errors globally or per service | A: `elk-query.sh top-errors [--service <slug>] --hours N` | Writing `/tmp/top_errors.sh` with a `terms` agg on `serviceName.keyword` — already built-in |
| First occurrence of an error pattern | A: `elk-query.sh first-occurrence --service <slug> --query "<pattern>" --hours 168` | Writing `/tmp/first.sh` with a `sort: asc` + `size: 1` query — identical to built-in |
| Extract specific fields from results | A + `jq`: `elk-query.sh errors --service X --hours N \| jq '<filter>'` | Writing `/tmp/extract.sh` for field extraction that `jq` handles in a pipe |
| BPMN context (businessKey, processDefId, action) | A: `elk-query.sh bpmn-context --service <slug> --hours N` | Writing `/tmp/bpmn.sh` + `/tmp/parse.py` to extract nested JSON fields manually |
| BPMN process variable extraction | A: `elk-query.sh bpmn-variables --service <slug> --compare-control` | Writing `/tmp/vars.sh` to run two separate queries and parse nested JSON manually |
| Full Phase 1 BPMN triage (all 5 steps) | A: `elk-query.sh phase1-bpmn --service <slug> --hours N` | Running 5 separate `elk-query.sh` commands manually |
| Custom sub-aggregations (e.g., date_histogram with nested terms) | A: `elk-query.sh raw --body '<json>'` | N/A — `raw` is the approved entry point for custom ES JSON |
| Cross-record correlation requiring Python regex | A: `elk-query.sh raw --body '<json>' \| python3 -c '...'` | N/A — Python post-processing is a valid use of `raw` + pipe |
| Multi-query sequences with inter-query logic | Script using `elk-query.sh raw` per query (CORRECT) | Writing a script that sources `elk-lib.sh` directly — use `elk-query.sh raw` instead |

**Heuristic**: If your query has only `term`, `wildcard`, `range`, `query_string` filters
with a `size` and `sort`, Method A named commands almost certainly cover it.
If the query needs custom `aggs` or complex boolean logic, use `elk-query.sh raw`.
The ONLY reason to create a tmp script is multi-query sequences or inter-query
logic (loops, conditionals, accumulating state across queries). Even then, scripts
MUST call `elk-query.sh raw` — never `source elk-lib.sh`.

### Method A: elk-query.sh (built-in commands) — PREFERRED

The skill-bundled script at `.github/skills/elk-log-search/scripts/elk-query.sh`
handles auth, env selection, and common queries. It sources `elk-lib.sh` for
cookie/env resolution from `~/.ordertech-elk/environments.yaml`.

```bash
ELK=".github/skills/elk-log-search/scripts/elk-query.sh"

# List configured environments and cookie status
$ELK envs

# Kibana version / health
$ELK status

# Search (default: prod, order-tech-*, last 1h)
$ELK search --service bo-account --hours 2 --size 50
$ELK search --query "NullPointerException" --hours 1

# Search with exclusion, custom fields, and aggregation
$ELK search --service xoms-biller --query 'updateCMTs' --exclude-level INFO --hours 2
$ELK search --service xoms-biller --source '@timestamp,serviceName,level,status,message'
$ELK search --service ott-fulfillment --level ERROR --agg datacenter:6 --hours 4

# Errors shorthand
$ELK errors --service subscriber --hours 4

# Phase 1 composite triage (single request: sample + DC + configLabel + env + source aggs)
$ELK phase1-triage --service lean-orchestrator --hours 4

# Full Phase 1 BPMN triage (5 queries: errors + context + variables + trend + summary)
$ELK phase1-bpmn --service ott-fulfillment --hours 24

# BPMN process variable extraction (fail vs control comparison)
$ELK bpmn-variables --service ott-fulfillment --compare-control
$ELK bpmn-variables --service ott-fulfillment --business-key "abc-123:def-456:ADD"
$ELK bpmn-variables --service ott-fulfillment --fields "purchasedOfferId,partnerGroup"

# Trace a request across services
$ELK trace abc-123-def-456

# Top erroring services aggregation
$ELK top-errors --hours 2 --top 30

# First occurrence of an error pattern (searches 7-day max window, returns earliest match)
$ELK first-occurrence --service lean-orchestrator --query "purchasedOfferId" --hours 168

# Raw Elasticsearch JSON (replaces sourcing elk-lib.sh in scripts)
$ELK raw --body '{"size":0,"query":{"bool":{"filter":[{"range":{"@timestamp":{"gte":"now-1h"}}}]}},"aggs":{"by_svc":{"terms":{"field":"serviceName.keyword","size":20}}}}'
$ELK raw --body-file /tmp/custom-query.json | jq '.rawResponse.aggregations'
$ELK raw --body '{...}' | python3 -c 'import json,sys; ...'

# Use lower environment (stage/QA/dev/preprod)
$ELK --env lower search --service bo-account --hours 1
ELK_ENV=lower $ELK errors --hours 2

# Lower env: filter to specific environment within the cluster
$ELK --env lower search --service bo-account --query "mbosStage" --hours 1
```

### Method B: elk-query.sh raw (custom ES JSON) — APPROVED FALLBACK

For queries that need arbitrary ES JSON (custom aggregations, nested sub-aggs,
complex boolean logic) but don't need multi-query sequencing:

```bash
ELK=".github/skills/elk-log-search/scripts/elk-query.sh"

# Inline JSON body
$ELK raw --body '{"size":0,"query":{"bool":{"filter":[{"range":{"@timestamp":{"gte":"now-1h"}}},{"term":{"level.keyword":"ERROR"}}]}},"aggs":{"by_service":{"terms":{"field":"serviceName.keyword","size":20}}}}' | jq '.rawResponse.aggregations.by_service.buckets[]'

# JSON body from file (for complex queries)
$ELK raw --body-file /tmp/query.json | jq '...'

# Pipe to Python for cross-record analysis
$ELK raw --body '{...}' | python3 -c 'import json,sys; data=json.load(sys.stdin); ...'
```

**IMPORTANT**: `raw` handles auth, env selection, and cookie refresh automatically.
Do NOT source `elk-lib.sh` directly — use `raw` instead. The only exception is
multi-query scripts that need inter-query logic (see Method C).

### Method C: Multi-query script (last resort — agent/complex sequences only)

For multi-query sequences that need inter-query logic (loops, conditionals,
accumulating state), write a script via `create_file` tool. **The script MUST
use `elk-query.sh raw` for each query — never source `elk-lib.sh` directly.**
**Never use heredoc** (`<< 'EOF'`) in terminal — VS Code hangs.

```bash
# Step 1: Use create_file tool to write /tmp/multi-query.sh with:
#!/usr/bin/env bash
set -euo pipefail
ELK=".github/skills/elk-log-search/scripts/elk-query.sh"

# Query 1: Get error distribution
result1=$($ELK raw --body '{"size":0,"query":{...},"aggs":{...}}')
echo "$result1" | jq '...'

# Query 2: Use result1 to build the next query
service=$(echo "$result1" | jq -r '.rawResponse.aggregations...')
result2=$($ELK raw --body "{\"size\":5,...}")
echo "$result2" | jq '...'

# Step 2: Execute with single-line terminal command:
# bash /tmp/multi-query.sh
```

---

## Analysis Playbooks

### Playbook 1: Error Investigation

**Fast path (Phase 1 composite — preferred)**:
Use the `phase1-triage` command to get sample errors + all key aggregations in a single request:
```bash
elk-query.sh phase1-triage --service <slug> --hours <N>
```
This returns in ONE round trip: 5 sample error logs + DC distribution + configLabel distribution +
environment distribution + error source breakdown (logger → top messages) + total error count.
Replaces steps 1-3 and 5 below. After phase1-triage, proceed directly to step 4 (Trace).

**Fast path for wkfl-* BPMN services (preferred)**:
Use `phase1-bpmn` for a comprehensive 5-step BPMN triage in a single command:
```bash
elk-query.sh phase1-bpmn --service <slug> --hours <N>
```
Runs all standard Phase 1 queries: error count + DC distribution, businessKey extraction,
process variable comparison (fail vs control), 7-day error trend, and structured summary.
For wkfl-* services, prefer this over `phase1-triage` — it covers BPMN-specific dimensions.

**Step 0b — BPMN process variable extraction (MANDATORY for wkfl-* services)**:

When the service slug matches `wkfl-*`, Phase 1 MUST extract process variable state
for ≥1 failing order AND ≥1 succeeding control order BEFORE proceeding to Phase 2.
This is the single highest-value diagnostic step for Flowable services — it eliminates
hypotheses at Phase 1 instead of Phase 4, saving 2-3 investigation turns.

**Procedure**:
1. **Determine data source** (fast path vs sequential path):
   - **If `phase1-bpmn` was used** (fast path): the FAIL vs CONTROL data is already in Step 3 output.
     Extract the key differences from that output. Do NOT re-run the query.
   - **If sequential path was used** (`phase1-triage` + `bpmn-context`): run the comparison
     as a SEPARATE command now:
     ```bash
     elk-query.sh bpmn-variables --service <slug> --compare-control --hours 168
     ```

2. **Analyze the FAIL vs CONTROL diff**: For each variable in the extraction, compare values:
   - Identify which variables are `null` in FAIL but populated in CONTROL (or vice versa).
   - Identify which variables have different values between FAIL and CONTROL.
   - Record the diff as structured evidence.

3. **Write to Phase 1 evidence** (carried forward to all subsequent phases):
   ```
   BPMN Variable Diff (FAIL vs CONTROL):
   | Variable           | FAIL value | CONTROL value | Diagnostic significance |
   |--------------------|------------|---------------|------------------------|
   | purchasedOfferId   | null       | "d2815e06-..."| Missing = root cause?  |
   | partnerGroup       | "Streaming_POSTPAID" | "Streaming_POSTPAID" | Same — not causal |
   | entitlementProvider | "xsom"     | "xsom"        | Same — not causal       |
   ```

4. **Hypothesis narrowing**: Use the diff to immediately eliminate hypotheses:
   - Variables identical in FAIL and CONTROL → NOT causal (eliminate hypotheses about those fields).
   - Variables null/different in FAIL → likely causal (focus Phase 4 code investigation on the
     code paths that produce/consume these variables).

5. **Phase 4 scope hint**: Record which code paths to prioritize based on the diff:
   `Phase 4 focus: methods that set/validate <differing-variable-names>`

**BLOCKING**: If `bpmn-variables --compare-control` returns 0 CONTROL samples,
widen to `--hours 168` or remove the `--compare-control` flag and manually find
a non-ERROR log entry with the same `processDefinitionId`. If still no control
sample available, note the gap and proceed — do not block the investigation.

**Sequential path (when composite is insufficient or follow-up needed)**:
1. **Scope**: Get error count and top erroring services in the time window
2. **Sample**: Fetch 20-50 ERROR logs for the target service
3. **Classify**: Group by `LogEventMessage` or `logger_name` to find error patterns
3b. **First occurrence**: Determine when this error first appeared:
   ```bash
   elk-query.sh first-occurrence --service <slug> --query "<error-pattern>" --hours 168
   ```
   This searches the max 7-day window and returns the earliest matching log entry.
   The first-occurrence timestamp anchors Phase 4 (correlate with deploy times / code changes)
   and Phase 5 (timeline framework). If the error started before the current configLabel deploy,
   the root cause may be latent code triggered by new data, not a code change.
4. **Trace**: Pick representative `GlobalTrackingId` values, trace the full request flow
5. **Compare**: Check if errors are DC-specific (aggregate by `datacenter`)
6. **Version**: Check `configLabel` — did a recent deploy cause the errors? The configLabel IS the config branch/tag name — use it directly for `git checkout <configLabel>` to get the exact code
7. **Report**: Summarize error classes, frequency, blast radius, root cause hypothesis

### Playbook 2: Request Tracing
1. **Find**: Search for the `GlobalTrackingId` across all logTypes
2. **Order**: Sort by `@timestamp` ascending to see the call chain
3. **Map**: Build a sequence: which service called which, latencies at each hop
4. **Identify**: Find where the failure/slowness occurred in the chain
5. **Deep dive**: Read the `message` JSON for full request/response bodies at the failure point

### Playbook 3: Performance Analysis
1. **Baseline**: Aggregate `API_RESPONSE` durations per service (stats/percentiles)
2. **Outliers**: Find requests with high `duration` values
3. **Fan-out**: For slow requests, trace `GlobalTrackingId` to find slow downstream hops
4. **Compare DCs**: Same service across datacenters — is one DC slower?
5. **Time correlation**: Use date_histogram to see if latency spiked at a specific time

### Playbook 3b: External Dependency Latency Measurement (MANDATORY before theorizing about timeouts)

When the hypothesis involves a timeout, slow external call, or dependency failure,
**measure actual latency before theorizing**. Do NOT assume "the call was slow" without
evidence from DOWNSTREAM_RESPONSE or FEIGN_RESPONSE `duration` fields.

1. **Measure actual latency** of the external dependency:
   ```bash
   ELK=".github/skills/elk-log-search/scripts/elk-query.sh"
   $ELK raw --body '{"size":0,"query":{"bool":{"filter":[{"range":{"@timestamp":{"gte":"now-2h"}}},{"wildcard":{"serviceName.keyword":"*<calling-service>*"}},{"terms":{"logType.keyword":["DOWNSTREAM_RESPONSE","FEIGN_RESPONSE"]}},{"match":{"message":"<target-service-or-url>"}}]}},"aggs":{"latency_stats":{"extended_stats":{"field":"duration"}},"latency_percentiles":{"percentiles":{"field":"duration","percents":[50,90,95,99]}},"by_dc":{"terms":{"field":"datacenter.keyword"},"aggs":{"dc_latency":{"percentiles":{"field":"duration","percents":[50,95,99]}}}}}}'
   ```
   Note: `duration` may be stored as keyword in some services. If `extended_stats` fails,
   fall back to `terms` aggregation on `duration.keyword` to see distribution.

2. **Compare to configured timeout**: Find the timeout value from MobileBackOfficeConfig
   (`connectTimeout`, `readTimeout`, `socketTimeout`) for that dependency.

3. **Classify**:
   | p99 latency vs timeout | Classification |
   |----------------------|----------------|
   | p99 < 50% of timeout | Latency is NOT the issue |
   | p99 > 50% of timeout | Latency is a contributing factor |
   | p99 > 80% of timeout | Latency is likely the PRIMARY cause |
   | p99 > timeout | Timeout confirmed — external dependency is too slow |

4. **Report**: Include the measured p50/p95/p99, configured timeout, and classification
   in the investigation findings. Never say "probably slow" without these numbers.

### Playbook 4: Deployment Impact Assessment
1. **Identify version**: Find the `configLabel` for new and old version — each IS a config branch/tag name, use directly for `git diff <old-configLabel>..<new-configLabel>`
2. **Time boundary**: Determine when the new version started logging
3. **Compare**: Error rates before vs after deployment
4. **DC rollout**: Check if new version is in all DCs or rolling
5. **Regression signals**: New error messages, new 5xx status codes, latency increase

> **Query templates**: See `INVESTIGATION-BRAIN.md` → "Named Recipe: configLabel-Change Regression Detector" for ready-to-use ES aggregation queries (before/after by DC, configLabel distribution in error window).

### Playbook 5: Cross-Service Dependency Failure
1. **Detect**: Service A reports errors calling Service B (FEIGN_RESPONSE/DOWNSTREAM_RESPONSE with error statusCode)
2. **Correlate**: Check Service B's own logs for the same timeframe
3. **Cascade**: Follow the dependency chain — is B failing because of C?
4. **Blast radius**: How many upstream services are affected by B's failure?
5. **DC affinity**: Is the failure DC-specific?

> **Deeper investigation**: For multi-service failures, use the `service-traversal`
> skill which implements a formal DAG traversal algorithm with pattern detection.

### Multi-DC Timing Correlation

When errors appear in multiple datacenters, check timestamps:
1. Same error across ≥2 DCs within 5 seconds → **SHARED RESOURCE CONTENTION** (DB, cache, external dependency).
2. Correlate error types across DCs: same exception = shared resource; different exceptions = independent failures.
3. Check for companion errors: `ORA-01013`, `LOCK_TIME_`, `deadlock`, `timeout`.
4. If contention detected: add "Multi-DC database contention" as a hypothesis.

### Query Iteration Strategy

If the first query doesn't answer the question:
- **Narrow**: add more filters (service, level, logType)
- **Widen**: expand time range or remove service filter
- **Pivot**: switch from search to aggregation or vice versa
- **Trace**: follow a GlobalTrackingId to see the full request chain
- **Compare**: look at the same query across different timeframes or DCs

---

## Related Skills — Deeper Investigation

These playbooks provide a starting point. For deeper analysis, the `incident-investigator`
agent orchestrates a layered skill ecosystem built on top of this skill:

| Need | Skill | What It Adds |
|------|-------|-------------|
| Classify the error type | `error-taxonomy` | 8-category, 30+ subcategory classification |
| Quick severity assessment | `quick-triage` | FMEA scoring, recommendation routing |
| Full impact scope | `blast-radius` | Services, DCs, channels, customer impact |
| Cross-service error tracing | `service-traversal` | DAG traversal, pattern detection, origin identification |
| Code at deployed commit | `code-forensics` | configLabel → Artifactory → commit → git blame |
| Structured root cause analysis | `rca-synthesis` | 7 frameworks + ACH Matrix + Abductive Verification + Debiasing |
| Adversarial RCA critique | `rca-quality-gate` | 3 parallel critics + meta-reviewer + Socratic gates + adaptive depth |
| Fix proposals & prevention | `rca-recommendations` | Control classification, fix proposals, Jira tickets |

All these skills use `elk-log-search` as their ELK query foundation.

---

## Output Format

When presenting results to the user:

1. **Summary first**: "Found X errors in the last Y hours for service Z"
2. **Top patterns**: Group errors by message/class, show counts
3. **Representative samples**: Show 3-5 actual log entries with key fields
4. **Actionable insights**: Root cause hypothesis, affected scope, recommended next steps
5. **Follow-up queries**: Suggest what to search next if the picture is incomplete

For aggregation results, prefer tables:
```
| Service | Error Count | Top Error |
|---|---|---|
| g2wc-bo-account-production | 142 | Connection timeout |
```

---

## Bounds & Safety

- **Max result size**: 500 (never request more in a single query)
- **Max time window**: 7 days (168 hours)
- **Max aggregation buckets**: 200
- **Query timeout**: 60 seconds
- **Never search for PII fields** (comcastAccountNumber) without explicit user request
- **Always include a time range filter** — never run an unbounded time query
