# Log Analyst — Orchestration & Flow Reference

> **Audience**: Developers using the `incident-investigator` agent and its skill ecosystem.
> This document shows how skills, scripts, reference docs, prompts, and templates
> connect end-to-end.

---

## 1. Entry Points (How to Start)

```mermaid
flowchart LR
    subgraph Prompts["Slash-command Prompts"]
        P1["/triage\n<em>Quick severity check</em>"]
        P2["/investigate\n<em>Full RCA</em>"]
        P3["/code-forensics\n<em>Code-level analysis</em>"]
        P4["/pre-mortem\n<em>Predict future failure</em>"]
    end

    subgraph Agent["incident-investigator Agent"]
        A["incident-investigator.agent.md\n(Orchestrator)"]
    end

    P1 --> A
    P2 --> A
    P3 --> A
    P4 --> A
    U["Direct @incident-investigator chat"] --> A
```

| Prompt file | What it does | Tier |
|---|---|---|
| `prompts/incident-investigator.prompt.md` | All investigations — agent classifies intent and routes automatically | Any |
| `prompts/pre-mortem.prompt.md` | Predict how a fix might fail (Tier 3 sub-workflow) | Tier 3 |

---

## 2. Skill Dependency Graph

```mermaid
flowchart TD
    ELK["elk-log-search\n(Foundation)"]
    ET["error-taxonomy\n(Classification)"]
    QT["quick-triage\n(Rapid Assessment)"]
    BR["blast-radius\n(Impact Scope)"]
    ST["service-traversal\n(DAG Tracing)"]
    CF["code-forensics\n(Commit Analysis)"]
    RS["rca-synthesis\n(7 Frameworks + ACH)"]
    QG["rca-quality-gate\n(Adversarial Critique)"]
    RR["rca-recommendations\n(Action Plans)"]

    ELK --> QT
    ELK --> BR
    ELK --> ST
    ET --> QT
    ET --> BR
    ET --> RS
    QT --> BR
    BR --> ST
    ST --> CF
    CF --> RS
    RS --> QG
    QG -->|ACCEPT| RR
    QG -->|REVISE| RS

    classDef foundation fill:#e1f5fe,stroke:#0288d1
    classDef analysis fill:#f3e5f5,stroke:#7b1fa2
    classDef synthesis fill:#fff3e0,stroke:#ef6c00
    classDef gate fill:#fce4ec,stroke:#c62828

    class ELK foundation
    class ET,QT,BR,ST,CF analysis
    class RS synthesis
    class QG,RR gate
```

**Legend**: Blue = foundation | Purple = analysis skills | Orange = synthesis | Red = quality gate & output

---

## 3. Full RCA Investigation Flow (Phases 0–8)

```mermaid
flowchart TD
    START((User Request)) --> CLASSIFY{Classify Request}

    CLASSIFY -->|Quick check| TIER1["Tier 1\nPhases 0 → 1 → 6"]
    CLASSIFY -->|Standard| TIER2["Tier 2\nPhases 0 → 7"]
    CLASSIFY -->|Deep/Critical| TIER3["Tier 3\nPhases 0 → 8"]

    subgraph Phase0["Phase 0 — Intake & Triage"]
        P0A["Collect signal\n(error, service, time, IDs)"]
        P0B["quick-triage skill\n+ error-taxonomy"]
        P0C["FMEA Severity Score"]
        P0D{"Gate 1\nProblem Definition"}
    end

    subgraph Phase1["Phase 1 — Log Retrieval"]
        P1A["elk-log-search skill\n(primary + context queries)"]
        P1B["Anchoring Bias:\nquery 1+ additional service"]
        P1C{"Gate 2\nEvidence Sufficiency"}
    end

    subgraph Phase2["Phase 2 — Blast Radius"]
        P2A["blast-radius skill\n(services, DCs, channels)"]
        P2B{"Tier Escalation?\n>5 services → Tier 3"}
    end

    subgraph Phase3["Phase 3 — Service Traversal"]
        P3A["service-traversal skill\n(DAG-based tracing)"]
        P3B["Detect patterns:\ncascade, circuit breaker,\ntimeout, retry storm"]
        P3C["Anchoring check:\ntraverse from 2nd service"]
        P3D{"Gate 3\nHypothesis Formation\n(min 3 hypotheses)"}
    end

    subgraph Phase4["Phase 4 — Code Investigation"]
        P4A["code-forensics skill\nconfigLabel → commit → code"]
        P4B["Confirmation Bias:\nsearch for counter-evidence"]
    end

    subgraph Phase5["Phase 5 — RCA Synthesis"]
        P5A["rca-synthesis skill\n7 frameworks"]
        P5B["Tier 2+:\nACH Matrix + Debiasing"]
        P5C["Tier 3:\nAbductive Verification"]
        P5D{"Gate 4\nRoot Cause Validation\nconfidence ≥ 0.60?"}
    end

    subgraph Phase5b["Phase 5b — Adversarial Critique"]
        P5bA["rca-quality-gate skill"]
        P5bB["Tier 2: Evidence audit\n(single pass)"]
        P5bC["Tier 3: 3 Critics +\nMeta-Reviewer"]
        P5bD{"Meta Decision:\nACCEPT / REVISE / REJECT"}
        P5bE{"Gate 5\nRemediation Verification"}
    end

    subgraph Phase6["Phase 6 — Recommendations"]
        P6A["rca-recommendations skill"]
        P6B["Control classification\nfix proposals, Jira drafts"]
        P6C["Tier 3:\npre-mortem on fix"]
    end

    subgraph Phase7["Phase 7 — Validation"]
        P7A["Re-read findings\nverify evidence chains"]
        P7B["Human review checklist\n(automation bias)"]
    end

    subgraph Phase8["Phase 8 — Effectiveness"]
        P8A["Define success criteria"]
        P8B["Schedule checkpoints:\n1w, 1m, 1q"]
        P8C["Recurrence escalation"]
    end

    TIER1 --> Phase0
    TIER2 --> Phase0
    TIER3 --> Phase0

    P0A --> P0B --> P0C --> P0D
    P0D -->|PASS| Phase1
    P0D -->|FAIL| STOP1(("Restate problem"))

    P1A --> P1B --> P1C
    P1C -->|PASS| Phase2
    P1C -->|FAIL| STOP2(("Insufficient logs"))

    P2A --> P2B
    P2B -->|No| Phase3
    P2B -->|Yes: escalate| Phase3

    P3A --> P3B --> P3C --> P3D
    P3D -->|PASS| Phase4
    P3D -->|FAIL: <3 hyp| STOP3(("Need more evidence"))

    P4A --> P4B --> Phase5

    P5A --> P5B --> P5C --> P5D
    P5D -->|PASS & Tier 2+| Phase5b
    P5D -->|PASS & Tier 1| Phase6
    P5D -->|FAIL| LOOP1["Loop: gather more evidence"]

    P5bA --> P5bB
    P5bA --> P5bC
    P5bC --> P5bD
    P5bD -->|ACCEPT| P5bE
    P5bD -->|REVISE max 3x| Phase5
    P5bD -->|REJECT| STOP4(("Restart from Phase 1"))
    P5bE -->|PASS| Phase6

    P6A --> P6B --> P6C

    Phase6 --> Phase7
    P7A --> P7B

    Phase7 -->|Tier 3| Phase8
    Phase7 -->|Tier 1-2| OUTPUT

    P8A --> P8B --> P8C --> OUTPUT

    OUTPUT((RCA Report +\nAction Plan))

    style Phase0 fill:#e8f5e9,stroke:#2e7d32
    style Phase1 fill:#e1f5fe,stroke:#0288d1
    style Phase2 fill:#fff3e0,stroke:#ef6c00
    style Phase3 fill:#f3e5f5,stroke:#7b1fa2
    style Phase4 fill:#fce4ec,stroke:#c62828
    style Phase5 fill:#fff9c4,stroke:#f9a825
    style Phase5b fill:#fce4ec,stroke:#c62828
    style Phase6 fill:#e0f2f1,stroke:#00695c
    style Phase7 fill:#f5f5f5,stroke:#616161
    style Phase8 fill:#ede7f6,stroke:#4527a0
```

---

## 4. Tier Comparison

```mermaid
gantt
    title Investigation Depth by Tier
    dateFormat X
    axisFormat %s

    section Tier 1 (Quick)
    Phase 0 — Triage         :t1p0, 0, 1
    Phase 1 — Log Retrieval  :t1p1, 1, 2
    Phase 6 — Recommendations:t1p6, 2, 3

    section Tier 2 (Standard)
    Phase 0 — Triage         :t2p0, 0, 1
    Phase 1 — Log Retrieval  :t2p1, 1, 2
    Phase 2 — Blast Radius   :t2p2, 2, 3
    Phase 3 — Traversal      :t2p3, 3, 4
    Phase 4 — Code           :t2p4, 4, 5
    Phase 5 — RCA Synthesis  :t2p5, 5, 6
    Phase 5b — Critique (1x) :t2p5b, 6, 7
    Phase 6 — Recommendations:t2p6, 7, 8
    Phase 7 — Validation     :t2p7, 8, 9

    section Tier 3 (Deep)
    Phase 0 — Triage         :t3p0, 0, 1
    Phase 1 — Log Retrieval  :t3p1, 1, 2
    Phase 2 — Blast Radius   :t3p2, 2, 3
    Phase 3 — Traversal      :t3p3, 3, 4
    Phase 4 — Code           :t3p4, 4, 5
    Phase 5 — RCA Synthesis  :t3p5, 5, 6
    Phase 5b — Critique (3x) :crit, t3p5b, 6, 9
    Phase 6 — Recommendations:t3p6, 9, 10
    Phase 7 — Validation     :t3p7, 10, 11
    Phase 8 — Effectiveness  :t3p8, 11, 12
```

| Aspect | Tier 1 | Tier 2 | Tier 3 |
|--------|--------|--------|--------|
| **Phases** | 0, 1, 6 | 0–7 | 0–8 (all) |
| **Socratic Gates** | Gate 1 | Gates 1–4 | All 5 |
| **Frameworks** | Five Whys (3 levels) | 7 + ACH | 7 + ACH + Abductive |
| **Critics** | None | Evidence (1 pass) | All 3 + meta-reviewer |
| **Revision Cycles** | 0 | 1 | Up to 3 |
| **Pre-Mortem** | No | No | Yes |
| **Effectiveness** | No | Brief | Full Phase 8 |
| **Cognitive Debiasing** | None | Basic (anchoring, confirmation) | Full 7-bias framework |

---

## 5. File Layout & Ownership

```mermaid
flowchart TD
    subgraph Agent[".github/agents/"]
        LA["incident-investigator.agent.md\n(Orchestrator)"]
    end

    subgraph Prompts[".github/prompts/"]
        PR1["incident-investigator.prompt.md"]
        PR4["pre-mortem.prompt.md"]
    end

    subgraph Skills[".github/skills/"]
        subgraph ELK["elk-log-search/"]
            S1["SKILL.md"]
            S1R1["FIELD-REFERENCE.md"]
            S1R2["INVESTIGATION-BRAIN.md"]
            S1R3["ORCHESTRATION.md ← you are here"]
            subgraph ELKscripts["scripts/"]
                SC1["elk-query.sh"]
                SC2["elk-lib.sh"]
                SC3["elk-setup.sh"]
                SC4["elk-deep-trace.py"]
                SC5["resolve-commits.sh"]
                SC6["elk-sso-login.py"]
            end
        end

        subgraph ET["error-taxonomy/"]
            S2["SKILL.md"]
        end

        subgraph QT["quick-triage/"]
            S3["SKILL.md"]
        end

        subgraph BR["blast-radius/"]
            S4["SKILL.md"]
        end

        subgraph SV["service-traversal/"]
            S5["SKILL.md"]
            S5R1["DAG-ALGORITHM.md"]
        end

        subgraph CF["code-forensics/"]
            S6["SKILL.md"]
            S6R1["HEXAGONAL-PATTERNS.md"]
        end

        subgraph RS["rca-synthesis/"]
            S7["SKILL.md"]
            S7R1["FRAMEWORKS.md"]
            S7R2["FMEA-SCORING.md"]
            S7R3["ACH-MATRIX.md"]
            S7R4["ABDUCTIVE-VERIFICATION.md"]
            S7R5["COGNITIVE-BIASES.md"]
        end

        subgraph QG["rca-quality-gate/"]
            S8["SKILL.md"]
            S8R1["ADAPTIVE-DEPTH.md"]
            S8R2["SOCRATIC-CHECKPOINTS.md"]
        end

        subgraph RR["rca-recommendations/"]
            S9["SKILL.md"]
        end
    end

    subgraph Templates[".github/shared/templates/"]
        T1["rca-report.md"]
        T2["action-plan.md"]
        T3["triage-summary.md"]
    end

    subgraph Instructions[".github/instructions/"]
        I1["elk-log-search.instructions.md\n(trigger reference)"]
        I2["incident-root-cause-investigation.instructions.md"]
    end

    LA --> S1
    LA --> S2
    LA --> S3
    LA --> S4
    LA --> S5
    LA --> S6
    LA --> S7
    LA --> S8
    LA --> S9

    PR1 --> LA
    PR4 --> LA

    S9 --> T2
    S7 --> T1
    S3 --> T3
```

---

## 6. Adversarial Critique Flow (Phase 5b Detail)

```mermaid
flowchart TD
    RCA["RCA Synthesis\nOutput"] --> TIER{"Investigation\nTier?"}

    TIER -->|Tier 1| SKIP["Skip critique\n→ Phase 6"]
    TIER -->|Tier 2| SINGLE["Evidence Sufficiency\nAudit (single pass)"]
    TIER -->|Tier 3| FULL["Full Adversarial\nCritique"]

    subgraph Critics["Three Parallel Critics"]
        C1["Devil's Advocate\n• Challenge root cause\n• Propose alternatives\n• Find logical gaps"]
        C2["Evidence Sufficiency\n• Data completeness\n• Correlation ≠ causation\n• Statistical significance"]
        C3["Framework Completeness\n• All 7 frameworks applied?\n• ACH matrix complete?\n• Cross-validation done?"]
    end

    FULL --> C1
    FULL --> C2
    FULL --> C3

    C1 --> META["Meta-Reviewer\n• Aggregate critic scores\n• Compute composite confidence\n• Check for debiasing gaps"]
    C2 --> META
    C3 --> META

    SINGLE --> META

    META --> DEC{"Decision"}
    DEC -->|"ACCEPT\n(confidence ≥ threshold)"| PASS["→ Phase 6\nRecommendations"]
    DEC -->|"REVISE\n(specific guidance)"| LOOP{"Cycle\n≤ 3?"}
    DEC -->|"REJECT\n(fundamental flaw)"| RESTART["→ Restart\nfrom Phase 1"]

    LOOP -->|Yes| RCA
    LOOP -->|"No (max reached)"| ESCALATE["Report with\ncaveats +\nconfidence score"]

    style Critics fill:#fce4ec,stroke:#c62828
    style META fill:#fff3e0,stroke:#ef6c00
```

---

## 7. Cognitive Debiasing Integration

```mermaid
flowchart LR
    subgraph Biases["7 Tracked Biases"]
        B1["Availability\n(recent = likely)"]
        B2["Anchoring\n(first finding = answer)"]
        B3["Confirmation\n(seek supporting)"]
        B4["Narrative\n(good story = true)"]
        B5["Automation\n(trust the tool)"]
        B6["Hindsight\n(obvious in retrospect)"]
        B7["Groupthink\n(consensus = correct)"]
    end

    subgraph Phases["Where Checks Apply"]
        P0["Phase 0: Availability\n→ Force 3 differences\nfrom similar incident"]
        P1["Phase 1: Anchoring\n→ Query ≥1 additional\nservice"]
        P4["Phase 4: Confirmation\n→ Search for\ncounter-evidence"]
        P5["Phase 5: Narrative\n→ ACH Matrix\neliminates stories"]
        P7["Phase 7: Automation\n→ Human checklist\nof assumptions"]
    end

    B1 -.-> P0
    B2 -.-> P1
    B3 -.-> P4
    B4 -.-> P5
    B5 -.-> P7
```

---

## 8. Session Memory Flow

```mermaid
sequenceDiagram
    participant U as User
    participant A as incident-investigator Agent
    participant SM as Session Memory
    participant S as Skills

    U->>A: "Investigate errors in bo-account"
    A->>SM: Check for existing state
    SM-->>A: (empty or prior state)

    A->>S: Phase 0 — quick-triage
    S-->>A: Severity: HIGH, Tier: 2
    A->>SM: Write incident-investigator-state.md<br/>(problem, severity, tier)

    A->>S: Phase 1 — elk-log-search
    S-->>A: 342 errors, 3 DCs
    A->>SM: Write incident-investigator-evidence.md<br/>(log excerpts, patterns)

    A->>S: Phase 2 — blast-radius
    S-->>A: 8 services, 2 channels
    A->>SM: Update incident-investigator-state.md<br/>(impact scope)

    Note over A,SM: Context getting large...<br/>Compress prior phases to summary blocks

    A->>S: Phase 3 — service-traversal
    A->>S: Phase 4 — code-forensics
    A->>SM: Append to incident-investigator-evidence.md

    A->>S: Phase 5 — rca-synthesis
    S-->>A: Root cause + FMEA + ACH
    A->>SM: Write incident-investigator-rca.md

    A->>S: Phase 5b — rca-quality-gate
    S-->>A: ACCEPT (confidence 0.82)
    A->>SM: Update incident-investigator-state.md

    A->>S: Phase 6 — rca-recommendations
    S-->>A: Action plan + Jira drafts

    A->>U: Final RCA Report + Action Plan

    Note over U,A: If interrupted, Resume Protocol<br/>reads session memory files
```

---

## 9. Quick Reference: What to Use When

| You want to... | Use this | Skill(s) involved |
|---|---|---|
| Check if an error is critical | `/triage` | quick-triage → error-taxonomy |
| Search ELK logs directly | `@incident-investigator search for...` | elk-log-search |
| Trace a request end-to-end | `@incident-investigator trace <ID>` | elk-log-search (Playbook 2) |
| See how many services are affected | `@incident-investigator blast radius` | blast-radius |
| Follow error across services | `@incident-investigator trace across services` | service-traversal |
| Investigate the deployed code | `/code-forensics` | code-forensics |
| Full root cause analysis | `/investigate` | All 9 skills (phased) |
| Stress-test a proposed fix | `/pre-mortem` | rca-synthesis |
| Compare datacenters | `@incident-investigator compare DCs` | elk-log-search (Playbook 4) |
| Check deployment impact | `@incident-investigator deployment impact` | elk-log-search (Playbook 4) |
