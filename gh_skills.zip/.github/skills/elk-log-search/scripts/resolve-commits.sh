#!/usr/bin/env bash
# ============================================================================
# resolve-commits.sh — Resolve git commit SHAs from Artifactory build metadata
#
# For each service in version-comparison.tsv, queries Artifactory to get the
# exact git.commitId for target, prior-prod, and next-baseline versions. Uses a
# local mapping file (artifactory-path-map.conf) to resolve Maven group paths.
# Falls back to Artifactory search API and auto-updates the mapping.
#
# Designed for bash 3.x (macOS default) — no associative arrays.
#
# Usage:
#   resolve-commits.sh --version-file <path> --path-map <path> --out-dir <dir> \
#     [--parallel <n>] [--dry-run]
#
# Inputs:
#   --version-file  Path to version-comparison.tsv (pipe-delimited)
#   --path-map      Path to artifactory-path-map.conf (read/write)
#   --out-dir       Output directory for per-service JSON + summary
#   --parallel      Parallel workers (default: 4)
#   --dry-run       Print commands without executing
#
# Output:
#   <out-dir>/<service-name>.json  — per-service commit data (target, prior, next)
#   <out-dir>/_summary.tsv         — service|target_sha|prior_sha|next_sha|status
#   <out-dir>/_summary.json        — aggregated stats
#
# Dependencies: curl, jq
# ============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SHARED_LIB="${SCRIPT_DIR}/../../shared/scripts/_gh-lib.sh"
# shellcheck source=../../shared/scripts/_gh-lib.sh
[[ -f "$SHARED_LIB" ]] && source "$SHARED_LIB" || {
  echo "ERROR: Shared library not found at $SHARED_LIB" >&2; exit 1
}

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
readonly ARTIFACTORY_BASE="https://artifactory.comcast.com/artifactory"
readonly ARTIFACTORY_REPO="xmobile-libs"
readonly CURL_TIMEOUT=15
readonly MAX_RETRIES=2

# ---------------------------------------------------------------------------
# Globals
# ---------------------------------------------------------------------------
VERSION_FILE=""
PATH_MAP=""
OUT_DIR=""
PARALLEL=4
DRY_RUN=false

# ---------------------------------------------------------------------------
# Usage
# ---------------------------------------------------------------------------
usage() {
  cat >&2 <<'EOF'
Usage: resolve-commits.sh --version-file <path> --path-map <path> --out-dir <dir>
                          [--parallel <n>] [--dry-run]

Required:
  --version-file  Path to version-comparison.tsv (pipe-delimited)
  --path-map      Path to artifactory-path-map.conf (read/write for auto-update)
  --out-dir       Output directory for JSON files

Optional:
  --parallel      Parallel workers (default: 4)
  --dry-run       Print what would be fetched without calling APIs
EOF
  exit 1
}

# ---------------------------------------------------------------------------
# Parse arguments
# ---------------------------------------------------------------------------
while [[ $# -gt 0 ]]; do
  case "$1" in
    --version-file) VERSION_FILE="$2"; shift 2 ;;
    --path-map)     PATH_MAP="$2";     shift 2 ;;
    --out-dir)      OUT_DIR="$2";      shift 2 ;;
    --parallel)     PARALLEL="$2";     shift 2 ;;
    --dry-run)      DRY_RUN=true;      shift   ;;
    -h|--help)      usage ;;
    *)              err "Unknown option: $1"; usage ;;
  esac
done

[[ -z "$VERSION_FILE" ]] && { err "--version-file is required"; usage; }
[[ -z "$PATH_MAP" ]]     && { err "--path-map is required";     usage; }
[[ -z "$OUT_DIR" ]]      && { err "--out-dir is required";      usage; }
[[ -f "$VERSION_FILE" ]] || { err "Version file not found: $VERSION_FILE"; exit 1; }
[[ -f "$PATH_MAP" ]]     || { err "Path map not found: $PATH_MAP";        exit 1; }

require_tools curl jq
mkdir -p "$OUT_DIR"

# ---------------------------------------------------------------------------
# Path map loading — reads conf file into parallel arrays
# Bash 3.x compatible: two indexed arrays for prefix and service overrides
# ---------------------------------------------------------------------------
# Arrays for prefix entries: _pm_prefix_key[i], _pm_prefix_val[i]
# Arrays for service entries: _pm_svc_key[i], _pm_svc_val[i]
_pm_prefix_key=()
_pm_prefix_val=()
_pm_svc_key=()
_pm_svc_val=()

load_path_map() {
  _pm_prefix_key=()
  _pm_prefix_val=()
  _pm_svc_key=()
  _pm_svc_val=()

  while IFS= read -r line; do
    # Skip comments and blank lines
    [[ -z "$line" || "$line" == "#"* ]] && continue
    local key val
    key="${line%%=*}"
    val="${line#*=}"
    if [[ "$key" == prefix:* ]]; then
      _pm_prefix_key+=("${key#prefix:}")
      _pm_prefix_val+=("$val")
    elif [[ "$key" == service:* ]]; then
      _pm_svc_key+=("${key#service:}")
      _pm_svc_val+=("$val")
    fi
  done < "$PATH_MAP"

  log "Path map loaded: ${#_pm_prefix_key[@]} prefixes, ${#_pm_svc_key[@]} service overrides"
}

# ---------------------------------------------------------------------------
# Look up Maven group path for a service
# Priority: service override → prefix default → empty (triggers search)
# ---------------------------------------------------------------------------
lookup_group_path() {
  local svc="$1"
  local i

  # 1) Service override
  for ((i = 0; i < ${#_pm_svc_key[@]}; i++)); do
    if [[ "${_pm_svc_key[$i]}" == "$svc" ]]; then
      echo "${_pm_svc_val[$i]}"
      return 0
    fi
  done

  # 2) Prefix default — find the LONGEST matching prefix
  local best_match=""
  local best_len=0
  for ((i = 0; i < ${#_pm_prefix_key[@]}; i++)); do
    local pfx="${_pm_prefix_key[$i]}"
    # Service must start with prefix followed by -
    if [[ "$svc" == "${pfx}-"* ]]; then
      local pfx_len=${#pfx}
      if [[ $pfx_len -gt $best_len ]]; then
        best_match="${_pm_prefix_val[$i]}"
        best_len=$pfx_len
      fi
    fi
  done

  if [[ -n "$best_match" ]]; then
    echo "$best_match"
    return 0
  fi

  # 3) Default to mobile group (most services are there)
  warn "No prefix match for '${svc}' — defaulting to com/comcast/xfinity/mobile"
  echo "com/comcast/xfinity/mobile"
  return 0
}

# ---------------------------------------------------------------------------
# Search Artifactory for a service's group path and update the mapping file
# Uses the artifact search API: /api/search/artifact?name=<pom>&repos=<repo>
# ---------------------------------------------------------------------------
search_and_update_mapping() {
  local svc="$1"
  local version="$2"
  local pom_name="${svc}-${version}.pom"

  log "Searching Artifactory for ${pom_name} ..."
  local search_url="${ARTIFACTORY_BASE}/api/search/artifact?name=${pom_name}&repos=${ARTIFACTORY_REPO}"
  local result
  result=$(curl -sf --max-time "$CURL_TIMEOUT" "$search_url" 2>/dev/null) || {
    warn "Artifactory search failed for ${pom_name}"
    return 1
  }

  # Extract the storage URI from results[0].uri
  local storage_uri
  storage_uri=$(echo "$result" | jq -r '.results[0].uri // empty') || return 1
  [[ -z "$storage_uri" ]] && { warn "No results for ${pom_name}"; return 1; }

  # Parse group path from URI:
  #   .../api/storage/xmobile-libs/com/comcast/xfinity/bo/bo-account/3.0.179/bo-account-3.0.179.pom
  # We need the part between "xmobile-libs/" and "/<service>/<version>/"
  local path_after_repo
  path_after_repo=$(echo "$storage_uri" | sed "s|.*${ARTIFACTORY_REPO}/||")
  # Remove /<service>/<version>/<pom> from end
  local group_path
  group_path=$(echo "$path_after_repo" | sed "s|/${svc}/.*||")

  if [[ -z "$group_path" || "$group_path" == "$path_after_repo" ]]; then
    warn "Could not parse group path from URI: $storage_uri"
    return 1
  fi

  log "Discovered: ${svc} → ${group_path}"

  # Append to mapping file (service-level override)
  echo "service:${svc}=${group_path}" >> "$PATH_MAP"

  # Update in-memory arrays
  _pm_svc_key+=("$svc")
  _pm_svc_val+=("$group_path")

  echo "$group_path"
  return 0
}

# ---------------------------------------------------------------------------
# Fetch git.commitId from Artifactory for a specific service+version
# Returns: commit SHA on stdout, or "NOT_FOUND" / "ERROR"
# ---------------------------------------------------------------------------
fetch_commit_sha() {
  local svc="$1"
  local version="$2"
  local group_path="$3"

  [[ -z "$version" || "$version" == "NEW_SERVICE" || "$version" == "NOT_FOUND" ]] && {
    echo "N/A"
    return 0
  }

  local pom_path="${group_path}/${svc}/${version}/${svc}-${version}.pom"
  local prop_url="${ARTIFACTORY_BASE}/api/storage/${ARTIFACTORY_REPO}/${pom_path}?properties=git.commitId"

  local attempt=0
  while [[ $attempt -le $MAX_RETRIES ]]; do
    local response
    response=$(curl -sf --max-time "$CURL_TIMEOUT" "$prop_url" 2>/dev/null) && {
      local sha
      sha=$(echo "$response" | jq -r '.properties["git.commitId"][0] // empty')
      if [[ -n "$sha" ]]; then
        echo "$sha"
        return 0
      fi
      # Property endpoint returned but no git.commitId — artifact exists, no commit metadata
      echo "NO_COMMIT_ID"
      return 0
    }
    attempt=$((attempt + 1))
    [[ $attempt -le $MAX_RETRIES ]] && sleep 1
  done

  echo "ERROR"
  return 0
}

# ---------------------------------------------------------------------------
# Process a single service — resolve both target and prior commit SHAs
# Writes JSON to OUT_DIR/<service>.json
# ---------------------------------------------------------------------------
resolve_service() {
  local svc="$1"
  local target_version="$2"
  local prior_version="$3"
  local transition="$4"
  local next_version="${5:-}"
  local out_file="${OUT_DIR}/${svc}.json"

  # Resolve group path (lookup → search fallback)
  local group_path
  group_path=$(lookup_group_path "$svc") || {
    # Search fallback using target version
    group_path=$(search_and_update_mapping "$svc" "$target_version") || {
      # Try prior version if target fails
      if [[ -n "$prior_version" && "$prior_version" != "NEW_SERVICE" && "$prior_version" != "NOT_FOUND" ]]; then
        group_path=$(search_and_update_mapping "$svc" "$prior_version") || {
          warn "${svc}: could not resolve Artifactory group path"
          jq -n --arg svc "$svc" --arg target "$target_version" --arg prior "$prior_version" \
            '{service: $svc, target_version: $target, prior_version: $prior, error: "GROUP_PATH_NOT_FOUND", target_sha: "ERROR", prior_sha: "ERROR", next_version: null, next_sha: "N/A"}' \
            > "$out_file"
          return
        }
      else
        warn "${svc}: could not resolve Artifactory group path"
        jq -n --arg svc "$svc" --arg target "$target_version" --arg prior "$prior_version" \
          '{service: $svc, target_version: $target, prior_version: $prior, error: "GROUP_PATH_NOT_FOUND", target_sha: "ERROR", prior_sha: "ERROR", next_version: null, next_sha: "N/A"}' \
          > "$out_file"
        return
      fi
    }
  }

  if [[ "$DRY_RUN" == "true" ]]; then
    log "DRY-RUN: ${svc} → group=${group_path} target=${target_version} prior=${prior_version} next=${next_version:-N/A}"
    return
  fi

  # Fetch commit SHAs
  local target_sha prior_sha next_sha
  target_sha=$(fetch_commit_sha "$svc" "$target_version" "$group_path")

  # If target fetch failed, the group path from prefix default may be wrong.
  # Try search fallback to discover the correct path and retry.
  if [[ "$target_sha" == "ERROR" ]]; then
    local alt_group
    alt_group=$(search_and_update_mapping "$svc" "$target_version" 2>/dev/null) || true
    if [[ -n "$alt_group" && "$alt_group" != "$group_path" ]]; then
      warn "${svc}: prefix group '${group_path}' failed, discovered '${alt_group}' via search"
      group_path="$alt_group"
      target_sha=$(fetch_commit_sha "$svc" "$target_version" "$group_path")
    fi
  fi

  prior_sha=$(fetch_commit_sha "$svc" "$prior_version" "$group_path")

  # Resolve next-baseline SHA if version is available
  next_sha="N/A"
  if [[ -n "$next_version" && "$next_version" != "NOT_IN_NEXT" && "$next_version" != "UNAVAILABLE" ]]; then
    next_sha=$(fetch_commit_sha "$svc" "$next_version" "$group_path")
  fi

  # Determine status
  local status="OK"
  if [[ "$target_sha" == "ERROR" || "$prior_sha" == "ERROR" ]]; then
    status="PARTIAL_ERROR"
  elif [[ "$target_sha" == "NO_COMMIT_ID" || "$prior_sha" == "NO_COMMIT_ID" ]]; then
    status="MISSING_METADATA"
  elif [[ "$target_sha" == "N/A" && "$prior_sha" == "N/A" ]]; then
    status="BOTH_NA"
  fi

  # Write per-service JSON
  jq -n \
    --arg svc "$svc" \
    --arg target_ver "$target_version" \
    --arg prior_ver "$prior_version" \
    --arg next_ver "${next_version:-}" \
    --arg transition "$transition" \
    --arg group_path "$group_path" \
    --arg target_sha "$target_sha" \
    --arg prior_sha "$prior_sha" \
    --arg next_sha "$next_sha" \
    --arg status "$status" \
    '{
      service: $svc,
      target_version: $target_ver,
      prior_version: $prior_ver,
      next_version: (if $next_ver == "" or $next_ver == "NOT_IN_NEXT" or $next_ver == "UNAVAILABLE" then null else $next_ver end),
      transition: $transition,
      group_path: $group_path,
      target_sha: $target_sha,
      prior_sha: $prior_sha,
      next_sha: $next_sha,
      status: $status
    }' > "$out_file"
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
main() {
  log "=== resolve-commits.sh ==="
  log "Version file: ${VERSION_FILE}"
  log "Path map:     ${PATH_MAP}"
  log "Output dir:   ${OUT_DIR}"
  log "Parallel:     ${PARALLEL}"
  log "Dry run:      ${DRY_RUN}"

  # Load mapping file
  load_path_map

  # Read version-comparison.tsv (skip header)
  # Format: service|target_version|prior_prod_version|transition|source|next_baseline_version|next_baseline_source
  local total=0
  local queue_file="${OUT_DIR}/_queue.tmp"
  : > "$queue_file"

  while IFS='|' read -r svc target prior transition _source next_ver _rest; do
    echo "${svc}|${target}|${prior}|${transition}|${next_ver:-}" >> "$queue_file"
    total=$((total + 1))
  done < <(tail -n +2 "$VERSION_FILE")

  log "Queued ${total} services for commit resolution"

  if [[ "$DRY_RUN" == "true" ]]; then
    log "DRY-RUN mode — printing what would be resolved"
    while IFS='|' read -r svc target prior transition next_ver; do
      resolve_service "$svc" "$target" "$prior" "$transition" "$next_ver"
    done < "$queue_file"
    log "DRY-RUN complete."
    rm -f "$queue_file"
    return 0
  fi

  # Parallel execution (same pattern as fetch-prs.sh)
  local has_wait_n=false
  if [[ "${BASH_VERSINFO[0]:-0}" -ge 5 ]] || \
     [[ "${BASH_VERSINFO[0]:-0}" -eq 4 && "${BASH_VERSINFO[1]:-0}" -ge 3 ]]; then
    has_wait_n=true
  fi

  local running=0
  while IFS='|' read -r svc target prior transition next_ver; do
    resolve_service "$svc" "$target" "$prior" "$transition" "$next_ver" &
    running=$((running + 1))
    if [[ $running -ge $PARALLEL ]]; then
      if [[ "$has_wait_n" == "true" ]]; then
        wait -n 2>/dev/null || true
        running=$((running - 1))
      else
        wait
        running=0
      fi
    fi
  done < "$queue_file"
  wait

  rm -f "$queue_file"

  # Build summary TSV + stats
  local success=0 errors=0 missing_meta=0 na_count=0
  local summary_tsv="${OUT_DIR}/_summary.tsv"
  echo "service|target_version|target_sha|prior_version|prior_sha|next_version|next_sha|status" > "$summary_tsv"

  local next_resolved=0

  for f in "${OUT_DIR}"/*.json; do
    [[ "$(basename "$f")" == "_summary.json" ]] && continue
    [[ ! -f "$f" ]] && continue

    local svc_name target_sha prior_sha next_sha status
    svc_name=$(jq -r '.service' "$f")
    target_sha=$(jq -r '.target_sha' "$f")
    prior_sha=$(jq -r '.prior_sha' "$f")
    next_sha=$(jq -r '.next_sha // "N/A"' "$f")
    status=$(jq -r '.status' "$f")
    local target_ver prior_ver next_ver
    target_ver=$(jq -r '.target_version' "$f")
    prior_ver=$(jq -r '.prior_version' "$f")
    next_ver=$(jq -r '.next_version // "N/A"' "$f")

    echo "${svc_name}|${target_ver}|${target_sha}|${prior_ver}|${prior_sha}|${next_ver}|${next_sha}|${status}" >> "$summary_tsv"

    # Count services with resolved next SHAs
    if [[ "$next_sha" != "N/A" && "$next_sha" != "ERROR" && "$next_sha" != "NO_COMMIT_ID" ]]; then
      next_resolved=$((next_resolved + 1))
    fi

    case "$status" in
      OK)               success=$((success + 1)) ;;
      PARTIAL_ERROR)    errors=$((errors + 1)) ;;
      MISSING_METADATA) missing_meta=$((missing_meta + 1)) ;;
      BOTH_NA)          na_count=$((na_count + 1)) ;;
      *)                errors=$((errors + 1)) ;;
    esac
  done

  # Count check
  local actual_count
  actual_count=$(tail -n +2 "$summary_tsv" | wc -l | tr -d ' ')
  if [[ "$actual_count" -ne "$total" ]]; then
    warn "Count mismatch: queued=${total} but resolved=${actual_count}"
  fi

  # Write summary JSON
  jq -n \
    --argjson total "$total" \
    --argjson ok "$success" \
    --argjson errors "$errors" \
    --argjson missing_meta "$missing_meta" \
    --argjson na "$na_count" \
    --argjson actual "$actual_count" \
    --argjson next_resolved "$next_resolved" \
    '{
      total_services: $total,
      resolved_ok: $ok,
      partial_error: $errors,
      missing_metadata: $missing_meta,
      both_na: $na,
      actual_output_count: $actual,
      count_match: ($total == $actual),
      next_baseline_resolved: $next_resolved
    }' > "${OUT_DIR}/_summary.json"

  log "=== Summary ==="
  log "Total: ${total} | OK: ${success} | Errors: ${errors} | Missing metadata: ${missing_meta} | N/A: ${na_count} | Next resolved: ${next_resolved}"
  if [[ "$actual_count" -eq "$total" ]]; then
    log "✅ Count verified: ${actual_count}/${total}"
  else
    warn "⚠️  Count mismatch: ${actual_count}/${total}"
  fi

  cat "${OUT_DIR}/_summary.json"
}

main
