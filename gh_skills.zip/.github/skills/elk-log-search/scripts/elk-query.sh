#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────────────────────
# elk-query.sh — OrderTech ELK (Kibana) REST query tool
#
# Searches logs, lists indices/dashboards, tails services.
# Environment and cookie are loaded from ~/.ordertech-elk/environments.yaml.
#
# Usage:
#   elk-query.sh [--env <env>] <command> [options]
#
# Examples:
#   elk-query.sh status
#   elk-query.sh --env prod search --service bo-account --hours 2
#   ELK_ENV=stage elk-query.sh search --query "NullPointerException"
#   elk-query.sh envs
# ──────────────────────────────────────────────────────────────────────────────
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=elk-lib.sh
source "${SCRIPT_DIR}/elk-lib.sh"

readonly SCRIPT_NAME="$(basename "$0")"
readonly DEFAULT_SIZE=20
readonly DEFAULT_HOURS=1

# ── Index resolution ─────────────────────────────────────────────────────────
# Returns the correct default index for the current environment.
# Prod uses "order-tech-*", lower uses "order-tech-lower-*".
elk_default_index() {
  local env="${ELK_ENV:-prod}"
  case "$env" in
    prod|custom) echo "order-tech-*" ;;
    *)           echo "order-tech-lower-*" ;;
  esac
}

# ── Parse global flags (before command) ──────────────────────────────────────
while [[ $# -gt 0 ]]; do
  case "$1" in
    --env|-e)
      [[ $# -lt 2 ]] && elk_die "--env requires a value"
      export ELK_ENV="$2"; shift 2 ;;
    --help) usage; exit 0 ;;
    -*) break ;;   # unknown flag — pass to command
    *)  break ;;   # positional — it's the command
  esac
done

# ── Commands ─────────────────────────────────────────────────────────────────

cmd_envs() {
  elk_list_envs
}

cmd_status() {
  elk_load_env
  elk_info "Fetching Kibana status ..."
  elk_get "/api/status" | elk_pretty
}

cmd_indices() {
  elk_load_env
  elk_info "Listing data views / index patterns ..."
  local result
  result=$(elk_get "/api/data_views" 2>/dev/null) || true
  if [[ -n "$result" ]]; then
    echo "$result" | elk_pretty
  else
    elk_info "(Data Views API unavailable — falling back to saved objects)"
    elk_get "/api/saved_objects/_find?type=index-pattern&per_page=100" | elk_pretty
  fi
}

cmd_search() {
  elk_load_env
  local service="" query="" size="$DEFAULT_SIZE" hours="$DEFAULT_HOURS" index="" level=""
  local exclude_level="" source_fields="" agg_spec=""

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --service|-s)        [[ $# -lt 2 ]] && elk_die "--service requires a value";        service="$2";        shift 2 ;;
      --query|-q)          [[ $# -lt 2 ]] && elk_die "--query requires a value";          query="$2";          shift 2 ;;
      --size|-n)           [[ $# -lt 2 ]] && elk_die "--size requires a value";           size="$2";           shift 2 ;;
      --hours)             [[ $# -lt 2 ]] && elk_die "--hours requires a value";          hours="$2";          shift 2 ;;
      --index|-i)          [[ $# -lt 2 ]] && elk_die "--index requires a value";          index="$2";          shift 2 ;;
      --level|-l)          [[ $# -lt 2 ]] && elk_die "--level requires a value";          level="$2";          shift 2 ;;
      --exclude-level)     [[ $# -lt 2 ]] && elk_die "--exclude-level requires a value";  exclude_level="$2";  shift 2 ;;
      --source)            [[ $# -lt 2 ]] && elk_die "--source requires a value";         source_fields="$2";  shift 2 ;;
      --agg)               [[ $# -lt 2 ]] && elk_die "--agg requires a value";            agg_spec="$2";       shift 2 ;;
      *) elk_die "Unknown search option: $1" ;;
    esac
  done

  # Validate bounds
  [[ "$size" =~ ^[0-9]+$ ]]  || elk_die "--size must be a positive integer"
  [[ "$hours" =~ ^[0-9]+$ ]] || elk_die "--hours must be a positive integer"
  (( size  > ELK_MAX_SIZE  )) && elk_die "--size exceeds max ($ELK_MAX_SIZE)"
  (( hours > ELK_MAX_HOURS )) && elk_die "--hours exceeds max ($ELK_MAX_HOURS) — 7 days"

  # Validate --exclude-level: allow-list of known levels (max 5 chars)
  # Use tr for bash 3.2 compat (macOS default) — ${var^^} requires bash 4+
  if [[ -n "$exclude_level" ]]; then
    exclude_level=$(printf '%s' "$exclude_level" | tr '[:lower:]' '[:upper:]')
    case "$exclude_level" in
      ERROR|WARN|INFO|DEBUG|TRACE) : ;;
      *) elk_die "--exclude-level must be one of: ERROR, WARN, INFO, DEBUG, TRACE" ;;
    esac
  fi

  # Validate --source: only allow safe field name characters (alphanumeric, underscore, dot, comma)
  if [[ -n "$source_fields" ]]; then
    [[ "$source_fields" =~ ^[a-zA-Z0-9_.,]+$ ]] || elk_die "--source contains invalid characters (allowed: a-z A-Z 0-9 _ . ,)"
  fi

  # Validate --agg: must be field:size format
  local agg_field="" agg_size=10
  if [[ -n "$agg_spec" ]]; then
    if [[ "$agg_spec" =~ ^([a-zA-Z0-9_.]+):([0-9]+)$ ]]; then
      agg_field="${BASH_REMATCH[1]}"
      agg_size="${BASH_REMATCH[2]}"
      (( agg_size > 100 )) && elk_die "--agg size exceeds max (100)"
      (( agg_size < 1 ))   && elk_die "--agg size must be >= 1"
    elif [[ "$agg_spec" =~ ^[a-zA-Z0-9_.]+$ ]]; then
      agg_field="$agg_spec"
    else
      elk_die "--agg must be FIELD or FIELD:SIZE (e.g. datacenter:10)"
    fi
  fi

  index="${index:-$(elk_default_index)}"

  # Build must clauses
  local must_clauses='[]'
  if [[ -n "$service" ]]; then
    must_clauses=$(cat <<QUERY
[
  {
    "bool": {
      "should": [
        { "match": { "serviceName": "${service}" } },
        { "match": { "service_name": "${service}" } },
        { "match": { "application": "${service}" } },
        { "match": { "app": "${service}" } }
      ],
      "minimum_should_match": 1
    }
  }
]
QUERY
    )
  fi

  if [[ -n "$level" ]]; then
    if elk_has_jq; then
      must_clauses=$(echo "$must_clauses" | jq --arg l "$level" \
        '. + [{"term": {"level.keyword": ($l | ascii_upcase)}}]')
    else
      # tr for bash 3.2 compat (macOS default) — ${var^^} requires bash 4+
      local ul
      ul=$(printf '%s' "$level" | tr '[:lower:]' '[:upper:]')
      must_clauses="${must_clauses%]}, {\"term\": {\"level.keyword\": \"${ul}\"}}]"
    fi
  fi

  if [[ -n "$query" ]]; then
    if elk_has_jq; then
      must_clauses=$(echo "$must_clauses" | jq --arg q "$query" \
        '. + [{"query_string": {"query": $q, "default_operator": "AND"}}]')
    else
      must_clauses="${must_clauses%]}, {\"query_string\": {\"query\": \"${query}\", \"default_operator\": \"AND\"}}]"
    fi
  fi

  # Build must_not clauses (--exclude-level)
  local must_not_clauses='[]'
  if [[ -n "$exclude_level" ]]; then
    must_not_clauses=$(cat <<MUSTNOT
[{"term": {"level.keyword": "${exclude_level}"}}]
MUSTNOT
    )
  fi

  # Build _source: custom if --source provided, otherwise default
  local source_json
  if [[ -n "$source_fields" ]]; then
    # Convert comma-separated to JSON array: "a,b,c" → ["a","b","c"]
    source_json=$(echo "$source_fields" | awk -F',' '{
      printf "["
      for(i=1;i<=NF;i++) {
        gsub(/^ +| +$/,"",$i)
        printf "\"%s\"",$i
        if(i<NF) printf ","
      }
      printf "]"
    }')
  else
    source_json='["@timestamp", "message", "level", "serviceName", "logger_name",
              "LogEventMessage", "logType", "threadContextId",
              "GlobalTrackingId", "statusCode", "url", "uri", "method",
              "duration", "environment", "datacenter", "configLabel",
              "SalesChannel", "SessionId"]'
  fi

  # Build aggregation clause (--agg)
  local agg_json=''
  if [[ -n "$agg_field" ]]; then
    agg_json=", \"aggs\": {\"by_${agg_field}\": {\"terms\": {\"field\": \"${agg_field}.keyword\", \"size\": ${agg_size}}}}"
  fi

  local body
  body=$(cat <<BODY
{
  "size": ${size},
  "query": {
    "bool": {
      "must": ${must_clauses},
      "must_not": ${must_not_clauses},
      "filter": [
        { "range": { "@timestamp": { "gte": "now-${hours}h" } } }
      ]
    }
  },
  "sort": [{ "@timestamp": { "order": "desc" } }],
  "_source": ${source_json}
  ${agg_json}
}
BODY
  )

  local info_parts="index='${index}' service='${service:-<all>}' level='${level:-<all>}'"
  [[ -n "$exclude_level" ]] && info_parts="${info_parts} exclude='${exclude_level}'"
  [[ -n "$source_fields" ]] && info_parts="${info_parts} source='${source_fields}'"
  [[ -n "$agg_field" ]]     && info_parts="${info_parts} agg='${agg_field}:${agg_size}'"
  info_parts="${info_parts} query='${query:-<none>}' hours=${hours} size=${size}"
  elk_info "Searching ${info_parts} ..."
  elk_search "$index" "$body" | elk_pretty
}

cmd_tail() {
  local service=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --service|-s) [[ $# -lt 2 ]] && elk_die "--service requires a value"; service="$2"; shift 2 ;;
      *) elk_die "Unknown tail option: $1" ;;
    esac
  done
  [[ -z "$service" ]] && elk_die "tail requires --service <name>"
  cmd_search --service "$service" --size 30 --hours 1
}

cmd_errors() {
  local service="" hours="$DEFAULT_HOURS" size="$DEFAULT_SIZE"
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --service|-s) [[ $# -lt 2 ]] && elk_die "--service requires a value"; service="$2"; shift 2 ;;
      --hours)      [[ $# -lt 2 ]] && elk_die "--hours requires a value";   hours="$2";   shift 2 ;;
      --size|-n)    [[ $# -lt 2 ]] && elk_die "--size requires a value";    size="$2";    shift 2 ;;
      *) elk_die "Unknown errors option: $1" ;;
    esac
  done
  local args=(--level ERROR --hours "$hours" --size "$size")
  [[ -n "$service" ]] && args+=(--service "$service")
  cmd_search "${args[@]}"
}

cmd_first_occurrence() {
  elk_load_env
  local service="" query="" hours="168" index="" level="ERROR"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --service|-s)  [[ $# -lt 2 ]] && elk_die "--service requires a value";  service="$2";  shift 2 ;;
      --query|-q)    [[ $# -lt 2 ]] && elk_die "--query requires a value";    query="$2";    shift 2 ;;
      --hours)       [[ $# -lt 2 ]] && elk_die "--hours requires a value";    hours="$2";    shift 2 ;;
      --index|-i)    [[ $# -lt 2 ]] && elk_die "--index requires a value";    index="$2";    shift 2 ;;
      --level|-l)    [[ $# -lt 2 ]] && elk_die "--level requires a value";    level="$2";    shift 2 ;;
      *) elk_die "Unknown first-occurrence option: $1" ;;
    esac
  done

  [[ "$hours" =~ ^[0-9]+$ ]] || elk_die "--hours must be a positive integer"
  (( hours > ELK_MAX_HOURS )) && elk_die "--hours exceeds max ($ELK_MAX_HOURS) — 7 days"

  index="${index:-$(elk_default_index)}"

  # Build must clauses
  local must_clauses='[]'
  if [[ -n "$service" ]]; then
    must_clauses=$(cat <<QUERY
[
  {
    "bool": {
      "should": [
        { "match": { "serviceName": "${service}" } },
        { "match": { "service_name": "${service}" } },
        { "match": { "application": "${service}" } },
        { "match": { "app": "${service}" } }
      ],
      "minimum_should_match": 1
    }
  }
]
QUERY
    )
  fi

  if [[ -n "$level" ]]; then
    if elk_has_jq; then
      must_clauses=$(echo "$must_clauses" | jq --arg l "$level" \
        '. + [{"term": {"level.keyword": ($l | ascii_upcase)}}]')
    else
      local ul
      ul=$(printf '%s' "$level" | tr '[:lower:]' '[:upper:]')
      must_clauses="${must_clauses%]}, {\"term\": {\"level.keyword\": \"${ul}\"}}]"
    fi
  fi

  if [[ -n "$query" ]]; then
    if elk_has_jq; then
      must_clauses=$(echo "$must_clauses" | jq --arg q "$query" \
        '. + [{"query_string": {"query": $q, "default_operator": "AND"}}]')
    else
      must_clauses="${must_clauses%]}, {\"query_string\": {\"query\": \"${query}\", \"default_operator\": \"AND\"}}]"
    fi
  fi

  local body
  body=$(cat <<BODY
{
  "size": 1,
  "query": {
    "bool": {
      "must": ${must_clauses},
      "filter": [
        { "range": { "@timestamp": { "gte": "now-${hours}h" } } }
      ]
    }
  },
  "sort": [{ "@timestamp": { "order": "asc" } }],
  "_source": ["@timestamp", "message", "level", "serviceName", "logger_name",
              "LogEventMessage", "logType", "datacenter", "configLabel",
              "GlobalTrackingId"]
}
BODY
  )

  elk_info "First occurrence: service='${service:-<all>}' level='${level:-ERROR}' query='${query:-<none>}' hours=${hours} ..."
  elk_search "$index" "$body" | elk_pretty
}

cmd_trace() {
  elk_load_env
  local tracking_id="" hours=24
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --id|-t)    [[ $# -lt 2 ]] && elk_die "--id requires a value";    tracking_id="$2"; shift 2 ;;
      --hours)    [[ $# -lt 2 ]] && elk_die "--hours requires a value"; hours="$2";       shift 2 ;;
      *) tracking_id="$1"; shift ;;
    esac
  done
  [[ -z "$tracking_id" ]] && elk_die "trace requires a tracking ID (--id <id> or positional)"

  local body
  body=$(cat <<BODY
{
  "size": 200,
  "query": {
    "bool": {
      "should": [
        { "match_phrase": { "GlobalTrackingId": "${tracking_id}" } },
        { "match_phrase": { "globaltrackingid": "${tracking_id}" } },
        { "match_phrase": { "threadContextId": "${tracking_id}" } }
      ],
      "minimum_should_match": 1,
      "filter": [
        { "range": { "@timestamp": { "gte": "now-${hours}h" } } }
      ]
    }
  },
  "sort": [{ "@timestamp": { "order": "asc" } }],
  "_source": ["@timestamp", "serviceName", "level", "logType",
              "LogEventMessage", "method", "uri", "statusCode",
              "duration", "GlobalTrackingId", "threadContextId",
              "datacenter", "configLabel"]
}
BODY
  )

  elk_info "Tracing ID '${tracking_id}' (last ${hours}h) ..."
  elk_search "$(elk_default_index)" "$body" | elk_pretty
}

# ── identify: auto-detect ID type (GTI vs SessionId vs embedded) ─────────────
# Tries structured trace fields first, then falls back to free-text search.
# Returns JSON with id_type + hits, plus the matching log entries.
# Max 2 ELK queries instead of the 4-5 manual iteration pattern.
cmd_identify() {
  elk_load_env
  local id="" hours=168
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --hours)  [[ $# -lt 2 ]] && elk_die "--hours requires a value"; hours="$2"; shift 2 ;;
      *)        id="$1"; shift ;;
    esac
  done
  [[ -z "$id" ]] && elk_die "identify requires a UUID or tracking ID (positional or after options)"

  # Input validation: alphanumeric, hyphens, underscores, colons only (UUIDs, GTIs, session IDs)
  [[ "$id" =~ ^[a-zA-Z0-9:_-]+$ ]] || elk_die "identify: ID contains invalid characters (allowed: a-z A-Z 0-9 : _ -)"
  (( ${#id} > 200 )) && elk_die "identify: ID exceeds max length (200)"
  [[ "$hours" =~ ^[0-9]+$ ]] || elk_die "--hours must be a positive integer"
  (( hours > ELK_MAX_HOURS )) && elk_die "--hours exceeds max ($ELK_MAX_HOURS) — 7 days"

  local index
  index="$(elk_default_index)"

  # Strategy 1: Try as GlobalTrackingId / threadContextId (structured fields)
  local trace_body
  trace_body=$(cat <<BODY
{
  "size": 5,
  "query": {
    "bool": {
      "should": [
        { "match_phrase": { "GlobalTrackingId": "${id}" } },
        { "match_phrase": { "globaltrackingid": "${id}" } },
        { "match_phrase": { "threadContextId": "${id}" } }
      ],
      "minimum_should_match": 1,
      "filter": [
        { "range": { "@timestamp": { "gte": "now-${hours}h" } } }
      ]
    }
  },
  "sort": [{ "@timestamp": { "order": "asc" } }],
  "_source": ["@timestamp", "serviceName", "level", "logType",
              "GlobalTrackingId", "threadContextId", "datacenter", "configLabel"]
}
BODY
  )

  elk_info "Identifying '${id}' — trying GlobalTrackingId/threadContextId first ..."
  local trace_result trace_total
  trace_result=$(elk_search "$index" "$trace_body")
  trace_total=$(echo "$trace_result" | jq -r '
    (.rawResponse.hits.total.value // .rawResponse.hits.total // 0)
  ' 2>/dev/null || echo "0")

  if [[ "$trace_total" -gt 0 ]]; then
    elk_info "IDENTIFIED as GlobalTrackingId/threadContextId — ${trace_total} hit(s)"
    echo "{\"id_type\": \"GlobalTrackingId\", \"total_hits\": ${trace_total}}"
    echo "$trace_result" | elk_pretty
    return 0
  fi

  # Strategy 2: Try as SessionId or embedded ID in message body (free-text)
  elk_info "Not a GTI — trying free-text search on message/SessionId fields ..."
  local qs_body
  qs_body=$(cat <<BODY
{
  "size": 5,
  "query": {
    "bool": {
      "must": [
        { "multi_match": { "query": "${id}", "fields": ["message", "LogEventMessage", "SessionId"], "type": "phrase" } }
      ],
      "filter": [
        { "range": { "@timestamp": { "gte": "now-${hours}h" } } }
      ]
    }
  },
  "sort": [{ "@timestamp": { "order": "asc" } }],
  "_source": ["@timestamp", "serviceName", "level", "logType",
              "GlobalTrackingId", "threadContextId", "SessionId",
              "datacenter", "configLabel"]
}
BODY
  )

  local qs_result qs_total
  qs_result=$(elk_search "$index" "$qs_body")
  qs_total=$(echo "$qs_result" | jq -r '
    (.rawResponse.hits.total.value // .rawResponse.hits.total // 0)
  ' 2>/dev/null || echo "0")

  if [[ "$qs_total" -gt 0 ]]; then
    # Extract the actual GlobalTrackingId from results for follow-up tracing
    local extracted_gti
    extracted_gti=$(echo "$qs_result" | jq -r '
      [.rawResponse.hits.hits[]._source |
       (.GlobalTrackingId // .globaltrackingid // .threadContextId // empty)] |
      map(select(. != null and . != "")) | unique | first // "none"
    ' 2>/dev/null || echo "none")

    elk_info "IDENTIFIED as SessionId/embedded — ${qs_total} hit(s)"
    if [[ "$extracted_gti" != "none" && "$extracted_gti" != "null" && "$extracted_gti" != "$id" ]]; then
      elk_info "  Extracted GlobalTrackingId: ${extracted_gti}"
      elk_info "  Follow-up: elk-query.sh trace ${extracted_gti}"
      echo "{\"id_type\": \"SessionId_or_embedded\", \"total_hits\": ${qs_total}, \"extracted_gti\": \"${extracted_gti}\"}"
    else
      echo "{\"id_type\": \"SessionId_or_embedded\", \"total_hits\": ${qs_total}}"
    fi
    echo "$qs_result" | elk_pretty
    return 0
  fi

  # Neither strategy found results
  elk_info "NOT FOUND — '${id}' not in structured fields or message body (${hours}h window)"
  echo "{\"id_type\": \"unknown\", \"total_hits\": 0}"
  return 0
}

cmd_top_errors() {
  elk_load_env
  local hours="$DEFAULT_HOURS" top=20 service="" by="config"
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --hours)           [[ $# -lt 2 ]] && elk_die "--hours requires a value";   hours="$2";   shift 2 ;;
      --top|-n)          [[ $# -lt 2 ]] && elk_die "--top requires a value";     top="$2";     shift 2 ;;
      --service|-s)      [[ $# -lt 2 ]] && elk_die "--service requires a value"; service="$2"; shift 2 ;;
      --by)              [[ $# -lt 2 ]] && elk_die "--by requires a value";      by="$2";      shift 2 ;;
      *) elk_die "Unknown top-errors option: $1" ;;
    esac
  done

  local body
  if [[ -n "$service" ]]; then
    # Per-service mode: top error sources (logger_name) with message breakdown
    body=$(cat <<BODY
{
  "size": 0,
  "query": {
    "bool": {
      "filter": [
        { "range": { "@timestamp": { "gte": "now-${hours}h" } } },
        { "term": { "level.keyword": "ERROR" } },
        { "wildcard": { "serviceName.keyword": "*${service}*" } }
      ]
    }
  },
  "aggs": {
    "by_logger": {
      "terms": { "field": "logger_name.keyword", "size": ${top}, "order": { "_count": "desc" } },
      "aggs": {
        "top_messages": {
          "terms": { "field": "LogEventMessage.keyword", "size": 3, "order": { "_count": "desc" }, "missing": "(no message)" }
        }
      }
    },
    "total_errors": { "value_count": { "field": "level.keyword" } }
  }
}
BODY
    )
    elk_info "Top ${top} error sources for '${service}' (last ${hours}h) ..."
    elk_search "$(elk_default_index)" "$body" | jq '
      (.rawResponse.aggregations.total_errors.value // 0) as $total |
      "Total errors: \($total)",
      "",
      (.rawResponse.aggregations.by_logger.buckets[] |
        {logger: .key, count: .doc_count,
         messages: [.top_messages.buckets[] | "\(.key) (\(.doc_count))"]})
    ' 2>/dev/null
  else
    # Global mode: aggregate by configLabel (default) or serviceName (--by instance)
    local agg_field label
    if [[ "$by" == "instance" ]]; then
      agg_field="serviceName.keyword"
      label="service instance (per datacenter)"
    else
      agg_field="configLabel.keyword"
      label="service (across all datacenters)"
    fi
    body=$(cat <<BODY
{
  "size": 0,
  "query": {
    "bool": {
      "filter": [
        { "range": { "@timestamp": { "gte": "now-${hours}h" } } },
        { "term": { "level.keyword": "ERROR" } }
      ]
    }
  },
  "aggs": {
    "by_service": {
      "terms": { "field": "${agg_field}", "size": ${top}, "order": { "_count": "desc" } }
    }
  }
}
BODY
    )
    elk_info "Top ${top} erroring services by ${label} (last ${hours}h) ..."
    elk_search "$(elk_default_index)" "$body" | jq '.rawResponse.aggregations.by_service.buckets[] | {service: .key, errors: .doc_count}' 2>/dev/null
  fi
}

cmd_fields() {
  elk_load_env
  local index="$(elk_default_index)"
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --index|-i) [[ $# -lt 2 ]] && elk_die "--index requires a value"; index="$2"; shift 2 ;;
      *) elk_die "Unknown fields option: $1" ;;
    esac
  done

  elk_info "Fields for index '${index}' ..."
  elk_get "/api/index_patterns/_fields_for_wildcard?pattern=${index}&meta_fields=_source&meta_fields=_id&meta_fields=_index" 2>/dev/null \
    | jq '.fields | sort_by(.name)[] | select(.metadata_field == false) | "\(.name)  [\(.type)] agg=\(.aggregatable) search=\(.searchable)"' -r 2>/dev/null
}

cmd_field_values() {
  elk_load_env
  local index="$(elk_default_index)" field="" top=20 hours=1
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --index|-i)  [[ $# -lt 2 ]] && elk_die "--index requires a value";  index="$2"; shift 2 ;;
      --field|-f)  [[ $# -lt 2 ]] && elk_die "--field requires a value";  field="$2"; shift 2 ;;
      --top|-n)    [[ $# -lt 2 ]] && elk_die "--top requires a value";    top="$2";   shift 2 ;;
      --hours)     [[ $# -lt 2 ]] && elk_die "--hours requires a value";  hours="$2"; shift 2 ;;
      *) elk_die "Unknown field-values option: $1" ;;
    esac
  done
  [[ -z "$field" ]] && elk_die "--field is required. Example: --field serviceName"

  # Try keyword sub-field first, fall back to plain field
  local kw_field="${field}.keyword"
  local body
  body=$(cat <<BODY
{
  "size": 0,
  "query": { "range": { "@timestamp": { "gte": "now-${hours}h" } } },
  "aggs": {
    "values": {
      "terms": { "field": "${kw_field}", "size": ${top}, "order": { "_count": "desc" } }
    },
    "total_docs": { "value_count": { "field": "@timestamp" } }
  }
}
BODY
  )

  elk_info "Top ${top} values for '${field}' in '${index}' (last ${hours}h) ..."
  local result
  result=$(elk_search "$index" "$body" 2>/dev/null)
  local bucket_count
  bucket_count=$(echo "$result" | jq '.rawResponse.aggregations.values.buckets | length' 2>/dev/null || echo 0)

  if [[ "$bucket_count" -eq 0 ]]; then
    # Retry without .keyword (numeric/boolean fields)
    body=$(echo "$body" | sed "s|\"${kw_field}\"|\"${field}\"|")
    result=$(elk_search "$index" "$body" 2>/dev/null)
  fi

  local total
  total=$(echo "$result" | jq '.rawResponse.aggregations.total_docs.value // 0' 2>/dev/null)
  elk_info "Sampled from ${total} documents"
  echo "$result" | jq '.rawResponse.aggregations.values.buckets[] | {value: (.key_as_string // .key), count: .doc_count}' 2>/dev/null
}

cmd_phase1_triage() {
  elk_load_env
  local service="" hours="$DEFAULT_HOURS" index=""

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --service|-s) [[ $# -lt 2 ]] && elk_die "--service requires a value"; service="$2"; shift 2 ;;
      --hours)      [[ $# -lt 2 ]] && elk_die "--hours requires a value";   hours="$2";   shift 2 ;;
      --index|-i)   [[ $# -lt 2 ]] && elk_die "--index requires a value";   index="$2";   shift 2 ;;
      *) elk_die "Unknown phase1-triage option: $1" ;;
    esac
  done
  [[ -z "$service" ]] && elk_die "phase1-triage requires --service"

  # Validate bounds
  [[ "$hours" =~ ^[0-9]+$ ]] || elk_die "--hours must be a positive integer"
  (( hours > ELK_MAX_HOURS )) && elk_die "--hours exceeds max ($ELK_MAX_HOURS) — 7 days"

  index="${index:-$(elk_default_index)}"

  # Single composite query: 5 sample hits + 4 aggregation dimensions
  local body
  body=$(cat <<BODY
{
  "size": 5,
  "query": {
    "bool": {
      "must": [
        { "wildcard": { "serviceName.keyword": "*${service}*" } },
        { "term": { "level.keyword": "ERROR" } }
      ],
      "filter": [
        { "range": { "@timestamp": { "gte": "now-${hours}h" } } }
      ]
    }
  },
  "sort": [{ "@timestamp": { "order": "desc" } }],
  "_source": ["@timestamp", "serviceName", "level", "logType",
              "LogEventMessage", "message", "logger_name",
              "GlobalTrackingId", "threadContextId",
              "datacenter", "configLabel", "environment",
              "SalesChannel", "statusCode", "uri", "method", "duration"],
  "aggs": {
    "by_dc": {
      "terms": { "field": "datacenter.keyword", "size": 10 }
    },
    "by_config": {
      "terms": { "field": "configLabel.keyword", "size": 5, "order": { "_count": "desc" } }
    },
    "by_error_source": {
      "terms": { "field": "logger_name.keyword", "size": 10, "order": { "_count": "desc" } },
      "aggs": {
        "top_messages": {
          "terms": { "field": "LogEventMessage.keyword", "size": 3, "order": { "_count": "desc" }, "missing": "(no message)" }
        }
      }
    },
    "by_env": {
      "terms": { "field": "environment.keyword", "size": 10 }
    },
    "total_errors": { "value_count": { "field": "level.keyword" } }
  }
}
BODY
  )

  elk_info "Phase 1 composite triage for '${service}' (last ${hours}h, index=${index}) ..."
  elk_info "Returns: 5 sample errors + DC/configLabel/errorSource/environment aggregations"

  local result
  result=$(elk_search "$index" "$body")

  # Output structured sections for agent consumption
  elk_info ""
  elk_info "=== TOTAL ERRORS ==="
  echo "$result" | jq '.rawResponse.aggregations.total_errors.value // 0' 2>/dev/null

  elk_info ""
  elk_info "=== DC DISTRIBUTION ==="
  echo "$result" | jq '.rawResponse.aggregations.by_dc.buckets[] | {dc: .key, count: .doc_count}' 2>/dev/null

  elk_info ""
  elk_info "=== CONFIGLABEL DISTRIBUTION ==="
  echo "$result" | jq '.rawResponse.aggregations.by_config.buckets[] | {configLabel: .key, count: .doc_count}' 2>/dev/null

  elk_info ""
  elk_info "=== ENVIRONMENT DISTRIBUTION ==="
  echo "$result" | jq '.rawResponse.aggregations.by_env.buckets[] | {environment: .key, count: .doc_count}' 2>/dev/null

  elk_info ""
  elk_info "=== ERROR SOURCE BREAKDOWN ==="
  echo "$result" | jq '.rawResponse.aggregations.by_error_source.buckets[] |
    {logger: .key, count: .doc_count,
     messages: [.top_messages.buckets[] | "\(.key) (\(.doc_count))"]}' 2>/dev/null

  elk_info ""
  elk_info "=== SAMPLE ERROR LOGS (up to 5) ==="
  echo "$result" | jq '[.rawResponse.hits.hits[]._source] |
    .[] | {
      timestamp: .["@timestamp"],
      service: .serviceName,
      dc: .datacenter,
      config: .configLabel,
      logger: .logger_name,
      message: (.LogEventMessage // .message | tostring | .[0:200]),
      trackingId: .GlobalTrackingId,
      threadCtx: .threadContextId,
      channel: .SalesChannel,
      status: .statusCode,
      uri: .uri
    }' 2>/dev/null
}

cmd_bpmn_context() {
  elk_load_env
  local service="" hours="$DEFAULT_HOURS" index="" size=20

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --service|-s) [[ $# -lt 2 ]] && elk_die "--service requires a value"; service="$2"; shift 2 ;;
      --hours)      [[ $# -lt 2 ]] && elk_die "--hours requires a value";   hours="$2";   shift 2 ;;
      --size|-n)    [[ $# -lt 2 ]] && elk_die "--size requires a value";    size="$2";    shift 2 ;;
      --index|-i)   [[ $# -lt 2 ]] && elk_die "--index requires a value";   index="$2";   shift 2 ;;
      *) elk_die "Unknown bpmn-context option: $1" ;;
    esac
  done
  [[ -z "$service" ]] && elk_die "bpmn-context requires --service <name>"

  # Validate bounds
  [[ "$hours" =~ ^[0-9]+$ ]] || elk_die "--hours must be a positive integer"
  (( hours > ELK_MAX_HOURS )) && elk_die "--hours exceeds max ($ELK_MAX_HOURS)"
  [[ "$size" =~ ^[0-9]+$ ]]  || elk_die "--size must be a positive integer"
  (( size > 50 )) && size=50  # Cap at 50 to prevent context exhaustion

  index="${index:-$(elk_default_index)}"

  # Query ERROR logs for BPMN service and extract nested JSON fields
  local body
  body=$(cat <<BODY
{
  "size": ${size},
  "query": {
    "bool": {
      "must": [
        { "wildcard": { "serviceName.keyword": "*${service}*" } },
        { "term": { "level.keyword": "ERROR" } }
      ],
      "filter": [
        { "range": { "@timestamp": { "gte": "now-${hours}h" } } }
      ]
    }
  },
  "sort": [{ "@timestamp": { "order": "desc" } }],
  "_source": ["@timestamp", "serviceName", "message", "LogEventMessage",
              "datacenter", "configLabel", "GlobalTrackingId", "threadContextId"]
}
BODY
  )

  elk_info "Extracting BPMN context from '${service}' ERROR logs (last ${hours}h) ..."
  elk_info "Fields: businessKey, processDefinitionId, action, parentBusinessKey/orderId"

  local result
  result=$(elk_search "$index" "$body")

  # Two-tier extraction: (1) JSON parse, (2) scan() regex fallback for malformed messages.
  # scan() uses simple patterns with no quote escaping — avoids bash/jq/regex escape hell.
  # Reports extraction_quality + recommended_trace so the caller knows which tier/key to use.
  echo "$result" | jq -r '
    # Helper: UUID regex (8-4-4-4-12 hex)
    def uuid_re: "[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}";

    # Helper: extract first regex match from text. scan() returns capture groups as arrays.
    # Usage: "text" | first_match("field.{1,10}(capture_pattern)") → "captured" or null
    def first_match(re): try ([scan(re)] | .[0][0]) catch null;

    [.rawResponse.hits.hits[]._source] |
    [.[] | {
      timestamp: .["@timestamp"],
      service: .serviceName,
      dc: .datacenter,
      config: .configLabel,
      trackingId: .GlobalTrackingId,
      threadCtx: .threadContextId,
      message_raw: (.message // ""),
      logEvent: (.LogEventMessage // "")
    } | . + (
      # Bind message_raw to $msg so it survives into the catch block
      # (jq catch receives the error string as ".", not the original object)
      .message_raw as $msg |
      # Tier 1: Parse message as JSON and extract BPMN fields via structured access
      try ($msg | fromjson | {
        businessKey: (.context.businessKey // .instanceVariables.businessKey // .businessKey // null),
        processDefinitionId: (.context.processDefinitionId // .processDefinitionId // null),
        action: (.context.action // .instanceVariables.action // .action // null),
        parentBusinessKey: (.context.parentBusinessKey // .instanceVariables.parentBusinessKey // null),
        orderId: (.context.orderId // .instanceVariables.orderId // null),
        _extract_tier: "json"
      }) catch (
        # Tier 2: Regex fallback using scan() — works on malformed/prefixed/partial JSON.
        # Pattern: "fieldName" + 1-10 lazy separator chars + "(captured value)".
        # Lazy .{1,10}? prevents greedy over-matching (e.g., eating into the value).
        {
          businessKey:        ($msg | first_match("businessKey.{1,10}?(" + uuid_re + ")")),
          processDefinitionId:($msg | first_match("processDefinitionId.{1,10}?([a-zA-Z][a-zA-Z0-9_-]+:[0-9]+)")),
          action:             ($msg | first_match("action.{1,10}?(ASYNCCANCEL|CANCEL|CHANGE|DISCONNECT|MODIFY|ADD|RETURN)")),
          parentBusinessKey:  ($msg | first_match("parentBusinessKey.{1,10}?(" + uuid_re + ")")),
          orderId:            ($msg | first_match("orderId.{1,10}?(" + uuid_re + ")")),
          _extract_tier: "regex"
        }
      )
    ) | del(.message_raw)] |

    # Compute extraction quality metrics + graduated trace key recommendation
    {
      total_samples: length,
      extraction_quality: {
        json_parsed:      [.[] | select(._extract_tier == "json")]  | length,
        regex_fallback:   [.[] | select(._extract_tier == "regex")] | length,
        with_business_key:[.[] | select(.businessKey != null)]      | length,
        with_process_def: [.[] | select(.processDefinitionId != null)] | length
      },
      unique_business_keys: [.[].businessKey        | select(. != null)] | unique,
      unique_process_defs:  [.[].processDefinitionId| select(. != null)] | unique,
      unique_actions:       [.[].action             | select(. != null)] | unique,
      unique_parent_keys:   [.[].parentBusinessKey  | select(. != null)] | unique,
      unique_order_ids:     [.[].orderId            | select(. != null)] | unique,

      # Graduated fallback: pick the narrowest available trace key.
      # Priority: businessKey > orderId > parentBusinessKey > threadContextId > NONE
      # GlobalTrackingId is intentionally excluded — too broad for wkfl-* services.
      recommended_trace: (
        if   ([.[].businessKey       | select(. != null)] | length) > 0
        then { key: "businessKey",       scope: "process-instance", values: ([.[].businessKey       | select(. != null)] | unique) }
        elif ([.[].orderId           | select(. != null)] | length) > 0
        then { key: "orderId",           scope: "order-level",      values: ([.[].orderId           | select(. != null)] | unique) }
        elif ([.[].parentBusinessKey | select(. != null)] | length) > 0
        then { key: "parentBusinessKey", scope: "parent-order",     values: ([.[].parentBusinessKey | select(. != null)] | unique) }
        elif ([.[].threadCtx | select(. != null and . != "")] | length) > 0
        then { key: "threadContextId",   scope: "service-thread",   values: ([.[].threadCtx | select(. != null and . != "")] | unique | .[0:5]) }
        else { key: "NONE",              scope: "no-usable-key",    values: [] }
        end
      ),
      sample_entries: [limit(3; .[])] | [.[] | {
        timestamp, service, dc, config, trackingId, threadCtx,
        businessKey, processDefinitionId, action, parentBusinessKey, orderId,
        _extract_tier,
        logEvent: (.logEvent | tostring | .[0:150])
      }]
    }
  ' 2>/dev/null
}

cmd_bpmn_variables() {
  elk_load_env
  local service="" hours=168 index="" size=3
  local business_key="" order_id="" fields="" compare_control=false

  # Default extraction fields — covers the most commonly investigated BPMN variables.
  # Callers can override with --fields to target service-specific variables.
  local default_fields="purchasedOfferId,partnerGroup,entitlementProvider,action,businessKey,orderId,parentBusinessKey,productFamily,processDefinitionId"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --service|-s)        [[ $# -lt 2 ]] && elk_die "--service requires a value";       service="$2";       shift 2 ;;
      --business-key|-b)   [[ $# -lt 2 ]] && elk_die "--business-key requires a value";  business_key="$2";  shift 2 ;;
      --order-id|-o)       [[ $# -lt 2 ]] && elk_die "--order-id requires a value";      order_id="$2";      shift 2 ;;
      --fields|-f)         [[ $# -lt 2 ]] && elk_die "--fields requires a value";        fields="$2";        shift 2 ;;
      --hours)             [[ $# -lt 2 ]] && elk_die "--hours requires a value";         hours="$2";         shift 2 ;;
      --size|-n)           [[ $# -lt 2 ]] && elk_die "--size requires a value";          size="$2";          shift 2 ;;
      --index|-i)          [[ $# -lt 2 ]] && elk_die "--index requires a value";         index="$2";         shift 2 ;;
      --compare-control)   compare_control=true; shift ;;
      *) elk_die "Unknown bpmn-variables option: $1" ;;
    esac
  done
  [[ -z "$service" ]] && elk_die "bpmn-variables requires --service <name>"

  # Validate bounds — reuse shared constants from elk-lib.sh
  [[ "$hours" =~ ^[0-9]+$ ]] || elk_die "--hours must be a positive integer"
  (( hours > ELK_MAX_HOURS )) && elk_die "--hours exceeds max ($ELK_MAX_HOURS) — 7 days"
  [[ "$size" =~ ^[0-9]+$ ]]  || elk_die "--size must be a positive integer"
  (( size > 20 )) && size=20  # Hard cap — prevents context exhaustion

  index="${index:-$(elk_default_index)}"
  fields="${fields:-$default_fields}"

  # Sanitize service slug — only allow alphanumeric, dash, underscore, dot
  if [[ ! "$service" =~ ^[a-zA-Z0-9._-]+$ ]]; then
    elk_die "--service contains invalid characters (allowed: a-z A-Z 0-9 . _ -)"
  fi

  # Sanitize fields list — only allow alphanumeric, underscore, comma
  if [[ ! "$fields" =~ ^[a-zA-Z0-9_,]+$ ]]; then
    elk_die "--fields contains invalid characters (allowed: a-z A-Z 0-9 _ ,)"
  fi

  # Build the scoping clause for businessKey or orderId (narrows to specific instance)
  # Sanitize: strip characters that would break JSON string context (quotes, backslashes)
  local scope_clause=""
  if [[ -n "$business_key" ]]; then
    local safe_bk="${business_key//\"/}"
    safe_bk="${safe_bk//\\/}"
    scope_clause="{\"query_string\": {\"query\": \"\\\"${safe_bk}\\\"\", \"default_field\": \"message\"}}"
  elif [[ -n "$order_id" ]]; then
    local safe_oid="${order_id//\"/}"
    safe_oid="${safe_oid//\\/}"
    scope_clause="{\"query_string\": {\"query\": \"\\\"${safe_oid}\\\"\", \"default_field\": \"message\"}}"
  fi

  # ── Helper: run one extraction query ──────────────────────────────────────
  # Args: $1=label  $2=extra_must_json (or "")  $3=extra_must_not_json (or "")
  _bpmn_var_query() {
    local label="$1"
    local extra_must="${2:-}"
    local extra_must_not="${3:-}"

    # Assemble must clauses
    local must_parts=""
    must_parts="${must_parts}{\"wildcard\": {\"serviceName.keyword\": \"*${service}*\"}},"
    if [[ -n "$scope_clause" ]]; then
      must_parts="${must_parts}${scope_clause},"
    fi
    if [[ -n "$extra_must" ]]; then
      must_parts="${must_parts}${extra_must},"
    fi
    # Remove trailing comma
    must_parts="${must_parts%,}"

    # Assemble must_not clause (for control sample)
    local must_not_section=""
    if [[ -n "$extra_must_not" ]]; then
      must_not_section="\"must_not\": [${extra_must_not}],"
    fi

    local body
    body=$(printf '{
  "size": %d,
  "query": {
    "bool": {
      "must": [%s],
      %s
      "filter": [
        { "range": { "@timestamp": { "gte": "now-%dh" } } }
      ]
    }
  },
  "sort": [{ "@timestamp": { "order": "desc" } }],
  "_source": ["@timestamp", "serviceName", "message", "level",
              "datacenter", "configLabel", "GlobalTrackingId",
              "threadContextId", "LogEventMessage", "logType"]
}' "$size" "$must_parts" "$must_not_section" "$hours")

    elk_info "[$label] Querying ${size} samples (last ${hours}h) ..."
    local result
    result=$(elk_search "$index" "$body")

    # Extract requested fields from nested message JSON.
    # Uses the same 2-tier approach as bpmn-context: JSON parse → regex fallback.
    # The --fields list is passed as a jq arg and split at commas.
    echo "$result" | jq --arg fields_csv "$fields" --arg lbl "$label" -r '
      ($fields_csv | split(",")) as $field_names |

      # Helper: extract a named field from parsed JSON object
      # Checks 3 locations: .context.<key>, .instanceVariables.<key>, .<key>
      def extract_field(obj; name):
        (obj.context[name] // obj.instanceVariables[name] // obj[name] // null) |
        if . == null then null
        elif type == "object" or type == "array" then (. | tostring | .[0:120])
        else tostring
        end;

      [.rawResponse.hits.hits[]._source] |
      if length == 0 then
        { sample_set: $lbl, total_samples: 0, variables: [], entries: [] }
      else
        {
          sample_set: $lbl,
          total_samples: length,
          variables: $field_names,
          entries: [.[] | . as $src |
            ($src.message // "" ) as $msg |
            (try ($msg | fromjson) catch {}) as $parsed |
            {
              timestamp: $src["@timestamp"],
              service: $src.serviceName,
              dc: $src.datacenter,
              level: $src.level,
              config: $src.configLabel,
              trackingId: $src.GlobalTrackingId,
              threadCtx: $src.threadContextId,
              logEvent: ($src.LogEventMessage // $msg | tostring | .[0:150]),
              vars: (reduce $field_names[] as $f ({}; . + { ($f): extract_field($parsed; $f) }))
            }
          ]
        }
      end
    ' 2>/dev/null
  }

  # ── Execute queries ───────────────────────────────────────────────────────
  if [[ "$compare_control" == true ]]; then
    elk_info "Compare mode: fetching FAIL + CONTROL samples for '${service}'"
    elk_info "Fields: ${fields}"

    # FAIL sample: level=ERROR
    _bpmn_var_query "FAIL" '{"term": {"level.keyword": "ERROR"}}' ""

    elk_info ""

    # CONTROL sample: level != ERROR (successful execution)
    _bpmn_var_query "CONTROL" "" '{"term": {"level.keyword": "ERROR"}}'
  else
    elk_info "Single-mode extraction for '${service}'"
    elk_info "Fields: ${fields}"

    # Default: ERROR logs (most common investigation starting point)
    _bpmn_var_query "SAMPLE" '{"term": {"level.keyword": "ERROR"}}' ""
  fi
}

cmd_phase1_bpmn() {
  elk_load_env
  local service="" hours=24 index=""

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --service|-s) [[ $# -lt 2 ]] && elk_die "--service requires a value"; service="$2"; shift 2 ;;
      --hours)      [[ $# -lt 2 ]] && elk_die "--hours requires a value";   hours="$2";   shift 2 ;;
      --index|-i)   [[ $# -lt 2 ]] && elk_die "--index requires a value";   index="$2";   shift 2 ;;
      *) elk_die "Unknown phase1-bpmn option: $1" ;;
    esac
  done
  [[ -z "$service" ]] && elk_die "phase1-bpmn requires --service <name>"

  # Validate bounds
  [[ "$hours" =~ ^[0-9]+$ ]] || elk_die "--hours must be a positive integer"
  (( hours > ELK_MAX_HOURS )) && elk_die "--hours exceeds max ($ELK_MAX_HOURS) — 7 days"

  index="${index:-$(elk_default_index)}"

  # Sanitize service slug — only allow alphanumeric, dash, underscore, dot
  if [[ ! "$service" =~ ^[a-zA-Z0-9._-]+$ ]]; then
    elk_die "--service contains invalid characters (allowed: a-z A-Z 0-9 . _ -)"
  fi

  elk_info "╔══════════════════════════════════════════════════════════════════╗"
  elk_info "║  Phase 1 BPMN Triage: ${service}"
  elk_info "║  Time window: last ${hours}h  |  Index: ${index}"
  elk_info "╚══════════════════════════════════════════════════════════════════╝"
  elk_info ""

  # ── Step 1: Error count + DC distribution (single aggregation query) ──────
  elk_info "━━━ Step 1/5: Error Count + DC Distribution ━━━"
  local step1_body
  step1_body=$(printf '{
  "size": 0,
  "query": {
    "bool": {
      "must": [
        { "wildcard": { "serviceName.keyword": "*%s*" } },
        { "term": { "level.keyword": "ERROR" } }
      ],
      "filter": [
        { "range": { "@timestamp": { "gte": "now-%dh" } } }
      ]
    }
  },
  "aggs": {
    "by_dc": {
      "terms": { "field": "datacenter.keyword", "size": 10 }
    },
    "by_config": {
      "terms": { "field": "configLabel.keyword", "size": 5, "order": { "_count": "desc" } }
    },
    "by_error_source": {
      "terms": { "field": "logger_name.keyword", "size": 10, "order": { "_count": "desc" } },
      "aggs": {
        "top_messages": {
          "terms": { "field": "LogEventMessage.keyword", "size": 3, "order": { "_count": "desc" }, "missing": "(no message)" }
        }
      }
    },
    "total_errors": { "value_count": { "field": "level.keyword" } }
  }
}' "$service" "$hours")

  local step1_result
  step1_result=$(elk_search "$index" "$step1_body")

  echo "$step1_result" | jq '{
    total_errors: (.rawResponse.aggregations.total_errors.value // 0),
    dc_distribution: [.rawResponse.aggregations.by_dc.buckets[] | {dc: .key, count: .doc_count}],
    config_labels: [.rawResponse.aggregations.by_config.buckets[] | {config: .key, count: .doc_count}],
    error_sources: [.rawResponse.aggregations.by_error_source.buckets[] |
      {logger: .key, count: .doc_count,
       messages: [.top_messages.buckets[] | "\(.key | .[0:120]) (\(.doc_count))"]}]
  }' 2>/dev/null

  elk_info ""

  # ── Step 2: businessKey extraction from first 3 ERROR samples ─────────────
  elk_info "━━━ Step 2/5: businessKey Extraction (3 ERROR samples) ━━━"
  cmd_bpmn_context --service "$service" --hours "$hours" --size 3 --index "$index"

  elk_info ""

  # ── Step 3: Process variable comparison (fail vs control) ─────────────────
  elk_info "━━━ Step 3/5: Process Variables (FAIL vs CONTROL) ━━━"
  cmd_bpmn_variables --service "$service" --hours "$hours" --size 3 --compare-control --index "$index"

  elk_info ""

  # ── Step 4: 7-day error trend (date histogram, 1-day buckets) ─────────────
  elk_info "━━━ Step 4/5: 7-Day Error Trend ━━━"
  local step4_body
  step4_body=$(printf '{
  "size": 0,
  "query": {
    "bool": {
      "must": [
        { "wildcard": { "serviceName.keyword": "*%s*" } },
        { "term": { "level.keyword": "ERROR" } }
      ],
      "filter": [
        { "range": { "@timestamp": { "gte": "now-168h" } } }
      ]
    }
  },
  "aggs": {
    "daily_trend": {
      "date_histogram": { "field": "@timestamp", "calendar_interval": "day" },
      "aggs": {
        "by_dc": {
          "terms": { "field": "datacenter.keyword", "size": 6 }
        }
      }
    }
  }
}' "$service")

  local step4_result
  step4_result=$(elk_search "$index" "$step4_body")

  echo "$step4_result" | jq '[.rawResponse.aggregations.daily_trend.buckets[] | {
    date: .key_as_string,
    errors: .doc_count,
    by_dc: [.by_dc.buckets[] | {dc: .key, count: .doc_count}]
  }]' 2>/dev/null

  elk_info ""

  # ── Step 5: Structured summary ────────────────────────────────────────────
  elk_info "━━━ Step 5/5: Phase 1 BPMN Summary ━━━"
  local total_errors
  total_errors=$(echo "$step1_result" | jq '.rawResponse.aggregations.total_errors.value // 0' 2>/dev/null)
  local dc_count
  dc_count=$(echo "$step1_result" | jq '.rawResponse.aggregations.by_dc.buckets | length' 2>/dev/null)
  local config_label
  config_label=$(echo "$step1_result" | jq -r '.rawResponse.aggregations.by_config.buckets[0].key // "unknown"' 2>/dev/null)

  elk_info "┌─────────────────────────────────────────────┐"
  elk_info "│ Service:       ${service}"
  elk_info "│ Total errors:  ${total_errors} (last ${hours}h)"
  elk_info "│ DCs affected:  ${dc_count}"
  elk_info "│ Config label:  ${config_label}"
  elk_info "│ Trend:         see Step 4 output"
  elk_info "│ Variables:     see Step 3 output"
  elk_info "└─────────────────────────────────────────────┘"
}

# ── Raw Elasticsearch query passthrough ──────────────────────────────────────
# Allows callers to send arbitrary ES JSON through the authenticated channel
# without sourcing elk-lib.sh directly. This is the ONLY approved Method 3
# entry point — scripts MUST use this instead of `source elk-lib.sh`.
cmd_raw() {
  elk_load_env
  local index="" body="" body_file=""

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --index|-i)     [[ $# -lt 2 ]] && elk_die "--index requires a value";     index="$2";     shift 2 ;;
      --body|-b)      [[ $# -lt 2 ]] && elk_die "--body requires a value";      body="$2";      shift 2 ;;
      --body-file|-f) [[ $# -lt 2 ]] && elk_die "--body-file requires a value"; body_file="$2"; shift 2 ;;
      *) elk_die "Unknown raw option: $1" ;;
    esac
  done

  index="${index:-$(elk_default_index)}"

  # Resolve body: --body-file takes precedence over --body
  if [[ -n "$body_file" ]]; then
    [[ -f "$body_file" ]] || elk_die "--body-file not found: $body_file"
    # Cap file size at 64KB to prevent unbounded reads
    local file_size
    file_size=$(wc -c < "$body_file" | tr -d ' ')
    (( file_size > 65536 )) && elk_die "--body-file exceeds max size (64KB)"
    body=$(cat "$body_file")
  fi

  [[ -z "$body" ]] && elk_die "raw requires --body '<json>' or --body-file <path>"

  # Minimal JSON syntax check: must start with { and end with }
  local trimmed
  trimmed=$(echo "$body" | sed 's/^[[:space:]]*//' | sed 's/[[:space:]]*$//')
  [[ "$trimmed" == "{"* ]] || elk_die "--body must be a JSON object (starts with '{')"

  elk_info "Raw query index='${index}' body-length=${#body} ..."
  elk_search "$index" "$body"
}

cmd_dashboards() {
  elk_load_env
  elk_info "Listing saved dashboards ..."
  elk_get "/api/saved_objects/_find?type=dashboard&per_page=100" | elk_pretty
}

cmd_saved_searches() {
  elk_load_env
  elk_info "Listing saved searches ..."
  elk_get "/api/saved_objects/_find?type=search&per_page=100" | elk_pretty
}

cmd_cluster_health() {
  elk_load_env
  elk_info "Fetching Elasticsearch cluster health ..."
  elk_get "/elasticsearch/_cluster/health" | elk_pretty
}

# ── Usage ────────────────────────────────────────────────────────────────────
usage() {
  cat <<EOF
${SCRIPT_NAME} — OrderTech ELK query tool

Config: ~/.ordertech-elk/environments.yaml
Setup: elk-setup.sh

Global options:
  --env, -e ENV     Select environment (default: prod)
                    Or set ELK_ENV=<env>

Commands:
  envs              List configured environments and cookie status
  status            Kibana version, health, plugins
  indices           List data views / index patterns
  fields            List all fields for an index pattern
  field-values      Show top distinct values for a field
  search            Search logs (see options below)
  errors            Search ERROR logs (shorthand)
  first-occurrence  Find the earliest log entry matching a pattern (7-day max, sort asc, size 1)
  tail              Quick tail of recent logs for a service
  trace             Trace a request by GlobalTrackingId
  identify          Auto-detect ID type (GTI vs SessionId) and return matching logs
  top-errors        Top erroring services (aggregation)
  phase1-triage     Composite Phase 1 query: sample errors + DC/config/env/source aggs (single request)
  bpmn-context      Extract BPMN diagnostic fields (businessKey, processDefId, action) from ERROR logs
  bpmn-variables    Extract specific process variables from BPMN service logs (with --compare-control)
  phase1-bpmn       Full Phase 1 triage for wkfl-* services: errors + context + variables + trend
  raw               Send raw Elasticsearch JSON (Method 3 entry point — replaces sourcing elk-lib.sh)
  dashboards        List saved dashboards
  saved-searches    List saved searches
  cluster-health    Elasticsearch cluster health

Search options:
  --service, -s NAME   Filter by service name
  --query,   -q TEXT   Free-text search (Lucene syntax)
  --level,   -l LEVEL  Filter by level (ERROR, WARN, INFO, DEBUG, TRACE)
  --exclude-level LVL  Exclude a level (must_not — e.g. exclude INFO)
  --size,    -n NUM    Result count (default: 20, max: 500)
  --hours       NUM    Time window (default: 1, max: 168)
  --index,   -i PAT    Index pattern (default: order-tech-*)
  --source    FIELDS   Custom _source fields (comma-separated, overrides default)
  --agg     FIELD:SIZE Add a terms aggregation on FIELD (default size: 10, max: 100)

Errors options:
  --service, -s NAME   Filter by service name
  --hours       NUM    Time window (default: 1)
  --size,    -n NUM    Result count (default: 20)

Trace options:
  --id, -t ID          GlobalTrackingId (or positional arg)
  --hours       NUM    How far back to search (default: 24)

Identify options:
  ID                   UUID, tracking ID, or session ID (positional arg, required)
  --hours       NUM    How far back to search (default: 168 = 7 days)
  Runs up to 2 ELK queries: first tries structured GTI/threadContextId fields,
  then falls back to free-text search on message/SessionId fields.
  Returns JSON with id_type (GlobalTrackingId | SessionId_or_embedded | unknown)
  and extracted_gti if a GlobalTrackingId was found in the matching logs.
  Use when you have a UUID but don't know if it's a GTI or SessionId.

Top-errors options:
  --hours       NUM    Time window (default: 1)
  --top, -n NUM        How many results (default: 20)
  --service, -s NAME   Drill into one service (aggregates by error source/logger)
  --by          MODE   Grouping: config (default) | instance
                         config    → group by configLabel (combined across all DCs)
                         instance  → group by serviceName (per-DC breakdown)

Phase1-triage options:
  --service, -s NAME   Service slug (required). Uses wildcard: *<slug>*
  --hours       NUM    Time window (default: 1, max: 168)
  --index,   -i PAT    Index pattern (default: order-tech-*)
  One request returns: 5 sample errors + DC/configLabel/env/errorSource aggregations

First-occurrence options:
  --service, -s NAME   Service slug (optional). Uses multi-field match: serviceName, service_name, application, app
  --query,   -q TEXT   Text/pattern to search for (optional but recommended)
  --level,   -l LEVEL  Log level filter (default: ERROR)
  --hours       NUM    Time window (default: 168 = 7 days max)
  --index,   -i PAT    Index pattern (default: order-tech-*)
  Returns the single earliest log entry matching the criteria (sort asc, size 1).
  Use to anchor investigation timelines — correlate with deploy times and code changes.

Bpmn-context options:
  --service, -s NAME   Service slug (required). Uses wildcard: *<slug>*
  --hours       NUM    Time window (default: 1, max: 168)
  --size,    -n NUM    Sample count for extraction (default: 20, max: 50)
  --index,   -i PAT    Index pattern (default: order-tech-*)
  Extracts: businessKey, processDefinitionId, action, parentBusinessKey, orderId
  from nested JSON in the message field of ERROR log entries.
  Use for wkfl-* BPMN services to get process-level correlation IDs.

Bpmn-variables options:
  --service, -s NAME      Service slug (required). Uses wildcard: *<slug>*
  --business-key, -b KEY  Scope to a specific process instance by businessKey
  --order-id, -o ID       Alternative: scope by orderId (searches message body)
  --fields, -f LIST       Comma-separated variable names to extract
                          (default: purchasedOfferId,partnerGroup,entitlementProvider,action,
                           businessKey,orderId,parentBusinessKey,productFamily,processDefinitionId)
  --compare-control       Fetch FAIL (level=ERROR) + CONTROL (level!=ERROR) side-by-side
  --hours       NUM       Time window (default: 168, max: 168)
  --size,    -n NUM       Sample count per query (default: 3, max: 20)
  --index,   -i PAT       Index pattern (default: order-tech-*)
  Extracts arbitrary Flowable process variables from the nested message JSON.
  Uses 2-tier extraction: JSON parse (context/instanceVariables) → regex fallback.

Phase1-bpmn options:
  --service, -s NAME   Service slug (required). For wkfl-* BPMN services.
  --hours       NUM    Time window (default: 24, max: 168)
  --index,   -i PAT    Index pattern (default: order-tech-*)
  Runs 5 sequential queries in one command:
    1. Error count + DC/config/source distribution
    2. businessKey extraction (bpmn-context, 3 samples)
    3. Process variable comparison (bpmn-variables --compare-control)
    4. 7-day error trend (date histogram by day + DC)
    5. Structured summary block

Fields options:
  --index, -i PAT      Index pattern (default: order-tech-*)

Field-values options:
  --field, -f NAME     Field name (required, e.g. serviceName, level, datacenter)
  --index, -i PAT      Index pattern (default: order-tech-*)
  --top,   -n NUM      How many distinct values (default: 20)
  --hours       NUM    Time window to sample from (default: 1)

Raw options:
  --index, -i PAT      Index pattern (default: order-tech-*)
  --body,  -b JSON     Elasticsearch query JSON string
  --body-file, -f PATH Read query JSON from file (max 64KB)
  Sends raw ES JSON through the authenticated channel. Use for:
  - Custom aggregations not covered by named commands
  - Complex boolean queries with nested sub-aggs
  - Pipeline to jq/python for post-processing
  This is the ONLY approved way to run custom ES queries.
  Do NOT source elk-lib.sh directly in scripts.

Examples:
  $SCRIPT_NAME envs
  $SCRIPT_NAME status
  $SCRIPT_NAME fields
  $SCRIPT_NAME fields --index bis-prod-*
  $SCRIPT_NAME field-values --field serviceName --top 50
  $SCRIPT_NAME field-values --field level
  $SCRIPT_NAME field-values --field datacenter
  $SCRIPT_NAME field-values --field logType --index order-tech-*
  $SCRIPT_NAME search --service bo-account --hours 2 --size 50
  $SCRIPT_NAME search --service xoms-biller --query 'updateCMTs' --exclude-level INFO --hours 2
  $SCRIPT_NAME search --service xoms-biller --source '@timestamp,serviceName,level,status,message'
  $SCRIPT_NAME search --service ott-fulfillment --level ERROR --agg datacenter:6 --hours 4
  $SCRIPT_NAME errors --service subscriber --hours 4
  $SCRIPT_NAME first-occurrence --service lean-orchestrator --query "purchasedOfferId" --hours 168
  $SCRIPT_NAME trace abc-123-def-456
  $SCRIPT_NAME identify f94c490f-3d37-48f0-ae9b-cd79192228a7
  $SCRIPT_NAME top-errors --hours 2 --top 30
  $SCRIPT_NAME top-errors --service bo-account --hours 2
  $SCRIPT_NAME phase1-triage --service lean-orchestrator --hours 4
  $SCRIPT_NAME bpmn-context --service lean-orchestrator --hours 24
  $SCRIPT_NAME bpmn-variables --service ott-fulfillment --compare-control
  $SCRIPT_NAME bpmn-variables --service ott-fulfillment --business-key "abc-123:def-456:ADD"
  $SCRIPT_NAME bpmn-variables --service ott-fulfillment --fields "purchasedOfferId,partnerGroup"
  $SCRIPT_NAME phase1-bpmn --service ott-fulfillment --hours 48
  $SCRIPT_NAME raw --body '{"size":0,"query":{"bool":{"filter":[{"range":{"@timestamp":{"gte":"now-1h"}}}]}},"aggs":{"by_svc":{"terms":{"field":"serviceName.keyword","size":20}}}}'
  $SCRIPT_NAME raw --body-file /tmp/custom-query.json | jq '.rawResponse.aggregations'
  $SCRIPT_NAME --env stage search --service bo-account

  # Lower environment:
  ELK_ENV=stage $SCRIPT_NAME search --query "timeout" --hours 1
EOF
  exit 0
}

# ── Main ─────────────────────────────────────────────────────────────────────
[[ $# -eq 0 ]] && usage

COMMAND="$1"; shift

case "$COMMAND" in
  envs)            cmd_envs ;;
  status)          cmd_status ;;
  indices)         cmd_indices ;;
  fields)          cmd_fields "$@" ;;
  field-values)    cmd_field_values "$@" ;;
  search)          cmd_search "$@" ;;
  errors)          cmd_errors "$@" ;;
  first-occurrence) cmd_first_occurrence "$@" ;;
  tail)            cmd_tail "$@" ;;
  trace)           cmd_trace "$@" ;;
  identify)        cmd_identify "$@" ;;
  top-errors)      cmd_top_errors "$@" ;;
  phase1-triage)   cmd_phase1_triage "$@" ;;
  bpmn-context)    cmd_bpmn_context "$@" ;;
  bpmn-variables)  cmd_bpmn_variables "$@" ;;
  phase1-bpmn)     cmd_phase1_bpmn "$@" ;;
  raw)             cmd_raw "$@" ;;
  dashboards)      cmd_dashboards ;;
  saved-searches)  cmd_saved_searches ;;
  cluster-health)  cmd_cluster_health ;;
  help|--help|-h)  usage ;;
  *)               elk_die "Unknown command: $COMMAND. Run '$SCRIPT_NAME help'." ;;
esac
