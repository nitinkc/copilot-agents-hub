#!/usr/bin/env python3
"""
elk-sso-login.py — Automated SSO cookie refresh for OrderTech ELK

Uses Playwright (headless Chromium) with persistent browser state so
Azure AD SSO only needs to be completed once interactively. Subsequent
runs reuse the saved session and refresh the cookie headlessly.

Flow:
  1. First run: opens visible Chromium → user completes Azure AD SSO/MFA
  2. Playwright saves session to ~/.ordertech-elk/browser-state/<env>/
  3. Later runs: headless → Azure AD auto-renews → no interaction needed
  4. If session expires, falls back to visible browser automatically

Prerequisites:
    pip3 install playwright
    python3 -m playwright install chromium

Usage:
    python3 elk-sso-login.py                  # prod (default)
    python3 elk-sso-login.py --env lower      # lower environment
    python3 elk-sso-login.py --env prod lower # both at once
    python3 elk-sso-login.py --headed         # force visible browser
    python3 elk-sso-login.py --install        # install dependencies
"""

import argparse
import io
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

# ── Force UTF-8 output on Windows (cp1252 cannot encode box-drawing chars) ──
if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

# ── Constants ────────────────────────────────────────────────────────────────
CONFIG_DIR = Path.home() / ".ordertech-elk"
BROWSER_STATE_DIR = CONFIG_DIR / "browser-state"
COOKIE_DIR = CONFIG_DIR / "cookies"
ENV_FILE = CONFIG_DIR / "environments.yaml"

COOKIE_NAME = "ccssession"
NAV_TIMEOUT_MS = 90_000          # 90s for initial page load (VPN + SSO redirects)
SSO_WAIT_TIMEOUT_MS = 300_000    # 5 min for user to complete MFA
POST_LOGIN_SETTLE_S = 3          # seconds to wait after redirect
VERIFY_TIMEOUT_S = 15            # timeout for cookie verification request

# Platform-appropriate User-Agent — Azure AD Conditional Access uses this
# to determine device platform. A mismatch (e.g., macOS UA on Windows)
# causes error 53003 because no registered device matches the claimed platform.
if sys.platform == "win32":
    USER_AGENT = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36 Edg/125.0.0.0"
    )
elif sys.platform == "linux":
    USER_AGENT = (
        "Mozilla/5.0 (X11; Linux x86_64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
    )
else:
    USER_AGENT = (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Safari/605.1.15"
    )


# ── Minimal YAML reader (matches elk-lib.sh _yaml_read) ─────────────────────
def yaml_read_env(filepath, env_name):
    """Read url and cookie path for an env from our simple YAML config."""
    result = {}
    in_section = False
    with open(filepath) as f:
        for line in f:
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            # Top-level key
            if not line[0].isspace() and ":" in line:
                key = line.split(":")[0].strip()
                if key == env_name:
                    in_section = True
                elif in_section:
                    break  # past our section
                else:
                    in_section = False
                continue
            if in_section:
                if ":" in stripped:
                    k, v = stripped.split(":", 1)
                    k = k.strip()
                    v = v.strip().split("#")[0].strip()  # strip inline comments
                    result[k] = v
    return result


def load_env_config(env_name):
    """Load environment config from environments.yaml."""
    if not ENV_FILE.exists():
        print(f"ERROR: Config not found: {ENV_FILE}")
        print("Run: elk-setup.sh  (creates default config)")
        sys.exit(1)

    cfg = yaml_read_env(str(ENV_FILE), env_name)
    if not cfg.get("url"):
        # List available envs
        available = []
        with open(ENV_FILE) as f:
            for line in f:
                if not line[0:1].isspace() and ":" in line and not line.strip().startswith("#"):
                    available.append(line.split(":")[0].strip())
        print(f"ERROR: Environment '{env_name}' not found in {ENV_FILE}")
        print(f"Available: {', '.join(available)}")
        sys.exit(1)

    cookie_path = cfg.get("cookie", f"~/.ordertech-elk/cookies/{env_name}.cookie")
    cookie_path = Path(cookie_path.replace("~", str(Path.home())))

    return {
        "name": cfg.get("name", env_name),
        "url": cfg["url"],
        "cookie_path": cookie_path,
    }


# ── Install ──────────────────────────────────────────────────────────────────
def install_deps():
    """Install Playwright and Chromium."""
    print("Installing playwright...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "playwright"])
    print("\nInstalling Chromium browser...")
    subprocess.check_call([sys.executable, "-m", "playwright", "install", "chromium"])
    print("\nDone! You can now run:")
    print("  python3 elk-sso-login.py")
    print("  python3 elk-sso-login.py --env lower")


# ── Cookie verification ─────────────────────────────────────────────────────
def verify_cookie(env_name):
    """Verify a saved cookie actually works by making a test API call.
    Returns True if the cookie is valid, False otherwise."""
    env = load_env_config(env_name)
    cookie_path = env["cookie_path"]
    if not cookie_path.exists():
        print(f"  ✗ Cookie file missing: {cookie_path}")
        return False

    cookie_val = cookie_path.read_text().strip()
    if not cookie_val:
        print(f"  ✗ Cookie file empty: {cookie_path}")
        return False

    url = env["url"]
    # Use Kibana status endpoint — lightweight, no index needed
    test_url = f"{url}/api/status"

    try:
        result = subprocess.run(
            [
                "curl", "-sS", "--max-time", str(VERIFY_TIMEOUT_S),
                "-o", "/dev/null", "-w", "%{http_code}",
                "-b", f"ccssession={cookie_val}",
                "-H", "kbn-xsrf: true",
                "-H", f"Referer: {url}/",
                "-A", USER_AGENT,
                test_url,
            ],
            capture_output=True, text=True, timeout=VERIFY_TIMEOUT_S + 5,
        )
        http_code = result.stdout.strip()
        if http_code.startswith("2"):
            print(f"  ✓ Cookie verified (HTTP {http_code})")
            return True
        else:
            print(f"  ✗ Cookie rejected (HTTP {http_code})")
            return False
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as exc:
        print(f"  ✗ Verification failed: {exc}")
        return False


# ── SSO Login ────────────────────────────────────────────────────────────────

_RETRY_HEADED = object()  # sentinel: caller should retry with headed=True
_RETRY_CDP = object()     # sentinel: caller should try CDP fallback

_CDP_PORT_RANGE = (9222, 9232)  # range to scan for an available debugging port


def _find_available_port():
    """Find an available TCP port in the CDP range. Returns port or None."""
    import socket
    for port in range(_CDP_PORT_RANGE[0], _CDP_PORT_RANGE[1]):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    return None


def _find_browser_exe():
    """Find Edge or Chrome executable on the current platform."""
    if sys.platform == "win32":
        candidates = [
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        ]
    elif sys.platform == "darwin":
        candidates = [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
            os.path.expanduser("~/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
            os.path.expanduser("~/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"),
            "/Applications/Chromium.app/Contents/MacOS/Chromium",
        ]
    else:  # Linux
        candidates = [
            "/usr/bin/microsoft-edge",
            "/usr/bin/google-chrome",
            "/usr/bin/google-chrome-stable",
            "/usr/bin/chromium-browser",
            "/usr/bin/chromium",
        ]
    for path in candidates:
        if os.path.exists(path):
            return path
    # Fallback: search PATH
    for name in ("msedge", "microsoft-edge", "google-chrome", "chromium"):
        found = shutil.which(name)
        if found:
            return found
    return None


def _attempt_login_cdp(env_name):
    """
    Launch Edge/Chrome WITHOUT Playwright automation flags so Azure AD SSO works.
    After the user logs in, connect via CDP (read-only) to extract the ccssession cookie.

    This bypasses Playwright-injected flags (--use-mock-keychain, --disable-sync,
    --password-store=basic) that prevent credential access and cause Azure AD errors.
    Works on Windows, macOS, and Linux.
    """
    import urllib.request
    import urllib.error
    from playwright.sync_api import sync_playwright

    env = load_env_config(env_name)
    # Dedicated CDP profile dir — separate from Playwright state dir
    state_dir = BROWSER_STATE_DIR / (env_name + "-cdp")
    state_dir.mkdir(parents=True, exist_ok=True)
    COOKIE_DIR.mkdir(parents=True, exist_ok=True)

    kibana_url = env["url"] + "/app/discover"
    cookie_path = Path(env["cookie_path"])

    browser_exe = _find_browser_exe()
    if not browser_exe:
        print("ERROR: No Edge or Chrome found for CDP fallback.")
        return False

    cdp_port = _find_available_port()
    if not cdp_port:
        print(f"ERROR: No available port in range {_CDP_PORT_RANGE[0]}-{_CDP_PORT_RANGE[1]}")
        return False

    # Clean stale lock files from prior crashed instances
    for lock_file in ("SingletonLock", "SingletonSocket", "SingletonCookie"):
        lf = state_dir / lock_file
        if lf.exists() or lf.is_symlink():
            lf.unlink(missing_ok=True)

    browser_name = os.path.basename(browser_exe).split(".")[0]
    print(f"\nLaunching {browser_name} (no automation flags) for SSO...")
    print(f"CDP port: {cdp_port}")
    print(f"URL: {kibana_url}\n")
    sys.stdout.flush()

    # Launch browser with ONLY remote-debugging flags — no Playwright automation flags
    proc = subprocess.Popen(
        [
            browser_exe,
            f"--remote-debugging-port={cdp_port}",
            f"--user-data-dir={str(state_dir)}",
            "--no-first-run",
            "--no-default-browser-check",
            kibana_url,
        ],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    # Wait for CDP endpoint (up to 30s)
    cdp_url = f"http://127.0.0.1:{cdp_port}/json/version"
    ready = False
    for _ in range(30):
        try:
            urllib.request.urlopen(cdp_url, timeout=2)
            ready = True
            break
        except (urllib.error.URLError, OSError):
            time.sleep(1)

    if not ready:
        print(f"ERROR: CDP endpoint not ready on port {cdp_port}")
        proc.terminate()
        return False

    print(f"{browser_name} is open. Complete the Azure AD SSO login in the browser.")
    print("Press ENTER here once you see the Kibana dashboard...")
    sys.stdout.flush()
    try:
        input()
    except EOFError:
        # Non-interactive terminal — poll for cookie appearance, max 180s (bounded)
        print("(Non-interactive terminal — polling for cookie, max 180s...)")
        sys.stdout.flush()
        from playwright.sync_api import sync_playwright as _sp
        poll_deadline = time.time() + 180
        while time.time() < poll_deadline:
            time.sleep(5)
            try:
                with _sp() as p:
                    br = p.chromium.connect_over_cdp(f"http://127.0.0.1:{cdp_port}")
                    for ctx in br.contexts:
                        for ck in ctx.cookies():
                            if ck["name"] == COOKIE_NAME:
                                # Cookie found — proceed to extraction below
                                break
                        else:
                            continue
                        break
            except Exception:
                continue

    # Extract cookie via CDP — retry up to 3 times with 3s gap
    cookie_value = None
    for attempt in range(3):
        try:
            with sync_playwright() as p:
                browser = p.chromium.connect_over_cdp(f"http://127.0.0.1:{cdp_port}")
                for ctx in browser.contexts:
                    for cookie in ctx.cookies():
                        if cookie["name"] == COOKIE_NAME:
                            cookie_value = cookie["value"]
                            break
                    if cookie_value:
                        break
        except Exception as exc:
            if attempt < 2:
                time.sleep(3)
                continue
            print(f"CDP connect error after {attempt + 1} attempts: {exc}")
        if cookie_value:
            break

    # Terminate the browser we launched
    proc.terminate()
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=5)

    if not cookie_value:
        print(f"ERROR: Cookie '{COOKIE_NAME}' not found via CDP.")
        print("Ensure you completed SSO and can see the Kibana dashboard.")
        return False

    cookie_path.parent.mkdir(parents=True, exist_ok=True)
    cookie_path.write_text(cookie_value)
    try:
        cookie_path.chmod(0o600)
    except OSError:
        pass  # chmod not supported on all Windows configs

    print(f"\n\u2713 Cookie saved ({len(cookie_value)} chars) -> {cookie_path}")
    print("  Verifying cookie ...")
    verify_cookie(env_name)
    return True


def _print_manual_cookie_instructions(env_name, env):
    """Print instructions for manual cookie paste when browser can't launch."""
    url = env["url"]
    cookie_path = env["cookie_path"]
    print(f"\n{'─' * 60}")
    print("  Browser cannot launch in this terminal.")
    print("  Paste the cookie manually instead:")
    print(f"{'─' * 60}")
    print(f"\n  1. Open a regular terminal (not VS Code) and run:")
    print(f"     python3 {Path(__file__).resolve()} --env {env_name} --headed")
    print(f"\n  OR paste the cookie directly:")
    print(f"  1. Open {url}/app/discover in your browser")
    print(f"  2. Log in through Azure AD SSO")
    print(f"  3. DevTools (F12) → Application → Cookies → copy '{COOKIE_NAME}' value")
    print(f"  4. Run: echo '<value>' > {cookie_path}")
    print()


def _attempt_login(env_name, force_headed=False):
    """
    Single login attempt. Returns True on success, or _RETRY_HEADED
    if the caller should retry with a visible browser.
    """
    from playwright.sync_api import sync_playwright

    env = load_env_config(env_name)
    state_dir = BROWSER_STATE_DIR / env_name
    state_dir.mkdir(parents=True, exist_ok=True)
    COOKIE_DIR.mkdir(parents=True, exist_ok=True)

    # Clean stale Chromium lock files left by crashed browser processes.
    # A stale SingletonLock causes TargetClosedError on next launch.
    for lock_file in ("SingletonLock", "SingletonSocket", "SingletonCookie"):
        lf = state_dir / lock_file
        if lf.exists() or lf.is_symlink():
            lf.unlink(missing_ok=True)

    kibana_url = env["url"] + "/app/discover"
    cookie_path = env["cookie_path"]

    # Decide headless vs headed
    has_saved_state = state_dir.exists() and any(state_dir.iterdir())
    use_headless = has_saved_state and not force_headed

    mode_str = "headless (saved session)" if use_headless else "interactive"
    print(f"\n{'─' * 60}")
    print(f"  Environment:  {env['name']} ({env_name})")
    print(f"  URL:          {env['url']}")
    print(f"  Mode:         {mode_str}")
    print(f"{'─' * 60}\n")

    with sync_playwright() as p:
        launch_args = ["--no-sandbox", "--disable-gpu"]
        # On Windows, use system Edge so Azure AD Conditional Access can verify
        # device compliance via WAM/PRT (prevents error 53003 "device unregistered").
        # Strip Playwright automation flags that block Windows credential access:
        #   --disable-sync        -> prevents account sign-in
        #   --use-mock-keychain   -> blocks system credential store (macOS/Linux)
        #   --password-store=basic -> bypasses Windows Credential Manager
        if sys.platform == "win32":
            use_channel = "msedge"
            ignore_args = ["--disable-sync", "--use-mock-keychain", "--password-store=basic"]
        else:
            use_channel = None
            ignore_args = []
        try:
            browser = p.chromium.launch_persistent_context(
                user_data_dir=str(state_dir),
                headless=use_headless,
                channel=use_channel,
                user_agent=USER_AGENT,
                args=launch_args,
                ignore_default_args=ignore_args,
                accept_downloads=False,
                ignore_https_errors=True,
            )
        except Exception as exc:
            # Browser binary can't launch — common in non-GUI terminals (VS Code, SSH)
            exc_name = type(exc).__name__
            if "TargetClosed" in exc_name or "BrowserClosed" in exc_name or "crash" in str(exc).lower():
                if use_headless:
                    print(f"Headless browser failed to launch: {exc_name}")
                    return _RETRY_HEADED
                # Headed mode also failed — try CDP fallback
                return _RETRY_CDP
            raise

        page = browser.pages[0] if browser.pages else browser.new_page()

        try:
            print(f"Opening {kibana_url} ...")
            # Use 'commit' — returns as soon as the server responds (before full load).
            # SSO redirect chains can hang on 'domcontentloaded' or 'networkidle'.
            page.goto(kibana_url, wait_until="commit", timeout=NAV_TIMEOUT_MS)
            # Let the SSO redirect chain settle
            page.wait_for_load_state("domcontentloaded", timeout=NAV_TIMEOUT_MS)
            page.wait_for_timeout(3000)

            current_url = page.url

            # Check if redirected to Azure AD login
            if "login.microsoftonline.com" in current_url or "login.live.com" in current_url:
                if use_headless:
                    print("Azure AD session expired — switching to interactive browser ...")
                    browser.close()
                    return _RETRY_HEADED

                print("\n  ┌─────────────────────────────────────────────┐")
                print("  │  Complete SSO login in the browser window.  │")
                print("  │  This window will close automatically.      │")
                print("  └─────────────────────────────────────────────┘\n")

                # Wait for redirect back to Kibana after SSO + MFA
                page.wait_for_url(
                    f"**{env['url']}/**",
                    timeout=SSO_WAIT_TIMEOUT_MS,
                )
                print("SSO completed!")

            # Let cookies settle
            time.sleep(POST_LOGIN_SETTLE_S)

            # Extract ccssession cookie
            cookies = browser.cookies(env["url"])
            cc = next((c for c in cookies if c["name"] == COOKIE_NAME), None)

            if not cc:
                avail = [c["name"] for c in cookies]
                print(f"ERROR: '{COOKIE_NAME}' cookie not found.")
                print(f"Cookies present: {avail}")
                browser.close()
                sys.exit(1)

            # Save
            cookie_path.parent.mkdir(parents=True, exist_ok=True)
            cookie_path.write_text(cc["value"])
            try:
                cookie_path.chmod(0o600)
            except OSError:
                pass  # chmod not supported on Windows — file is still saved

            # Persist the User-Agent alongside the cookie so queries use the same UA
            ua_path = cookie_path.with_suffix(".cookie.ua")
            ua_path.write_text(USER_AGENT)
            try:
                ua_path.chmod(0o600)
            except OSError:
                pass

            expiry_str = ""
            if cc.get("expires", 0) > 0:
                exp_local = time.strftime(
                    "%Y-%m-%d %H:%M:%S", time.localtime(cc["expires"])
                )
                expiry_str = f"  (expires {exp_local})"

            print(f"\n✓ Cookie saved: {cookie_path}{expiry_str}")
            print(f"  {len(cc['value'])} chars")

            # Verify the cookie actually works
            print("  Verifying cookie ...")
            if verify_cookie(env_name):
                return True
            else:
                print("  Cookie saved but verification failed.")
                if use_headless:
                    browser.close()
                    return _RETRY_HEADED
                return False

        except Exception as exc:
            print(f"ERROR: {exc}")
            try:
                browser.close()
            except Exception:
                pass
            if use_headless:
                print("Retrying with visible browser ...")
                return _RETRY_HEADED
            # Headed mode failed with a non-crash error — try CDP
            return _RETRY_CDP

        finally:
            try:
                browser.close()
            except Exception:
                pass


def _nuke_browser_state(env_name):
    """Delete corrupted browser state directories and recreate empty.
    Clears both Playwright and CDP profile dirs.
    Returns True if state was cleared, False if nothing to clear."""
    cleared = False
    for suffix in ("", "-cdp"):
        state_dir = BROWSER_STATE_DIR / (env_name + suffix)
        if state_dir.exists() and any(state_dir.iterdir()):
            size_mb = sum(f.stat().st_size for f in state_dir.rglob('*') if f.is_file()) / (1024 * 1024)
            print(f"\nBrowser state corrupted ({size_mb:.0f} MB). Clearing {state_dir} ...")

            def _ignore_locked(func, path, exc_info):
                """Skip files locked by another process (Windows WinError 32)."""
                err = exc_info[1]
                if isinstance(err, PermissionError) and getattr(err, 'winerror', None) == 32:
                    pass  # file in use by another process — leave it
                else:
                    print(f"  Warning: could not remove {path}: {err}")

            shutil.rmtree(state_dir, onerror=_ignore_locked)
            state_dir.mkdir(parents=True, exist_ok=True)
            cleared = True
    if cleared:
        print("Browser state cleared — retrying with clean profile ...\n")
    return cleared


def do_login(env_name, force_headed=False):
    """
    Perform SSO login with automatic fallback chain.
    Retries happen OUTSIDE the Playwright context to avoid nested event loops.

    Recovery chain (all platforms):
      1. Playwright headless (if saved session exists)
      2. Playwright headed (with ignore_default_args on Windows)
      3. If headed fails → CDP fallback (real browser, no automation flags)
      4. If CDP fails → nuke corrupted state → Playwright headed one more time
      5. If still fails → print manual instructions and exit

    On Windows with --headed: CDP is tried first (proven to bypass Azure AD
    device compliance issues), then Playwright as fallback.
    """
    try:
        from playwright.sync_api import sync_playwright  # noqa: F401
    except ImportError:
        print("ERROR: playwright not installed.")
        print("Run:  python3 elk-sso-login.py --install")
        sys.exit(1)

    # Windows + explicit headed: try CDP first (proven fix for Azure AD 53003)
    if force_headed and sys.platform == "win32":
        if _attempt_login_cdp(env_name):
            return True
        print("CDP approach failed — falling back to Playwright...\n")

    # Step 1: Try with current settings (headless if state exists)
    result = _attempt_login(env_name, force_headed=force_headed)

    # Step 2: Headless failed → try headed
    if result is _RETRY_HEADED:
        result = _attempt_login(env_name, force_headed=True)

    # Step 3: Playwright headed failed → try CDP fallback (any platform)
    if result is _RETRY_CDP:
        print("Playwright headed failed — trying CDP fallback...")
        if _attempt_login_cdp(env_name):
            return True
        result = False  # CDP also failed, continue to nuke

    # Step 4: Nuke corrupted state → Playwright headed one more time
    if result is _RETRY_HEADED or result is _RETRY_CDP or result is False:
        if _nuke_browser_state(env_name):
            result = _attempt_login(env_name, force_headed=True)

    # Step 5: All retries exhausted
    if result is _RETRY_HEADED or result is _RETRY_CDP or result is False:
        env = load_env_config(env_name)
        _print_manual_cookie_instructions(env_name, env)
        print(f"ERROR: All login attempts failed for '{env_name}'.")
        print("Try from a regular terminal (not VS Code):")
        print(f"  python3 {Path(__file__).resolve()} --env {env_name} --headed")
        sys.exit(1)

    return result


# ── Main ─────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description="OrderTech ELK — SSO cookie refresh",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s                   # refresh prod cookie
  %(prog)s --env lower       # refresh lower env cookie
  %(prog)s --env prod lower  # refresh both
  %(prog)s --headed          # force visible browser
  %(prog)s --install         # install playwright + chromium
        """,
    )
    parser.add_argument(
        "--env", nargs="+", default=["prod"],
        help="Environment(s) to refresh (default: prod)",
    )
    parser.add_argument(
        "--headed", action="store_true",
        help="Force visible browser even if saved session exists",
    )
    parser.add_argument(
        "--install", action="store_true",
        help="Install Playwright and Chromium, then exit",
    )
    parser.add_argument(
        "--verify", action="store_true",
        help="Verify saved cookie(s) work without re-logging in",
    )

    args = parser.parse_args()

    if args.install:
        install_deps()
        return

    if args.verify:
        all_ok = True
        for env in args.env:
            cfg = load_env_config(env)
            print(f"  {cfg['name']} ({env}):")
            if not verify_cookie(env):
                all_ok = False
        sys.exit(0 if all_ok else 1)

    for env in args.env:
        do_login(env, force_headed=args.headed)

    if len(args.env) > 1:
        print(f"\n✓ All {len(args.env)} environments refreshed.")


if __name__ == "__main__":
    main()
