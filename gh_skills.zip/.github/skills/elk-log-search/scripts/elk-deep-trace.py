#!/usr/bin/env python3
"""
elk-deep-trace.py — Cross-service deep trace and root cause analysis tool.

Two layers:
  WHAT happened (trace layer):
    error-origin      Find which service generates vs relays an error
    single-trace      Trace one threadContextId across all services
    order-trace       Trace one globalTrackingId across all services
    retry-detect      Detect retry loops for a globalTrackingId
    test-in-prod      Check if a test/hardcoded value appears in prod
    call-topo         Map callers and targets for an API path

  WHY it happened (root cause layer):
    compare           Compare a successful vs failed request to the same endpoint
    onset             Find when an error first appeared and what deployed around it
    input-diff        Extract and diff input values from failures vs successes
    permanence        Determine if repeated failures are permanent or transient
    data-lineage      Trace an entity backward to find where bad data originated
    deploy-correlate  Correlate error rate changes with deployments (configLabel)

  Combined:
    full-investigate  Chain: origin → trace → compare → permanence → onset

Algorithms from INVESTIGATION-BRAIN.md § 13-15.
Requires: ~/.ordertech-elk/cookies/{env}.cookie (from elk-sso-login.py)
"""

import subprocess
import json
import os
import sys
import re
import argparse
from collections import defaultdict


# ── ELK query engine ─────────────────────────────────────────────────────────

def elk_query(query_body, index="order-tech-*", env="prod", timeout=45):
    """Execute an ELK query and return the parsed response."""
    cookie_paths = [
        os.path.expanduser(f"~/.ordertech-elk/cookies/{env}.cookie"),
        os.path.expanduser(f"~/.elk/cookie-{env}.txt"),
    ]
    cookie = None
    for p in cookie_paths:
        if os.path.exists(p):
            cookie = open(p).read().strip()
            break
    if not cookie:
        die(f"No cookie found. Run: elk-sso-login.py --env {env}")

    urls = {
        "prod": "https://ot-logs-prod.sys.comcast.net",
        "lower": "https://ot-logs-lower.sys.comcast.net",
    }
    base = urls.get(env, urls["prod"])
    ua = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
          "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15")

    payload = json.dumps({"params": {"index": index, "body": query_body}})
    result = subprocess.run(
        ["curl", "-s", "--max-time", str(timeout),
         base + "/internal/search/es",
         "-H", "Content-Type: application/json",
         "-H", "Accept: application/json",
         "-H", "kbn-xsrf: true",
         "-H", f"Referer: {base}/",
         "-A", ua,
         "-b", f"ccssession={cookie}",
         "-d", payload],
        capture_output=True, text=True,
        encoding="utf-8", errors="replace"
    )

    if not result.stdout.strip():
        die("Empty response from ELK. Cookie may be expired. "
            f"Run: elk-sso-login.py --env {env}")

    try:
        raw = json.loads(result.stdout)
    except json.JSONDecodeError:
        if "302" in result.stdout or "<html>" in result.stdout.lower():
            die(f"Got HTTP redirect (cookie expired). Run: elk-sso-login.py --env {env}")
        die(f"Invalid JSON response: {result.stdout[:200]}")

    return raw.get("rawResponse", raw)


def get_total(data):
    """Extract total hit count from ES response."""
    total = data.get("hits", {}).get("total", 0)
    return total.get("value", 0) if isinstance(total, dict) else total


def parse_inner(msg):
    """Parse nested JSON from the message field."""
    try:
        return json.loads(msg)
    except (json.JSONDecodeError, TypeError):
        return {"_raw": str(msg)[:300]}


def extract_fields(hit_source):
    """Extract commonly used fields from a hit's _source.
    
    Fields exist at TWO levels in order-tech-* documents:
    - Top-level _source fields: uri, method, statusCode, duration, configLabel,
      serviceName, logType, level, threadContextId
    - Nested inside _source.message (JSON string): context.url, context.status,
      context.request.header.*, LogEventMessage, stack_trace, body, exception
    
    This function merges both levels, preferring top-level for structured fields.
    """
    s = hit_source
    inner = parse_inner(s.get("message", ""))
    ctx = inner.get("context", {}) if isinstance(inner.get("context"), dict) else {}

    # URI: top-level field for API_REQUEST/API_RESPONSE, fallback to inner
    uri = s.get("uri", "") or inner.get("uri", "")

    # Status: top-level 'statusCode', inner 'context.status', or inner 'status'
    status = (s.get("statusCode", "") or ctx.get("status", "")
              or inner.get("statusCode", ""))

    # Duration: top-level or inner
    duration = s.get("duration", "") or inner.get("duration", "")

    # configLabel: top-level or inner context
    config_label = (s.get("configLabel", "") or ctx.get("configLabel", "")
                    or inner.get("configLabel", ""))

    # Method: top-level or inner
    method = s.get("method", "") or inner.get("method", "")

    # threadContextId: top-level or inner
    tcid = s.get("threadContextId", "") or inner.get("threadContextId", "")

    # globalTrackingId: inner context header (two spellings)
    gtid = (ctx.get("request.header.globaltrackingid", "")
            or ctx.get("request.header.globalTrackingId", ""))

    return {
        "inner": inner,
        "ctx": ctx,
        "logType": s.get("logType", "") or inner.get("logType", "?"),
        "level": s.get("level", "") or inner.get("level", "?"),
        "service": inner.get("service", s.get("serviceName", "?")),
        "svc_short": (inner.get("service", s.get("serviceName", "?"))
                      .split("-production")[0]),
        "url": ctx.get("url", ""),
        "status": str(status),
        "uri": uri,
        "duration": str(duration),
        "method": method,
        "body": str(inner.get("body", ""))[:250],
        "msg": (inner.get("LogEventMessage", inner.get("message", "")) or "")[:200],
        "stack_trace": inner.get("stack_trace", ""),
        "exception": inner.get("exception", ""),
        "feign_origin": ctx.get("request.header.x-feign-origin", ""),
        "tcid": tcid,
        "gtid": gtid,
        "configLabel": config_label,
        "timestamp": s.get("@timestamp", ""),
    }


def die(msg):
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(1)


# ═══════════════════════════════════════════════════════════════════════════════
# TRACE LAYER — WHAT happened
# ═══════════════════════════════════════════════════════════════════════════════


# ── Algorithm A: Error Origin Detection ──────────────────────────────────────

def error_origin(error_text, hours=1):
    """Find which service GENERATES vs RELAYS an error."""
    print(f"{'='*70}")
    print(f"ERROR ORIGIN: \"{error_text}\" (last {hours}h)")
    print(f"{'='*70}")

    d = elk_query({
        "size": 0,
        "query": {"bool": {"must": [
            {"range": {"@timestamp": {"gte": f"now-{hours}h"}}},
            {"query_string": {"query": f"\"{error_text}\"", "fields": ["message"]}}
        ]}},
        "aggs": {
            "by_service": {
                "terms": {"field": "serviceName.keyword", "size": 30},
                "aggs": {
                    "by_logtype": {"terms": {"field": "logType.keyword", "size": 10}},
                    "by_level": {"terms": {"field": "level.keyword", "size": 5}}
                }
            },
            "by_dc": {"terms": {"field": "datacenter.keyword", "size": 10}},
            "by_level": {"terms": {"field": "level.keyword", "size": 5}}
        }
    })

    total = get_total(d)
    print(f"\nTotal hits: {total}")

    origins = []
    relays = []
    for b in d["aggregations"]["by_service"]["buckets"]:
        svc = b["key"]
        count = b["doc_count"]
        lt_map = {x["key"]: x["doc_count"] for x in b["by_logtype"]["buckets"]}

        if lt_map.get("API_RESPONSE", 0) > 0:
            origins.append((svc, count, lt_map))
        else:
            relays.append((svc, count, lt_map))

    print(f"\n--- ORIGINS (generate API_RESPONSE with this error) ---")
    for svc, count, lt_map in sorted(origins, key=lambda x: -x[1]):
        lt_str = ", ".join(f"{k}={v}" for k, v in sorted(lt_map.items(), key=lambda x: -x[1]))
        print(f"  {svc}: {count}  [{lt_str}]")

    print(f"\n--- RELAYS (receive via FEIGN_RESPONSE, don't originate) ---")
    for svc, count, lt_map in sorted(relays, key=lambda x: -x[1]):
        lt_str = ", ".join(f"{k}={v}" for k, v in sorted(lt_map.items(), key=lambda x: -x[1]))
        print(f"  {svc}: {count}  [{lt_str}]")

    print(f"\n--- Datacenter distribution ---")
    for b in d["aggregations"]["by_dc"]["buckets"]:
        print(f"  {b['key']}: {b['doc_count']}")

    return {"total": total, "origins": origins, "relays": relays}


# ── Algorithm B: Single Transaction Trace ────────────────────────────────────

def single_trace(thread_ctx_id, hours=1):
    """Trace ALL logs for one threadContextId across all services."""
    print(f"{'='*70}")
    print(f"SINGLE TRACE: threadContextId={thread_ctx_id}")
    print(f"{'='*70}")

    d = elk_query({
        "size": 50,
        "query": {"bool": {"must": [
            {"range": {"@timestamp": {"gte": f"now-{hours}h"}}},
            {"term": {"threadContextId.keyword": thread_ctx_id}}
        ]}},
        "sort": [{"@timestamp": "asc"}]
    })

    total = get_total(d)
    print(f"Total logs: {total}")

    prev_svc = ""
    for i, h in enumerate(d["hits"]["hits"]):
        f = extract_fields(h["_source"])

        if f["service"] != prev_svc:
            print(f"\n  --- {f['svc_short']} ---")
            prev_svc = f["service"]

        marker = {"FEIGN_REQUEST": " >>>", "FEIGN_RESPONSE": " <<<",
                   "DOWNSTREAM_REQUEST": " >>>", "DOWNSTREAM_RESPONSE": " <<<",
                   "API_REQUEST": " IN>", "API_RESPONSE": " <OUT"}.get(f["logType"], "")

        print(f"  [{i+1:2d}]{marker} {f['logType']:24s} {f['level']:5s}")
        if f["uri"]: print(f"       uri: {f['uri']}")
        if f["url"]: print(f"       url: {f['url']}")
        if f["status"]: print(f"       status: {f['status']}")
        if f["duration"]: print(f"       duration: {f['duration']}ms")
        if f["feign_origin"]: print(f"       X-Feign-Origin: {f['feign_origin']}")
        if f["body"] and f["body"] not in ("None", "{}", ""):
            print(f"       body: {f['body']}")
        if f["stack_trace"]:
            for line in f["stack_trace"].split("\n")[:5]:
                print(f"       | {line}")
        elif f["exception"]:
            print(f"       exception: {str(f['exception'])[:200]}")
        elif f["msg"] and not any(x in str(f["msg"]) for x in
                                  ["BEGIN request", "END request", "Outbound Feign"]):
            print(f"       msg: {f['msg']}")

    return d


# ── Algorithm C: Order Trace (globalTrackingId) ─────────────────────────────

def order_trace(gtid, hours=2):
    """Trace an order across ALL services via globalTrackingId."""
    print(f"{'='*70}")
    print(f"ORDER TRACE: globalTrackingId={gtid}")
    print(f"{'='*70}")

    d = elk_query({
        "size": 100,
        "query": {"bool": {"must": [
            {"range": {"@timestamp": {"gte": f"now-{hours}h"}}},
            {"query_string": {"query": f"\"{gtid}\"", "fields": ["message"]}}
        ]}},
        "sort": [{"@timestamp": "asc"}],
        "_source": ["@timestamp", "serviceName", "logType", "level",
                     "message", "threadContextId"]
    })

    total = get_total(d)
    print(f"Total logs: {total}")

    svc_counts = {}
    prev_svc = ""
    for i, h in enumerate(d["hits"]["hits"]):
        f = extract_fields(h["_source"])
        svc_counts[f["svc_short"]] = svc_counts.get(f["svc_short"], 0) + 1

        if f["service"] != prev_svc:
            print(f"\n  --- {f['svc_short']} ---")
            prev_svc = f["service"]

        extra = ""
        if f["url"]: extra = f" url={f['url'][:80]}"
        if f["status"]: extra += f" [{f['status']}]"

        marker = ""
        if f["level"] == "ERROR": marker = " !!!"
        elif f["level"] == "WARN": marker = " ?"

        tcid = f["tcid"][:12]
        print(f"  [{i+1:2d}] {f['logType']:22s} {f['level']:5s} t={tcid}{marker}{extra}")

        if any(x in str(f["msg"]).lower() for x in
               ["failed", "error", "unable", "exception"]):
            print(f"       >>> {f['msg']}")

    print(f"\n--- Service summary ---")
    for svc, count in sorted(svc_counts.items(), key=lambda x: -x[1]):
        print(f"  {svc}: {count} logs")

    return d


# ── Algorithm D: Retry Loop Detection ────────────────────────────────────────

def retry_detect(gtid, hours=24):
    """Detect if a globalTrackingId is stuck in a retry loop."""
    print(f"{'='*70}")
    print(f"RETRY DETECTION: {gtid} (last {hours}h)")
    print(f"{'='*70}")

    d = elk_query({
        "size": 0,
        "query": {"bool": {"must": [
            {"range": {"@timestamp": {"gte": f"now-{hours}h"}}},
            {"query_string": {"query": f"\"{gtid}\"", "fields": ["message"]}}
        ]}},
        "aggs": {
            "over_time": {"date_histogram": {"field": "@timestamp", "interval": "1h"}},
            "by_logtype": {"terms": {"field": "logType.keyword", "size": 10}},
            "by_level": {"terms": {"field": "level.keyword", "size": 5}},
            "by_service": {"terms": {"field": "serviceName.keyword", "size": 20}}
        }
    })

    total = get_total(d)
    print(f"Total logs: {total}")

    intervals = [b for b in d["aggregations"]["over_time"]["buckets"]
                 if b["doc_count"] > 0]
    print(f"Hours with activity: {len(intervals)} of {hours}")

    if len(intervals) > 1:
        counts = [b["doc_count"] for b in intervals]
        avg = sum(counts) / len(counts)
        stddev = (sum((c - avg) ** 2 for c in counts) / len(counts)) ** 0.5
        cv = stddev / avg if avg > 0 else 0
        print(f"Logs per active hour: avg={avg:.1f}, stddev={stddev:.1f}, CV={cv:.2f}")
        if cv < 0.3 and len(intervals) > 3:
            print(f">>> RETRY LOOP DETECTED: {len(intervals)} "
                  f"evenly-spaced retries (~{avg:.0f} logs/hr)")
            print(f"    Regularity (CV<0.3) strongly suggests a timer-based retry pattern.")
            print(f"    Use 'permanence' command to determine if the error is permanent.")
        elif len(intervals) > 3:
            print(f">>> POSSIBLE retry pattern: {len(intervals)} hours active, "
                  f"but irregular (CV={cv:.2f})")

    print(f"\n--- Hourly breakdown ---")
    for b in intervals:
        print(f"  {b['key_as_string']}: {b['doc_count']}")

    print(f"\n--- By level ---")
    for b in d["aggregations"]["by_level"]["buckets"]:
        print(f"  {b['key']}: {b['doc_count']}")

    print(f"\n--- By service ---")
    for b in d["aggregations"]["by_service"]["buckets"][:10]:
        svc_short = b["key"].split("-production")[0] if "-production" in b["key"] else b["key"]
        print(f"  {svc_short}: {b['doc_count']}")


# ── Algorithm E: Test Value in Prod ──────────────────────────────────────────

def test_in_prod(test_value, hours=4):
    """Check if a hardcoded/test value appears in production logs."""
    print(f"{'='*70}")
    print(f"TEST VALUE IN PROD: \"{test_value}\" (last {hours}h)")
    print(f"{'='*70}")

    d = elk_query({
        "size": 0,
        "query": {"bool": {"must": [
            {"range": {"@timestamp": {"gte": f"now-{hours}h"}}},
            {"query_string": {"query": f"\"{test_value}\"", "fields": ["message"]}},
            {"term": {"environment.keyword": "mbosProd"}}
        ]}},
        "aggs": {
            "by_service": {
                "terms": {"field": "serviceName.keyword", "size": 30},
                "aggs": {
                    "by_logtype": {"terms": {"field": "logType.keyword", "size": 10}},
                    "by_level": {"terms": {"field": "level.keyword", "size": 5}}
                }
            }
        }
    })

    total = get_total(d)
    if total == 0:
        print(f"  CLEAN: \"{test_value}\" not found in production logs ({hours}h)")
        return

    print(f"  WARNING: {total} hits in production ({hours}h)")
    for b in d["aggregations"]["by_service"]["buckets"]:
        lt = ", ".join(f"{x['key']}={x['doc_count']}"
                       for x in b["by_logtype"]["buckets"])
        lv = ", ".join(f"{x['key']}={x['doc_count']}"
                       for x in b["by_level"]["buckets"])
        print(f"  {b['key']}: {b['doc_count']}  [{lt}]  level=[{lv}]")


# ── Algorithm F: Call Topology ───────────────────────────────────────────────

def call_topo(uri_pattern, hours=1):
    """Map who calls whom for a specific API path."""
    print(f"{'='*70}")
    print(f"CALL TOPOLOGY: \"{uri_pattern}\" (last {hours}h)")
    print(f"{'='*70}")

    # Callers (FEIGN_REQUEST to this URI)
    d1 = elk_query({
        "size": 5,
        "query": {"bool": {"must": [
            {"range": {"@timestamp": {"gte": f"now-{hours}h"}}},
            {"query_string": {"query": f"\"{uri_pattern}\"", "fields": ["message"]}},
            {"term": {"logType.keyword": "FEIGN_REQUEST"}}
        ]}},
        "aggs": {
            "by_service": {"terms": {"field": "serviceName.keyword", "size": 20}}
        },
        "sort": [{"@timestamp": "desc"}]
    })

    print(f"\n--- CALLERS (FEIGN_REQUEST) ---")
    total1 = get_total(d1)
    print(f"Total: {total1}")
    for b in d1["aggregations"]["by_service"]["buckets"]:
        print(f"  {b['key']}: {b['doc_count']}")

    # Targets (API_REQUEST for this URI)
    d2 = elk_query({
        "size": 5,
        "query": {"bool": {"must": [
            {"range": {"@timestamp": {"gte": f"now-{hours}h"}}},
            {"query_string": {"query": f"\"{uri_pattern}\"", "fields": ["message"]}},
            {"term": {"logType.keyword": "API_REQUEST"}}
        ]}},
        "aggs": {
            "by_service": {"terms": {"field": "serviceName.keyword", "size": 20}}
        },
        "sort": [{"@timestamp": "desc"}]
    })

    print(f"\n--- TARGETS (API_REQUEST) ---")
    total2 = get_total(d2)
    print(f"Total: {total2}")
    for b in d2["aggregations"]["by_service"]["buckets"]:
        print(f"  {b['key']}: {b['doc_count']}")

    print(f"\n--- X-Feign-Origin (call chains) ---")
    for h in d2["hits"]["hits"]:
        inner = parse_inner(h["_source"].get("message", ""))
        ctx = inner.get("context", {}) if isinstance(inner.get("context"), dict) else {}
        fo = ctx.get("request.header.x-feign-origin", "")
        if fo:
            print(f"  {fo}")


# ═══════════════════════════════════════════════════════════════════════════════
# ROOT CAUSE LAYER — WHY it happened
# ═══════════════════════════════════════════════════════════════════════════════


# ── Algorithm G: Success vs Failure Comparison ───────────────────────────────

def compare(uri_or_error, hours=1):
    """Compare a SUCCESSFUL request vs a FAILED request to the same endpoint.

    Answers: Why does this specific request fail when similar requests succeed?
    Technique: pull one 2xx API_RESPONSE and one 4xx/5xx API_RESPONSE to the
    same URI, then diff the request payloads side by side.
    """
    print(f"{'='*70}")
    print(f"COMPARE SUCCESS vs FAILURE: \"{uri_or_error}\" (last {hours}h)")
    print(f"{'='*70}")

    # --- Get a FAILED request sample ---
    fail_d = elk_query({
        "size": 3,
        "query": {"bool": {"must": [
            {"range": {"@timestamp": {"gte": f"now-{hours}h"}}},
            {"query_string": {"query": f"\"{uri_or_error}\"", "fields": ["message"]}},
            {"term": {"logType.keyword": "API_RESPONSE"}},
            {"term": {"level.keyword": "ERROR"}}
        ]}},
        "sort": [{"@timestamp": "desc"}],
    })
    fail_hits = fail_d["hits"]["hits"]

    if not fail_hits:
        print("  No FAILED API_RESPONSE found matching this pattern.")
        return

    fail_f = extract_fields(fail_hits[0]["_source"])
    anchor_uri = fail_f["uri"]

    print(f"\n--- FAILURE sample ---")
    print(f"  Service:   {fail_f['svc_short']}")
    print(f"  URI:       {anchor_uri}")
    print(f"  Status:    {fail_f['status']}")
    print(f"  Timestamp: {fail_f['timestamp']}")
    if fail_f["body"] and fail_f["body"] not in ("None", "{}"):
        print(f"  Body:      {fail_f['body']}")
    if fail_f["msg"]:
        print(f"  Message:   {fail_f['msg']}")
    if fail_f["stack_trace"]:
        for line in fail_f["stack_trace"].split("\n")[:3]:
            print(f"  | {line}")

    # Get the inbound API_REQUEST for this same threadContextId (to see input)
    fail_input = _get_api_request_for_tcid(fail_f["tcid"], hours)
    if fail_input:
        print(f"\n--- FAILURE input (API_REQUEST for same thread) ---")
        _print_request_summary(fail_input)

    # --- Get a SUCCESS request to the same endpoint (generalized URI) ---
    # Strip variable path segments (IDs, UUIDs, numbers) to find the endpoint pattern
    search_term = _generalize_uri(anchor_uri) if anchor_uri else uri_or_error

    succ_d = elk_query({
        "size": 3,
        "query": {"bool": {"must": [
            {"range": {"@timestamp": {"gte": f"now-{hours}h"}}},
            {"query_string": {"query": f"\"{search_term}\"", "fields": ["message"]}},
            {"term": {"logType.keyword": "API_RESPONSE"}},
            {"terms": {"level.keyword": ["INFO", "DEBUG"]}}
        ],
        "must_not": [
            {"term": {"level.keyword": "ERROR"}}
        ]}},
        "sort": [{"@timestamp": "desc"}],
    })
    succ_hits = succ_d["hits"]["hits"]

    if not succ_hits:
        print(f"\n--- SUCCESS sample ---")
        print(f"  No successful API_RESPONSE found for: {search_term}")
        print(f"  >>> This endpoint may ALWAYS fail (100% error rate).")
        return

    succ_f = extract_fields(succ_hits[0]["_source"])
    print(f"\n--- SUCCESS sample ---")
    print(f"  Service:   {succ_f['svc_short']}")
    print(f"  URI:       {succ_f['uri']}")
    print(f"  Status:    {succ_f['status']}")
    print(f"  Timestamp: {succ_f['timestamp']}")

    succ_input = _get_api_request_for_tcid(succ_f["tcid"], hours)
    if succ_input:
        print(f"\n--- SUCCESS input (API_REQUEST for same thread) ---")
        _print_request_summary(succ_input)

    # --- Diff analysis ---
    print(f"\n--- DIFF ANALYSIS ---")
    if fail_input and succ_input:
        _diff_requests(fail_input, succ_input)
    else:
        print("  Could not retrieve both request inputs for comparison.")
        print("  Manually compare the URI path parameters above.")


def _get_api_request_for_tcid(tcid, hours):
    """Fetch the API_REQUEST log for a given threadContextId."""
    if not tcid:
        return None
    d = elk_query({
        "size": 1,
        "query": {"bool": {"must": [
            {"range": {"@timestamp": {"gte": f"now-{hours}h"}}},
            {"term": {"threadContextId.keyword": tcid}},
            {"term": {"logType.keyword": "API_REQUEST"}}
        ]}}
    })
    if d["hits"]["hits"]:
        return extract_fields(d["hits"]["hits"][0]["_source"])
    return None


def _print_request_summary(f):
    """Print a compact summary of a request."""
    print(f"  URI:    {f['uri']}")
    print(f"  Method: {f['method'] or '?'}")
    if f["body"] and f["body"] not in ("None", "{}"):
        print(f"  Body:   {f['body']}")
    if f["feign_origin"]:
        print(f"  Caller: {f['feign_origin']}")


def _diff_requests(fail_f, succ_f):
    """Compare two request field dicts and highlight differences."""
    fail_uri = fail_f["uri"] or ""
    succ_uri = succ_f["uri"] or ""

    fail_parts = fail_uri.strip("/").split("/")
    succ_parts = succ_uri.strip("/").split("/")
    max_len = max(len(fail_parts), len(succ_parts))
    uri_diffs = []
    for i in range(max_len):
        fp = fail_parts[i] if i < len(fail_parts) else "<missing>"
        sp = succ_parts[i] if i < len(succ_parts) else "<missing>"
        if fp != sp:
            uri_diffs.append(f"  segment[{i}]: FAIL=\"{fp}\"  SUCCESS=\"{sp}\"")

    if uri_diffs:
        print("  URI path differences (likely the variable input):")
        for d in uri_diffs:
            print(d)
    else:
        print("  URI paths identical — difference is in request body or headers.")

    fail_body = fail_f["body"] or ""
    succ_body = succ_f["body"] or ""
    if fail_body != succ_body and fail_body and succ_body:
        print(f"  Body difference:")
        print(f"    FAIL: {fail_body[:200]}")
        print(f"    SUCC: {succ_body[:200]}")

    fail_caller = fail_f["feign_origin"] or ""
    succ_caller = succ_f["feign_origin"] or ""
    if fail_caller != succ_caller and fail_caller and succ_caller:
        print(f"  Different callers:")
        print(f"    FAIL called by: {fail_caller}")
        print(f"    SUCC called by: {succ_caller}")


def _generalize_uri(uri):
    """Extract the static endpoint pattern from a URI by keeping only path keywords.
    
    Example: /api/provisioningorder/12345%3Aabc/updatelineinquiry/9876
         --> updatelineinquiry
    Keeps the most specific non-ID segment as the search term.
    """
    if not uri:
        return uri
    # URL-decode and split
    decoded = uri.replace("%3A", ":").replace("%2F", "/")
    segments = [s for s in decoded.strip("/").split("/") if s]
    # Filter out segments that look like IDs (numeric, UUID-like, or contain ':')
    keywords = []
    for seg in segments:
        if re.match(r'^[\d]+$', seg):
            continue  # pure numeric
        if re.match(r'^[0-9a-f]{8}-', seg, re.IGNORECASE):
            continue  # UUID
        if ':' in seg:
            continue  # composite ID
        if re.match(r'^[\d]+%3[Aa]', seg):
            continue  # encoded composite ID
        if seg in ('api', 'v1', 'v2', 'v3'):
            continue  # generic path prefixes
        keywords.append(seg)
    # Use the last keyword (most specific, typically the operation name)
    return keywords[-1] if keywords else uri


# ── Algorithm H: Onset Detection ─────────────────────────────────────────────

def onset(error_text, hours=24):
    """Find WHEN an error first appeared, and what configLabel deployed near that time.

    Answers: Is this error new (deployment-triggered) or chronic (data/infra)?
    Technique: 15-minute histogram over time window to find the spike, then
    configLabel aggregation in the spike window vs the quiet window before it.
    """
    print(f"{'='*70}")
    print(f"ONSET DETECTION: \"{error_text}\" (last {hours}h)")
    print(f"{'='*70}")

    d = elk_query({
        "size": 0,
        "query": {"bool": {"must": [
            {"range": {"@timestamp": {"gte": f"now-{hours}h"}}},
            {"query_string": {"query": f"\"{error_text}\"", "fields": ["message"]}},
            {"term": {"level.keyword": "ERROR"}}
        ]}},
        "aggs": {
            "over_time": {
                "date_histogram": {"field": "@timestamp", "interval": "15m"},
            },
            "by_config": {
                "terms": {"field": "configLabel.keyword", "size": 20}
            },
            "by_service": {
                "terms": {"field": "serviceName.keyword", "size": 10}
            }
        }
    })

    total = get_total(d)
    print(f"\nTotal errors: {total}")

    buckets = d["aggregations"]["over_time"]["buckets"]
    active = [(b["key_as_string"], b["doc_count"]) for b in buckets if b["doc_count"] > 0]

    if not active:
        print("  No errors found in this time window.")
        return

    onset_ts = active[0][0]
    onset_count = active[0][1]
    peak = max(active, key=lambda x: x[1])
    latest = active[-1]

    print(f"\n--- Timeline ---")
    print(f"  First seen:  {onset_ts} ({onset_count} errors)")
    print(f"  Peak:        {peak[0]} ({peak[1]} errors)")
    print(f"  Latest:      {latest[0]} ({latest[1]} errors)")

    first_half = [c for _, c in active[:len(active)//2]]
    second_half = [c for _, c in active[len(active)//2:]]
    avg_first = sum(first_half) / max(len(first_half), 1)
    avg_second = sum(second_half) / max(len(second_half), 1)

    if not first_half or avg_first == 0:
        trend = "NEW — appeared recently"
    elif avg_second > avg_first * 1.5:
        trend = "INCREASING — getting worse"
    elif avg_second < avg_first * 0.5:
        trend = "DECREASING — may be self-healing or fixed"
    else:
        trend = "STABLE — chronic issue, not deployment-related"
    print(f"  Trend:       {trend}")

    print(f"\n--- ConfigLabels (deployed versions) ---")
    for b in d["aggregations"]["by_config"]["buckets"]:
        print(f"  {b['key']}: {b['doc_count']} errors")

    print(f"\n--- Services ---")
    for b in d["aggregations"]["by_service"]["buckets"]:
        svc_short = b["key"].split("-production")[0] if "-production" in b["key"] else b["key"]
        print(f"  {svc_short}: {b['doc_count']} errors")

    print(f"\n--- Root cause hypothesis ---")
    configs = [b["key"] for b in d["aggregations"]["by_config"]["buckets"]]
    if len(configs) == 1:
        print(f"  Single version: {configs[0]}")
        print(f"  If onset is recent → likely DEPLOYMENT-CAUSED (this version introduced it).")
        print(f"  If onset is old → CHRONIC issue, not version-specific.")
    elif len(configs) > 1:
        print(f"  Multiple versions: {', '.join(configs[:5])}")
        print(f"  Error spans versions → likely DATA or EXTERNAL issue (not code regression).")
    print(f"  Trend: {trend}")


# ── Algorithm I: Input Divergence ─────────────────────────────────────────────

def input_diff(uri_pattern, hours=1):
    """Extract and compare input values from failures vs successes for an endpoint.

    Answers: What specific input values trigger failure?
    Technique: Sample N failures and N successes, extract path params and body
    fields, show which values appear only in failures.
    """
    print(f"{'='*70}")
    print(f"INPUT DIVERGENCE: \"{uri_pattern}\" (last {hours}h)")
    print(f"{'='*70}")

    fail_d = elk_query({
        "size": 20,
        "query": {"bool": {"must": [
            {"range": {"@timestamp": {"gte": f"now-{hours}h"}}},
            {"query_string": {"query": f"\"{uri_pattern}\"", "fields": ["message"]}},
            {"term": {"logType.keyword": "API_RESPONSE"}},
            {"term": {"level.keyword": "ERROR"}}
        ]}},
        "sort": [{"@timestamp": "desc"}],
    })

    succ_d = elk_query({
        "size": 20,
        "query": {"bool": {"must": [
            {"range": {"@timestamp": {"gte": f"now-{hours}h"}}},
            {"query_string": {"query": f"\"{uri_pattern}\"", "fields": ["message"]}},
            {"term": {"logType.keyword": "API_RESPONSE"}},
            {"terms": {"level.keyword": ["INFO", "DEBUG"]}}
        ]}},
        "sort": [{"@timestamp": "desc"}],
    })

    fail_uris = [extract_fields(h["_source"])["uri"]
                 for h in fail_d["hits"]["hits"]
                 if extract_fields(h["_source"])["uri"]]
    succ_uris = [extract_fields(h["_source"])["uri"]
                 for h in succ_d["hits"]["hits"]
                 if extract_fields(h["_source"])["uri"]]

    print(f"\n  Failures sampled: {len(fail_uris)}")
    print(f"  Successes sampled: {len(succ_uris)}")

    if not fail_uris:
        print("  No failure URIs found.")
        return

    print(f"\n--- Failure URIs (unique) ---")
    for uri in sorted(set(fail_uris))[:15]:
        print(f"  FAIL: {uri}")

    print(f"\n--- Success URIs (unique) ---")
    for uri in sorted(set(succ_uris))[:15]:
        print(f"  SUCC: {uri}")

    if fail_uris and succ_uris:
        fail_segs = _extract_variable_segments(fail_uris)
        succ_segs = _extract_variable_segments(succ_uris)

        if fail_segs or succ_segs:
            print(f"\n--- Variable path segments ---")
            all_positions = sorted(set(list(fail_segs.keys()) + list(succ_segs.keys())))
            for pos in all_positions:
                fvals = fail_segs.get(pos, set())
                svals = succ_segs.get(pos, set())
                fail_only = fvals - svals
                succ_only = svals - fvals
                overlap = fvals & svals
                if fail_only or succ_only:
                    print(f"  Segment[{pos}]:")
                    if fail_only:
                        print(f"    FAIL-ONLY values: {sorted(fail_only)[:10]}")
                    if succ_only:
                        print(f"    SUCC-ONLY values: {sorted(succ_only)[:10]}")
                    if overlap:
                        print(f"    In both (not discriminating): {len(overlap)} values")


def _extract_variable_segments(uris):
    """Find URI path segments that vary across a set of URIs."""
    if not uris:
        return {}
    split = [u.strip("/").split("/") for u in uris]
    max_len = max(len(s) for s in split)
    variable = {}
    for i in range(max_len):
        vals = set()
        for s in split:
            if i < len(s):
                vals.add(s[i])
        if len(vals) > 1:
            variable[i] = vals
    return variable


# ── Algorithm J: Permanence Test ─────────────────────────────────────────────

def permanence(gtid, hours=24):
    """Determine if repeated failures for an entity are permanent or transient.

    Answers: Is retrying this request wasteful (permanent) or useful (transient)?
    Technique: For a given globalTrackingId, check if the error response is
    IDENTICAL across all retry attempts. Identical = permanent. Varying = transient.
    """
    print(f"{'='*70}")
    print(f"PERMANENCE TEST: {gtid} (last {hours}h)")
    print(f"{'='*70}")

    d = elk_query({
        "size": 50,
        "query": {"bool": {"must": [
            {"range": {"@timestamp": {"gte": f"now-{hours}h"}}},
            {"query_string": {"query": f"\"{gtid}\"", "fields": ["message"]}},
            {"terms": {"level.keyword": ["ERROR", "WARN"]}}
        ]}},
        "sort": [{"@timestamp": "asc"}],
    })

    hits = d["hits"]["hits"]
    total = get_total(d)
    print(f"Total ERROR/WARN logs: {total} (sampled {len(hits)})")

    if not hits:
        print("  No error/warn logs found for this tracking ID.")
        return

    signatures = []
    timestamps = []
    for h in hits:
        f = extract_fields(h["_source"])
        sig = f"{f['svc_short']}|{f['logType']}|{f['status']}|{f['msg'][:80]}"
        signatures.append(sig)
        timestamps.append(f["timestamp"])

    sig_counts = defaultdict(int)
    for s in signatures:
        sig_counts[s] += 1

    print(f"\n--- Error signatures ({len(sig_counts)} unique across {len(signatures)} errors) ---")
    for sig, count in sorted(sig_counts.items(), key=lambda x: -x[1]):
        parts = sig.split("|", 3)
        print(f"  [{count}x] svc={parts[0]} logType={parts[1]} status={parts[2]}")
        print(f"          msg: {parts[3]}")

    print(f"\n--- Verdict ---")
    if len(timestamps) >= 2:
        print(f"  First error: {timestamps[0]}")
        print(f"  Last error:  {timestamps[-1]}")

    if len(sig_counts) == 1:
        the_count = list(sig_counts.values())[0]
        print(f"  PERMANENT: Same error repeated {the_count} times (identical signature).")
        print(f"  >>> Retrying will NEVER succeed. Root cause is data or external system.")
        print(f"  >>> Recommendation: stop retries, alert for manual review.")
    elif len(sig_counts) <= 3:
        print(f"  LIKELY PERMANENT: {len(sig_counts)} distinct errors, but highly repetitive.")
        print(f"  >>> Check if these are different manifestations of the same root cause.")
    else:
        print(f"  POSSIBLY TRANSIENT: {len(sig_counts)} distinct error patterns.")
        print(f"  >>> Different errors suggest changing conditions — retries MAY succeed.")

    # Check if any attempt succeeded
    succ_d = elk_query({
        "size": 0,
        "query": {"bool": {"must": [
            {"range": {"@timestamp": {"gte": f"now-{hours}h"}}},
            {"query_string": {"query": f"\"{gtid}\"", "fields": ["message"]}},
            {"term": {"logType.keyword": "API_RESPONSE"}},
            {"terms": {"level.keyword": ["INFO", "DEBUG"]}}
        ]}}
    })
    succ_total = get_total(succ_d)
    if succ_total > 0:
        print(f"\n  NOTE: {succ_total} SUCCESS responses also found for this tracking ID.")
        print(f"  >>> The error is INTERMITTENT, not permanent. Retries sometimes work.")
    else:
        print(f"\n  CONFIRMED: Zero successful responses found. Error is PERSISTENT.")


# ── Algorithm K: Data Lineage (Backward Trace) ──────────────────────────────

def data_lineage(gtid, hours=24):
    """Trace an entity BACKWARD to find where it entered the system.

    Answers: Where did the bad data originate? Which service first received it?
    Technique: Find the EARLIEST log for a globalTrackingId — that's the entry
    point. Then examine who called it (X-Feign-Origin, upstream API_REQUEST).
    """
    print(f"{'='*70}")
    print(f"DATA LINEAGE: {gtid} (last {hours}h)")
    print(f"{'='*70}")

    d = elk_query({
        "size": 20,
        "query": {"bool": {"must": [
            {"range": {"@timestamp": {"gte": f"now-{hours}h"}}},
            {"query_string": {"query": f"\"{gtid}\"", "fields": ["message"]}}
        ]}},
        "sort": [{"@timestamp": "asc"}],
    })

    total = get_total(d)
    hits = d["hits"]["hits"]
    print(f"Total logs: {total} (showing earliest {len(hits)})")

    if not hits:
        print("  No logs found for this tracking ID.")
        return

    first_request = None
    all_services = []
    for h in hits:
        f = extract_fields(h["_source"])
        all_services.append(f["svc_short"])
        if f["logType"] == "API_REQUEST" and not first_request:
            first_request = f

    print(f"\n--- Chronological service order ---")
    seen = []
    for svc in all_services:
        if svc not in seen:
            seen.append(svc)
    for i, svc in enumerate(seen):
        marker = " <<< ENTRY POINT" if i == 0 else ""
        print(f"  {i+1}. {svc}{marker}")

    if first_request:
        print(f"\n--- Entry point details ---")
        print(f"  Service:     {first_request['svc_short']}")
        print(f"  Timestamp:   {first_request['timestamp']}")
        print(f"  URI:         {first_request['uri']}")
        print(f"  Method:      {first_request['inner'].get('method', '?')}")
        if first_request["feign_origin"]:
            print(f"  Called by:   {first_request['feign_origin']}")
            print(f"  >>> The data came from: {first_request['feign_origin']}")
            print(f"  >>> Trace that caller to find the original data source.")
        else:
            print(f"  Called by:   External (no X-Feign-Origin — this is the system boundary)")
            print(f"  >>> Check: API consumer, UI, batch job, or message queue.")

        if first_request["body"] and first_request["body"] not in ("None", "{}"):
            print(f"\n--- Entry point request body ---")
            print(f"  {first_request['body']}")
    else:
        f0 = extract_fields(hits[0]["_source"])
        print(f"\n  No API_REQUEST found — earliest log may be an internal operation.")
        print(f"  Earliest: {f0['svc_short']} {f0['logType']} {f0['level']} @ {f0['timestamp']}")

    # Show first error to connect entry → failure
    errors = [extract_fields(h["_source"]) for h in hits
              if extract_fields(h["_source"])["level"] == "ERROR"]

    if errors and first_request:
        e = errors[0]
        print(f"\n--- Cause chain ---")
        print(f"  Data entered at: {first_request['svc_short']} ({first_request['timestamp']})")
        print(f"  Failed at:       {e['svc_short']} ({e['timestamp']})")
        err_idx = seen.index(e["svc_short"]) if e["svc_short"] in seen else len(seen)
        print(f"  Data traveled:   {' -> '.join(seen[:err_idx+1])}")
        print(f"  Error message:   {e['msg']}")


# ── Algorithm L: Deployment Correlation ──────────────────────────────────────

def deploy_correlate(error_text, hours=24):
    """Correlate error rate with configLabel (deployment version) changes.

    Answers: Did a new deployment introduce this error?
    Technique: Time-series of error count per configLabel. If one version appears
    at the same time errors spike, that's the causal deployment.
    """
    print(f"{'='*70}")
    print(f"DEPLOYMENT CORRELATION: \"{error_text}\" (last {hours}h)")
    print(f"{'='*70}")

    d = elk_query({
        "size": 0,
        "query": {"bool": {"must": [
            {"range": {"@timestamp": {"gte": f"now-{hours}h"}}},
            {"query_string": {"query": f"\"{error_text}\"", "fields": ["message"]}},
            {"term": {"level.keyword": "ERROR"}}
        ]}},
        "aggs": {
            "over_time": {
                "date_histogram": {"field": "@timestamp", "interval": "1h"},
                "aggs": {
                    "by_config": {
                        "terms": {"field": "configLabel.keyword", "size": 10}
                    }
                }
            },
            "by_config_total": {
                "terms": {"field": "configLabel.keyword", "size": 20}
            },
            "by_service": {
                "terms": {"field": "serviceName.keyword", "size": 10},
                "aggs": {
                    "by_config": {
                        "terms": {"field": "configLabel.keyword", "size": 5}
                    }
                }
            }
        }
    })

    total = get_total(d)
    print(f"\nTotal errors: {total}")

    print(f"\n--- Error count by configLabel (version) ---")
    configs = d["aggregations"]["by_config_total"]["buckets"]
    for b in configs:
        pct = (b["doc_count"] / total * 100) if total > 0 else 0
        print(f"  {b['key']}: {b['doc_count']} ({pct:.1f}%)")

    print(f"\n--- Hourly error rate by version ---")
    active_buckets = [b for b in d["aggregations"]["over_time"]["buckets"]
                      if b["doc_count"] > 0]

    for b in active_buckets:
        ts = b["key_as_string"][:16]
        count = b["doc_count"]
        configs_in_hour = [(c["key"].split("-")[-1] if "-" in c["key"] else c["key"],
                           c["doc_count"])
                          for c in b["by_config"]["buckets"]]
        config_str = ", ".join(f"{k}={v}" for k, v in configs_in_hour)
        print(f"  {ts}: {count:5d}  [{config_str}]")

    print(f"\n--- Deployment analysis ---")
    if len(configs) == 1:
        print(f"  Single version: {configs[0]['key']}")
        print(f"  All errors from one version — check if it's a new deployment.")
    elif len(configs) > 1:
        version_first_seen = {}
        for b in active_buckets:
            for c in b["by_config"]["buckets"]:
                if c["key"] not in version_first_seen:
                    version_first_seen[c["key"]] = b["key_as_string"]

        print(f"  Version first-seen times:")
        for ver, ts in sorted(version_first_seen.items(), key=lambda x: x[1]):
            print(f"    {ver}: first errors at {ts}")

        if len(version_first_seen) >= 2:
            versions = sorted(version_first_seen.items(), key=lambda x: x[1])
            latest = versions[-1]
            earlier = versions[0]
            if latest[1] > earlier[1]:
                print(f"\n  >>> Version {latest[0]} appeared AFTER {earlier[0]}.")
                print(f"  >>> If error rate increased after {latest[1]}, "
                      f"this deployment is the likely cause.")
            else:
                print(f"\n  >>> Versions appeared simultaneously — error is not version-specific.")
    else:
        print("  No configLabel data — cannot determine deployment correlation.")


# ═══════════════════════════════════════════════════════════════════════════════
# COMBINED PIPELINE
# ═══════════════════════════════════════════════════════════════════════════════

def full_investigate(error_text, hours=1):
    """Run the complete investigation pipeline: what → why → permanence → onset.

    Pipeline:
      Step 1: Error Origin   — WHO generates this error?
      Step 2: Sample Trace   — WHAT does a failed transaction look like?
      Step 3: Compare         — WHY does this fail when others succeed?
      Step 4: Retry Detection — IS this being retried fruitlessly?
      Step 5: Permanence      — IS retrying wasteful (permanent error)?
      Step 6: Onset           — WHEN did this start and what deployed?
    """
    print(f"{'='*70}")
    print(f"FULL INVESTIGATION: \"{error_text}\"")
    print(f"{'='*70}")

    # ── Step 1: Find origin ──
    print(f"\n{'─'*70}")
    print("STEP 1: Error Origin — WHO generates this error?")
    print(f"{'─'*70}")
    result = error_origin(error_text, hours)

    if not result["origins"]:
        print("\nNo origin services found. Check the error text.")
        return

    # ── Step 2: Sample trace ──
    print(f"\n{'─'*70}")
    print("STEP 2: Sample Trace — WHAT does a failed transaction look like?")
    print(f"{'─'*70}")

    top_origin_svc = result["origins"][0][0]
    print(f"  Tracing from top origin: {top_origin_svc}")

    d = elk_query({
        "size": 1,
        "query": {"bool": {"must": [
            {"range": {"@timestamp": {"gte": f"now-{hours}h"}}},
            {"term": {"serviceName.keyword": top_origin_svc}},
            {"query_string": {"query": f"\"{error_text}\"", "fields": ["message"]}},
            {"term": {"level.keyword": "ERROR"}}
        ]}},
        "sort": [{"@timestamp": "desc"}]
    })

    if not d["hits"]["hits"]:
        print("  No samples found in origin service.")
        return

    sample = extract_fields(d["hits"]["hits"][0]["_source"])
    tcid = sample["tcid"]
    gtid = sample["gtid"]

    if tcid:
        single_trace(tcid, hours)

    # ── Step 3: Compare success vs failure ──
    print(f"\n{'─'*70}")
    print("STEP 3: Compare — WHY does this fail when others succeed?")
    print(f"{'─'*70}")
    anchor_uri = sample["uri"]
    compare(anchor_uri if anchor_uri else error_text, hours)

    # ── Step 4: Retry detection ──
    if gtid:
        print(f"\n{'─'*70}")
        print("STEP 4: Retry Detection — IS this being retried fruitlessly?")
        print(f"{'─'*70}")
        retry_detect(gtid, min(hours * 6, 24))

        # ── Step 5: Permanence test ──
        print(f"\n{'─'*70}")
        print("STEP 5: Permanence — IS retrying wasteful?")
        print(f"{'─'*70}")
        permanence(gtid, min(hours * 6, 24))

    # ── Step 6: Onset ──
    print(f"\n{'─'*70}")
    print("STEP 6: Onset — WHEN did this start and what deployed?")
    print(f"{'─'*70}")
    onset(error_text, max(hours, 24))


# ═══════════════════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="Cross-service deep trace and root cause analysis tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Trace layer (WHAT happened):
  error-origin      Find which service generates vs relays an error
  single-trace      Trace one threadContextId across all services
  order-trace       Trace one globalTrackingId across all services
  retry-detect      Detect retry loops for a globalTrackingId
  test-in-prod      Check if a test/hardcoded value appears in prod
  call-topo         Map callers and targets for an API path

Root cause layer (WHY it happened):
  compare           Compare a successful vs failed request to the same endpoint
  onset             Find when an error first appeared and what deployed around it
  input-diff        Extract and diff input values from failures vs successes
  permanence        Determine if repeated failures are permanent or transient
  data-lineage      Trace an entity backward to find where bad data originated
  deploy-correlate  Correlate error rate changes with deployments (configLabel)

Combined:
  full-investigate   Chain: origin → trace → compare → permanence → onset
        """)

    parser.add_argument("command", choices=[
        "error-origin", "single-trace", "order-trace",
        "retry-detect", "test-in-prod", "call-topo",
        "compare", "onset", "input-diff",
        "permanence", "data-lineage", "deploy-correlate",
        "full-investigate",
    ])
    parser.add_argument("value", help="Error text, ID, URI, or pattern to investigate")
    parser.add_argument("--hours", type=int, default=1, help="Time window (default: 1)")
    parser.add_argument("--env", default="prod", choices=["prod", "lower"])

    args = parser.parse_args()

    commands = {
        "error-origin": lambda: error_origin(args.value, args.hours),
        "single-trace": lambda: single_trace(args.value, args.hours),
        "order-trace": lambda: order_trace(args.value, args.hours),
        "retry-detect": lambda: retry_detect(args.value, args.hours),
        "test-in-prod": lambda: test_in_prod(args.value, args.hours),
        "call-topo": lambda: call_topo(args.value, args.hours),
        "compare": lambda: compare(args.value, args.hours),
        "onset": lambda: onset(args.value, args.hours),
        "input-diff": lambda: input_diff(args.value, args.hours),
        "permanence": lambda: permanence(args.value, args.hours),
        "data-lineage": lambda: data_lineage(args.value, args.hours),
        "deploy-correlate": lambda: deploy_correlate(args.value, args.hours),
        "full-investigate": lambda: full_investigate(args.value, args.hours),
    }

    commands[args.command]()


if __name__ == "__main__":
    main()
