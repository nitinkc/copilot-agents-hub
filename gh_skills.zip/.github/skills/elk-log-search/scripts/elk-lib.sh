#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────────────────────
# elk-lib.sh — Shared library for OrderTech ELK scripts
#
# Source this file; do not execute directly.
# Provides: environment loading, cookie management, curl wrappers, helpers.
# ──────────────────────────────────────────────────────────────────────────────

# ── Guard: source-only ───────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  echo "ERROR: elk-lib.sh is a library — source it, don't execute it." >&2
  exit 1
fi

# ── Guard: approved callers only ─────────────────────────────────────────────
# elk-lib.sh MUST only be sourced by elk-query.sh (the single approved entry point).
# Agent-generated scripts MUST use `elk-query.sh raw` instead of sourcing this file.
# This guard uses BASH_SOURCE to verify the caller — cannot be bypassed with env vars.
_elk_lib_caller="$(basename "${BASH_SOURCE[1]:-unknown}" 2>/dev/null || echo unknown)"
if [[ "$_elk_lib_caller" != "elk-query.sh" ]]; then
  echo "ERROR: elk-lib.sh must not be sourced directly." >&2
  echo "  Caller was: ${BASH_SOURCE[1]:-unknown}" >&2
  echo "" >&2
  echo "  Use elk-query.sh instead:" >&2
  echo "    elk-query.sh search --service <name> --level ERROR --hours 2" >&2
  echo "    elk-query.sh raw --body '{\"size\":0, \"query\":{...}}'" >&2
  echo "    elk-query.sh raw --body-file /tmp/query.json" >&2
  echo "" >&2
  echo "  See: elk-query.sh help" >&2
  return 1 2>/dev/null || exit 1
fi
unset _elk_lib_caller

# ── Constants ────────────────────────────────────────────────────────────────
readonly ELK_CONFIG_DIR="${HOME}/.ordertech-elk"
readonly ELK_ENV_FILE="${ELK_CONFIG_DIR}/environments.yaml"
readonly ELK_MAX_SIZE=500
readonly ELK_MAX_HOURS=168
ELK_UA_DEFAULT="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Safari/605.1.15"
ELK_UA="$ELK_UA_DEFAULT"  # overridden per-env from persisted .ua file
readonly ELK_ACCEPT="text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"

# ── Resolved at load time ───────────────────────────────────────────────────
ELK_RESOLVED_URL=""
ELK_RESOLVED_COOKIE=""
ELK_RESOLVED_COOKIE_NAME="ccssession"  # default; overridden per-env via cookie_name
ELK_RESOLVED_ENV=""
ELK_RESOLVED_REFERER=""

# ── Utility functions ────────────────────────────────────────────────────────
elk_has_jq()  { command -v jq  >/dev/null 2>&1; }
elk_has_yq()  { command -v yq  >/dev/null 2>&1; }

elk_die() { echo "ERROR: $*" >&2; exit 1; }

elk_info() { echo "$*" >&2; }

elk_pretty() {
  if elk_has_jq; then jq .; else cat; fi
}

# ── YAML parser (no yq dependency) ──────────────────────────────────────────
# Minimal parser for our simple flat YAML. Reads a value under a top-level key.
# Usage: _yaml_read <file> <env> <field>
# Example: _yaml_read environments.yaml prod url
_yaml_read() {
  local file="$1" env="$2" field="$3"
  local in_env=false
  while IFS= read -r line; do
    # Skip comments and blank lines
    [[ "$line" =~ ^[[:space:]]*# ]] && continue
    [[ -z "${line// /}" ]] && continue

    # Top-level key (no leading whitespace, ends with colon)
    if [[ "$line" =~ ^[a-zA-Z_][a-zA-Z0-9_-]*: ]]; then
      local key="${line%%:*}"
      if [[ "$key" == "$env" ]]; then
        in_env=true
      else
        $in_env && break  # We've passed our section
        in_env=false
      fi
      continue
    fi

    # Indented field within our section
    if $in_env; then
      local trimmed="${line#"${line%%[![:space:]]*}"}"  # strip leading whitespace
      local fkey="${trimmed%%:*}"
      if [[ "$fkey" == "$field" ]]; then
        local fval="${trimmed#*: }"
        # Remove trailing comments
        fval="${fval%%#*}"
        # Trim whitespace
        fval="${fval%"${fval##*[![:space:]]}"}"
        echo "$fval"
        return 0
      fi
    fi
  done < "$file"
  return 1
}

# ── Environment loading ─────────────────────────────────────────────────────
# Resolves: URL, cookie, referer for the selected environment.
# Priority:
#   1. Explicit ELK_COOKIE / ELK_URL env vars (for backward compat / CI)
#   2. environments.yaml keyed by ELK_ENV (default: prod)
elk_load_env() {
  local env="${ELK_ENV:-prod}"

  # Override 1: explicit env vars
  if [[ -n "${ELK_URL:-}" && -n "${ELK_COOKIE:-}" ]]; then
    ELK_RESOLVED_URL="$ELK_URL"
    ELK_RESOLVED_COOKIE="$ELK_COOKIE"
    ELK_RESOLVED_COOKIE_NAME="${ELK_COOKIE_NAME:-ccssession}"
    ELK_RESOLVED_ENV="custom"
    ELK_RESOLVED_REFERER="${ELK_URL}/"
    elk_info "Using explicit ELK_URL + ELK_COOKIE (env=custom)"
    return 0
  fi

  # Check config file exists
  if [[ ! -f "$ELK_ENV_FILE" ]]; then
    elk_die "Config not found: $ELK_ENV_FILE
Run: elk-setup.sh   (or create the file manually)"
  fi

  # Read URL
  local url
  url=$(_yaml_read "$ELK_ENV_FILE" "$env" "url") || \
    elk_die "Environment '$env' not found in $ELK_ENV_FILE
Available environments: $(grep -E '^[a-zA-Z]' "$ELK_ENV_FILE" | sed 's/:.*//' | tr '\n' ' ')"
  [[ -z "$url" ]] && elk_die "No 'url' for environment '$env'"

  # Read cookie path
  local cookie_path
  cookie_path=$(_yaml_read "$ELK_ENV_FILE" "$env" "cookie") || \
    elk_die "No 'cookie' path for environment '$env'"

  # Expand ~ in path
  cookie_path="${cookie_path/#\~/$HOME}"

  if [[ ! -f "$cookie_path" ]]; then
    elk_die "Cookie file not found: $cookie_path
To set it up (SSO — recommended):
  elk-setup.sh --install-sso       # one-time
  elk-setup.sh --sso-login --env $env

Or manually:
  1. Log in to ${url}/app/discover
  2. DevTools → Application → Cookies → copy 'ccssession' value
  3. echo '<value>' > $cookie_path
  4. chmod 600 $cookie_path"
  fi

  local cookie_val
  cookie_val="$(cat "$cookie_path")"
  [[ -z "$cookie_val" ]] && elk_die "Cookie file is empty: $cookie_path"

  # Warn if cookie file is older than 4 hours (sessions typically expire in 4-8h)
  local cookie_age_s=0
  if [[ "$(uname)" == "Darwin" ]]; then
    cookie_age_s=$(( $(date +%s) - $(stat -f %m "$cookie_path") ))
  else
    cookie_age_s=$(( $(date +%s) - $(stat -c %Y "$cookie_path") ))
  fi
  local cookie_age_h=$(( cookie_age_s / 3600 ))
  if (( cookie_age_h >= 4 )); then
    elk_info "WARNING: Cookie is ${cookie_age_h}h old and may be expired."
    elk_info "  Refresh: elk-setup.sh --sso-login --env $env"
  fi

  # Read cookie name (default: ccssession — EaaS instances use "sid")
  local cookie_name
  cookie_name=$(_yaml_read "$ELK_ENV_FILE" "$env" "cookie_name") || cookie_name="ccssession"

  # Load persisted User-Agent (saved alongside cookie during SSO login)
  local ua_path="${cookie_path}.ua"
  if [[ -f "$ua_path" && -s "$ua_path" ]]; then
    ELK_UA="$(cat "$ua_path")"
  else
    ELK_UA="$ELK_UA_DEFAULT"
  fi

  ELK_RESOLVED_URL="$url"
  ELK_RESOLVED_COOKIE="$cookie_val"
  ELK_RESOLVED_COOKIE_NAME="$cookie_name"
  ELK_RESOLVED_ENV="$env"
  ELK_RESOLVED_REFERER="${url}/"

  local env_name
  env_name=$(_yaml_read "$ELK_ENV_FILE" "$env" "name") || env_name="$env"
  elk_info "Environment: $env_name ($env) → $url [cookie: $cookie_name]"
}

# ── Cookie auto-refresh ──────────────────────────────────────────────────────
# Attempts headless SSO refresh. Returns 0 on success, 1 on failure.
# On success, reloads the cookie into ELK_RESOLVED_COOKIE.
_elk_auto_refresh_cookie() {
  local env="${ELK_RESOLVED_ENV:-prod}"
  local script_dir
  script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  local sso_script="${script_dir}/elk-sso-login.py"

  if [[ ! -f "$sso_script" ]]; then
    elk_info "SSO script not found: $sso_script"
    return 1
  fi

  if ! command -v python3 >/dev/null 2>&1; then
    elk_info "python3 not found — cannot auto-refresh cookie"
    return 1
  fi

  # Check playwright is installed (fast — just import check)
  if ! python3 -c "import playwright" 2>/dev/null; then
    elk_info "Playwright not installed — cannot auto-refresh cookie"
    elk_info "  Install: python3 elk-sso-login.py --install"
    return 1
  fi

  elk_info "Cookie expired — attempting automatic headless refresh ..."

  # Clean stale Chromium lock files that cause TargetClosedError
  local browser_state="${ELK_CONFIG_DIR}/browser-state/${env}"
  if [[ -d "$browser_state" ]]; then
    rm -f "$browser_state/SingletonLock" "$browser_state/SingletonSocket" "$browser_state/SingletonCookie" 2>/dev/null
  fi

  local refresh_out="/tmp/elk-sso-refresh-$$.log"
  if python3 "$sso_script" --env "$env" > "$refresh_out" 2>&1; then
    # Show SSO output
    while IFS= read -r line; do elk_info "  [sso] $line"; done < "$refresh_out"
    rm -f "$refresh_out"
    # Reload cookie from file
    local cookie_path
    cookie_path=$(_yaml_read "$ELK_ENV_FILE" "$env" "cookie") || return 1
    cookie_path="${cookie_path/#\~/$HOME}"
    if [[ -f "$cookie_path" && -s "$cookie_path" ]]; then
      ELK_RESOLVED_COOKIE="$(cat "$cookie_path")"
      # Reload persisted UA (SSO login saves it alongside the cookie)
      local ua_path="${cookie_path}.ua"
      if [[ -f "$ua_path" && -s "$ua_path" ]]; then
        ELK_UA="$(cat "$ua_path")"
      fi
      elk_info "Cookie refreshed successfully."
      return 0
    fi
  else
    # Show SSO output for debugging
    while IFS= read -r line; do elk_info "  [sso] $line"; done < "$refresh_out"
    rm -f "$refresh_out"
  fi

  elk_info "Auto-refresh failed. Manual refresh needed:"
  elk_info "  python3 $sso_script --env $env --headed"
  return 1
}

# Guard: already tried auto-refresh this session? (prevents infinite loop)
_ELK_REFRESH_ATTEMPTED=false

# ── curl wrappers ────────────────────────────────────────────────────────────
# NOTE: The openresty OIDC proxy requires browser-like User-Agent + Referer.
# All wrappers detect 302 (expired cookie) and auto-refresh once per session.

# Core curl wrapper — all requests go through here.
# Detects 302 redirects (expired cookie), attempts auto-refresh, retries once.
_elk_curl() {
  local method="$1"; shift  # GET or POST
  local path="$1"; shift
  # Remaining args passed directly to curl (e.g., -d '...' or -d @file)

  local tmpout="/tmp/elk-response-$$.tmp"
  local http_code

  _elk_curl_once() {
    http_code=$(curl -sS --max-time 60 -o "$tmpout" -w "%{http_code}" \
      -b "${ELK_RESOLVED_COOKIE_NAME}=$ELK_RESOLVED_COOKIE" \
      -H "kbn-xsrf: true" \
      -H "Content-Type: application/json" \
      -H "Accept: application/json" \
      -H "Referer: $ELK_RESOLVED_REFERER" \
      -A "$ELK_UA" \
      "$@" \
      "${ELK_RESOLVED_URL}${path}" 2>/dev/null)
  }

  _elk_curl_once "$@"

  # Detect 302 redirect (expired cookie) — response body is HTML, not JSON
  if [[ "$http_code" == "302" || "$http_code" == "301" || "$http_code" == "303" ]]; then
    if [[ "$_ELK_REFRESH_ATTEMPTED" == "false" ]]; then
      _ELK_REFRESH_ATTEMPTED=true
      if _elk_auto_refresh_cookie; then
        # Retry the original request with the new cookie
        _elk_curl_once "$@"
        if [[ "$http_code" == "302" || "$http_code" == "301" || "$http_code" == "303" ]]; then
          rm -f "$tmpout"
          elk_die "Cookie refresh succeeded but server still returns $http_code.
Try manual refresh: python3 elk-sso-login.py --env ${ELK_RESOLVED_ENV} --headed"
        fi
      else
        rm -f "$tmpout"
        exit 3
      fi
    else
      rm -f "$tmpout"
      elk_die "Cookie expired (HTTP $http_code). Auto-refresh already attempted.
Manual refresh: python3 elk-sso-login.py --env ${ELK_RESOLVED_ENV} --headed"
    fi
  fi

  # Check for other HTTP errors
  if [[ "${http_code:0:1}" != "2" ]]; then
    local body_preview
    body_preview=$(head -c 200 "$tmpout" 2>/dev/null || true)
    rm -f "$tmpout"
    elk_die "HTTP $http_code from ${path}
${body_preview}"
  fi

  cat "$tmpout"
  rm -f "$tmpout"
}

elk_get() {
  local path="$1"
  _elk_curl GET "$path"
}

elk_post() {
  local path="$1"
  local body="$2"
  _elk_curl POST "$path" -d "$body"
}

# Post from a file (avoids shell escaping issues with large JSON)
elk_post_file() {
  local path="$1"
  local file="$2"
  _elk_curl POST "$path" -d "@${file}"
}

# ── Search helper ────────────────────────────────────────────────────────────
# Builds query JSON, writes to /tmp, posts via elk_post_file.
# Usage: elk_search <index> <query_body_json>
# NOTE: Uses printf (not heredoc) so elk-lib.sh can be sourced safely in
#       VS Code's integrated terminal, which corrupts state on heredocs.
elk_search() {
  local index="$1"
  local body="$2"
  local tmpfile="/tmp/elk-query-$$.json"

  printf '{"params":{"index":"%s","body":%s}}\n' "$index" "$body" > "$tmpfile"

  elk_post_file "/internal/search/es" "$tmpfile"
  rm -f "$tmpfile"
}

# ── Aggregation helper ───────────────────────────────────────────────────────
# Convenience: search with size=0 and extract aggregations.
elk_agg() {
  local index="$1"
  local body="$2"
  elk_search "$index" "$body" | jq '.rawResponse.aggregations' 2>/dev/null
}

# ── Environment listing ─────────────────────────────────────────────────────
elk_list_envs() {
  if [[ ! -f "$ELK_ENV_FILE" ]]; then
    elk_die "Config not found: $ELK_ENV_FILE"
  fi
  echo "Configured environments (${ELK_ENV_FILE}):" >&2
  echo "" >&2
  local current="${ELK_ENV:-prod}"
  while IFS= read -r line; do
    [[ "$line" =~ ^[[:space:]]*# ]] && continue
    [[ -z "${line// /}" ]] && continue
    if [[ "$line" =~ ^([a-zA-Z_][a-zA-Z0-9_-]*): ]]; then
      local key="${BASH_REMATCH[1]}"
      local name url cookie_path status
      name=$(_yaml_read "$ELK_ENV_FILE" "$key" "name") || name="$key"
      url=$(_yaml_read "$ELK_ENV_FILE" "$key" "url") || url="(not set)"
      cookie_path=$(_yaml_read "$ELK_ENV_FILE" "$key" "cookie") || cookie_path="(not set)"
      cookie_path="${cookie_path/#\~/$HOME}"
      if [[ -f "$cookie_path" && -s "$cookie_path" ]]; then
        # Check cookie age — report STALE if ≥4h (likely expired)
        local cookie_age_s=0
        if [[ "$(uname)" == "Darwin" ]]; then
          cookie_age_s=$(( $(date +%s) - $(stat -f %m "$cookie_path") ))
        else
          cookie_age_s=$(( $(date +%s) - $(stat -c %Y "$cookie_path") ))
        fi
        local cookie_age_h=$(( cookie_age_s / 3600 ))
        if (( cookie_age_h >= 8 )); then
          status="cookie STALE (${cookie_age_h}h old — likely EXPIRED)"
        elif (( cookie_age_h >= 4 )); then
          status="cookie STALE (${cookie_age_h}h old — may be expired)"
        else
          status="cookie OK (${cookie_age_h}h old)"
        fi
      elif [[ -f "$cookie_path" ]]; then
        status="cookie EMPTY"
      else
        status="cookie MISSING"
      fi
      local marker="  "
      [[ "$key" == "$current" ]] && marker="→ "
      printf "%s%-12s  %-20s  %s  [%s]\n" "$marker" "$key" "$name" "$url" "$status"
    fi
  done < "$ELK_ENV_FILE"
}
