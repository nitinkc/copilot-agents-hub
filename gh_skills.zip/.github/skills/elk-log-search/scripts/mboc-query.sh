#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────────────────────
# mboc-query.sh — Fetch config values from MobileBackOfficeConfig (MBOC)
#
# Fetches Spring Cloud Config YAML from the MBOC repo via GitHub API.
# Supports the full Spring override chain:
#   application.yml → {AppName}.yml → {AppName}-{profile}.yml
#
# Usage:
#   mboc-query.sh --service <slug> --config-label <configLabel> [options]
#   mboc-query.sh --service <slug> --config-label <configLabel> --key <yaml.key>
#   mboc-query.sh --service <slug> --config-label <configLabel> --env prod
#   mboc-query.sh --service <slug> --config-label <configLabel> --list-files
#   mboc-query.sh --service <slug> --config-label <configLabel> --diff <other-configLabel>
#
# Examples:
#   mboc-query.sh --service wkfl-billing-order --config-label wkfl-billing-order-1.0.4338.6 --key cbmLineLevelServicePromoIds
#   mboc-query.sh --service wkfl-billing-order --config-label wkfl-billing-order-1.0.4338.6 --env prod
#   mboc-query.sh --service wkfl-billing-order --config-label wkfl-billing-order-1.0.4338.6 --list-files
#   mboc-query.sh --service wkfl-billing-order --config-label wkfl-billing-order-1.0.4338.6 --diff wkfl-billing-order-1.0.4264.9
# ──────────────────────────────────────────────────────────────────────────────
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/../../../.." && pwd)"

readonly MBOC_ORG="comcast-modesto"
readonly MBOC_REPO="MobileBackOfficeConfig"
readonly SERVICE_MAPPINGS="${REPO_ROOT}/.github/shared/service_mappings.json"
readonly MAX_API_CALLS=10    # hard cap on GitHub API calls per invocation
readonly MAX_DIFF_FILES=6    # max files to compare in diff mode
readonly CURL_TIMEOUT=15     # seconds per API call

# ── Utility ──────────────────────────────────────────────────────────────────
die()  { echo "ERROR: $*" >&2; exit 1; }
info() { echo "$*" >&2; }

usage() {
  cat <<'EOF'
Usage: mboc-query.sh --service <slug> --config-label <configLabel> [options]

Required:
  --service <slug>            Service slug (e.g., wkfl-billing-order)
  --config-label <label>      configLabel from ELK (IS the MBOC branch name)

Options:
  --key <yaml.key>            Extract a specific YAML key (dot-separated path)
  --env <profile>             Environment profile (prod, stage, qa, dev). Default: prod
  --list-files                List all config files on the branch
  --diff <other-configLabel>  Compare config between two configLabel branches
  --raw                       Output raw YAML (skip key extraction)
  --help                      Show this help

Override Chain (highest priority last):
  application.yml → {AppName}.yml → {AppName}-{profile}.yml
EOF
}

# ── Resolve Spring app name from slug ────────────────────────────────────────
# Uses service_mappings.json (primary) or PascalCase fallback.
resolve_app_name() {
  local slug="$1"
  local app_name=""

  # Primary: service_mappings.json → repo_name (which IS the Spring app name)
  # head -1 guards against duplicate entries in the mappings file.
  if [[ -f "$SERVICE_MAPPINGS" ]] && command -v jq >/dev/null 2>&1; then
    app_name=$(jq -r --arg s "$slug" \
      '[.services[] | select(.service == $s) | .repo_name // empty] | first // empty' \
      "$SERVICE_MAPPINGS")
  fi

  if [[ -n "$app_name" ]]; then
    echo "$app_name"
    return 0
  fi

  # Fallback: PascalCase conversion (does NOT handle naming traps — see NAMING-AND-RESOLUTION.md §2)
  if command -v python3 >/dev/null 2>&1; then
    app_name=$(python3 -c "import re,sys; print(re.sub(r'(?:^|-)(\w)', lambda m: m.group(1).upper(), sys.argv[1]))" "$slug")
    info "WARNING: '${slug}' not in service_mappings.json — using PascalCase fallback: ${app_name}"
    info "         This may be wrong for naming-trap services (mbo-*, *2, xoms-*). Verify manually."
    echo "$app_name"
    return 0
  fi

  die "Cannot resolve app name for '${slug}': not in service_mappings.json and python3 unavailable"
}

# ── Verify branch exists via GitHub API ──────────────────────────────────────
verify_branch() {
  local branch="$1"
  local http_code
  http_code=$(curl -sf --max-time "$CURL_TIMEOUT" -o /dev/null -w '%{http_code}' \
    -H "Authorization: token $(gh auth token)" \
    "https://api.github.com/repos/${MBOC_ORG}/${MBOC_REPO}/branches/${branch}" 2>/dev/null) || true

  if [[ "$http_code" == "200" ]]; then
    return 0
  elif [[ "$http_code" == "404" ]]; then
    return 1
  else
    die "GitHub API returned HTTP ${http_code} for branch '${branch}'. Check auth: gh auth status"
  fi
}

# ── Fetch a single file from MBOC branch ────────────────────────────────────
fetch_file() {
  local branch="$1" filepath="$2"
  local content
  content=$(gh api "repos/${MBOC_ORG}/${MBOC_REPO}/contents/${filepath}?ref=${branch}" \
    --jq '.content' 2>/dev/null) || return 1

  if [[ -z "$content" || "$content" == "null" ]]; then
    return 1
  fi

  echo "$content" | base64 -d 2>/dev/null || return 1
}

# ── List all files on a branch ───────────────────────────────────────────────
list_branch_files() {
  local branch="$1"
  gh api "repos/${MBOC_ORG}/${MBOC_REPO}/git/trees/${branch}?recursive=0" \
    --jq '.tree[] | select(.type == "blob") | .path' 2>/dev/null
}

# ── Extract a key from YAML ──────────────────────────────────────────────────
# Supports two modes:
#   1. Dot-path (e.g., "billing-order.servicePromoEnabled") — exact path lookup
#   2. Leaf key (e.g., "servicePromoEnabled") — recursive search for the key name
# Uses python3+PyYAML (handles multi-doc YAML, nested keys). Falls back to grep.
extract_key() {
  local yaml_content="$1" key="$2"

  # Primary: python3 + PyYAML (handles multi-doc, nested, complex YAML)
  if command -v python3 >/dev/null 2>&1; then
    local result
    result=$(python3 -c "
import yaml, sys

key = sys.argv[1]
docs = list(yaml.safe_load_all(sys.stdin))

def get_by_path(data, parts):
    for p in parts:
        if isinstance(data, dict) and p in data:
            data = data[p]
        else:
            return None
    return data

def find_leaf(data, target, path=''):
    results = []
    if isinstance(data, dict):
        for k, v in data.items():
            p = path + '.' + k if path else k
            if k == target:
                results.append((p, v))
            results.extend(find_leaf(v, target, p))
    elif isinstance(data, list):
        for i, item in enumerate(data):
            results.extend(find_leaf(item, target, path + '[' + str(i) + ']'))
    return results

# Try exact dot-path first, then leaf search
parts = key.split('.')
for doc in docs:
    if doc is None:
        continue
    val = get_by_path(doc, parts)
    if val is not None:
        print(val)
        sys.exit(0)

# Leaf key search (last segment or full key as leaf name)
leaf = parts[-1]
for doc in docs:
    if doc is None:
        continue
    matches = find_leaf(doc, leaf)
    if matches:
        path, val = matches[0]
        # Print with path context so the user knows where it came from
        if path != leaf:
            print(val, file=sys.stdout)
            print('  (full path: ' + path + ')', file=sys.stderr)
        else:
            print(val)
        sys.exit(0)

sys.exit(1)
" "$key" <<< "$yaml_content") && { echo "$result"; return 0; }
  fi

  # Fallback: yq (mikefarah version — no jq-style // empty)
  if command -v yq >/dev/null 2>&1; then
    local result
    result=$(echo "$yaml_content" | yq ".. | select(has(\"${key}\")) | .${key}" 2>/dev/null)
    if [[ -n "$result" && "$result" != "null" ]]; then
      echo "$result"
      return 0
    fi
  fi

  # Grep fallback: flat keys only (key at any indentation level)
  local flat_match
  flat_match=$(echo "$yaml_content" | grep -E "^[[:space:]]*${key}:" | head -1 | sed 's/^[^:]*:[[:space:]]*//')
  if [[ -n "$flat_match" ]]; then
    echo "$flat_match"
    return 0
  fi

  return 1
}

# ── Fetch full override chain ────────────────────────────────────────────────
# Returns merged content with source annotations.
# Spring Cloud Config precedence: application.yml < {AppName}.yml < {AppName}-{profile}.yml
fetch_override_chain() {
  local branch="$1" app_name="$2" profile="$3"
  local api_calls=0

  local files=("application.yml" "${app_name}.yml" "${app_name}-${profile}.yml")
  local found_any=false

  for file in "${files[@]}"; do
    if (( api_calls >= MAX_API_CALLS )); then
      info "WARNING: API call cap (${MAX_API_CALLS}) reached. Remaining files skipped."
      break
    fi

    local content
    content=$(fetch_file "$branch" "$file" 2>/dev/null) || true
    (( api_calls++ ))

    if [[ -n "$content" ]]; then
      found_any=true
      echo "# ── ${file} (branch: ${branch}) ──"
      echo "$content"
      echo ""
    fi
  done

  if ! $found_any; then
    info "WARNING: No config files found on branch '${branch}' for app '${app_name}'"
    return 1
  fi
}

# ── Diff two configLabel branches ────────────────────────────────────────────
diff_branches() {
  local branch1="$1" branch2="$2" app_name="$3" profile="$4"
  local files=("application.yml" "${app_name}.yml" "${app_name}-${profile}.yml")
  local api_calls=0

  info "Comparing config: ${branch1} vs ${branch2}"
  info ""

  for file in "${files[@]}"; do
    if (( api_calls >= MAX_DIFF_FILES )); then
      info "WARNING: Diff API call cap (${MAX_DIFF_FILES}) reached."
      break
    fi

    local content1 content2
    content1=$(fetch_file "$branch1" "$file" 2>/dev/null) || true
    content2=$(fetch_file "$branch2" "$file" 2>/dev/null) || true
    (( api_calls += 2 ))

    if [[ -z "$content1" && -z "$content2" ]]; then
      continue
    fi

    echo "# ── ${file} ──"
    if [[ -z "$content1" ]]; then
      echo "  (not present on ${branch1})"
    elif [[ -z "$content2" ]]; then
      echo "  (not present on ${branch2})"
    elif [[ "$content1" == "$content2" ]]; then
      echo "  (identical)"
    else
      diff --label "${branch1}/${file}" --label "${branch2}/${file}" \
        <(echo "$content1") <(echo "$content2") || true
    fi
    echo ""
  done
}

# ── Parse arguments ──────────────────────────────────────────────────────────
SERVICE=""
CONFIG_LABEL=""
KEY=""
PROFILE="prod"
LIST_FILES=false
DIFF_LABEL=""
RAW=false

while [[ $# -gt 0 ]]; do
  case "$1" in
    --service|-s)      [[ $# -lt 2 ]] && die "--service requires a value"; SERVICE="$2"; shift 2 ;;
    --config-label|-c) [[ $# -lt 2 ]] && die "--config-label requires a value"; CONFIG_LABEL="$2"; shift 2 ;;
    --key|-k)          [[ $# -lt 2 ]] && die "--key requires a value"; KEY="$2"; shift 2 ;;
    --env|-e)          [[ $# -lt 2 ]] && die "--env requires a value"; PROFILE="$2"; shift 2 ;;
    --list-files)      LIST_FILES=true; shift ;;
    --diff|-d)         [[ $# -lt 2 ]] && die "--diff requires a configLabel"; DIFF_LABEL="$2"; shift 2 ;;
    --raw)             RAW=true; shift ;;
    --help|-h)         usage; exit 0 ;;
    *)                 die "Unknown option: $1. Use --help for usage." ;;
  esac
done

# ── Validate required arguments ──────────────────────────────────────────────
[[ -z "$SERVICE" ]]      && die "Missing required --service <slug>"
[[ -z "$CONFIG_LABEL" ]] && die "Missing required --config-label <configLabel>"

# Validate profile is an expected value
case "$PROFILE" in
  prod|stage|qa|dev|preprod|local) ;;
  *) die "Unknown profile '${PROFILE}'. Expected: prod, stage, qa, dev, preprod, local" ;;
esac

# ── Verify gh CLI is available and authenticated ─────────────────────────────
command -v gh >/dev/null 2>&1 || die "gh CLI not found. Install: https://cli.github.com/"
gh auth token >/dev/null 2>&1 || die "gh not authenticated. Run: gh auth login"

# ── Resolve app name ────────────────────────────────────────────────────────
APP_NAME=$(resolve_app_name "$SERVICE")
info "Service: ${SERVICE} → App name: ${APP_NAME}"
info "Branch:  ${CONFIG_LABEL}"

# ── Verify branch exists ────────────────────────────────────────────────────
if ! verify_branch "$CONFIG_LABEL"; then
  # configLabel branch might not exist if it's a newer version
  # Try the base version (strip hotfix segment) as fallback
  BASE_LABEL=$(echo "$CONFIG_LABEL" | sed 's/\.[0-9]*$//')
  if [[ "$BASE_LABEL" != "$CONFIG_LABEL" ]]; then
    info "Branch '${CONFIG_LABEL}' not found. Trying base: '${BASE_LABEL}'"
    if verify_branch "$BASE_LABEL"; then
      info "⚠️  Using base branch '${BASE_LABEL}' (hotfix branch '${CONFIG_LABEL}' not in MBOC)"
      CONFIG_LABEL="$BASE_LABEL"
    else
      die "Neither branch '${CONFIG_LABEL}' nor '${BASE_LABEL}' exists in ${MBOC_REPO}"
    fi
  else
    die "Branch '${CONFIG_LABEL}' does not exist in ${MBOC_REPO}"
  fi
fi

# ── Execute command ──────────────────────────────────────────────────────────

# Mode: list files
if $LIST_FILES; then
  info "Files on branch '${CONFIG_LABEL}':"
  list_branch_files "$CONFIG_LABEL"
  exit 0
fi

# Mode: diff two branches
if [[ -n "$DIFF_LABEL" ]]; then
  if ! verify_branch "$DIFF_LABEL"; then
    die "Diff target branch '${DIFF_LABEL}' does not exist in ${MBOC_REPO}"
  fi
  diff_branches "$CONFIG_LABEL" "$DIFF_LABEL" "$APP_NAME" "$PROFILE"
  exit 0
fi

# Mode: fetch config (with optional key extraction)
if [[ -n "$KEY" ]] && ! $RAW; then
  # Key extraction mode — search in reverse precedence order (highest-priority file wins)
  # Files: {AppName}-{profile}.yml > {AppName}.yml > application.yml
  local_files=("${APP_NAME}-${PROFILE}.yml" "${APP_NAME}.yml" "application.yml")
  FOUND=false
  KEY_PATH_FILE=$(mktemp "${TMPDIR:-/tmp}/mboc-key-path.XXXXXX")
  trap 'rm -f "$KEY_PATH_FILE"' EXIT

  for file in "${local_files[@]}"; do
    content=$(fetch_file "$CONFIG_LABEL" "$file" 2>/dev/null) || continue
    value=$(extract_key "$content" "$KEY" 2>"$KEY_PATH_FILE") || continue
    if [[ -n "$value" ]]; then
      path_info=""
      [[ -s "$KEY_PATH_FILE" ]] && path_info=$(cat "$KEY_PATH_FILE")
      echo "${KEY} = ${value}"
      [[ -n "$path_info" ]] && echo "  ${path_info}"
      echo "  source: ${file} (branch: ${CONFIG_LABEL})"
      FOUND=true
      break
    fi
  done

  if ! $FOUND; then
    info "Key '${KEY}' not found in any config file on branch '${CONFIG_LABEL}'"
    info "Searched: ${local_files[*]}"
    exit 1
  fi
else
  # Full chain mode — fetch all override files and display
  CHAIN_OUTPUT=$(fetch_override_chain "$CONFIG_LABEL" "$APP_NAME" "$PROFILE")

  if [[ -z "$CHAIN_OUTPUT" ]]; then
    die "No config files found for ${APP_NAME} on branch ${CONFIG_LABEL}"
  fi

  echo "$CHAIN_OUTPUT"
fi
