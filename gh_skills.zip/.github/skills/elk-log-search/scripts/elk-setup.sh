#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────────────────────
# elk-setup.sh — Bootstrap ~/.ordertech-elk config directory
#
# Creates:
#   ~/.ordertech-elk/
#   ~/.ordertech-elk/environments.yaml   (if not present)
#   ~/.ordertech-elk/cookies/            (mode 700)
#
# Usage:
#   elk-setup.sh                  # interactive setup
#   elk-setup.sh --set-cookie prod   # set/update cookie for an environment
#   elk-setup.sh --add-env stage https://ot-logs-stage.sys.comcast.net
# ──────────────────────────────────────────────────────────────────────────────
set -euo pipefail

readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly CONFIG_DIR="${HOME}/.ordertech-elk"
readonly ENV_FILE="${CONFIG_DIR}/environments.yaml"
readonly COOKIE_DIR="${CONFIG_DIR}/cookies"

die() { echo "ERROR: $*" >&2; exit 1; }
info() { echo "→ $*"; }

ensure_dirs() {
  mkdir -p "$CONFIG_DIR"
  mkdir -p "$COOKIE_DIR"
  chmod 700 "$COOKIE_DIR"
}

create_default_config() {
  if [[ -f "$ENV_FILE" ]]; then
    info "Config already exists: $ENV_FILE"
    return 0
  fi

  cat > "$ENV_FILE" << 'YAML'
# OrderTech ELK Environment Configuration
# Select env: export ELK_ENV=prod  (or --env prod on elk-query.sh)

prod:
  name: Production
  url: https://ot-logs-prod.sys.comcast.net
  cookie: ~/.ordertech-elk/cookies/prod.cookie

lower:
  name: Lower Environments (Stage/QA/Dev/Preprod)
  url: https://ot-logs-lower.sys.comcast.net
  cookie: ~/.ordertech-elk/cookies/lower.cookie
YAML
  info "Created config: $ENV_FILE"
}

set_cookie() {
  local env="$1"
  local cookie_file="${COOKIE_DIR}/${env}.cookie"

  echo ""
  echo "Setting cookie for environment: $env"
  echo ""
  echo "Steps:"
  echo "  1. Open the Kibana URL for '$env' in your browser"
  echo "  2. Log in via SSO"
  echo "  3. DevTools → Application → Cookies"
  echo "  4. Copy the 'ccssession' cookie VALUE (not name)"
  echo ""

  if [[ -t 0 ]]; then
    # Interactive — read from terminal
    echo "Paste the ccssession value below (then press Enter):"
    read -r cookie_value
  else
    # Piped input
    read -r cookie_value
  fi

  [[ -z "$cookie_value" ]] && die "Empty cookie value"

  # Strip any accidental name= prefix
  cookie_value="${cookie_value#ccssession=}"
  cookie_value="${cookie_value#sid=}"

  echo -n "$cookie_value" > "$cookie_file"
  chmod 600 "$cookie_file"
  info "Cookie saved: $cookie_file ($(wc -c < "$cookie_file" | tr -d ' ') bytes)"
}

add_env() {
  local env="$1"
  local url="$2"
  local cookie_path="~/.ordertech-elk/cookies/${env}.cookie"

  if grep -q "^${env}:" "$ENV_FILE" 2>/dev/null; then
    info "Environment '$env' already exists in $ENV_FILE"
    return 0
  fi

  cat >> "$ENV_FILE" <<ENTRY

${env}:
  name: ${env}
  url: ${url}
  cookie: ${cookie_path}
ENTRY
  info "Added environment '$env' → $url"
  info "Cookie path: $cookie_path"
  echo ""
  read -rp "Set the cookie now? [Y/n] " yn
  case "$yn" in
    [Nn]*) info "Skipped. Set it later: elk-setup.sh --set-cookie $env" ;;
    *)     set_cookie "$env" ;;
  esac
}

# ── Main ─────────────────────────────────────────────────────────────────────
case "${1:-}" in
  --set-cookie)
    [[ -z "${2:-}" ]] && die "Usage: elk-setup.sh --set-cookie <env>"
    ensure_dirs
    set_cookie "$2"
    ;;
  --sso-login)
    shift
    # Delegate to elk-sso-login.py (pass remaining args: --env, --headed, etc.)
    exec python3 "${SCRIPT_DIR}/elk-sso-login.py" "$@"
    ;;
  --install-sso)
    exec python3 "${SCRIPT_DIR}/elk-sso-login.py" --install
    ;;
  --add-env)
    [[ -z "${2:-}" || -z "${3:-}" ]] && die "Usage: elk-setup.sh --add-env <name> <url>"
    ensure_dirs
    create_default_config
    add_env "$2" "$3"
    ;;
  --help|-h)
    cat <<EOF
elk-setup.sh — Bootstrap OrderTech ELK configuration

Usage:
  elk-setup.sh                           Interactive setup (creates config + sets prod cookie)
  elk-setup.sh --set-cookie <env>        Set/refresh cookie for an environment (manual paste)
  elk-setup.sh --sso-login [--env ...]   SSO login via browser (automated cookie refresh)
  elk-setup.sh --install-sso             Install Playwright + Chromium for SSO login
  elk-setup.sh --add-env <name> <url>    Add a new environment

SSO login (recommended):
  elk-setup.sh --install-sso             One-time: install browser automation
  elk-setup.sh --sso-login               Refresh prod cookie via SSO
  elk-setup.sh --sso-login --env lower   Refresh lower env cookie via SSO
  elk-setup.sh --sso-login --env prod lower  Refresh both

  First run opens a browser for SSO. Later runs are headless (automatic).

Config: ${CONFIG_DIR}/
  environments.yaml    Environment definitions (URLs + cookie paths)
  cookies/             Cookie files (mode 600, gitignored)
  browser-state/       Playwright session data (for SSO login)
EOF
    exit 0
    ;;
  *)
    # Full interactive setup
    info "Setting up OrderTech ELK configuration..."
    echo ""
    echo "  This will configure ELK log search for prod + lower environments."
    echo "  Requires: VPN connected, curl, jq, python3."
    echo ""
    ensure_dirs
    create_default_config

    # Check if Playwright is installed
    has_playwright=false
    if python3 -c "import playwright" 2>/dev/null; then
      has_playwright=true
    fi

    # Check if prod cookie exists
    if [[ ! -f "${COOKIE_DIR}/prod.cookie" || ! -s "${COOKIE_DIR}/prod.cookie" ]]; then
      if $has_playwright; then
        echo ""
        read -rp "Log in to Production via SSO? [Y/n] " yn
        case "$yn" in
          [Nn]*) info "Skipped. Set it later: elk-setup.sh --sso-login" ;;
          *)     exec python3 "${SCRIPT_DIR}/elk-sso-login.py" --headed ;;
        esac
      else
        echo ""
        echo "Playwright not installed. Choose:"
        echo "  a) Install Playwright now (recommended — enables automated SSO)"
        echo "  b) Paste cookie manually"
        echo "  c) Skip (set up later)"
        read -rp "Choice [a/b/c]: " choice
        case "$choice" in
          [aA])
            python3 "${SCRIPT_DIR}/elk-sso-login.py" --install
            echo ""
            info "Now logging in to Production..."
            exec python3 "${SCRIPT_DIR}/elk-sso-login.py" --headed
            ;;
          [bB]) set_cookie prod ;;
          *)    info "Skipped. Set it later: elk-setup.sh --sso-login" ;;
        esac
      fi
    else
      info "Production cookie already exists ($(wc -c < "${COOKIE_DIR}/prod.cookie" | tr -d ' ') bytes)"

      # Check lower cookie
      if [[ ! -f "${COOKIE_DIR}/lower.cookie" || ! -s "${COOKIE_DIR}/lower.cookie" ]]; then
        echo ""
        read -rp "Log in to Lower environment via SSO? [Y/n] " yn
        case "$yn" in
          [Nn]*) info "Skipped. Set it later: elk-setup.sh --sso-login --env lower" ;;
          *)
            if $has_playwright; then
              exec python3 "${SCRIPT_DIR}/elk-sso-login.py" --env lower --headed
            else
              info "Playwright not installed. Run: elk-setup.sh --install-sso"
            fi
            ;;
        esac
      else
        info "Lower cookie already exists ($(wc -c < "${COOKIE_DIR}/lower.cookie" | tr -d ' ') bytes)"
      fi
    fi

    echo ""
    info "Setup complete!"
    echo ""
    echo "  Config:  $ENV_FILE"
    echo "  Cookies: $COOKIE_DIR/"
    echo ""
    echo "Next steps:"
    echo "  1. Verify:  elk-query.sh envs"
    echo "  2. Test:    elk-query.sh search --size 1 --hours 1"
    echo "  3. Lower:   elk-query.sh --env lower search --size 1 --hours 1"
    echo ""
    echo "Cookie refresh (run daily or when expired):"
    echo "  elk-setup.sh --sso-login --env prod lower"
    ;;
esac
