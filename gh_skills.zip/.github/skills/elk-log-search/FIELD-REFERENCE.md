# ELK Field Reference — order-tech-* (Kibana 7.17.9)

> **Purpose:** Authoritative guide for composing precise ELK queries.  
> Use this instead of generic full-text searches whenever posible.  
> Last refreshed: 2026-04-08 from live prod index (24h sample).

---

## Query strategy decision tree

```
User asks about...
│
├─ A specific service?          → term on serviceName.keyword  (use wildcard for partial)
├─ Error/log level?             → term on level.keyword
├─ Request/response logs?       → term on logType.keyword
├─ A datacenter?                → term on datacenter.keyword
├─ HTTP status codes?           → term on status.keyword  (numeric e.g. "500")
│                               → OR statusCode.keyword   (Spring enum e.g. "INTERNAL_SERVER_ERROR")
├─ A sales channel?             → term on SalesChannel.keyword
├─ A request trace?             → term on GlobalTrackingId (text match, two spellings!)
├─ Exception/error message?     → match/query_string on message field (free text)
├─ A specific API path?         → wildcard on uri.keyword  (e.g. "/api/customer/*")
├─ Downstream/feign calls?      → term on logType.keyword = "DOWNSTREAM_REQUEST" or "FEIGN_REQUEST"
└─ Across all text?             → query_string on message (last resort, expensive)
```

---

## Tier 1 — Enum filters (use `term` with `.keyword`, aggregatable)

### `level.keyword`
Log severity. Always use `term` filter, never free text.

| Value | Count (24h) | Notes |
|---|---|---|
| `INFO` | 1.7B | Default; most volume |
| `WARN` | 101M | Degraded behavior |
| `ERROR` | 28M | Failures requiring attention |
| `TRACE` | 17M | Per-step trace logging |
| `DEBUG` | 3.8M | Verbose debug output |

**Query example:**
```json
{ "term": { "level.keyword": "ERROR" } }
```

---

### `logType.keyword`
Classifies the log entry type. Critical for scoping to request/response pairs.

| Value | Count (24h) | What it contains |
|---|---|---|
| `STANDARD` | 806M | Generic service logs, exceptions, business events |
| `API_REQUEST` | 213M | Inbound HTTP request BEGIN (headers, method, uri) |
| `API_RESPONSE` | 213M | Inbound HTTP response END (statusCode, duration) |
| `DOWNSTREAM_REQUEST` | 132M | Outbound HTTP call (to another service) |
| `DOWNSTREAM_RESPONSE` | 132M | Outbound HTTP response received |
| `FEIGN_REQUEST` | 128M | Feign client request |
| `FEIGN_RESPONSE` | 128M | Feign client response |

**Key pairs:**
- Inbound: `API_REQUEST` + `API_RESPONSE` — correlated by `requestId`
- Outbound: `DOWNSTREAM_REQUEST` + `DOWNSTREAM_RESPONSE` — correlated by `threadContextId`
- Feign: `FEIGN_REQUEST` + `FEIGN_RESPONSE` — correlated by `threadContextId`

**Query example — only inbound requests:**
```json
{ "terms": { "logType.keyword": ["API_REQUEST", "API_RESPONSE"] } }
```

---

### `datacenter.keyword`
Physical deployment location.

| Value | Count (24h) | Notes |
|---|---|---|
| `wc-g2` | 708M | West Coast Gen2 (highest volume) |
| `po-g2` | 508M | Portland Gen2 |
| `as-g7` | 454M | Ashburn Gen7 |
| `as-g6` | 200M | Ashburn Gen6 |
| `g3` | 3.3M | Gen3 (legacy) |
| `ho-g3` | 184K | Home Office Gen3 |
| `ch2-g2` | 65K | Chicago Gen2 |
| `as-g8` | 45K | Ashburn Gen8 |

**Query example:**
```json
{ "term": { "datacenter.keyword": "as-g7" } }
```

---

### `environment.keyword`
Deployment environment.

| Value | Count (24h) | Notes |
|---|---|---|
| `mbosProd` | 1.8B | **Primary production** |
| `ot-ops-prod` | 51M | OT Ops production |
| `mpa-prod` | 597K | MPA production |
| `mbosPreprod` | 27K | Pre-production |
| `otQa` | 18K | QA |
| `mpa-stage` / `mbosStage` | ~14K each | Staging |
| `mbosPerf` | 14K | Performance |
| `mbosDev` / `mbosCi` | ~12K each | Dev/CI |

**For production investigations, always add:**
```json
{ "term": { "environment.keyword": "mbosProd" } }
```

**For lower env investigations, filter by target environment:**
```json
{ "term": { "environment.keyword": "mbosStage" } }
```

Lower env values: `mbosStage` · `mbosQa` · `mbosDev` · `mbosPreprod` · `mbosCi` · `mbosPerf` · `otQa` · `mpa-stage`

---

### `SalesChannel.keyword`
Channel the request came from.

| Value | Count (24h) | Notes |
|---|---|---|
| `WEB` | 571M | Web portal |
| `TELESALES` | 319M | Call center agents |
| `RETAIL` | 107M | Retail stores |
| `XFINITY_APP` | 59M | Mobile app |
| `ONLINE` | 2.4M | Online self-service |
| `ETL` | 2.2M | Batch/ETL jobs |
| `MOBILE` | 1.7M | Mobile web |
| `XM360` | 529K | XM360 channel |

---

### `TenantId.keyword`
Account/service type.

| Value | Count (24h) | Notes |
|---|---|---|
| `POSTPAID` | 45M | Postpaid accounts |
| `PREPAID` | 2.3M | Prepaid accounts |
| `TRIAL` | 1.6M | Trial accounts |
| `ORION` | 14K | Orion platform |

---

### `method.keyword`
HTTP method (inbound requests).

| Value | Count (24h) |
|---|---|
| `GET` | 503M |
| `POST` | 148M |
| `PUT` | 6.8M |
| `PATCH` | 1.2M |
| `DELETE` | 57K |

---

### `status.keyword`
HTTP numeric status code (from `API_RESPONSE` logType).

| Value | Meaning | Count (24h) |
|---|---|---|
| `200` | OK | 216M |
| `204` | No Content | 9M |
| `404` | Not Found | 5.9M |
| `202` | Accepted | 1M |
| `500` | Internal Server Error | 456K |
| `400` | Bad Request | 312K |
| `201` | Created | 198K |
| `405` | Method Not Allowed | 58K |
| `422` | Unprocessable Entity | 45K |
| `502` | Bad Gateway | 4K |
| `429` | Too Many Requests | 4K |
| `403` | Forbidden | 3.5K |
| `503` | Service Unavailable | 3.4K |
| `409` | Conflict | 1.9K |
| `401` | Unauthorized | 1.2K |

**For error investigations:** filter `status.keyword` in `["400","500","502","503","504","429"]`

---

### `statusCode.keyword`
Spring `HttpStatus` enum name (on `API_RESPONSE` logType). Parallel to `status`.

| Value | HTTP Equivalent |
|---|---|
| `INTERNAL_SERVER_ERROR` | 500 |
| `BAD_REQUEST` | 400 |
| `NOT_FOUND` | 404 |
| `NO_CONTENT` | 204 |
| `ACCEPTED` | 202 |
| `CREATED` | 201 |
| `FORBIDDEN` | 403 |
| `UNAUTHORIZED` | 401 |
| `GATEWAY_TIMEOUT` | 504 |
| `BAD_GATEWAY` | 502 |
| `SERVICE_UNAVAILABLE` | 503 |
| `REQUEST_TIMEOUT` | 408 |
| `CONFLICT` | 409 |
| `UNPROCESSABLE_ENTITY` | 422 |
| `PRECONDITION_FAILED` | 412 |

> **Prefer `status.keyword`** for numeric codes; use `statusCode.keyword` when the user says the Spring enum name.

---

## Tier 2 — ID / exact-match filters (high cardinality, use `term` or `wildcard`)

| Field | `.keyword`? | Use case | Query type |
|---|---|---|---|
| `serviceName` | `serviceName.keyword` | Filter to one service | `wildcard: "*bo-account*"` (partial) or `term` (exact) |
| `configLabel` | `configLabel.keyword` | Service build name = exact deployed artifact version. The value IS the config branch/tag name — use directly for git checkout. Prefixes vary: `mbos-`, `ds-`, `bo-`, `wkfl-`, `xoms-`, `mbo-`. | `term: "mbos-bo-account-1.0.817"` |
| `GlobalTrackingId` | text only — use `match` | Trace a request across services | `match` or `query_string` |
| `globaltrackingid` | `globaltrackingid.keyword` | Same field, lowercase variant | `term` |
| `threadContextId` | `threadContextId.keyword` | Correlate request/response pairs | `term` |
| `requestId` | `requestId.keyword` | Unique per-request ID | `term` |
| `logger_name` | `logger_name.keyword` | Filter to a specific Java class | `term` or `wildcard` |
| `uri` | `uri.keyword` | Exact API path | `term` or `wildcard: "/api/customer/*"` |
| `url_path` | `url_path.keyword` | URL path (nginx layer) | `wildcard` |
| `comcastAccountNumber` | `comcastAccountNumber.keyword` | Account investigation | `term` |
| `locationId` | `locationId.keyword` | Location filter | `term` |
| `code` | `code.keyword` | Business/error code | `term` |
| `offerId` | `offerId.keyword` | Offer ID | `term` |
| `serialNumber` | `serialNumber.keyword` | Device serial | `term` |
| `domain` | `domain.keyword` | Downstream service domain | `term` or `wildcard` |

> **Tracing warning:** `GlobalTrackingId` (mixed case, text) and `globaltrackingid.keyword` (lowercase) are two separate fields. Always search BOTH:
> ```json
> { "bool": { "should": [
>   { "match": { "GlobalTrackingId": "<id>" } },
>   { "term":  { "globaltrackingid.keyword": "<id>" } }
> ], "minimum_should_match": 1 } }
> ```

---

## Tier 3 — Free text only (no `.keyword`, use `match` or `query_string`)

| Field | What's in it | When to use |
|---|---|---|
| `message` | Full JSON blob of the log event including all fields | Exception messages, stack traces, any keyword not in a dedicated field |
| `LogEventMessage` | Short human-readable summary (not always present) | Quick title-level grep; absent on many STANDARD logs |
| `tags` | Logstash processing tags | Rarely useful |
| `Origin` | HTTP Origin header | CORS investigations |
| `Client-Id` | API client identity | Client-level investigations |
| `SessionId` | User session | Session correlation (no keyword — use `match`) |
| `duration` | Response time string | Present on API_RESPONSE; **not numeric** — use `match` for range workarounds |

> **Note on `message`:** It is a serialized JSON string. Use `query_string` with wildcards:
> ```json
> { "query_string": { "query": "NullPointerException", "fields": ["message"] } }
> ```

---

## Time field

| Field | Type | Notes |
|---|---|---|
| `@timestamp` | `date` | Always use for time range filters. Format: ISO-8601 or `now-Nh` |

**Standard time filter (always include):**
```json
{ "range": { "@timestamp": { "gte": "now-1h" } } }
```

---

## serviceName naming convention

Services follow the pattern: `{datacenter}-{service-slug}-{environment-suffix}`

Examples:
- `g2po-biller-account-production` → datacenter `po-g2`, service `biller-account`, env prod  
- `g7as-mvno-account-production` → datacenter `as-g7`, service `mvno-account`, env prod
- `g2wc-customer-gateway-production` → datacenter `wc-g2`, service `customer-gateway`, env prod

**To find all instances of a service across datacenters, use `wildcard`:**
```json
{ "wildcard": { "serviceName.keyword": "*biller-account*" } }
```

### Resolving user-provided service names to ELK slugs

The `serviceName` field uses the **cf_app_name** from deployment, which often
differs from the `service` key (e.g., user says "bo-account" but ELK uses
`biller-account`). Do NOT guess — use the authoritative lookup chain:

1. **Primary** — local `service_mappings.json` (225 services):
   ```bash
   jq -r '.services[] | select(.service == "<slug>" or .cf_app_name == "<slug>") | .cf_app_name' \
     .github/shared/service_mappings.json
   ```
2. **Naming traps & full resolution chain** — see `code-forensics/NAMING-AND-RESOLUTION.md`.
3. **DC prefix table** — see `INVESTIGATION-BRAIN.md` Section 1.

> **Do not hardcode alias tables.** The 225-service `service_mappings.json` and
> `code-forensics/NAMING-AND-RESOLUTION.md` naming traps are the single sources of truth.

---

## Query composition recipes

### 1. Errors for a service in the last 2 hours
```json
{
  "query": { "bool": { "filter": [
    { "range":    { "@timestamp":       { "gte": "now-2h" } } },
    { "wildcard": { "serviceName.keyword": "*biller-account*" } },
    { "term":     { "level.keyword":    "ERROR" } }
  ]}},
  "sort": [{ "@timestamp": { "order": "desc" } }],
  "size": 50
}
```

### 2. Trace a request by GlobalTrackingId
```json
{
  "query": { "bool": { "filter": [
    { "range": { "@timestamp": { "gte": "now-24h" } } }
  ], "should": [
    { "match": { "GlobalTrackingId": "<tracking-id>" } },
    { "term":  { "globaltrackingid.keyword": "<tracking-id>" } },
    { "match": { "threadContextId": "<tracking-id>" } }
  ], "minimum_should_match": 1 }},
  "sort": [{ "@timestamp": { "order": "asc" } }],
  "size": 200
}
```

### 3. 5xx errors from TELESALES channel
```json
{
  "query": { "bool": { "filter": [
    { "range": { "@timestamp": { "gte": "now-1h" } } },
    { "term":  { "logType.keyword":     "API_RESPONSE" } },
    { "term":  { "SalesChannel.keyword": "TELESALES" } },
    { "terms": { "status.keyword":      ["500","502","503","504"] } }
  ]}},
  "size": 50
}
```

### 4. Downstream timeouts from a service
```json
{
  "query": { "bool": { "filter": [
    { "range":    { "@timestamp":        { "gte": "now-1h" } } },
    { "wildcard": { "serviceName.keyword": "*customer-gateway*" } },
    { "terms":    { "logType.keyword":   ["DOWNSTREAM_RESPONSE", "FEIGN_RESPONSE"] } },
    { "terms":    { "statusCode.keyword": ["GATEWAY_TIMEOUT","SERVICE_UNAVAILABLE","REQUEST_TIMEOUT"] } }
  ]}},
  "size": 50
}
```

### 5. Top error-count by service (aggregation)
```json
{
  "size": 0,
  "query": { "bool": { "filter": [
    { "range": { "@timestamp": { "gte": "now-1h" } } },
    { "term":  { "level.keyword": "ERROR" } }
  ]}},
  "aggs": {
    "by_service": {
      "terms": { "field": "serviceName.keyword", "size": 20, "order": { "_count": "desc" } }
    }
  }
}
```

### 6. Exception message full-text search
```json
{
  "query": { "bool": { "filter": [
    { "range": { "@timestamp": { "gte": "now-1h" } } },
    { "term":  { "level.keyword": "ERROR" } }
  ], "must": [
    { "query_string": { "query": "NullPointerException OR TimeoutException", "fields": ["message"] } }
  ]}},
  "size": 50
}
```

### 7. Slow responses (duration contains a value — string field workaround)
```json
{
  "query": { "bool": { "filter": [
    { "range":    { "@timestamp":        { "gte": "now-1h" } } },
    { "term":     { "logType.keyword":   "API_RESPONSE" } },
    { "wildcard": { "serviceName.keyword": "*payment*" } }
  ]}},
  "_source": ["@timestamp","serviceName","duration","uri","status","GlobalTrackingId"],
  "sort": [{ "@timestamp": { "order": "desc" } }],
  "size": 50
}
```

---

## Index patterns available

| Pattern | Content |
|---|---|
| `order-tech-*` | **Primary** — all OrderTech microservice logs (API, downstream, BPMN, standard) |
| `bis-prod-*` | BIS (Business Intelligence Service) logs |
| `nginx-prod-*` | NGINX / load balancer access logs |
| `vendor-proxy-prod-*` | Vendor proxy layer logs |
| `bom-prod-*` | BOM (Bill of Materials) service logs |

> Default index for all queries: **`order-tech-*`**
> Switch with `--index <pattern>` in `elk-query.sh` or `"index"` param in raw queries.

---

## Tableau → ELK Service Name Mapping

When an investigation starts from a Tableau dashboard (stuck orders, fallout reports),
the service names in Tableau often differ from ELK `serviceName` slugs. Use this table
to translate. For the full 225-service mapping, use `service_mappings.json`.

| Tableau Label | ELK Service Slug | Notes |
|---|---|---|
| `OTT Fulfillment` / `ott-fulfillment` | `ott-fulfillment` | Direct match |
| `Lean Orchestrator` | `lean-orchestrator` | Tableau uses space-separated |
| `Billing Order` / `BillingOrder` | `billing-order` | wkfl-billing-order in serviceName |
| `XOMS Order Review` / `Order Review` | `xoms-order-review` | wkfl-xoms-order-review in serviceName |
| `XOMS Biller` | `xoms-biller` | |
| `BO Account` / `Biller Account` | `biller-account` | Tableau "BO" = ELK "biller" |
| `Subscriber` / `Subscriber Service` | `subscriber` | |
| `Customer Gateway` | `customer-gateway` | |
| `Equipment Fulfillment` | `equipment-fulfillment` | |
| `MVNO Account` | `mvno-account` | |
| `Payment Service` | `payment` | Tableau has "Service" suffix |

> **Do not hardcode new aliases here.** If a Tableau label is not in this table,
> use the resolution chain: `service_mappings.json` → `code-forensics/NAMING-AND-RESOLUTION.md`.
> Update this table only after confirming the mapping is correct and stable.
