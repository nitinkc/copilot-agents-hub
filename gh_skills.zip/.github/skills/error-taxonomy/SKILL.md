---
name: error-taxonomy
description: >
  Standardized error classification for OrderTech microservices. Provides an
  8-category, 30+ subcategory taxonomy for classifying production errors.
  Used by quick-triage, rca-synthesis, and blast-radius skills.
---

# Skill: Error Taxonomy

## Goal

Classify any production error into a standardized category and subcategory
to drive severity mapping, investigation routing, and prevention planning.

## Inputs

| Input | Source | Required |
|---|---|---|
| Error message or exception class | ELK logs or user-provided | Yes |
| Stack trace (if available) | ELK `message` field | No |
| Service name | ELK `serviceName.keyword` | No |

## When to Use

- Classifying errors found in ELK logs
- Assigning severity to incidents
- Routing investigation to the right skill/team
- Comparing error patterns across services

## Step 0 — Load ELK Knowledge

If classifying an error from ELK logs, also load:
```
read_file .github/skills/elk-log-search/FIELD-REFERENCE.md
```

## Classification Rules

1. Classify by the **root exception**, not the wrapper. `HttpServerErrorException`
   wrapping a `NullPointerException` is **DATA**, not **CONNECTION**.
2. If multiple categories apply, use the **deepest cause** category.
3. **BUSINESS_LOGIC** takes precedence over **DATA** when the validation is a
   business rule.
4. **EXTERNAL** takes precedence when the error originates outside our codebase.
5. **RESOURCE_EXHAUSTION** is a contributing factor, rarely a root cause. Always
   ask: "What caused the exhaustion?"

## Level 1: Error Categories

### 1. CONNECTION

Failures in establishing or maintaining network connections between services.

| Subcategory | Common Exceptions | Typical Root Cause |
|-------------|-------------------|-------------------|
| Refused | `ConnectException: Connection refused` | Target service down, wrong port, firewall |
| Reset | `SocketException: Connection reset` | Target crashed mid-request, load balancer eviction |
| DNS | `UnknownHostException` | DNS resolution failure, service discovery issue |
| TLS/SSL | `SSLHandshakeException`, `CertificateException` | Expired cert, CA mismatch, TLS version incompatibility |

**ELK signals**: `logType=DOWNSTREAM_RESPONSE` or `FEIGN_RESPONSE` with error
statusCode, `message` containing "Connection refused" or "Connection reset".

### 2. TIMEOUT

Operations exceeding configured time limits.

| Subcategory | Common Exceptions | Typical Root Cause |
|-------------|-------------------|-------------------|
| Connect | `ConnectTimeoutException` | Target overloaded, network latency |
| Read | `SocketTimeoutException`, `ReadTimeoutException` | Slow processing, database lock, long GC pause |
| Gateway | `504 Gateway Timeout` | Proxy/LB timeout before backend responds |
| Circuit Open | `CircuitBreakerOpenException`, `CallNotPermittedException` | Downstream failures exceeded threshold |
| Lock | `LockTimeoutException` | Database lock contention |

**ELK signals**: `statusCode.keyword` = `GATEWAY_TIMEOUT` or `REQUEST_TIMEOUT`,
`status.keyword` = `504` or `408`, high `duration` values, `message` containing
"timeout" or "CircuitBreaker".

### 3. DATA

Errors related to invalid, unexpected, or corrupt data.

| Subcategory | Common Exceptions | Typical Root Cause |
|-------------|-------------------|-------------------|
| NullReference | `NullPointerException` | Missing data, incomplete initialization |
| Validation | `ConstraintViolationException`, `MethodArgumentNotValid` | Invalid input, schema violation |
| Serialization | `JsonParseException`, `HttpMessageNotReadableException` | Malformed JSON/XML, encoding issue |
| Integrity | `DataIntegrityViolationException` | Unique constraint, FK violation |
| Type | `ClassCastException`, `NumberFormatException` | Wrong data type, mapping error |
| Stale | `OptimisticLockingFailureException`, `StaleObjectStateException` | Concurrent modification |

**ELK signals**: `level=ERROR` with `message` containing exception class names,
`status.keyword` = `400` or `422`, `statusCode.keyword` = `BAD_REQUEST` or
`UNPROCESSABLE_ENTITY`.

### 4. AUTHENTICATION & AUTHORIZATION

Security-related access failures.

| Subcategory | Common Exceptions | Typical Root Cause |
|-------------|-------------------|-------------------|
| Unauthenticated | `401 Unauthorized`, `AuthenticationException` | Missing/invalid/expired token |
| Unauthorized | `403 Forbidden`, `AccessDeniedException` | Insufficient permissions/role |
| Token | `JwtException`, `TokenExpiredException` | Token lifecycle, clock skew |
| Certificate | `CertificateExpiredException` | mTLS cert rotation failure |

**ELK signals**: `status.keyword` = `401` or `403`, `statusCode.keyword` =
`UNAUTHORIZED` or `FORBIDDEN`.

### 5. RESOURCE EXHAUSTION

System resources depleted.

| Subcategory | Common Exceptions | Typical Root Cause |
|-------------|-------------------|-------------------|
| Memory | `OutOfMemoryError` | Memory leak, oversized payload, insufficient heap |
| Threads | `RejectedExecutionException` | Thread pool saturated |
| Connections | `ConnectionPoolTimeoutException` | Connection leak, pool too small, slow queries |
| Disk | `IOException: No space left` | Log rotation failure, temp file accumulation |
| File Descriptors | `Too many open files` | Socket/file handle leak |

**ELK signals**: `message` containing "OutOfMemoryError", "RejectedExecution",
"pool", "exhausted". Often correlated with increasing error rates and latency.

### 6. EXTERNAL DEPENDENCY

Failures originating from systems outside our platform.

| Subcategory | Common Exceptions | Typical Root Cause |
|-------------|-------------------|-------------------|
| Vendor API | `502 Bad Gateway`, `503 Service Unavailable` | Vendor outage, rate limiting |
| Database | `JDBCConnectionException`, `TransactionSystemException` | DB overload, replication lag |
| Message Queue | `AmqpException`, `KafkaException` | Broker unavailable, partition rebalance |
| Cache | `RedisConnectionException` | Redis cluster issue |

**ELK signals**: `status.keyword` = `502` or `503`, `logType=DOWNSTREAM_RESPONSE`
or `FEIGN_RESPONSE` with error status, `message` containing vendor/external
service names.

### 7. BUSINESS LOGIC

Failures in business rule execution or workflow processing.

| Subcategory | Common Exceptions | Typical Root Cause |
|-------------|-------------------|-------------------|
| Rule Violation | `BusinessRuleException` | Invalid state transition, constraint check |
| Workflow | `BpmnError`, `FlowableException` | BPMN process error, delegate failure |
| State | `IllegalStateException` | Invalid lifecycle state, race condition |
| Idempotency | `DuplicateRequestException` | Retry delivered duplicate, missing idempotency key |
| DRL Rule | `RuleEvaluationException` | Drools rule failure, missing fact |

**ELK signals**: `message` containing "BpmnError", "FlowableException",
"BusinessRule", "IllegalState". Domain-specific error codes in `code.keyword`.

### 8. INFRASTRUCTURE

Platform/infrastructure-level failures.

| Subcategory | Common Exceptions | Typical Root Cause |
|-------------|-------------------|-------------------|
| K8s | `CrashLoopBackOff`, `OOMKilled` | Container resource limits, startup failures |
| Config | `BeanCreationException`, `ConfigurationException` | Missing config, invalid property |
| Deployment | `ImagePullBackOff`, `ErrImagePull` | Bad image tag, registry auth issue |
| Network Policy | `ConnectionRefused` (intermittent, specific pods) | K8s network policy misconfiguration |

**ELK signals**: Service completely absent from logs (no entries at all),
`message` containing "BeanCreation", "ApplicationContext" failures during startup.

## Severity Mapping

| Category + Context | Default Severity |
|---|---|
| Any + customer-facing + data loss | S1-Blocker |
| Any + customer-facing + feature unavailable | S2-Critical |
| Any + customer-facing + degraded experience | S3-Major |
| Any + internal only | S4-Minor |
| RESOURCE_EXHAUSTION (any) | S2-Critical (can cascade) |
| BUSINESS_LOGIC + Workflow (stuck processes) | S2-Critical |
| TIMEOUT + Circuit Open (cascading) | S2-Critical |
| EXTERNAL + single vendor | S3-Major (if fallback exists) |

## ELK Query for Error Classification

To classify errors for a service, fetch a sample and examine the exception:

```bash
ELK=".github/skills/elk-log-search/scripts/elk-query.sh"
$ELK errors --service <service-slug> --hours 1 --size 20
```

Then parse the `message` JSON for `exception` and `LogEventMessage` fields.
Map the exception class to the taxonomy above.

## Output Contract

When classifying an error, produce:

```yaml
error_classification:
  category: "CONNECTION" | "TIMEOUT" | "DATA" | "AUTH" | "RESOURCE_EXHAUSTION" | "EXTERNAL" | "BUSINESS_LOGIC" | "INFRASTRUCTURE"
  subcategory: string           # From the subcategory column above
  root_exception: string        # Java exception class name
  severity: "S1-Blocker" | "S2-Critical" | "S3-Major" | "S4-Minor"
  confidence: float             # 0.0-1.0
  evidence: string              # Log entry or code reference supporting the classification
  notes: string[]               # Any classification ambiguities or caveats
```
