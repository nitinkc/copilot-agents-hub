#!/usr/bin/env python3
"""
snow-sso-login.py — Automated SSO cookie refresh for ServiceNow

Uses Playwright (headless Chromium) with persistent browser state so
Azure AD SSO only needs to be completed once interactively. Subsequent
runs reuse the saved session and refresh the cookie headlessly.

Flow:
  1. First run: opens visible Chromium → user completes Azure AD SSO/MFA
  2. Playwright saves session to ~/.ordertech-snow/browser-state/
  3. Later runs: headless → Azure AD auto-renews → no interaction needed
  4. If session expires, falls back to visible browser automatically

Prerequisites:
    pip3 install playwright
    python3 -m playwright install chromium

Usage:
    python3 snow-sso-login.py                  # login (default)
    python3 snow-sso-login.py --headed         # force visible browser
    python3 snow-sso-login.py --verify         # test saved cookie
    python3 snow-sso-login.py --install        # install dependencies
"""

import argparse
import os
import shutil
import sys
import time
from pathlib import Path

# ── Constants ────────────────────────────────────────────────────────────────
CONFIG_DIR = Path.home() / ".ordertech-snow"
BROWSER_STATE_DIR = CONFIG_DIR / "browser-state"
COOKIE_FILE = CONFIG_DIR / "snow.cookie"

SNOW_INSTANCE = os.environ.get("SNOW_INSTANCE", "comcast.service-now.com")
SNOW_BASE_URL = "https://" + SNOW_INSTANCE

# Cookies required for JSONv2 API authentication
REQUIRED_COOKIES = ["JSESSIONID", "glide_session_store"]
OPTIONAL_COOKIES = [
    "glide_sso_id", "glide_user_route", "glide_user_activity",
    "glide_node_id_for_js", "BIGipServerpool_comcast",
]

NAV_TIMEOUT_MS = 90_000          # 90s for initial page load (VPN + SSO redirects)
SSO_WAIT_TIMEOUT_MS = 300_000    # 5 min for user to complete MFA
POST_LOGIN_SETTLE_S = 5          # seconds to wait after redirect (SNOW is slow)
VERIFY_TIMEOUT_S = 30            # timeout for cookie verification request

USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15"
)


# ── Install ──────────────────────────────────────────────────────────────────
def install_deps():
    """Install Playwright and Chromium."""
    import subprocess
    print("Installing playwright...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "playwright"])
    print("\nInstalling Chromium browser...")
    subprocess.check_call([sys.executable, "-m", "playwright", "install", "chromium"])
    print("\nDone! You can now run:")
    print("  python3 snow-sso-login.py")


# ── Cookie verification ─────────────────────────────────────────────────────
def verify_cookie():
    """Verify a saved cookie works by making a test JSONv2 API call.
    Returns True if the cookie is valid, False otherwise."""
    import subprocess

    if not COOKIE_FILE.exists():
        print("  \u2717 Cookie file missing: {}".format(COOKIE_FILE))
        return False

    cookie_val = COOKIE_FILE.read_text().strip()
    if not cookie_val:
        print("  \u2717 Cookie file empty: {}".format(COOKIE_FILE))
        return False

    # Use JSONv2 API — lightweight query for 1 record
    test_url = "{}/incident.do?JSONv2&sysparm_query=active=true&sysparm_record_count=1&sysparm_fields=number".format(
        SNOW_BASE_URL
    )

    try:
        result = subprocess.run(
            [
                "curl", "-sS", "--max-time", str(VERIFY_TIMEOUT_S),
                "-o", "/dev/null", "-w", "%{http_code}",
                "-b", cookie_val,
                "-H", "Accept: application/json",
                "-H", "X-Requested-With: XMLHttpRequest",
                "-A", USER_AGENT,
                test_url,
            ],
            capture_output=True, text=True, timeout=VERIFY_TIMEOUT_S + 5,
        )
        http_code = result.stdout.strip()
        if http_code.startswith("2"):
            print("  \u2713 Cookie verified (HTTP {})".format(http_code))
            return True
        else:
            print("  \u2717 Cookie rejected (HTTP {})".format(http_code))
            return False
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as exc:
        print("  \u2717 Verification failed: {}".format(exc))
        return False


# ── SSO Login ────────────────────────────────────────────────────────────────

_RETRY_HEADED = object()  # sentinel: caller should retry with headed=True


def _print_manual_cookie_instructions():
    """Print instructions for manual cookie paste when browser can't launch."""
    print("\n{}".format("\u2500" * 60))
    print("  Browser cannot launch in this terminal.")
    print("  Paste the cookie manually instead:")
    print("{}".format("\u2500" * 60))
    print("\n  1. Open a regular terminal (not VS Code) and run:")
    print("     python3 {} --headed".format(Path(__file__).resolve()))
    print("\n  OR paste the cookie directly:")
    print("  1. Open {} in your browser".format(SNOW_BASE_URL))
    print("  2. Log in through Azure AD SSO")
    print("  3. DevTools (F12) \u2192 Network tab \u2192 any request \u2192 copy Cookie header")
    print("  4. Run: snow-query.sh set-cookie")
    print()


def _attempt_login(force_headed=False):
    """
    Single login attempt. Returns True on success, or _RETRY_HEADED
    if the caller should retry with a visible browser.
    """
    from playwright.sync_api import sync_playwright

    state_dir = BROWSER_STATE_DIR
    state_dir.mkdir(parents=True, exist_ok=True)
    COOKIE_FILE.parent.mkdir(parents=True, exist_ok=True)

    # Clean stale Chromium lock files left by crashed browser processes.
    for lock_file in ("SingletonLock", "SingletonSocket", "SingletonCookie"):
        lf = state_dir / lock_file
        if lf.exists() or lf.is_symlink():
            lf.unlink(missing_ok=True)

    login_url = SNOW_BASE_URL + "/login_locate_sso.do"

    # Decide headless vs headed
    has_saved_state = state_dir.exists() and any(
        p for p in state_dir.iterdir() if p.name not in ("SingletonLock", "SingletonSocket", "SingletonCookie")
    )
    use_headless = has_saved_state and not force_headed

    mode_str = "headless (saved session)" if use_headless else "interactive"
    print("\n{}".format("\u2500" * 60))
    print("  ServiceNow SSO Login")
    print("  Instance:  {}".format(SNOW_INSTANCE))
    print("  Mode:      {}".format(mode_str))
    print("{}".format("\u2500" * 60))
    print()

    with sync_playwright() as p:
        launch_args = ["--no-sandbox", "--disable-gpu"]
        try:
            browser = p.chromium.launch_persistent_context(
                user_data_dir=str(state_dir),
                headless=use_headless,
                user_agent=USER_AGENT,
                args=launch_args,
                accept_downloads=False,
                ignore_https_errors=True,
            )
        except Exception as exc:
            exc_name = type(exc).__name__
            if "TargetClosed" in exc_name or "BrowserClosed" in exc_name or "crash" in str(exc).lower():
                if use_headless:
                    print("Headless browser failed to launch: {}".format(exc_name))
                    return _RETRY_HEADED
                _print_manual_cookie_instructions()
                return False
            raise

        page = browser.pages[0] if browser.pages else browser.new_page()

        try:
            print("Opening {} ...".format(login_url))
            page.goto(login_url, wait_until="commit", timeout=NAV_TIMEOUT_MS)
            page.wait_for_load_state("domcontentloaded", timeout=NAV_TIMEOUT_MS)
            page.wait_for_timeout(3000)

            # Check if we already have the key session cookie (SSO auto-renewed)
            all_cookies_early = browser.cookies(SNOW_BASE_URL)
            early_cookie_map = {c["name"]: c["value"] for c in all_cookies_early}
            already_logged_in = "glide_session_store" in early_cookie_map

            if not already_logged_in:
                current_url = page.url
                on_snow_home = SNOW_INSTANCE in current_url and "login" not in current_url.split("?")[0].lower()

                if on_snow_home:
                    # Redirected to ServiceNow home but cookie not set yet — navigate to navpage to trigger it
                    print("On ServiceNow but session cookie not yet set — loading navpage ...")
                    page.goto(SNOW_BASE_URL + "/navpage.do", wait_until="domcontentloaded", timeout=NAV_TIMEOUT_MS)
                    time.sleep(POST_LOGIN_SETTLE_S)
                else:
                    # Still on login.do or redirected to SSO (Azure AD, ADFS, Okta, etc.)
                    if use_headless:
                        print("SSO session not available headlessly — switching to interactive browser ...")
                        browser.close()
                        return _RETRY_HEADED

                    # Headed mode: tell the user to complete SSO in the browser
                    print("\n  \u250c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2510")
                    print("  \u2502  Complete SSO login in the browser window.  \u2502")
                    print("  \u2502  This window will close automatically.      \u2502")
                    print("  \u2514\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2518")
                    print("  Current URL: {}".format(current_url[:80]))
                    print()

                    # Poll for glide_session_store cookie (SSO may redirect through
                    # Azure AD, ADFS, Okta, or any SAML/OIDC provider — we don't
                    # need to know the URL, just wait for the cookie to appear)
                    poll_interval_ms = 2000
                    max_polls = SSO_WAIT_TIMEOUT_MS // poll_interval_ms
                    for i in range(max_polls):
                        page.wait_for_timeout(poll_interval_ms)
                        poll_cookies = browser.cookies(SNOW_BASE_URL)
                        poll_map = {c["name"]: c["value"] for c in poll_cookies}
                        if "glide_session_store" in poll_map:
                            print("SSO completed! Waiting for page to settle...")
                            break
                        # Also check if we landed back on ServiceNow (non-login page)
                        cur = page.url
                        if SNOW_INSTANCE in cur and "login" not in cur.split("?")[0].lower():
                            print("Redirected back to ServiceNow — checking cookies...")
                            break
                    else:
                        print("Timed out waiting for SSO completion ({}s)".format(SSO_WAIT_TIMEOUT_MS // 1000))
                        browser.close()
                        return False

            # ServiceNow takes time to establish all session cookies after SSO
            # Navigate to a simple page to ensure all cookies are set
            page.goto(SNOW_BASE_URL + "/navpage.do", wait_until="domcontentloaded", timeout=NAV_TIMEOUT_MS)
            time.sleep(POST_LOGIN_SETTLE_S)

            # Extract all relevant cookies
            all_cookies = browser.cookies(SNOW_BASE_URL)
            cookie_map = {c["name"]: c["value"] for c in all_cookies}

            # Check required cookies are present
            missing = [name for name in REQUIRED_COOKIES if name not in cookie_map]
            if missing:
                avail = sorted(cookie_map.keys())
                print("ERROR: Required cookies missing: {}".format(missing))
                print("Cookies found: {}".format(avail))
                if use_headless:
                    browser.close()
                    return _RETRY_HEADED
                browser.close()
                return False

            # Build cookie string (required + optional)
            cookie_parts = []
            for name in REQUIRED_COOKIES + OPTIONAL_COOKIES:
                if name in cookie_map:
                    cookie_parts.append("{}={}".format(name, cookie_map[name]))

            cookie_string = "; ".join(cookie_parts)

            # Save
            COOKIE_FILE.write_text(cookie_string)
            try:
                COOKIE_FILE.chmod(0o600)
            except OSError:
                pass

            print("\n\u2713 Cookie saved: {}".format(COOKIE_FILE))
            print("  {} cookies, {} chars".format(len(cookie_parts), len(cookie_string)))

            # Show cookie names saved
            saved_names = [p.split("=")[0] for p in cookie_parts]
            print("  Cookies: {}".format(", ".join(saved_names)))

            # Show expiry of JSESSIONID if available
            jsession = next((c for c in all_cookies if c["name"] == "JSESSIONID"), None)
            if jsession and jsession.get("expires", 0) > 0:
                exp_local = time.strftime(
                    "%Y-%m-%d %H:%M:%S", time.localtime(jsession["expires"])
                )
                print("  JSESSIONID expires: {}".format(exp_local))

            # Verify the cookie actually works
            print("\n  Verifying cookie ...")
            if verify_cookie():
                return True
            else:
                print("  Cookie saved but verification failed.")
                if use_headless:
                    browser.close()
                    return _RETRY_HEADED
                return False

        except Exception as exc:
            print("ERROR: {}".format(exc))
            try:
                browser.close()
            except Exception:
                pass
            if use_headless:
                print("Retrying with visible browser ...")
                return _RETRY_HEADED
            _print_manual_cookie_instructions()
            return False

        finally:
            try:
                browser.close()
            except Exception:
                pass


def _nuke_browser_state():
    """Delete corrupted browser state directory and recreate it empty.
    Returns True if state was cleared, False if nothing to clear."""
    state_dir = BROWSER_STATE_DIR
    if state_dir.exists() and any(state_dir.iterdir()):
        size_mb = sum(
            f.stat().st_size for f in state_dir.rglob("*") if f.is_file()
        ) / (1024 * 1024)
        print("\nBrowser state appears corrupted ({:.0f} MB). Clearing {} ...".format(
            size_mb, state_dir
        ))
        shutil.rmtree(state_dir)
        state_dir.mkdir(parents=True, exist_ok=True)
        print("Browser state cleared \u2014 retrying with clean profile ...\n")
        return True
    return False


def do_login(force_headed=False):
    """
    Perform SSO login with automatic headless -> headed -> nuke-state-and-retry fallback.

    Recovery chain:
      1. Try headless (if saved session exists)
      2. If headless fails -> retry headed (interactive browser)
      3. If headed fails (browser crash) -> nuke corrupted browser state -> retry headed
      4. If still fails -> print manual instructions and exit
    """
    try:
        from playwright.sync_api import sync_playwright  # noqa: F401
    except ImportError:
        print("ERROR: playwright not installed.")
        print("Run:  python3 snow-sso-login.py --install")
        sys.exit(1)

    # Step 1: Try with current settings (headless if state exists)
    result = _attempt_login(force_headed=force_headed)

    # Step 2: Headless failed -> try headed
    if result is _RETRY_HEADED:
        result = _attempt_login(force_headed=True)

    # Step 3: Headed also failed -> corrupted state likely. Nuke and retry once.
    if result is _RETRY_HEADED or result is False:
        if _nuke_browser_state():
            result = _attempt_login(force_headed=True)

    # Step 4: All retries exhausted
    if result is _RETRY_HEADED or result is False:
        print("ERROR: All login attempts failed.")
        print("Try from a regular terminal (not VS Code):")
        print("  python3 {} --headed".format(Path(__file__).resolve()))
        sys.exit(1)

    return result


# ── Main ─────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description="ServiceNow — SSO cookie refresh",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s                   # refresh cookie (headless if session saved)
  %(prog)s --headed          # force visible browser
  %(prog)s --verify          # test saved cookie without re-logging in
  %(prog)s --install         # install playwright + chromium
        """,
    )
    parser.add_argument(
        "--headed", action="store_true",
        help="Force visible browser even if saved session exists",
    )
    parser.add_argument(
        "--install", action="store_true",
        help="Install Playwright and Chromium, then exit",
    )
    parser.add_argument(
        "--verify", action="store_true",
        help="Verify saved cookie works without re-logging in",
    )

    args = parser.parse_args()

    if args.install:
        install_deps()
        return

    if args.verify:
        print("  ServiceNow ({})".format(SNOW_INSTANCE))
        ok = verify_cookie()
        sys.exit(0 if ok else 1)

    do_login(force_headed=args.headed)


if __name__ == "__main__":
    main()
