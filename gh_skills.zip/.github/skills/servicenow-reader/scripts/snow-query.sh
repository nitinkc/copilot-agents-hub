#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────
# snow-query.sh — ServiceNow query tool (cookie-based auth)
#
# Auth: Uses browser session cookies stored in ~/.ordertech-snow/snow.cookie
# API:  JSONv2 (classic) — accepts session cookies unlike REST API
#
# Setup:
#   1. Log in to https://comcast.service-now.com in your browser
#   2. Run: snow-query.sh set-cookie
#   3. Follow the prompt to paste cookies from DevTools
#
# Usage:
#   snow-query.sh get-incident INC0012345
#   snow-query.sh get-change CHG0067890
#   snow-query.sh search-incidents "assignment_group.name=OrderTech^state!=7"
#   snow-query.sh search-changes "assignment_group.name=OrderTech"
#   snow-query.sh get-ci "order-tech"
#   snow-query.sh whoami
#   snow-query.sh set-cookie
# ─────────────────────────────────────────────────────────────────
set -euo pipefail

readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly SNOW_INSTANCE="${SNOW_INSTANCE:-comcast.service-now.com}"
readonly SNOW_BASE="https://${SNOW_INSTANCE}"
readonly CONFIG_DIR="$HOME/.ordertech-snow"
readonly COOKIE_FILE="${CONFIG_DIR}/snow.cookie"
readonly TIMEOUT=30
readonly MAX_RECORDS=50

# ─── Helpers ─────────────────────────────────────────────────────

die()  { echo "[ERROR] $*" >&2; exit 1; }
warn() { echo "[WARN] $*" >&2; }
info() { echo "[INFO] $*" >&2; }

check_cookie() {
  [[ -f "$COOKIE_FILE" ]] || die "No cookie file. Run: $0 set-cookie"
  local cookie
  cookie="$(cat "$COOKIE_FILE")"
  [[ -n "$cookie" ]] || die "Cookie file is empty. Run: $0 set-cookie"
  echo "$cookie"
}

# JSONv2 API query — returns JSON array in "records"
snow_query() {
  local table="$1"
  local query="$2"
  local fields="${3:-}"
  local limit="${4:-$MAX_RECORDS}"
  local cookie
  cookie="$(check_cookie)"

  # Build URL with curl -G + --data-urlencode so operators with spaces
  # (e.g. "NOT LIKE", "NOT IN") are properly encoded.
  local base_url="${SNOW_BASE}/${table}.do"
  local curl_args=( -s -G --max-time "$TIMEOUT"
    -H "Accept: application/json"
    -H "X-Requested-With: XMLHttpRequest"
    -b "$cookie"
    --data-urlencode "JSONv2"
    --data-urlencode "sysparm_query=${query}"
    --data-urlencode "sysparm_record_count=${limit}"
  )
  if [[ -n "$fields" ]]; then
    curl_args+=( --data-urlencode "sysparm_fields=${fields}" )
  fi

  local response
  response="$(curl "${curl_args[@]}" "$base_url" 2>&1)" || die "curl failed: $response"

  # Check for auth failure (HTML redirect or error)
  if echo "$response" | head -1 | grep -qi '<html\|login\|not authenticated'; then
    die "Session expired. Run: $0 login"
  fi

  echo "$response"
}

# Pretty-print key fields from a record
format_incident() {
  local json="$1"
  python3 -c "
import json, sys
data = json.loads(sys.stdin.read())
records = data.get('records', [])
if not records:
    print('[NOT FOUND] No matching records')
    sys.exit(0)
print('[FOUND] {} record(s)'.format(len(records)))
print()
for r in records:
    num = r.get('number', '?')
    desc = r.get('short_description', '?')[:100]
    state = r.get('u_state_string', r.get('state', '?'))
    pri = r.get('priority', '?')
    sev = r.get('severity', '?')
    grp = r.get('assignment_group', '?')
    opened = r.get('opened_at', '?')
    ci = r.get('cmdb_ci', '?')
    print('  {} | P{} S{} | {} | {} | {}'.format(num, pri, sev, state, grp[:30], desc))
print()
# Full JSON of first record
print('--- First record (full) ---')
print(json.dumps(records[0], indent=2, sort_keys=True))
" <<< "$json"
}

format_change() {
  local json="$1"
  python3 -c "
import json, sys
data = json.loads(sys.stdin.read())
records = data.get('records', [])
if not records:
    print('[NOT FOUND] No matching records')
    sys.exit(0)
print('[FOUND] {} record(s)'.format(len(records)))
print()
for r in records:
    num = r.get('number', '?')
    desc = r.get('short_description', '?')[:100]
    state = r.get('state', '?')
    risk = r.get('risk', '?')
    typ = r.get('type', '?')
    grp = r.get('assignment_group', '?')
    start = r.get('start_date', '?')
    print('  {} | {} | {} | Risk:{} | {} | {}'.format(num, typ, state, risk, grp[:30], desc))
print()
print('--- First record (full) ---')
print(json.dumps(records[0], indent=2, sort_keys=True))
" <<< "$json"
}

format_case() {
  local json="$1"
  python3 -c "
import json, sys
data = json.loads(sys.stdin.read())
records = data.get('records', [])
if not records:
    print('[NOT FOUND] No matching cases')
    sys.exit(0)
print('[FOUND] {} case(s)'.format(len(records)))
print()
for r in records:
    num = r.get('number', '?')
    desc = r.get('short_description', '?')[:100]
    state = r.get('state', '?')
    state_map = {'1':'New','2':'In Progress','3':'On Hold','6':'Resolved','7':'Closed'}
    state_label = state_map.get(state, state)
    pri = r.get('priority', '?')
    grp = r.get('assignment_group', '?')
    opened = r.get('opened_at', '?')
    closed = r.get('closed_at', '')
    print('  {} | P{} | {} | {} | {} | {}'.format(num, pri, state_label, opened[:10], grp[:30], desc))
print()
print('--- First record (full) ---')
print(json.dumps(records[0], indent=2, sort_keys=True))
" <<< "$json"
}

format_ci() {
  local json="$1"
  python3 -c "
import json, sys
data = json.loads(sys.stdin.read())
records = data.get('records', [])
if not records:
    print('[NOT FOUND] No matching CIs')
    sys.exit(0)
print('[FOUND] {} CI(s)'.format(len(records)))
for r in records:
    name = r.get('name', '?')
    cls = r.get('sys_class_name', '?')
    status = r.get('operational_status', '?')
    env = r.get('environment', '?')
    grp = r.get('support_group', '?')
    print('  {} | {} | {} | {} | {}'.format(name, cls, status, env, grp))
" <<< "$json"
}

# ─── Commands ────────────────────────────────────────────────────

cmd_set_cookie() {
  mkdir -p "$CONFIG_DIR"
  chmod 700 "$CONFIG_DIR"

  echo ""
  echo "ServiceNow Cookie Setup"
  echo "========================"
  echo ""
  echo "Steps:"
  echo "  1. Open https://${SNOW_INSTANCE} in your browser (log in via SSO)"
  echo "  2. Open DevTools (F12 / Cmd+Option+I)"
  echo "  3. Go to: Application → Cookies → https://${SNOW_INSTANCE}"
  echo "  4. Find these cookies and note their values:"
  echo "     - JSESSIONID"
  echo "     - glide_session_store"
  echo "     - glide_sso_id"
  echo "     - glide_user_route"
  echo "     - BIGipServerpool_comcast"
  echo ""
  echo "  OR (easier): Network tab → pick any request → copy the Cookie header value"
  echo ""
  echo "Paste the full cookie string below (semicolon-separated name=value pairs):"
  read -r cookie_value

  [[ -z "$cookie_value" ]] && die "Empty cookie value"

  # Strip leading "Cookie: " if pasted from request header
  cookie_value="${cookie_value#Cookie: }"

  echo -n "$cookie_value" > "$COOKIE_FILE"
  chmod 600 "$COOKIE_FILE"
  info "Cookie saved: $COOKIE_FILE ($(wc -c < "$COOKIE_FILE" | tr -d ' ') bytes)"

  # Verify
  echo ""
  info "Testing connectivity..."
  local result
  result="$(snow_query "sys_user" "user_nameISNOTEMPTY" "user_name,name,email" "1" 2>&1)" || {
    warn "Cookie test failed. The cookie might be expired or incomplete."
    return 1
  }

  if echo "$result" | python3 -c "import json,sys; d=json.loads(sys.stdin.read()); r=d.get('records',[]); print(r[0].get('name','?') if r else 'no records')" 2>/dev/null; then
    info "Connected successfully!"
  else
    warn "Got a response but couldn't parse it. Check the cookie."
  fi
}

cmd_whoami() {
  local cookie
  cookie="$(check_cookie)"

  # Use the REST API endpoint that returns current user from session
  local response
  response="$(curl -s --max-time "$TIMEOUT" \
    -H "Accept: application/json" \
    -H "X-Requested-With: XMLHttpRequest" \
    -b "$cookie" \
    "${SNOW_BASE}/api/now/ui/user/current_user" 2>&1)"

  # If REST API fails, try JSONv2 fallback
  if echo "$response" | grep -qi 'not authenticated\|error'; then
    info "REST API failed, trying JSONv2..."
    response="$(snow_query "sys_user" "active=true" "user_name,name,email,title" "1")"
    echo "$response" | python3 -c "
import json, sys
data = json.loads(sys.stdin.read())
records = data.get('records', [])
if records:
    r = records[0]
    print('Connected as: {} ({})'.format(r.get('name','?'), r.get('email','?')))
else:
    print('Connected but could not determine user')
"
  else
    echo "$response" | python3 -c "
import json, sys
data = json.loads(sys.stdin.read())
result = data.get('result', data)
print('Connected as: {} ({})'.format(result.get('user_display_name', result.get('name','?')), result.get('user_name','?')))
" 2>/dev/null || echo "$response" | head -5
  fi
}

cmd_get_incident() {
  local number="$1"
  local result
  result="$(snow_query "incident" "number=${number}" "" "1")"
  format_incident "$result"
}

cmd_get_change() {
  local number="$1"
  local result
  result="$(snow_query "change_request" "number=${number}" "" "1")"
  format_change "$result"
}

cmd_search_incidents() {
  local query="$1"
  local limit="${2:-20}"
  local result
  result="$(snow_query "incident" "${query}^ORDERBYDESCsys_updated_on" \
    "number,short_description,state,u_state_string,priority,severity,assignment_group,opened_at,cmdb_ci,resolved_at,close_code" \
    "$limit")"
  format_incident "$result"
}

cmd_search_changes() {
  local query="$1"
  local limit="${2:-20}"
  local result
  result="$(snow_query "change_request" "${query}^ORDERBYDESCsys_updated_on" \
    "number,short_description,state,type,risk,priority,assignment_group,start_date,end_date,cmdb_ci" \
    "$limit")"
  format_change "$result"
}

cmd_get_case() {
  local number="$1"
  local result
  result="$(snow_query "x_mcim_it_service_case2" "number=${number}" "" "1")"
  format_case "$result"
}

cmd_search_cases() {
  local query="$1"
  local limit="${2:-20}"
  local result
  result="$(snow_query "x_mcim_it_service_case2" "${query}^ORDERBYDESCsys_updated_on" \
    "number,short_description,state,priority,assignment_group,opened_at,closed_at,contact_type,description,symptom_sub_category,symptom_category" \
    "$limit")"
  format_case "$result"
}

cmd_get_ci() {
  local name="$1"
  local result
  result="$(snow_query "cmdb_ci" "nameLIKE${name}" \
    "name,sys_class_name,operational_status,environment,support_group,ip_address,category" \
    "20")"
  format_ci "$result"
}

cmd_resolve_group() {
  local name="$1"
  local result
  result="$(snow_query "sys_user_group" "nameLIKE${name}" \
    "sys_id,name,description,manager,email" \
    "10")"
  python3 -c "
import json, sys
data = json.loads(sys.stdin.read())
records = data.get('records', [])
if not records:
    print('[NOT FOUND] No groups matching: ${name}')
    sys.exit(1)
print('[FOUND] {} group(s)'.format(len(records)))
print()
for r in records:
    sid = r.get('sys_id', '')
    gname = r.get('name', '')
    desc = r.get('description', '')[:80]
    print('  {} | {} | {}'.format(sid, gname, desc))
print()
print('Use the sys_id in queries:')
print('  assignment_group={}'.format(records[0].get('sys_id', '')))
" <<< "$result"
}

cmd_check() {
  if [[ ! -f "$COOKIE_FILE" ]]; then
    echo "Status: NO COOKIE"
    echo "Run: $0 set-cookie"
    return 1
  fi

  local age_seconds
  age_seconds=$(( $(date +%s) - $(stat -f %m "$COOKIE_FILE" 2>/dev/null || stat -c %Y "$COOKIE_FILE" 2>/dev/null) ))
  local age_hours=$(( age_seconds / 3600 ))

  echo "Cookie file: $COOKIE_FILE"
  echo "Cookie age:  ${age_hours}h (${age_seconds}s)"

  if (( age_hours > 8 )); then
    warn "Cookie is ${age_hours}h old — likely expired. Run: $0 set-cookie"
  fi

  # Quick test
  info "Testing connectivity..."
  local result
  if result="$(snow_query "incident" "active=true" "number" "1" 2>&1)"; then
    if echo "$result" | grep -q '"number"'; then
      info "Connection OK"
    else
      warn "Got response but no records — cookie might be expired"
    fi
  else
    warn "Connection failed: $result"
  fi
}

# ─── Usage ───────────────────────────────────────────────────────

usage() {
  cat <<'EOF'

snow-query.sh — ServiceNow query tool

Commands:
  login                               SSO login via browser (automated cookie refresh)
  login --headed                      Force visible browser for SSO
  login --install                     Install Playwright + Chromium
  login --verify                      Verify saved cookie without re-login
  set-cookie                          Manual cookie paste (fallback)
  check                               Verify cookie status and connectivity
  whoami                              Show current user info
  get-incident <INC_NUMBER>           Fetch incident details
  get-change <CHG_NUMBER>             Fetch change request details
  get-case <CAS_NUMBER>               Fetch IT service case details
  search-incidents "<query>" [limit]  Search incidents
  search-changes "<query>" [limit]    Search change requests
  search-cases "<query>" [limit]      Search IT service cases
  get-ci "<name>"                     Search Configuration Items by name
  resolve-group "<name>"              Look up assignment group name → sys_id

Query syntax (ServiceNow encoded query):
  field=value                         Exact match
  fieldLIKEvalue                      Contains (case-insensitive)
  fieldNOT LIKEvalue                  Does not contain
  field!=value                        Not equal
  field>value / field<value           Greater/less than
  field>=value / field<=value         Greater/less than or equal
  fieldISEMPTY / fieldISNOTEMPTY      Null checks
  field1=val1^field2=val2             AND (^ separator)
  field1=val1^ORfield2=val2           OR
  active=true^priority<=2             Active P1/P2

Reference field translation:
  Fields like assignment_group store sys_ids, not display names.
  Use 'resolve-group' to look up the sys_id first:
    snow-query.sh resolve-group "OrderTechProductionSupport"
  Then use the sys_id in your query:
    snow-query.sh search-cases "assignment_group=<sys_id>^active=true"

  Incident table supports dot-walking (assignment_group.name=...).
  Case table does NOT — always use sys_id for cases.

Examples:
  snow-query.sh resolve-group "OrderTechProductionSupport"
  snow-query.sh search-cases "assignment_group=f55f722...^active=true^short_descriptionNOT LIKErecon" 100
  snow-query.sh search-incidents "assignment_group.name=OrderTech^active=true"
  snow-query.sh search-incidents "priority=1^state=2" 50
  snow-query.sh search-incidents "short_descriptionLIKEorder-tech^state!=7"
  snow-query.sh search-changes "assignment_group.name=OrderTech^state=implement"
  snow-query.sh get-ci "order-tech"

EOF
}

# ─── Main ────────────────────────────────────────────────────────

main() {
  local cmd="${1:-help}"
  shift || true

  case "$cmd" in
    login)              exec python3 "${SCRIPT_DIR}/snow-sso-login.py" "$@" ;;
    set-cookie)         cmd_set_cookie ;;
    check)              cmd_check ;;
    whoami)             cmd_whoami ;;
    get-incident)       [[ $# -ge 1 ]] || die "Usage: $0 get-incident <INC_NUMBER>"; cmd_get_incident "$1" ;;
    get-change)         [[ $# -ge 1 ]] || die "Usage: $0 get-change <CHG_NUMBER>"; cmd_get_change "$1" ;;
    get-case)           [[ $# -ge 1 ]] || die "Usage: $0 get-case <CAS_NUMBER>"; cmd_get_case "$1" ;;
    search-incidents)   [[ $# -ge 1 ]] || die "Usage: $0 search-incidents \"<query>\" [limit]"; cmd_search_incidents "$1" "${2:-20}" ;;
    search-changes)     [[ $# -ge 1 ]] || die "Usage: $0 search-changes \"<query>\" [limit]"; cmd_search_changes "$1" "${2:-20}" ;;
    search-cases)       [[ $# -ge 1 ]] || die "Usage: $0 search-cases \"<query>\" [limit]"; cmd_search_cases "$1" "${2:-20}" ;;
    get-ci)             [[ $# -ge 1 ]] || die "Usage: $0 get-ci \"<name>\""; cmd_get_ci "$1" ;;
    resolve-group)      [[ $# -ge 1 ]] || die "Usage: $0 resolve-group \"<name>\""; cmd_resolve_group "$1" ;;
    help|--help|-h)     usage ;;
    *)                  die "Unknown command: $cmd. Run: $0 help" ;;
  esac
}

main "$@"
