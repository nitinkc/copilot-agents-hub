---
name: servicenow-reader
description: Read-only ServiceNow ticket retrieval for incidents, changes, cases, and CIs. Uses browser session cookies with the JSONv2 API. Fetches ticket details, searches by query, and resolves Configuration Items.
---

# Skill: ServiceNow Reader

## Goal

Retrieve structured ServiceNow ticket context (incidents, change requests, IT service cases, configuration items) so agents can correlate production issues with ITSM records, validate deployment changes, and trace customer-reported cases back to technical root causes — without mutating ServiceNow state.

## Inputs

- A ServiceNow ticket number: `INC0012345`, `CHG0067890`, `CAS3434364`
- OR a search query in ServiceNow encoded query syntax
- OR natural language describing what to find (agent translates to query)

## Prerequisites

**Cookie File**: `~/.ordertech-snow/snow.cookie` — contains browser session cookies for `comcast.service-now.com`.

**API**: JSONv2 (classic). The REST API (`/api/now/table/`) requires Basic Auth or OAuth. The JSONv2 API (`/{table}.do?JSONv2`) accepts browser session cookies, so we use that.

**Cookie expiry**: Session cookies expire after ~8 hours. The `check` command reports cookie age and tests connectivity.

**Playwright** (optional but recommended): Enables automated SSO login via headless Chromium. Install once:
```bash
bash .github/skills/servicenow-reader/scripts/snow-query.sh login --install
```

### SSO Cookie Refresh (AUTOMATIC — agents run this without asking)

When `snow-query.sh` fails with "No cookie file" or "Session expired", the agent MUST
automatically refresh the cookie **without asking the user**. Do not prompt "please run login" —
just run it.

**Auto-refresh chain** (execute steps in order, stop on first success):

1. **Verify first** — maybe the cookie just needs a re-check:
   ```bash
   bash .github/skills/servicenow-reader/scripts/snow-query.sh login --verify
   ```
   If HTTP 200 → cookie is fine, proceed with the original query.

2. **Auto-refresh** (headless if prior session exists):
   ```bash
   bash .github/skills/servicenow-reader/scripts/snow-query.sh login
   ```
   - Headless auto-renew works when Azure AD session is still valid (~24h).
   - Falls back automatically: headless → headed → nuke state → headed.
   - If headed browser opens, the user completes MFA in the popup — no copy-paste needed.

3. **If Playwright is not installed**, install it automatically then retry:
   ```bash
   bash .github/skills/servicenow-reader/scripts/snow-query.sh login --install
   bash .github/skills/servicenow-reader/scripts/snow-query.sh login
   ```

4. **Verify after refresh**:
   ```bash
   bash .github/skills/servicenow-reader/scripts/snow-query.sh login --verify
   ```
   If HTTP 200 → proceed. If not → one more retry with `--headed`.

5. **HARD STOP only if all automated attempts fail.** Only then tell the user to paste manually:
   ```bash
   bash .github/skills/servicenow-reader/scripts/snow-query.sh set-cookie
   ```

**Never log cookie values in conversation text** — use them only inside `run_in_terminal` commands.

## Hard Constraints

- **Read-only**: No script performs POST, PUT, DELETE, or PATCH operations. Never mutate ServiceNow state.
- **Cookie security**: Cookies are stored in `~/.ordertech-snow/snow.cookie` with `chmod 600`. Never log or echo cookie values in conversation.
- **Timeout**: All curl calls have a 30-second timeout (`--max-time 30`).
- **No new dependencies**: Only `curl` and `python3` are required (pre-installed on macOS).
- **Fail-safe**: If the cookie is missing or the API returns an error, the script exits with a non-zero code. Agents must check the exit code before using output.

## Tables and Ticket Prefixes

| Prefix | Table | Command |
|--------|-------|---------|
| `INC` | `incident` | `get-incident`, `search-incidents` |
| `CHG` | `change_request` | `get-change`, `search-changes` |
| `CAS` | `sn_customerservice_case` | `get-case`, `search-cases` |
| (CI name) | `cmdb_ci` | `get-ci` |

## Steps

### Step 0 — Verify connectivity

Before any query, verify the cookie is valid:
```bash
bash .github/skills/servicenow-reader/scripts/snow-query.sh check
```
If it reports expired or fails, follow the Cookie Setup Procedure above.

### Step 1 — Detect ticket type from number prefix

```
INC* → incident       → use get-incident / search-incidents
CHG* → change_request → use get-change / search-changes
CAS* → case           → use get-case / search-cases
```

If the prefix is unknown, try `get-case` first (most common for customer-facing), then `get-incident`.

### Step 2 — Fetch ticket details

**Single ticket by number:**
```bash
# Incident
bash .github/skills/servicenow-reader/scripts/snow-query.sh get-incident INC0012345

# Change request
bash .github/skills/servicenow-reader/scripts/snow-query.sh get-change CHG0067890

# IT service case
bash .github/skills/servicenow-reader/scripts/snow-query.sh get-case CAS3434364
```

**Search by query:**
```bash
# Active incidents for OrderTech
bash .github/skills/servicenow-reader/scripts/snow-query.sh search-incidents "assignment_group.nameLIKEOrder^active=true"

# High priority incidents
bash .github/skills/servicenow-reader/scripts/snow-query.sh search-incidents "priority<=2^state!=7" 50

# Recent change requests
bash .github/skills/servicenow-reader/scripts/snow-query.sh search-changes "assignment_group.nameLIKEOrder^state=implement"

# Cases by description
bash .github/skills/servicenow-reader/scripts/snow-query.sh search-cases "short_descriptionLIKEclose order"

# Configuration Items
bash .github/skills/servicenow-reader/scripts/snow-query.sh get-ci "order-tech"
```

### Step 3 — Query Syntax Reference

ServiceNow encoded query syntax:

| Operator | Syntax | Example |
|----------|--------|---------|
| Equals | `field=value` | `priority=1` |
| Not equals | `field!=value` | `state!=7` |
| Contains | `fieldLIKEvalue` | `short_descriptionLIKEorder` |
| Greater than | `field>value` | `opened_at>2026-04-01` |
| Less/equal | `field<=value` | `priority<=2` |
| AND | `^` | `priority=1^state=2` |
| OR | `^OR` | `state=1^ORstate=2` |
| Order by (desc) | `^ORDERBYDESCfield` | `^ORDERBYDESCsys_updated_on` |
| Order by (asc) | `^ORDERBYfield` | `^ORDERBYopened_at` |
| Is not empty | `fieldISNOTEMPTY` | `assigned_toISNOTEMPTY` |
| Dot-walking | `field.name=value` | `assignment_group.name=OrderTech` |

### Step 4 — Key Fields by Table

**Incident (`incident`)**:
`number`, `short_description`, `description`, `state`, `u_state_string`, `priority`, `severity`, `assigned_to`, `assignment_group`, `opened_at`, `resolved_at`, `closed_at`, `close_code`, `close_notes`, `cmdb_ci`, `business_service`, `category`, `subcategory`, `caused_by`, `impact`, `urgency`

**Change Request (`change_request`)**:
`number`, `short_description`, `description`, `state`, `type`, `risk`, `impact`, `priority`, `assigned_to`, `assignment_group`, `start_date`, `end_date`, `cmdb_ci`, `business_service`, `close_code`, `close_notes`

**Case (`sn_customerservice_case`)**:
`number`, `short_description`, `description`, `state`, `priority`, `assignment_group`, `opened_at`, `closed_at`, `contact_type`, `contact`, `resolution_code`, `case_report`, `category`, `subcategory`

Case state values: `1`=New, `2`=In Progress, `3`=On Hold, `6`=Resolved, `7`=Closed

**Configuration Item (`cmdb_ci`)**:
`name`, `sys_class_name`, `operational_status`, `environment`, `support_group`, `ip_address`, `category`

### Step 5 — Present context to calling agent (MANDATORY)

After fetching, agents MUST present a **human-readable summary** — never dump raw JSON at the user.

#### Required Summary Format

For a single ticket:
```
## <NUMBER>: <short_description>

| Field | Value |
|-------|-------|
| Type | <Incident/Change/Case> |
| State | <state> |
| Priority | P<priority> |
| Severity | S<severity> (incidents only) |
| Assignment Group | <group> |
| Assigned To | <assignee or "Unassigned"> |
| Opened | <opened_at> |
| Closed | <closed_at or "Open"> |
| CI | <cmdb_ci or "—"> |

### Description
<description — preserve structure, extract key data points>
```

For cases with structured descriptions (BPM HOLDING, order details), parse the key-value pairs:
```
### Case Details
| Field | Value |
|-------|-------|
| Account Number | <extracted> |
| Order Type | <extracted> |
| BPM Order ID | <extracted> |
| FT Status | <extracted> |
| Requested Resolution | <extracted> |
```

For search results, show a summary table:
```
| Number | Priority | State | Group | Description |
|--------|----------|-------|-------|-------------|
| INC... | P1       | ...   | ...   | ...         |
```

## When to Activate

This skill should be invoked when **any** of the following conditions are true:

1. **Explicit ticket reference** — The user mentions a ServiceNow ticket number (`INC*`, `CHG*`, `CAS*`) or pastes a ServiceNow URL.
2. **Incident investigation** — During an RCA or incident investigation, the user references a ServiceNow incident tied to the production issue.
3. **Change validation** — The user asks about a deployment or change request, or wants to verify a CHG ticket's details.
4. **Case lookup** — The user references a customer case (CAS) to understand the customer-reported issue.
5. **CI discovery** — The user wants to find which Configuration Items exist for a service or application.
6. **Cross-reference** — Another skill (e.g., `incident-investigator`, `quick-triage`) needs ServiceNow context to correlate ELK log findings with ITSM records.
7. **Search** — The user asks to find incidents, changes, or cases matching criteria (group, priority, date range, keyword).

## Usage Patterns for Agents

### Pattern A: Incident investigation with SNOW correlation

```
Agent (incident-investigator): Found errors in ELK for biller-account
  → snow-query.sh search-incidents "short_descriptionLIKEbiller^active=true"
  → Correlate: is there an open INC for this issue?
  → If yes: fetch full details, link to RCA
```

### Pattern B: Change impact verification

```
User: "Did CHG0067890 cause the errors?"
Agent: → snow-query.sh get-change CHG0067890
       → Extract: start_date, end_date, cmdb_ci, risk
       → Compare with ELK error timeline
```

### Pattern C: Customer case to technical investigation

```
User: "Look up CAS3434364"
Agent: → snow-query.sh get-case CAS3434364
       → Extract: BPM Order ID, account, order type from description
       → Use BPM Order ID to trace in ELK logs
```

### Pattern D: Bulk search for active incidents

```
User: "Any open incidents for OrderTech?"
Agent: → snow-query.sh search-incidents "assignment_group.nameLIKEOrder^active=true" 20
       → Present summary table
```

### Pattern E: CI lookup for service mapping

```
Agent: Needs to map service name to ServiceNow CI
  → snow-query.sh get-ci "order-tech"
  → Use CI sys_id to search related incidents
```

## Output

The script outputs formatted text with a summary line and full JSON of the first record. Agents should parse the output and present per Step 5.

## Troubleshooting

| Symptom | Cause | Fix |
|---------|-------|-----|
| `[ERROR] No cookie file` | Cookie not set up | Run `snow-query.sh set-cookie` |
| `[ERROR] Session expired` | Cookie >8 hours old | Re-login to ServiceNow, re-copy cookies |
| `curl failed` | Network or SSL issue | Check VPN connectivity |
| `JSONDecodeError` | Table name wrong or HTML redirect | Cookie likely expired |
| Empty results | Wrong table for ticket prefix | Check prefix → table mapping in Step 1 |
