---
name: jira-wiki-reader
description: Read-only Jira ticket retrieval and Confluence wiki page fetching for development workflows. Fetches ticket details, linked issues, sub-tasks, comments, sprint context, and referenced wiki pages via shell scripts that call Jira Data Center REST API v2 and Confluence REST API.
---

# Skill: Jira & Wiki Reader

## Goal

Retrieve structured Jira ticket context and linked Confluence wiki content so agents can make informed decisions about requirements, scope, dependencies, design documents, and traceability — without ever mutating Jira or Confluence state.

## Inputs

- A Jira ticket key (e.g., `OM-1234`, `ECOM-567`, `CMXOTR-1398`) — provided explicitly by the developer, extracted from a PR title/branch/commit, or discovered by another agent/skill.
- OR a Confluence wiki URL (e.g., `https://etwiki.sys.comcast.net/pages/viewpage.action?spaceKey=XF&title=...`) — provided explicitly or extracted from a Jira ticket description.
- OR arbitrary text (URL, branch name, commit message) from which a ticket key or wiki link can be extracted.

## Prerequisites

**Jira Base URL**: Hardcoded to `https://tkts.sys.comcast.net` in `scripts/_lib.sh`. Developers do NOT need to set `JIRA_BASE_URL`.

**Personal Access Token (JIRA_PAT)**: Required for Jira authentication. Resolved in this order:
1. Environment variable `JIRA_PAT` (if already exported or set by sourcing env file on load)
2. Persistent file `~/.jira-reader.env` **(recommended — no restart needed, sourced on every run)**
3. On WSL: auto-scans Windows user home `/mnt/c/Users/<NTID>/.jira-reader.env`

**Wiki Personal Access Token (WIKI_PAT)**: Required for Confluence wiki page retrieval. Resolved in this order:
1. Environment variable `WIKI_PAT` (if already exported or set by sourcing env file on load)
2. Persistent file `~/.wiki-reader.env` **(recommended — no restart needed, sourced on every run)**
3. On WSL: auto-scans Windows user home `/mnt/c/Users/<NTID>/.wiki-reader.env`

If neither exists, the script exits with a clear error and the agent should follow the PAT Prompt procedure below.

### PAT Prompt and Save Procedure (agents MUST follow)

When a Jira or Wiki script fails with "PAT is not set", execute this procedure:

1. **Tell the user** their token is missing or expired and provide setup instructions:
   ```
   Your Jira/Wiki Personal Access Token is not configured (or has expired).

   To generate tokens:
   - Jira: https://tkts.sys.comcast.net/secure/ViewProfile.jspa?selectedTab=com.atlassian.pats.pats-plugin:jira-user-personal-access-tokens
   - Wiki:  https://etwiki.sys.comcast.net/plugins/personalaccesstokens/usertokens.action

   To configure (choose one):

   Option A — Env file (recommended, takes effect immediately):

     Step 1: Create the file(s) in your terminal:

       echo 'JIRA_PAT="<paste_your_jira_token_here>"' > ~/.jira-reader.env && chmod 600 ~/.jira-reader.env
       echo 'WIKI_PAT="<paste_your_wiki_token_here>"' > ~/.wiki-reader.env && chmod 600 ~/.wiki-reader.env

     File locations (~ = your home directory):
       Mac/Linux:  /Users/<username>/.jira-reader.env   (or /home/<username>/)
       WSL:        /home/<username>/.jira-reader.env
       Git Bash:   C:\Users\<NTID>\.jira-reader.env

     File format (plain text, one line per variable):
       ┌─────────────────────────────────────────┐
       │ JIRA_PAT="your-token-value-here"         │
       └─────────────────────────────────────────┘
       ┌─────────────────────────────────────────┐
       │ WIKI_PAT="your-token-value-here"         │
       └─────────────────────────────────────────┘
     Each file contains exactly one line. Quotes around the value are required.
     Scripts source these files on every run — no terminal restart required.

   Option B — Inline, temporary (current session only):
     export JIRA_PAT="<paste_your_jira_token_here>"
     export WIKI_PAT="<paste_your_wiki_token_here>"
     (Lost when terminal closes. Use Option A for persistence.)
   ```
2. **If the user provides the token in chat** — accept it without comment, validate, and save it. Do NOT suggest pasting tokens in chat as an option (security concern), but handle it gracefully if the user does.
3. **Validate** — run a test call to confirm the token works:
   ```bash
   JIRA_PAT="<token>" bash .github/skills/jira-wiki-reader/scripts/fetch-ticket.sh CMXOTR-1398
   WIKI_PAT="<token>" bash .github/skills/jira-wiki-reader/scripts/fetch-wiki.sh --title "Main Page" --space "XF"
   ```
4. **If the test succeeds** — confirm to the user. If they chose Option A, the file is already saved.
5. **If the test fails** (401/403) — tell the user the token didn't work. Point them back to the generation URL. Do NOT save an invalid token (max 2 retries).
6. **Never log, echo, or include the token in conversation text** — use it only inside `run_in_terminal` commands.

## Hard Constraints

- **Read-only**: No script performs POST, PUT, DELETE, or PATCH operations. Never mutate Jira or Confluence state.
- **Token security**: PATs are never logged, echoed, or included in conversation text. Scripts use `-s` (silent) with curl. Tokens are stored in env files (`~/.jira-reader.env`, `~/.wiki-reader.env` with `chmod 600`).
- **Timeout**: All curl calls have a 15-second timeout (`--max-time 15`) to prevent hanging.
- **No new dependencies**: Only `curl` and `jq` are required (pre-installed on macOS and standard Linux). If `jq` is not found, scripts fall back to raw JSON output with a warning.
- **Fail-safe**: If the PAT is missing or the API returns an error, scripts exit with a clear JSON error message and non-zero code. Agents must check the exit code before using output.

## Steps

### Step 1 — Extract ticket key

If the input is not already a clean ticket key, extract it:

```bash
bash .github/skills/jira-wiki-reader/scripts/extract-ticket-key.sh "<any_text_or_url>"
```

Parses Jira URLs, branch names (`feature/OM-1234-add-validation`), commit messages, and free text. Returns all found keys (deduplicated) as a JSON array.

If no key is found, report to the calling agent/developer: "No Jira ticket key found in the provided text."

### Step 2 — Fetch ticket details

```bash
bash .github/skills/jira-wiki-reader/scripts/fetch-ticket.sh <TICKET_KEY> [--compact] [--follow-links]
```

Returns: summary, description, status, priority, type, assignee, reporter, sprint, story points, labels, components, fix versions, created/updated dates, parent epic, acceptance criteria, subtasks (with details), linked issues (with relationship and status), and recent comments (last 5).

Optional flags:
- `--compact` — Strip `{code}` and `{noformat}` blocks, JSON log lines (`{"@timestamp"...`), and truncate description (1000 chars) and comments (500 chars). Use when ticket bodies contain large log dumps.
- `--follow-links` — Fetch one-level-deep summary (key, summary, status, priority, resolution) for each linked ticket. Adds a `linked_issue_details` array to the output. Capped at 10 linked tickets.

This is the primary command. Always run this first — it provides a comprehensive single-call view of the ticket. The additional scripts in Step 3 are for deeper dives (e.g., all comments, sprint siblings).

**Auto-fetch wiki links**: After fetching a ticket, scan the `description` field for Confluence URLs (`etwiki.sys.comcast.net`). If found, **immediately** fetch each wiki page — do NOT ask the user for permission. The goal is to build complete context (ticket + design docs) so agents can perform tasks effectively.

### Step 3 — Fetch additional context (as needed)

Run these based on what the calling agent/workflow needs:

**Linked issues** (for dependency tracing, impact analysis):
```bash
bash .github/skills/jira-wiki-reader/scripts/fetch-links.sh <TICKET_KEY>
```
Returns: all linked issues (blocks, is-blocked-by, relates-to, duplicates, etc.) with key, summary, status, and link type.

**Sub-tasks** (for scope understanding, work breakdown):
```bash
bash .github/skills/jira-wiki-reader/scripts/fetch-subtasks.sh <TICKET_KEY>
```
Returns: all sub-tasks with key, summary, status, and assignee.

**Comments** (for historical context, discussion, decisions):
```bash
bash .github/skills/jira-wiki-reader/scripts/fetch-comments.sh <TICKET_KEY> [MAX_RESULTS] [--extract-refs]
```
Returns: the most recent comments (default: 10) with author, timestamp, and body.

Optional flag:
- `--extract-refs` — Also extract structured references from comment bodies and include a `references` object with: `pull_requests` (GitHub PR URLs), `build_numbers` (service build versions), `ticket_refs` (other Jira keys mentioned), and `deployments` (comments mentioning deployment with date and snippet). Useful for RCA investigations and fix tracing.

**Sprint context** (for planning, sibling tickets):
```bash
bash .github/skills/jira-wiki-reader/scripts/fetch-sprint.sh <TICKET_KEY>
```
Returns: active sprint name, goal, start/end dates, and other tickets in the same sprint.

**JQL search or saved filter** (for bulk ticket retrieval, dashboards, or cross-ticket analysis):
```bash
# By JQL query:
bash .github/skills/jira-wiki-reader/scripts/fetch-jql.sh --jql "<JQL_QUERY>" [--max <N>]
# By saved filter ID:
bash .github/skills/jira-wiki-reader/scripts/fetch-jql.sh --filter <FILTER_ID> [--max <N>]
```
Examples:
```bash
bash .github/skills/jira-wiki-reader/scripts/fetch-jql.sh --jql 'project = CMXOTR AND status = Open AND priority = High'
bash .github/skills/jira-wiki-reader/scripts/fetch-jql.sh --filter 12345
bash .github/skills/jira-wiki-reader/scripts/fetch-jql.sh --jql 'assignee = currentUser() AND sprint in openSprints()' --max 20
```
Returns: total count, query used, and an array of ticket summaries (key, summary, status, type, priority, assignee, reporter, sprint, labels, components, fix versions). Results capped at 50 (default 25). Use `fetch-ticket.sh` per key for full details on individual tickets.

**Wiki page** (when ticket description contains a Confluence link):
```bash
bash .github/skills/jira-wiki-reader/scripts/fetch-wiki.sh "<CONFLUENCE_URL>"
# OR by page ID:
bash .github/skills/jira-wiki-reader/scripts/fetch-wiki.sh --id <PAGE_ID>
# OR by title + space:
bash .github/skills/jira-wiki-reader/scripts/fetch-wiki.sh --title "<PAGE_TITLE>" --space "<SPACE_KEY>"
```
Returns: title, space, author, version, labels, and body content (HTML stripped to plain text, max 50k characters). Requires `WIKI_PAT`.

**Batch ticket fetch** (multiple tickets in a single API call):
```bash
bash .github/skills/jira-wiki-reader/scripts/fetch-batch.sh KEY-1 KEY-2 KEY-3 ... [--compact]
```
Examples:
```bash
# Full details for 6 tickets in one call
bash .github/skills/jira-wiki-reader/scripts/fetch-batch.sh CMXOTB-3771 CMXOTB-3788 CMXOT2-1760 CMXOTB-4052 CMXOTB-4140 CMXOTB-4238
# Compact mode: strip code blocks, log lines, truncate descriptions and comments
bash .github/skills/jira-wiki-reader/scripts/fetch-batch.sh CMXOTB-3771 CMXOTB-3788 --compact
```
Returns: `{ count, requested, missing: [...], tickets: [...full ticket shape...], errors: [...] }`. Uses JQL `key in (...)` internally — one API call instead of N. Hard limit: 20 tickets per call. The `missing` array lists any requested keys that were not found (permission denied or nonexistent). Use `--compact` to strip `{code}` blocks, `{noformat}` blocks, JSON log lines, and truncate descriptions (1000 chars) and comments (500 chars).

### Step 4 — Present context to calling agent (MANDATORY)

After fetching, agents MUST present a **human-readable summary** — never dump raw JSON at the user. Parse the JSON and format the output as follows:

#### Required Summary Format

```
## <KEY>: <summary>

| Field | Value |
|-------|-------|
| Type | <type> |
| Status | <status> (<status_category>) |
| Priority | <priority> |
| Assignee | <assignee> |
| Reporter | <reporter> |
| Sprint | <sprint or "—"> |
| Story Points | <story_points or "—"> |
| Epic | <epic_key or "—"> |
| Labels | <comma-separated or "—"> |
| Components | <comma-separated or "—"> |
| Fix Versions | <comma-separated or "—"> |
| Created | <created date> |
| Updated | <updated date> |
| Resolution | <resolution or "Unresolved"> |

### Description
<description — preserve formatting, convert Jira wiki to Markdown bullet lists>

### Acceptance Criteria
<acceptance_criteria or "Not specified">
```

#### Conditional Sections (include when non-empty)

**Subtasks** — if `subtask_count > 0`:
```
### Subtasks (<count>)
| Key | Summary | Status | Assignee |
|-----|---------|--------|----------|
| ... | ...     | ...    | ...      |
```

**Linked Issues** — if `linked_issues` is non-empty:
```
### Linked Issues
| Relationship | Key | Summary | Status | Type |
|-------------|-----|---------|--------|------|
| blocks      | ... | ...     | ...    | ...  |
```

**Recent Comments** — if `comment_count > 0`:
```
### Comments (<comment_count> total, showing last <N>)
**<author>** (<date>):
> <body — truncate to key points, strip Jira user mentions [~userid]>

```

**Sprint Context** — if sprint data was fetched:
```
### Sprint Context
Sprint: <name> | Goal: <goal> | <start> → <end>
Sibling tickets: <list of related tickets in same sprint>
```

#### Presentation rules
- **Always show**: ticket details table + description + acceptance criteria (even if "Not specified").
- **Auto-include wiki content**: If the ticket description contained Confluence URLs and wiki pages were fetched, include a `### Referenced Wiki Documentation` section with the page title, key sections, and content summary. Never ask the user whether to fetch — just do it and present the combined context.
- **Convert Jira markup**: `*bold*` → `**bold**`, `{code}` → backtick blocks, `[text|url]` → `[text](url)`, `[~userid]` → `@userid`, nested `*/***/****` bullets → Markdown `-` indentation.
- **Truncate long descriptions** at 3000 characters with a "[truncated — full description in Jira]" note.
- **For comments**: strip visual noise, keep substance. Summarize if body exceeds 500 characters.
- **Tailor depth** to the calling context:
  - **Requirements grooming**: full details + all linked issues + all comments + acceptance criteria gaps
  - **PR review**: ticket table + acceptance criteria + description (for traceability check)
  - **Bug investigation**: ticket table + description + comments (for historical context)
  - **Development kickoff**: full details + subtasks + sprint context + acceptance criteria

## When to Activate

This skill should be invoked when **any** of the following conditions are true:

1. **Explicit ticket reference** — The user mentions a Jira ticket key or pastes a Jira URL.
2. **Explicit wiki reference** — The user pastes a Confluence/wiki URL (e.g., `etwiki.sys.comcast.net/...`).
3. **Wiki link in ticket** — A fetched Jira ticket description contains a Confluence URL — **automatically** fetch the linked wiki page for full context (no user prompt needed).
4. **PR/branch context** — A PR title, description, branch name, or commit message contains a ticket key pattern (`[A-Z][A-Z0-9]+-\d+`).
5. **Bug investigation** — The user is researching a bug and git log/blame output contains ticket references.
6. **Grooming/planning** — The user says "groom", "refine", "plan", "estimate", or "break down" with a ticket reference.
7. **Development kickoff** — The user says "start working on", "pick up", "implement", or similar with a ticket reference.
8. **Design/architecture context** — The user asks about design decisions, solution architecture, or references a wiki page for technical details.
9. **Dependency tracing** — A ticket's linked issues or sub-tasks are needed to understand scope or impact.
10. **Agent-initiated** — Another agent/skill requests Jira or wiki context discovered during its own workflow.

## Usage Patterns for Agents

### Pattern A: Developer starts work on a ticket

```
User: "Start working on OM-1234"
Agent: → extract-ticket-key.sh "OM-1234" → fetch-ticket.sh OM-1234 → fetch-subtasks.sh OM-1234
       → Use ticket context to understand requirements, acceptance criteria, and scope
```

### Pattern B: PR review with ticket context

```
Agent reviewing PR: → extract-ticket-key.sh "<pr_title_and_body>"
                    → fetch-ticket.sh <extracted_key>
                    → Validate PR changes against ticket requirements
```

### Pattern C: Bug investigation from git history

```
Agent: → git log --oneline -20 → extract-ticket-key.sh "<log_output>"
       → fetch-ticket.sh <key> → fetch-comments.sh <key>
       → Use historical context to understand the bug's origin
```

### Pattern D: Grooming/refinement

```
User: "Help me groom ECOM-456"
Agent: → fetch-ticket.sh ECOM-456 → fetch-links.sh ECOM-456 → fetch-subtasks.sh ECOM-456
       → If description contains wiki URL → fetch-wiki.sh "<url>"
       → Analyze completeness, suggest acceptance criteria, identify dependencies
```

### Pattern E: Wiki page deep-dive

```
User: "Fetch this wiki page: https://etwiki.sys.comcast.net/pages/viewpage.action?spaceKey=XF&title=..."
Agent: → fetch-wiki.sh "<url>"
       → Present page content in human-readable format
```

### Pattern F: Ticket + wiki context combined

```
User: "What's the full context for CMXOTR-1398?"
Agent: → fetch-ticket.sh CMXOTR-1398
       → Detect wiki URL in description → fetch-wiki.sh "<url>"
       → Present unified view: ticket details + wiki design document
```

### Pattern G: Bulk ticket retrieval via JQL or saved filter

```
User: "Show me all open high-priority bugs in CMXOTR"
Agent: → fetch-jql.sh --jql 'project = CMXOTR AND type = Bug AND status = Open AND priority = High'
       → Present summary table of matching tickets
       → If user asks for detail on a specific ticket → fetch-ticket.sh <key>
```

```
User: "Pull up filter 12345"
Agent: → fetch-jql.sh --filter 12345
       → Present summary table of matching tickets
```

```
User: "What's in my current sprint?"
Agent: → fetch-jql.sh --jql 'assignee = currentUser() AND sprint in openSprints()' --max 30
       → Present sprint board summary
```

### Pattern H: Cross-ticket cluster analysis (RCA, recurring defects)

```
User: "Analyze why CMXOTB-3771, CMXOTB-3788, CMXOT2-1760 keep breaking"
Agent: → bash .github/skills/jira-wiki-reader/scripts/fetch-batch.sh CMXOTB-3771 CMXOTB-3788 CMXOT2-1760 --compact
       → For each key: bash .github/skills/jira-wiki-reader/scripts/fetch-comments.sh <key> --extract-refs
       → Cross-correlate: timeline, common services, common errors, fix PRs
       → Produce: timeline table, root cause clusters, systemic recommendations
```

```
User: "What's the history of fixes for these tickets?"
Agent: → bash .github/skills/jira-wiki-reader/scripts/fetch-batch.sh KEY-1 KEY-2 KEY-3 --compact
       → bash .github/skills/jira-wiki-reader/scripts/fetch-comments.sh KEY-1 --extract-refs (for each key)
       → Collect references.pull_requests and references.build_numbers
       → Present: fix timeline with PR links, build versions, deployment dates
```

```
User: "Deep dive on CMXOTB-4052 and what it links to"
Agent: → bash .github/skills/jira-wiki-reader/scripts/fetch-ticket.sh CMXOTB-4052 --compact --follow-links
       → linked_issue_details shows one-level-deep summaries
       → If deeper context needed: bash .github/skills/jira-wiki-reader/scripts/fetch-ticket.sh <linked_key> for each
```

## Output

All scripts output **structured JSON** to stdout. Errors output JSON with an `"error"` key to stderr with a non-zero exit code.

**Important**: The JSON is the machine-readable transport format. Agents MUST parse it and present a human-readable summary per Step 4. Never show raw JSON to the user.

Example script JSON (for agent consumption — not shown directly to user):
```json
{
  "key": "OM-1234",
  "summary": "Implement order validation middleware",
  "description": "As a developer, I need order validation...",
  "status": "In Progress",
  "status_category": "In Progress",
  "type": "Story",
  "priority": "High",
  "assignee": "sree",
  "reporter": "jane",
  "story_points": 5,
  "sprint": "Sprint 24.3",
  "labels": ["middleware", "order-management"],
  "epic_key": "OM-900",
  "acceptance_criteria": "Given a valid order...",
  "subtask_count": 2,
  "subtasks": [
    {"key": "OM-1235", "summary": "Add input validation", "status": "Done", "type": "Sub-task"}
  ],
  "linked_issues": [
    {"relationship": "blocks", "key": "OM-1300", "summary": "Deploy pipeline", "status": "To Do"}
  ],
  "recent_comments": [
    {"author": "Jane Doe", "created": "2025-10-01T10:00:00.000+0000", "body": "Ready for review"}
  ],
  "comment_count": 3
}
```

Example error:
```json
{
  "error": "JIRA_PAT is not set and not found in ~/.jira-reader.env",
  "hint": "Token setup — create file ~/.jira-reader.env containing exactly: JIRA_PAT=\"<your_token>\" (one line, with quotes). Command: echo 'JIRA_PAT=\"<token>\"' > ~/.jira-reader.env && chmod 600 ~/.jira-reader.env"
}
```

## Script Inventory

| Script | Purpose | Dependencies |
|--------|---------|-------------|
| `scripts/_lib.sh` | Shared library (sourced, not executed) — env validation, curl wrapper, error formatting, ticket key regex | `curl`, `jq` (optional) |
| `scripts/extract-ticket-key.sh` | Extract ticket key(s) from arbitrary text | `grep` |
| `scripts/fetch-ticket.sh` | Fetch full ticket details (`--compact`, `--follow-links`) | `curl`, `jq` (optional) |
| `scripts/fetch-links.sh` | Fetch linked issues | `curl`, `jq` (optional) |
| `scripts/fetch-subtasks.sh` | Fetch sub-tasks | `curl`, `jq` (optional) |
| `scripts/fetch-comments.sh` | Fetch recent comments (`--extract-refs`) | `curl`, `jq` (optional) |
| `scripts/fetch-batch.sh` | Fetch multiple tickets in one API call (`--compact`) | `curl`, `jq` (optional) |
| `scripts/fetch-jql.sh` | JQL search or saved filter execution (`--jql`, `--filter`, `--max`) | `curl`, `jq` (optional) |
| `scripts/fetch-sprint.sh` | Fetch sprint context and sibling tickets | `curl`, `jq` (optional) |
| `scripts/fetch-wiki.sh` | Fetch Confluence wiki page content | `curl`, `jq` (optional) |

## Configuration Note

Custom field IDs (`customfield_XXXXX` in `fetch-ticket.sh`) vary per Jira instance. To find your actual field IDs:

```bash
curl -s -H "Authorization: Bearer $JIRA_PAT" \
  "$JIRA_BASE_URL/rest/api/2/field" | jq '.[] | {id, name}'
```

Update the field IDs in `scripts/fetch-ticket.sh` to match your instance (story points, sprint, epic link, acceptance criteria).

## Windows / WSL Compatibility

### Platform support

| Platform | Status | Terminal |
|----------|--------|----------|
| macOS | Works out of the box | Terminal, iTerm, VS Code terminal |
| Linux | Works out of the box | Any bash terminal |
| Windows + Git Bash | Works | Git Bash terminal in VS Code |
| Windows + WSL | Works (with path awareness) | WSL terminal in VS Code |
| Windows + PowerShell | Not supported (bash scripts) | Use Git Bash or WSL instead |

### Known issue: WSL home ≠ Windows home

On WSL, `~` resolves to `/home/<wsl_user>` (e.g., `/home/devcontainers`), NOT `C:\Users\<NTID>`. If a token was saved from PowerShell or Windows Explorer, the bash scripts won't find it.

**The scripts auto-detect WSL** and search for env files in this order:
1. `$JIRA_PAT` / `$WIKI_PAT` environment variable (if already exported)
2. `$HOME/.jira-reader.env` / `$HOME/.wiki-reader.env` (WSL or native home)
3. Windows user profile via `/mnt/c/Users/<NTID>/` (WSL only — auto-discovered)

### Agent troubleshooting: Windows PAT setup (MUST follow on Windows)

When running on Windows and the PAT is missing, agents MUST use this procedure instead of the standard Mac/Linux instructions:

1. **Detect the platform** — if the error mentions WSL or the terminal is PowerShell/Git Bash, assume Windows.
2. **Use inline PAT** as the fastest fix (works immediately, no file path issues):
   ```bash
   JIRA_PAT="<token>" bash .github/skills/jira-wiki-reader/scripts/fetch-ticket.sh <KEY>
   ```
3. **Save to WSL home** (for persistence in WSL terminals):
   ```bash
   echo 'JIRA_PAT="<token>"' > ~/.jira-reader.env && chmod 600 ~/.jira-reader.env
   ```
4. **Or save to Windows home** (for persistence across both PowerShell and WSL):
   ```powershell
   # In PowerShell:
   Set-Content -Path "$env:USERPROFILE\.jira-reader.env" -Value 'JIRA_PAT="<token>"'
   ```
   The scripts will auto-find it via `/mnt/c/Users/<NTID>/.jira-reader.env`.

5. **Do NOT mix PowerShell and bash syntax** — `$env:JIRA_PAT` (PowerShell) does not pass to bash subprocesses. Use inline `JIRA_PAT="..."` or env files.
6. **If WSL itself fails** ("Failed to start the systemd user session"): switch the VS Code terminal to **Git Bash** instead of WSL. Git Bash runs natively on Windows and doesn't need WSL.

Same procedure applies for `WIKI_PAT` / `~/.wiki-reader.env`.
