#!/usr/bin/env bash
# ============================================================================
# Jira Reader — Fetch Multiple Tickets in One Call (Read-Only)
# Uses JQL `key in (...)` to retrieve multiple tickets via a single API call.
#
# Usage:
#   bash .github/skills/jira-wiki-reader/scripts/fetch-batch.sh KEY-1 KEY-2 ... [--compact]
#
# Options:
#   --compact   Strip {code} blocks, log lines, and truncate long fields
#               (description: 1000 chars, comments: 500 chars)
#
# Output: JSON object with count, tickets array (full ticket shape), errors.
# Hard limit: 20 tickets per call (bounded execution — non-negotiable B).
# ============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/_lib.sh"

# ---------------------------------------------------------------------------
# Constants — bounded behavior
# ---------------------------------------------------------------------------
MAX_TICKETS=20  # Hard upper bound per call

# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------
COMPACT=false
KEYS=()

for arg in "$@"; do
  case "$arg" in
    --compact)
      COMPACT=true
      ;;
    -*)
      error_json "Unknown option: $arg" \
        "Usage: fetch-batch.sh KEY-1 KEY-2 ... [--compact]. Max ${MAX_TICKETS} keys."
      exit 1
      ;;
    *)
      KEYS+=("$(echo "$arg" | tr '[:lower:]' '[:upper:]')")
      ;;
  esac
done

if [ ${#KEYS[@]} -lt 1 ]; then
  error_json "No ticket keys provided" \
    "Usage: fetch-batch.sh KEY-1 KEY-2 ... [--compact]. Provide 1 to ${MAX_TICKETS} ticket keys."
  exit 1
fi

if [ ${#KEYS[@]} -gt "$MAX_TICKETS" ]; then
  error_json "Too many keys: ${#KEYS[@]} exceeds maximum of ${MAX_TICKETS}" \
    "Split into multiple calls of ${MAX_TICKETS} or fewer keys."
  exit 1
fi

# Validate each key format
for key in "${KEYS[@]}"; do
  validate_ticket_key "$key"
done

validate_env

# ---------------------------------------------------------------------------
# Build JQL: key in (KEY-1, KEY-2, ...)
# ---------------------------------------------------------------------------
JQL_KEYS=$(printf '"%s",' "${KEYS[@]}")
JQL_KEYS="${JQL_KEYS%,}"  # Remove trailing comma
JQL="key in (${JQL_KEYS})"

# URL-encode
if [ "$HAS_JQ" = true ]; then
  ENCODED_JQL=$(printf '%s' "$JQL" | jq -sRr @uri)
else
  ENCODED_JQL=$(printf '%s' "$JQL" | sed \
    -e 's/ /%20/g' \
    -e 's/"/%22/g' \
    -e 's/=/%3D/g' \
    -e 's/(/%28/g' \
    -e 's/)/%29/g' \
    -e 's/,/%2C/g' \
    -e 's/&/%26/g')
fi

# ---------------------------------------------------------------------------
# Fields — full ticket fields (same as fetch-ticket.sh)
# ---------------------------------------------------------------------------
FIELDS="summary,description,status,priority,issuetype,assignee,reporter,created,updated,resolutiondate"
FIELDS+=",labels,components,fixVersions,resolution"
FIELDS+=",customfield_10423"   # Story Points
FIELDS+=",customfield_10007"   # Sprint
FIELDS+=",customfield_18881"   # Epic Link (actual field on this instance)
FIELDS+=",customfield_10008"   # Epic Link (legacy/fallback)
FIELDS+=",customfield_10014"   # Acceptance Criteria
FIELDS+=",parent,subtasks,issuelinks,comment"

# ---------------------------------------------------------------------------
# Fetch
# ---------------------------------------------------------------------------
RAW=$(jira_curl "/search?jql=${ENCODED_JQL}&fields=${FIELDS}&maxResults=${MAX_TICKETS}&expand=names")

# ---------------------------------------------------------------------------
# Transform — compact mode strips noise
# ---------------------------------------------------------------------------
if [ "$HAS_JQ" = true ]; then
  REQUESTED_KEYS=$(printf '%s\n' "${KEYS[@]}" | jq -R . | jq -s .)
  echo "$RAW" | jq --arg compact "$COMPACT" --argjson requested_keys "$REQUESTED_KEYS" "${JQ_COMPACT_DEF}"'{
    count: (.issues | length),
    requested: ($requested_keys | length),
    missing: ([($requested_keys[]) as $k | if [.issues[].key] | index($k) | not then $k else empty end]),
    tickets: [
      .issues[] | {
        key: .key,
        summary: .fields.summary,
        description: (
          if (.fields.description | type) == "string" then
            if $compact == "true" then compact_text(.fields.description; 1000)
            else .fields.description
            end
          elif .fields.description == null then null
          else (.fields.description | tostring)
          end
        ),
        status: .fields.status.name,
        status_category: .fields.status.statusCategory.name,
        type: .fields.issuetype.name,
        priority: .fields.priority.name,
        assignee: (if .fields.assignee then .fields.assignee.displayName else "Unassigned" end),
        assignee_id: (if .fields.assignee then .fields.assignee.name else null end),
        reporter: (if .fields.reporter then .fields.reporter.displayName else null end),
        labels: (.fields.labels // []),
        components: [.fields.components[]?.name],
        fix_versions: [.fields.fixVersions[]?.name],
        resolution: (.fields.resolution.name // null),
        story_points: (.fields.customfield_10423 // null),
        sprint: (
          if .fields.customfield_10007 then
            if (.fields.customfield_10007 | type) == "array" then
              (.fields.customfield_10007 | last | .name // null)
            elif (.fields.customfield_10007 | type) == "string" then
              (.fields.customfield_10007 | capture("name=(?<n>[^,]+)") | .n // null)
            else null end
          else null end
        ),
        epic_key: (
          .fields.customfield_18881 //
          .fields.customfield_10008 //
          (if .fields.parent and (.fields.parent.fields.issuetype.name == "Epic") then .fields.parent.key else null end)
        ),
        parent_key: (.fields.parent.key // null),
        acceptance_criteria: (.fields.customfield_10014 // null),
        linked_issues: [
          .fields.issuelinks[]? | {
            relationship: (
              if .outwardIssue then .type.outward
              elif .inwardIssue then .type.inward
              else .type.name end
            ),
            direction: (if .outwardIssue then "outward" elif .inwardIssue then "inward" else "unknown" end),
            key: (.outwardIssue // .inwardIssue).key,
            summary: (.outwardIssue // .inwardIssue).fields.summary,
            status: (.outwardIssue // .inwardIssue).fields.status.name,
            priority: ((.outwardIssue // .inwardIssue).fields.priority.name // null),
            type: ((.outwardIssue // .inwardIssue).fields.issuetype.name // null)
          }
        ],
        recent_comments: [
          (.fields.comment.comments // []) | sort_by(.created) | reverse | .[0:5][] | {
            author: .author.displayName,
            created: .created,
            body: (
              if $compact == "true" then compact_text(.body; 500)
              else
                (if (.body | length) > 1000 then (.body[0:1000] + " [truncated]") else .body end)
              end
            )
          }
        ],
        comment_count: ((.fields.comment.total // (.fields.comment.comments | length)) // 0),
        created: .fields.created,
        updated: .fields.updated,
        resolved: (.fields.resolutiondate // null)
      }
    ],
    errors: ([($requested_keys[]) as $k | if [.issues[].key] | index($k) | not then {key: $k, error: "Ticket not found or not accessible"} else empty end])
  }'
else
  echo "$RAW"
  echo >&2 "[warn] jq not found — outputting raw Jira search response."
fi
