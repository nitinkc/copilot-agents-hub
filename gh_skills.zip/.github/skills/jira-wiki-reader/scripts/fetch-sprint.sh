#!/usr/bin/env bash
# ============================================================================
# Jira Reader — Fetch Sprint Context
# Retrieves the active sprint containing this ticket and lists sibling tickets.
#
# Usage: bash .github/skills/jira-wiki-reader/scripts/fetch-sprint.sh <TICKET_KEY>
#
# Note: This uses JQL search, which works on Jira Data Center with Agile plugin.
# ============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/_lib.sh"

if [ $# -lt 1 ]; then
  error_json "Missing required argument: TICKET_KEY" \
    "Usage: bash .github/skills/jira-wiki-reader/scripts/fetch-sprint.sh <TICKET_KEY>"
  exit 1
fi

TICKET_KEY="$(echo "$1" | tr '[:lower:]' '[:upper:]')"
validate_ticket_key "$TICKET_KEY"
validate_env

# Step 1: Get the sprint info from the ticket itself
TICKET_RAW=$(jira_curl "/issue/${TICKET_KEY}?fields=customfield_10007,project")

if [ "$HAS_JQ" != true ]; then
  echo "$TICKET_RAW"
  echo >&2 "[warn] jq required for sprint context extraction. Install jq for full functionality."
  exit 0
fi

# Extract sprint name and project key
SPRINT_NAME=$(echo "$TICKET_RAW" | jq -r '
  if .fields.customfield_10007 then
    if (.fields.customfield_10007 | type) == "array" then
      (.fields.customfield_10007 | map(select(.state == "active" or .state == "ACTIVE")) | first // (.fields.customfield_10007 | last)) | .name // empty
    elif (.fields.customfield_10007 | type) == "string" then
      (.fields.customfield_10007 | capture("name=(?<n>[^,]+)") | .n) // empty
    else empty
    end
  else empty
  end
')

PROJECT_KEY=$(echo "$TICKET_RAW" | jq -r '.fields.project.key // empty')

if [ -z "$SPRINT_NAME" ]; then
  error_json "No active sprint found for ${TICKET_KEY}." \
    "The ticket may not be assigned to a sprint, or the sprint data format may differ."
  exit 1
fi

# Step 2: Find all tickets in the same sprint via JQL
ENCODED_SPRINT=$(printf '%s' "$SPRINT_NAME" | jq -sRr @uri 2>/dev/null \
  || printf '%s' "$SPRINT_NAME" | sed 's/ /%20/g')

JQL="project=${PROJECT_KEY} AND sprint=\"${SPRINT_NAME}\" ORDER BY priority DESC, status ASC"
ENCODED_JQL=$(printf '%s' "$JQL" | jq -sRr @uri 2>/dev/null \
  || printf '%s' "$JQL" | sed 's/ /%20/g; s/"/%22/g; s/=/%3D/g')

SPRINT_TICKETS=$(jira_curl "/search?jql=${ENCODED_JQL}&fields=summary,status,issuetype,priority,assignee,customfield_10423&maxResults=50")

echo "$SPRINT_TICKETS" | jq --arg sprint "$SPRINT_NAME" --arg source_key "$TICKET_KEY" '{
  source_ticket: $source_key,
  sprint_name: $sprint,
  total_tickets: .total,
  tickets: [
    .issues[] | {
      key: .key,
      summary: .fields.summary,
      status: .fields.status.name,
      status_category: .fields.status.statusCategory.name,
      type: .fields.issuetype.name,
      priority: .fields.priority.name,
      assignee: (if .fields.assignee then .fields.assignee.displayName else "Unassigned" end),
      story_points: (.fields.customfield_10423 // null),
      is_source: (.key == $source_key)
    }
  ],
  summary: {
    total_points: ([.issues[] | .fields.customfield_10423 // 0] | add),
    completed: ([.issues[] | select(.fields.status.statusCategory.name == "Done")] | length),
    in_progress: ([.issues[] | select(.fields.status.statusCategory.name == "In Progress")] | length),
    todo: ([.issues[] | select(.fields.status.statusCategory.name == "To Do")] | length)
  }
}'
