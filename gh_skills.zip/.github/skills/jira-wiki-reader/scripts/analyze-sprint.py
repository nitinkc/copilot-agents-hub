#!/usr/bin/env python3
"""
Jira Reader — Sprint Data Analyzer
====================================
Reads cached raw Jira data and produces a structured analysis.json.
Used by both sprint-retrospective and standup-intelligence prompts.

Usage:
  python3 analyze-sprint.py --cache-dir /path/to/cache [--output /path/to/analysis.json]

Reads from cache:
  sprint-meta.json, sprint-report.json (if exists), tickets-full.json,
  changelogs.json, board-config.json (if exists), velocity.json (if exists)

Writes:
  {cache_dir}/analysis.json — structured analysis with all derived metrics

Hard limits: no Jira API calls. All data comes from cached files.
"""
import argparse
import json
import os
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)

from _pylib import parse_ts, load_json, save_json, build_ticket_map, extract_sp_from_report_item

# ---------------------------------------------------------------------------
# Status order for regression detection
# ---------------------------------------------------------------------------
STATUS_ORDER = {
    "to do": 0, "open": 0, "new": 0, "backlog": 0, "not started": 0,
    "in progress": 1, "develop": 1, "design": 1,
    "peer review": 2, "in review": 2, "validate": 2, "test": 2, "qa": 2,
    "done": 3, "closed": 3, "resolved": 3, "accepted": 3,
}


def parse_changelogs(changelogs, sprint_start, sprint_end):
    """Parse raw changelogs into structured transition data.

    Returns:
        dict with keys: status_transitions, blocked_periods, sp_changes,
            assignee_changes, sprint_changes, regressions
    """
    status_transitions = defaultdict(list)
    blocked_periods = defaultdict(list)
    sp_changes = defaultdict(list)
    assignee_changes = defaultdict(list)
    sprint_changes = defaultdict(list)
    regressions = []

    for key, histories in changelogs.items():
        for h in histories:
            ts = parse_ts(h.get("created", ""))
            if not ts:
                continue
            for item in h.get("items", []):
                field = item.get("field", "")
                from_str = item.get("fromString", "") or ""
                to_str = item.get("toString", "") or ""

                if field == "status":
                    status_transitions[key].append({
                        "ts": ts.isoformat(), "from": from_str, "to": to_str
                    })
                    # Detect regressions
                    fr_rank = STATUS_ORDER.get(from_str.lower(), -1)
                    to_rank = STATUS_ORDER.get(to_str.lower(), -1)
                    if fr_rank > to_rank >= 0:
                        regressions.append({
                            "key": key, "from": from_str, "to": to_str,
                            "date": ts.strftime("%Y-%m-%d"),
                        })
                elif field == "Sprint":
                    sprint_changes[key].append({
                        "ts": ts.isoformat(), "from": from_str, "to": to_str
                    })
                elif field == "assignee":
                    assignee_changes[key].append({
                        "ts": ts.isoformat(), "from": from_str, "to": to_str
                    })
                elif field.lower() in ("story points", "story_points"):
                    sp_changes[key].append({
                        "ts": ts.isoformat(), "from": from_str, "to": to_str
                    })

    # Sort transitions by timestamp
    for key in status_transitions:
        status_transitions[key].sort(key=lambda x: x["ts"])

    # Compute blocked periods from status transitions
    for key, trans in status_transitions.items():
        in_blocked = False
        block_start = None
        for t in trans:
            ts = parse_ts(t["ts"])
            if "block" in t["to"].lower() and not in_blocked:
                in_blocked = True
                block_start = ts
            elif in_blocked and "block" not in t["to"].lower():
                in_blocked = False
                if block_start:
                    blocked_periods[key].append({
                        "start": block_start.isoformat(),
                        "end": ts.isoformat(),
                        "days": (ts - block_start).days,
                    })
        if in_blocked and block_start:
            blocked_periods[key].append({
                "start": block_start.isoformat(),
                "end": sprint_end.isoformat(),
                "days": (sprint_end - block_start).days,
            })

    return {
        "status_transitions": dict(status_transitions),
        "blocked_periods": dict(blocked_periods),
        "sp_changes": dict(sp_changes),
        "assignee_changes": dict(assignee_changes),
        "sprint_changes": dict(sprint_changes),
        "regressions": regressions,
    }


def compute_sprint_metrics(ticket_map, sprint_report):
    """Compute high-level sprint metrics from ticket map and sprint report.

    Returns dict with committed, completed, carryover, scope change metrics.
    """
    # Treat sprint_report as absent if its contents are all empty (active sprint)
    has_report_data = (
        sprint_report
        and sprint_report.get("contents", {}).get("completedIssues")
        or sprint_report
        and sprint_report.get("contents", {}).get("issuesNotCompletedInCurrentSprint")
        or sprint_report
        and sprint_report.get("contents", {}).get("puntedIssues")
    ) if sprint_report else False

    if not has_report_data:
        # Active sprint mode — compute from ticket statuses directly
        total = len(ticket_map)
        done = sum(1 for v in ticket_map.values() if v["status_cat"] == "Done")
        in_prog = sum(1 for v in ticket_map.values() if v["status_cat"] == "In Progress")
        todo = total - done - in_prog
        done_sp = sum(v["sp"] or 0 for v in ticket_map.values() if v["status_cat"] == "Done")
        total_sp = sum(v["sp"] or 0 for v in ticket_map.values())
        not_done = total - done
        not_done_sp = total_sp - done_sp

        defect_count = sum(1 for v in ticket_map.values()
                           if "bug" in v["type"].lower() or "defect" in v["type"].lower())
        unestimated = sum(1 for v in ticket_map.values()
                          if v["sp"] is None and v["type"] not in ("Sub-task", "Epic"))
        canceled = sum(1 for v in ticket_map.values()
                       if v["resolution"].lower() in ("cancelled", "canceled", "won't do", "duplicate", "won't fix"))

        return {
            "total_items": total,
            "committed_items": total,
            "committed_sp": total_sp,
            "completed_items": done,
            "completed_sp": done_sp,
            "not_completed_items": not_done,
            "not_completed_sp": not_done_sp,
            "done_items": done,
            "done_sp": done_sp,
            "in_progress_items": in_prog,
            "todo_items": todo,
            "total_sp": total_sp,
            "punted_items": 0,
            "punted_sp": 0.0,
            "added_items": 0,
            "added_keys": [],
            "added_sp": 0.0,
            "completion_rate_items": done / total * 100 if total else 0,
            "completion_rate_sp": done_sp / total_sp * 100 if total_sp else 0,
            "scope_injection_pct": 0,
            "type_breakdown": dict(Counter(v["type"] for v in ticket_map.values())),
            "defect_count": defect_count,
            "defect_pct": defect_count / total * 100 if total else 0,
            "unestimated": unestimated,
            "canceled": canceled,
        }

    contents = sprint_report.get("contents", {})
    comp_issues = contents.get("completedIssues", [])
    nc_issues = contents.get("issuesNotCompletedInCurrentSprint", [])
    punt_issues = contents.get("puntedIssues", [])
    added_keys = set(contents.get("issueKeysAddedDuringSprint", {}).keys())

    def sum_sp(issue_list):
        total = 0.0
        for i in issue_list:
            sp = extract_sp_from_report_item(i)
            if sp is not None:
                total += sp
        return total

    comp_sp = sum_sp(comp_issues)
    nc_sp = sum_sp(nc_issues)
    punt_sp = sum_sp(punt_issues)

    all_report_keys = {i["key"] for i in comp_issues} | {i["key"] for i in nc_issues} | {i["key"] for i in punt_issues}
    committed_keys = all_report_keys - added_keys

    committed_sp = 0.0
    for ilist in [comp_issues, nc_issues, punt_issues]:
        for i in ilist:
            if i["key"] not in added_keys:
                sp = extract_sp_from_report_item(i)
                if sp:
                    committed_sp += sp

    added_sp = 0.0
    for ilist in [comp_issues, nc_issues]:
        for i in ilist:
            if i["key"] in added_keys:
                sp = extract_sp_from_report_item(i)
                if sp:
                    added_sp += sp

    total_items = len(comp_issues) + len(nc_issues)
    total_sp = comp_sp + nc_sp

    type_counter = Counter(v["type"] for v in ticket_map.values())
    defect_count = sum(1 for v in ticket_map.values()
                       if "bug" in v["type"].lower() or "defect" in v["type"].lower())
    unestimated = sum(1 for v in ticket_map.values()
                      if v["sp"] is None and v["type"] not in ("Sub-task", "Epic"))
    canceled = sum(1 for v in ticket_map.values()
                   if v["resolution"].lower() in ("cancelled", "canceled", "won't do", "duplicate", "won't fix"))

    return {
        "committed_items": len(committed_keys),
        "committed_sp": committed_sp,
        "completed_items": len(comp_issues),
        "completed_sp": comp_sp,
        "not_completed_items": len(nc_issues),
        "not_completed_sp": nc_sp,
        "punted_items": len(punt_issues),
        "punted_sp": punt_sp,
        "added_items": len(added_keys),
        "added_keys": sorted(added_keys),
        "added_sp": added_sp,
        "total_items": total_items,
        "total_sp": total_sp,
        "completion_rate_items": len(comp_issues) / total_items * 100 if total_items else 0,
        "completion_rate_sp": comp_sp / total_sp * 100 if total_sp else 0,
        "scope_injection_pct": len(added_keys) / len(committed_keys) * 100 if committed_keys else 0,
        "type_breakdown": dict(type_counter),
        "defect_count": defect_count,
        "defect_pct": defect_count / len(ticket_map) * 100 if ticket_map else 0,
        "unestimated": unestimated,
        "canceled": canceled,
        # Compatibility keys for generate-standup-html.py (expects active-mode names)
        "done_items": len(comp_issues),
        "in_progress_items": sum(1 for v in ticket_map.values() if v["status_cat"] == "In Progress"),
        "todo_items": total_items - len(comp_issues) - sum(1 for v in ticket_map.values() if v["status_cat"] == "In Progress"),
        "done_sp": comp_sp,
    }


def compute_developer_metrics(ticket_map, changelog_data, sprint_start, sprint_end, tickets=None):
    """Compute per-developer metrics.

    Returns:
        list of dicts sorted by assigned count descending, each with:
        developer, assigned, completed, carryover, blocked_tickets,
        total_blocked_days, cycle_times, wip_peak, sp_assigned, sp_completed,
        status_regressions, missing_estimates, missing_descriptions, completion_rate,
        forward_transitions, backward_transitions, stale_tickets, late_starts,
        reassigned_from_count, reassigned_to_count, sp_change_count,
        comment_count, avg_time_to_start_days, transition_count
    """
    status_transitions = changelog_data["status_transitions"]
    blocked_periods = changelog_data["blocked_periods"]

    dev_stats = defaultdict(lambda: {
        "assigned": [], "completed": [], "carryover": [],
        "blocked_tickets": [], "total_blocked_days": 0,
        "cycle_times": [], "wip_peak": 0,
        "sp_assigned": 0.0, "sp_completed": 0.0,
        "status_regressions": [],
        "missing_estimates": 0, "missing_descriptions": 0,
        # Behavioral signals
        "forward_transitions": 0, "backward_transitions": 0,
        "transition_count": 0, "stale_tickets": [],
        "time_to_start": [],   # days from sprint start to first In Progress per ticket
        "late_starts": [],     # tickets not started until >50% of sprint
        "reassigned_from": 0, "reassigned_to": 0,
        "sp_change_count": 0, "comment_count": 0,
        "completion_days": [],  # sprint day (0..N) when each item was completed
    })

    for key, info in ticket_map.items():
        dev = info["assignee"]
        if dev == "Unassigned":
            continue
        s = dev_stats[dev]
        s["assigned"].append(key)
        if info["sp"]:
            s["sp_assigned"] += info["sp"]
        if info["in_completed"]:
            s["completed"].append(key)
            if info["sp"]:
                s["sp_completed"] += info["sp"]
        elif info["in_not_completed"]:
            s["carryover"].append(key)

        # Blocked
        bp = blocked_periods.get(key, [])
        if bp:
            td = sum(p["days"] for p in bp)
            if td > 0:
                s["blocked_tickets"].append(key)
                s["total_blocked_days"] += td

        # Cycle time
        trans = status_transitions.get(key, [])
        first_ip = None
        done_ts = None
        for t in trans:
            ts = parse_ts(t["ts"])
            if not first_ip and ("progress" in t["to"].lower() or "develop" in t["to"].lower()):
                first_ip = ts
            if "done" in t["to"].lower() or t["to"].lower() in ("closed", "resolved", "accepted"):
                done_ts = ts
        if first_ip and done_ts and done_ts > first_ip:
            s["cycle_times"].append({"key": key, "days": (done_ts - first_ip).days})

        # Regressions per developer
        for t in trans:
            fr_rank = STATUS_ORDER.get(t["from"].lower(), -1)
            to_rank = STATUS_ORDER.get(t["to"].lower(), -1)
            if fr_rank > to_rank >= 0:
                s["status_regressions"].append({
                    "key": key, "from": t["from"], "to": t["to"],
                    "date": parse_ts(t["ts"]).strftime("%Y-%m-%d") if parse_ts(t["ts"]) else "",
                })

        # Hygiene
        if info["sp"] is None and info["type"] not in ("Sub-task", "Epic"):
            s["missing_estimates"] += 1
        if not info["description"] or len(info["description"].strip()) < 10:
            s["missing_descriptions"] += 1

    # Compute WIP peak per developer
    for dev, s in dev_stats.items():
        ip_periods = []
        for key in s["assigned"]:
            trans = status_transitions.get(key, [])
            ip_start = None
            for t in trans:
                ts = parse_ts(t["ts"])
                if "progress" in t["to"].lower() or "develop" in t["to"].lower():
                    ip_start = ts
                elif ip_start and "progress" not in t["to"].lower() and "develop" not in t["to"].lower():
                    ip_periods.append((ip_start, ts))
                    ip_start = None
            if ip_start:
                ip_periods.append((ip_start, sprint_end))

        max_wip = 0
        for i, (s1, e1) in enumerate(ip_periods):
            concurrent = 1
            for j, (s2, e2) in enumerate(ip_periods):
                if i != j and s2 < e1 and e2 > s1:
                    concurrent += 1
            max_wip = max(max_wip, concurrent)
        s["wip_peak"] = max_wip

    # ── Behavioral signals: transitions, flow, responsiveness ──────────
    sprint_mid = sprint_start + (sprint_end - sprint_start) / 2
    sprint_duration = (sprint_end - sprint_start).days
    assignee_changes = changelog_data.get("assignee_changes", {})
    sp_changes = changelog_data.get("sp_changes", {})

    for dev, s in dev_stats.items():
        for key in s["assigned"]:
            trans = status_transitions.get(key, [])
            first_ip = None
            fwd = 0
            bwd = 0
            tc = 0
            for t in trans:
                ts = parse_ts(t["ts"])
                if not ts or ts < sprint_start or ts > sprint_end:
                    continue
                tc += 1
                fr_rank = STATUS_ORDER.get(t["from"].lower(), -1)
                to_rank = STATUS_ORDER.get(t["to"].lower(), -1)
                if fr_rank >= 0 and to_rank >= 0:
                    if to_rank > fr_rank:
                        fwd += 1
                    elif to_rank < fr_rank:
                        bwd += 1
                if not first_ip and ("progress" in t["to"].lower() or "develop" in t["to"].lower()):
                    first_ip = ts
            s["forward_transitions"] += fwd
            s["backward_transitions"] += bwd
            s["transition_count"] += tc

            # Time to start & late starts
            if first_ip:
                days_to_start = max(0, (first_ip - sprint_start).total_seconds() / 86400)
                s["time_to_start"].append(days_to_start)
                if first_ip > sprint_mid:
                    s["late_starts"].append(key)
            elif tc == 0:
                # No transitions during sprint — stale
                s["stale_tickets"].append(key)

            # Completion day within sprint (for delivery spread)
            done_statuses_lc = {"done", "closed", "resolved", "accepted", "released", "complete"}
            for t in trans:
                ts = parse_ts(t["ts"])
                if ts and t["to"].lower() in done_statuses_lc:
                    sprint_day = max(0, min(sprint_duration, (ts - sprint_start).days))
                    s["completion_days"].append(sprint_day)
                    break  # first done transition only

        # Reassignments: count times tickets were assigned TO or FROM this dev
        for key in s["assigned"]:
            for ac in assignee_changes.get(key, []):
                ts = parse_ts(ac["ts"])
                if not ts or ts < sprint_start or ts > sprint_end:
                    continue
                if ac.get("to", "") == dev:
                    s["reassigned_to"] += 1
                if ac.get("from", "") == dev:
                    s["reassigned_from"] += 1

        # SP changes on assigned tickets during sprint
        for key in s["assigned"]:
            for sc in sp_changes.get(key, []):
                ts = parse_ts(sc["ts"])
                if ts and sprint_start <= ts <= sprint_end:
                    s["sp_change_count"] += 1

    # Comment activity from raw tickets (if provided)
    if tickets:
        # Build assignee lookup from ticket_map
        ticket_assignees = {k: v["assignee"] for k, v in ticket_map.items()}
        for t in tickets:
            key = t.get("key", "")
            dev = ticket_assignees.get(key)
            if not dev or dev == "Unassigned" or dev not in dev_stats:
                continue
            comments = t.get("fields", {}).get("comment", {}).get("comments", [])
            for c in comments:
                author = c.get("author", {}).get("displayName", "")
                cts = parse_ts(c.get("created", ""))
                if cts and sprint_start <= cts <= sprint_end and author == dev:
                    dev_stats[dev]["comment_count"] += 1

    # Build output list sorted by assigned count descending
    result = []
    for dev, s in sorted(dev_stats.items(), key=lambda x: -len(x[1]["assigned"])):
        ac = len(s["assigned"])
        cc = len(s["completed"])
        avg_ct = (sum(ct["days"] for ct in s["cycle_times"]) / len(s["cycle_times"])
                  if s["cycle_times"] else 0)
        avg_tts = (sum(s["time_to_start"]) / len(s["time_to_start"])
                   if s["time_to_start"] else None)
        result.append({
            "developer": dev,
            "assigned_count": ac,
            "assigned_keys": s["assigned"],
            "completed_count": cc,
            "completed_keys": s["completed"],
            "carryover_count": len(s["carryover"]),
            "carryover_keys": s["carryover"],
            "completion_rate": cc / ac * 100 if ac else 0,
            "sp_assigned": s["sp_assigned"],
            "sp_completed": s["sp_completed"],
            "blocked_tickets": s["blocked_tickets"],
            "total_blocked_days": s["total_blocked_days"],
            "cycle_times": s["cycle_times"],
            "avg_cycle_time": avg_ct,
            "wip_peak": s["wip_peak"],
            "status_regressions": s["status_regressions"],
            "missing_estimates": s["missing_estimates"],
            "missing_descriptions": s["missing_descriptions"],
            # Behavioral signals
            "forward_transitions": s["forward_transitions"],
            "backward_transitions": s["backward_transitions"],
            "transition_count": s["transition_count"],
            "stale_tickets": s["stale_tickets"],
            "late_starts": s["late_starts"],
            "avg_time_to_start_days": round(avg_tts, 1) if avg_tts is not None else None,
            "reassigned_from_count": s["reassigned_from"],
            "reassigned_to_count": s["reassigned_to"],
            "sp_change_count": s["sp_change_count"],
            "comment_count": s["comment_count"],
            "completion_days": sorted(s["completion_days"]),
        })
    return result


def compute_blockers(ticket_map, changelog_data, current_only=False):
    """Compute blocker list sorted by days blocked descending.

    Args:
        current_only: When True (standup), include only tickets whose
            current Jira status contains 'block' and report days from
            the current open blocked period only.  When False (retro),
            include every ticket that was blocked at any point and
            report total blocked days across all periods.
    """
    blocked_periods = changelog_data["blocked_periods"]
    result = []
    for key, periods in blocked_periods.items():
        info = ticket_map.get(key, {})

        if current_only:
            current_status = (info.get("status", "") or "").lower()
            if "block" not in current_status:
                continue
            # Use only the last (open) blocked period for the days count
            current_period = periods[-1] if periods else None
            if current_period is None:
                continue
            days = current_period.get("days", 0)
        else:
            days = sum(p["days"] for p in periods)

        if days <= 0:
            continue
        result.append({
            "key": key,
            "summary": info.get("summary", ""),
            "assignee": info.get("assignee", ""),
            "days": days,
            "periods": periods,
        })
    result.sort(key=lambda x: -x["days"])
    return result


def compute_carryover(ticket_map, sprint_report, changelog_data, sprint_end):
    """Compute carryover items with context (days in status, blocked days, etc.)."""
    if not sprint_report:
        return []

    contents = sprint_report.get("contents", {})
    nc_issues = contents.get("issuesNotCompletedInCurrentSprint", [])
    added_keys = set(contents.get("issueKeysAddedDuringSprint", {}).keys())
    status_transitions = changelog_data["status_transitions"]
    blocked_periods = changelog_data["blocked_periods"]

    result = []
    for i in nc_issues:
        key = i["key"]
        info = ticket_map.get(key, {})
        sp = extract_sp_from_report_item(i)
        # Find last status change
        last_change = None
        for t in status_transitions.get(key, []):
            last_change = parse_ts(t["ts"])
        days_in_status = (sprint_end - last_change).days if last_change else 0
        blocked_days = sum(p["days"] for p in blocked_periods.get(key, []))

        result.append({
            "key": key,
            "summary": info.get("summary", ""),
            "assignee": info.get("assignee", ""),
            "type": info.get("type", ""),
            "sp": sp,
            "status": info.get("status", ""),
            "days_in_status": days_in_status,
            "blocked_days": blocked_days,
            "added_during": key in added_keys,
        })

    result.sort(key=lambda x: -(float(x["sp"]) if x["sp"] else 0))
    return result


def compute_hygiene(ticket_map, sprint_end):
    """Compute Jira hygiene findings."""
    missing_est = [k for k, v in ticket_map.items()
                   if v["sp"] is None and v["type"] not in ("Sub-task", "Epic")]
    missing_desc = [k for k, v in ticket_map.items()
                    if not v["description"] or len(v["description"].strip()) < 10]
    unassigned = [k for k, v in ticket_map.items()
                  if v["assignee"] == "Unassigned"]
    no_epic = [k for k, v in ticket_map.items()
               if not v["epic"] and v["type"] not in ("Sub-task", "Epic")]
    stale = []
    for k, v in ticket_map.items():
        if v["status_cat"] != "Done" and v["updated"]:
            udt = parse_ts(v["updated"])
            if udt and (sprint_end - udt).days > 5:
                stale.append(k)

    return {
        "missing_estimates": missing_est,
        "missing_descriptions": missing_desc,
        "unassigned": unassigned,
        "no_epic": no_epic,
        "stale_tickets": stale,
    }


def compute_estimate_changes(changelog_data, sprint_start, ticket_map):
    """Find estimate changes that occurred during the sprint."""
    result = []
    for key, changes in changelog_data["sp_changes"].items():
        for c in changes:
            ts = parse_ts(c["ts"])
            if ts and ts >= sprint_start:
                info = ticket_map.get(key, {})
                result.append({
                    "key": key,
                    "assignee": info.get("assignee", ""),
                    "from": c["from"],
                    "to": c["to"],
                    "date": ts.strftime("%Y-%m-%d"),
                })
    return result


def compute_velocity(velocity_data):
    """Extract velocity from raw velocity chart data."""
    if not velocity_data:
        return []
    sprints = velocity_data.get("sprints", [])
    entries = velocity_data.get("velocityStatEntries", {})
    result = []
    for vs in sprints[-6:]:
        sid = str(vs["id"])
        entry = entries.get(sid, {})
        result.append({
            "name": vs["name"],
            "estimated": entry.get("estimated", {}).get("value", 0),
            "completed": entry.get("completed", {}).get("value", 0),
        })
    return result


# ---------------------------------------------------------------------------
# Standup-specific: recent movements (last 24h)
# ---------------------------------------------------------------------------
def compute_recent_movements(changelog_data, ticket_map, hours=24):
    """Find status transitions, assignee changes, and comments in last N hours.

    Returns dict with status_moves, assignee_moves, recent_comments.
    """
    from datetime import timedelta
    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)

    status_moves = []
    for key, trans in changelog_data["status_transitions"].items():
        for t in trans:
            ts = parse_ts(t["ts"])
            if ts and ts >= cutoff:
                info = ticket_map.get(key, {})
                fr_rank = STATUS_ORDER.get(t["from"].lower(), -1)
                to_rank = STATUS_ORDER.get(t["to"].lower(), -1)
                signal = "forward" if to_rank > fr_rank else ("regression" if fr_rank > to_rank >= 0 else "lateral")
                status_moves.append({
                    "key": key, "from": t["from"], "to": t["to"],
                    "assignee": info.get("assignee", ""), "signal": signal,
                    "date": ts.strftime("%Y-%m-%d %H:%M"),
                })

    assignee_moves = []
    for key, changes in changelog_data["assignee_changes"].items():
        for c in changes:
            ts = parse_ts(c["ts"])
            if ts and ts >= cutoff:
                assignee_moves.append({
                    "key": key, "from": c["from"], "to": c["to"],
                    "date": ts.strftime("%Y-%m-%d %H:%M"),
                })

    return {
        "status_moves": status_moves,
        "assignee_moves": assignee_moves,
    }


# ---------------------------------------------------------------------------
# Standup-specific: WIP per developer and flow health
# ---------------------------------------------------------------------------
def compute_flow_health(ticket_map):
    """Compute WIP per developer and flow column distribution."""
    wip_by_dev = defaultdict(lambda: {"in_progress": 0, "in_review": 0, "test": 0, "total_active": 0})
    column_counts = Counter()

    for key, info in ticket_map.items():
        if info["status_cat"] == "Done":
            column_counts["Done"] += 1
            continue

        st_lower = info["status"].lower()
        dev = info["assignee"]
        column_counts[info["status"]] += 1

        # Not Started / backlog items are not active WIP
        if info["status_cat"] == "To Do" or st_lower == "not started":
            continue

        if dev == "Unassigned":
            continue

        d = wip_by_dev[dev]
        if "progress" in st_lower or "develop" in st_lower:
            d["in_progress"] += 1
            d["total_active"] += 1
        elif "review" in st_lower:
            d["in_review"] += 1
            d["total_active"] += 1
        elif "test" in st_lower or "qa" in st_lower:
            d["test"] += 1
            d["total_active"] += 1
        elif "block" in st_lower:
            d["total_active"] += 1
        else:
            d["total_active"] += 1

    # Check WIP violations (default limits)
    violations = []
    for dev, d in wip_by_dev.items():
        if d["in_progress"] > 2:
            violations.append({
                "developer": dev, "field": "in_progress",
                "count": d["in_progress"], "limit": 2,
            })

    return {
        "wip_by_developer": dict(wip_by_dev),
        "column_distribution": dict(column_counts),
        "wip_violations": violations,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Analyze cached Jira sprint data.")
    parser.add_argument("--cache-dir", required=True, help="Cache directory from fetch-sprint-data.py")
    parser.add_argument("--output", default=None, help="Output JSON path (default: {cache-dir}/analysis.json)")
    parser.add_argument("--standup", action="store_true", help="Include standup-specific analysis (recent movements, flow health)")

    args = parser.parse_args()
    output_path = args.output or os.path.join(args.cache_dir, "analysis.json")

    # Load cached data
    sprint_meta_raw = load_json(args.cache_dir, "sprint-meta.json")
    tickets = load_json(args.cache_dir, "tickets-full.json")
    changelogs = load_json(args.cache_dir, "changelogs.json")

    # Handle new format: {sprints: [...], primary_sprint_id, project_key}
    primary_sprint_id = None
    if isinstance(sprint_meta_raw, dict) and "sprints" in sprint_meta_raw:
        sprint_meta = sprint_meta_raw["sprints"]
        primary_sprint_id = sprint_meta_raw.get("primary_sprint_id")
    else:
        sprint_meta = sprint_meta_raw

    # Optional files
    sprint_report = None
    velocity_data = None
    try:
        sprint_report = load_json(args.cache_dir, "sprint-report.json")
    except FileNotFoundError:
        pass
    try:
        velocity_data = load_json(args.cache_dir, "velocity.json")
    except FileNotFoundError:
        pass

    # Determine sprint dates
    if isinstance(sprint_meta, list):
        # Active sprints mode — use primary sprint if identified, else first
        if primary_sprint_id:
            primary = next((s for s in sprint_meta if s["id"] == primary_sprint_id), sprint_meta[0])
        else:
            primary = sprint_meta[0]
        sprint_start = parse_ts(primary.get("startDate", ""))
        sprint_end = parse_ts(primary.get("endDate", ""))
        sprint_name = primary["name"]
        sprint_ids = [primary["id"]]
        # Store all sprint names for reference
        all_sprint_names = ", ".join(s["name"] for s in sprint_meta)
    else:
        sprint_start = parse_ts(sprint_meta.get("startDate", ""))
        sprint_end = parse_ts(sprint_meta.get("endDate", ""))
        sprint_name = sprint_meta.get("name", "")
        sprint_ids = [sprint_meta.get("id")]
        all_sprint_names = sprint_name

    if not sprint_start or not sprint_end:
        print("ERROR: Could not determine sprint dates from metadata", file=sys.stderr)
        sys.exit(1)

    sprint_duration = (sprint_end - sprint_start).days

    print(f"=== Analyzing: {sprint_name} ===")
    print(f"    Dates: {sprint_start.strftime('%Y-%m-%d')} to {sprint_end.strftime('%Y-%m-%d')} ({sprint_duration} days)")
    print(f"    Tickets: {len(tickets)}")

    # Build ticket map
    ticket_map = build_ticket_map(tickets, sprint_report)

    # Parse changelogs
    changelog_data = parse_changelogs(changelogs, sprint_start, sprint_end)

    # Compute all analyses
    sprint_metrics = compute_sprint_metrics(ticket_map, sprint_report)
    developer_metrics = compute_developer_metrics(ticket_map, changelog_data, sprint_start, sprint_end, tickets=tickets)
    blockers = compute_blockers(ticket_map, changelog_data, current_only=args.standup)
    carryover = compute_carryover(ticket_map, sprint_report, changelog_data, sprint_end)
    hygiene = compute_hygiene(ticket_map, sprint_end)
    estimate_changes = compute_estimate_changes(changelog_data, sprint_start, ticket_map)
    velocity = compute_velocity(velocity_data)

    # Build output
    analysis = {
        "sprint": {
            "name": sprint_name,
            "ids": sprint_ids,
            "start": sprint_start.isoformat(),
            "end": sprint_end.isoformat(),
            "duration_days": sprint_duration,
            "goal": sprint_meta.get("goal", "") if not isinstance(sprint_meta, list) else "",
            "state": sprint_meta.get("state", "") if not isinstance(sprint_meta, list) else "active",
            "all_sprint_names": all_sprint_names,
        },
        "ticket_count": len(tickets),
        "sprint_metrics": sprint_metrics,
        "developer_metrics": developer_metrics,
        "blockers": blockers,
        "carryover": carryover,
        "hygiene": hygiene,
        "estimate_changes": estimate_changes,
        "regressions": changelog_data["regressions"],
        "velocity": velocity,
    }

    # Standup-specific extras
    if args.standup:
        analysis["recent_movements"] = compute_recent_movements(changelog_data, ticket_map)
        analysis["flow_health"] = compute_flow_health(ticket_map)

    # Write output
    with open(output_path, "w") as f:
        json.dump(analysis, f, indent=2, default=str)

    print(f"\n✅ Analysis written: {output_path}")
    print(f"   Sprint metrics: {sprint_metrics.get('completed_items', sprint_metrics.get('done_items', '?'))} completed")
    print(f"   Developers: {len(developer_metrics)}")
    print(f"   Blockers: {len(blockers)}")
    print(f"   Carryover: {len(carryover)}")
    print(f"   Regressions: {len(changelog_data['regressions'])}")


if __name__ == "__main__":
    main()
