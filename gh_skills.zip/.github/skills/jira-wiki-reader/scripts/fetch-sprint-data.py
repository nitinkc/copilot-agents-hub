#!/usr/bin/env python3
"""
Jira Reader — Bulk Sprint Data Fetcher
=======================================
Fetches all raw Jira data for a sprint (or active sprints) and caches to disk.
Used by both sprint-retrospective and standup-intelligence prompts.

Usage:
  # Closed sprint (retro):
  python3 fetch-sprint-data.py --board-id 5395 --sprint-id 34510 --cache-dir /path/to/cache

  # Active sprints (standup):
  python3 fetch-sprint-data.py --board-id 5395 --active --cache-dir /path/to/cache

  # With custom Jira fields:
  python3 fetch-sprint-data.py --board-id 5395 --sprint-id 34510 --cache-dir /path/to/cache \\
      --extra-fields customfield_12345,customfield_67890

Output:
  {cache_dir}/
  ├── sprint-meta.json          # Sprint name, ID, dates, state, goal
  ├── sprint-report.json        # Sprint report: committed, completed, added, punted (closed sprints only)
  ├── tickets-full.json         # All tickets with full fields + changelog
  ├── changelogs.json           # Extracted changelogs: {key: [histories]}
  ├── board-config.json         # Board columns, WIP limits
  └── velocity.json             # Last 5 sprints velocity data

After this script runs, ALL downstream analysis reads from cache — zero additional API calls.

Hard limits (bounded execution — non-negotiable):
  - Max 5000 tickets (100 batches × 50)
  - 30s timeout per HTTP request
  - 0.3s delay between batches (rate limiting)
"""
import argparse
import os
import re
import subprocess
import sys
import time

# Add script directory to path for _pylib import
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)

from _pylib import (
    load_jira_pat, jira_get, save_json,
    BATCH_SIZE, MAX_BATCHES,
)

# ---------------------------------------------------------------------------
# Default Jira fields to fetch for every ticket
# ---------------------------------------------------------------------------
DEFAULT_FIELDS = (
    "key,summary,status,assignee,priority,issuetype,labels,created,updated,"
    "resolved,resolutiondate,resolution,customfield_10002,customfield_10423,"
    "components,fixVersions,customfield_18881,customfield_10008,description,comment,subtasks,"
    "customfield_10020,duedate,customfield_31282,customfield_31283,"
    "customfield_10040"
)


def fetch_sprint_meta(sprint_id, pat):
    """Fetch sprint metadata (name, dates, state, goal)."""
    print(f"[1] Fetching sprint metadata (ID: {sprint_id})...")
    data = jira_get(f"/rest/agile/1.0/sprint/{sprint_id}", pat=pat)
    if data:
        print(f"    Sprint: {data.get('name')} | State: {data.get('state')}")
    return data


def fetch_active_sprints(board_id, pat):
    """Fetch all active sprints for a board."""
    print(f"[1] Fetching active sprints for board {board_id}...")
    data = jira_get(f"/rest/agile/1.0/board/{board_id}/sprint?state=active", pat=pat)
    if data:
        sprints = data.get("values", [])
        print(f"    Found {len(sprints)} active sprint(s): {', '.join(s['name'] for s in sprints)}")
        return sprints
    return []


def fetch_sprint_report(board_id, sprint_id, pat):
    """Fetch sprint report (greenhopper) — committed, completed, added, punted."""
    print(f"[2] Fetching sprint report...")
    data = jira_get(
        f"/rest/greenhopper/1.0/rapid/charts/sprintreport?rapidViewId={board_id}&sprintId={sprint_id}",
        pat=pat,
    )
    if data:
        contents = data.get("contents", {})
        comp = len(contents.get("completedIssues", []))
        nc = len(contents.get("issuesNotCompletedInCurrentSprint", []))
        punt = len(contents.get("puntedIssues", []))
        added = len(contents.get("issueKeysAddedDuringSprint", {}))
        print(f"    Completed: {comp} | Not completed: {nc} | Punted: {punt} | Added: {added}")
    return data


def fetch_tickets_with_changelogs(sprint_ids, pat, extra_fields="", project_key=None):
    """Fetch all tickets for one or more sprints with changelog expansion.

    Args:
        sprint_ids: List of sprint IDs (ints) to query.
        pat: Jira PAT.
        extra_fields: Comma-separated additional Jira fields.
        project_key: Optional Jira project key to filter tickets (e.g. 'CMXOT2').

    Returns:
        tuple: (all_tickets, changelogs_dict)
    """
    # Build JQL — sprint IN (id1, id2, ...) with optional project filter
    if len(sprint_ids) == 1:
        jql = f"sprint={sprint_ids[0]}"
    else:
        jql = f"sprint in ({','.join(str(s) for s in sprint_ids)})"
    if project_key:
        jql = f"project={project_key} AND {jql}"

    fields = DEFAULT_FIELDS
    if extra_fields:
        fields = f"{fields},{extra_fields}"

    encoded_jql = jql.replace(" ", "%20").replace("=", "%3D").replace(",", "%2C").replace("(", "%28").replace(")", "%29")

    print(f"[3] Fetching all tickets (JQL: {jql})...")
    all_tickets = []
    start_at = 0
    batch_num = 0

    while batch_num < MAX_BATCHES:
        data = jira_get(
            f"/rest/api/2/search?jql={encoded_jql}"
            f"&startAt={start_at}&maxResults={BATCH_SIZE}"
            f"&expand=changelog"
            f"&fields={fields}",
            pat=pat,
        )
        if not data:
            print(f"    ERROR: Failed to fetch batch at startAt={start_at}", file=sys.stderr)
            break

        issues = data.get("issues", [])
        all_tickets.extend(issues)
        total = data.get("total", 0)
        print(f"    Batch {start_at}–{start_at + len(issues)} of {total}")

        start_at += BATCH_SIZE
        batch_num += 1
        if start_at >= total:
            break
        time.sleep(0.3)  # Rate limiting

    print(f"    Total tickets: {len(all_tickets)}")

    # Extract changelogs into separate structure
    print(f"[4] Extracting changelogs...")
    changelogs = {}
    total_entries = 0
    for t in all_tickets:
        key = t["key"]
        histories = t.get("changelog", {}).get("histories", [])
        changelogs[key] = histories
        total_entries += len(histories)
    print(f"    Changelog entries: {total_entries}")

    return all_tickets, changelogs


def fetch_board_config(board_id, pat):
    """Fetch board configuration (columns, WIP limits)."""
    print(f"[5] Fetching board config...")
    return jira_get(f"/rest/agile/1.0/board/{board_id}/configuration", pat=pat)


def fetch_velocity(board_id, pat, sprint_id=None):
    """Fetch velocity chart data for last N sprints.

    Falls back to computing velocity from individual sprint reports when the
    velocity chart endpoint returns empty (common on multi-team boards where
    the board filter doesn't match the velocity widget's expectations).
    """
    print(f"[6] Fetching velocity data...")
    data = jira_get(
        f"/rest/greenhopper/1.0/rapid/charts/velocity?rapidViewId={board_id}",
        pat=pat,
    )
    if data and data.get("sprints"):
        return data

    # Fallback: velocity chart returned empty — compute from sprint reports
    print(f"    ⚠️  Velocity chart empty — falling back to sprint report history")

    # Paginate to get ALL closed sprints (boards can have 90+)
    all_sprints = []
    start_at = 0
    max_pages = 10  # Hard cap: 10 pages × 50 = 500 sprints max
    for _ in range(max_pages):
        page = jira_get(
            f"/rest/agile/1.0/board/{board_id}/sprint?state=closed"
            f"&maxResults=50&startAt={start_at}",
            pat=pat,
        )
        if not page:
            break
        values = page.get("values", [])
        all_sprints.extend(values)
        if page.get("isLast", True) or not values:
            break
        start_at += len(values)

    if not all_sprints:
        return data  # Return original empty response

    # Resolve target sprint prefix for series filtering.
    # First try to find the sprint in the fetched list; if not found (sprint_id
    # may belong to a board that shares sprints), fetch its metadata directly.
    target_prefix = None
    if sprint_id:
        for s in all_sprints:
            if s["id"] == sprint_id:
                name = s.get("name", "")
                parts = name.split()
                if parts:
                    target_prefix = parts[0]
                break
        if not target_prefix:
            # Sprint not in list — fetch metadata directly
            meta = jira_get(f"/rest/agile/1.0/sprint/{sprint_id}", pat=pat)
            if meta:
                parts = meta.get("name", "").split()
                if parts:
                    target_prefix = parts[0]

    # Filter to same series and take last 7
    if target_prefix:
        series_sprints = [s for s in all_sprints
                          if s.get("name", "").startswith(target_prefix + " ")]
    else:
        series_sprints = all_sprints
    recent = series_sprints[-7:]

    # Fetch sprint report for each to get committed/completed SP
    velocity_sprints = []
    velocity_entries = {}
    for s in recent:
        sid = s["id"]
        report = jira_get(
            f"/rest/greenhopper/1.0/rapid/charts/sprintreport"
            f"?rapidViewId={board_id}&sprintId={sid}",
            pat=pat,
        )
        if not report:
            continue
        contents = report.get("contents", {})

        # Sum story points from completed issues
        completed_sp = 0.0
        for issue in contents.get("completedIssues", []):
            sp = issue.get("estimateStatistic", {}).get("statFieldValue", {}).get("value")
            if sp:
                completed_sp += float(sp)

        # Sum story points from all issues at sprint start (committed)
        # committed = completed + not-completed (excl. added during sprint)
        committed_sp = completed_sp
        for issue in contents.get("issuesNotCompletedInCurrentSprint", []):
            sp = issue.get("estimateStatistic", {}).get("statFieldValue", {}).get("value")
            if sp:
                committed_sp += float(sp)
        # Subtract added-during-sprint from committed (they weren't in original commitment)
        added_keys = set(contents.get("issueKeysAddedDuringSprint", {}).keys())
        for issue in contents.get("completedIssues", []):
            if issue.get("key") in added_keys:
                sp = issue.get("estimateStatistic", {}).get("statFieldValue", {}).get("value")
                if sp:
                    committed_sp -= float(sp)
        for issue in contents.get("issuesNotCompletedInCurrentSprint", []):
            if issue.get("key") in added_keys:
                sp = issue.get("estimateStatistic", {}).get("statFieldValue", {}).get("value")
                if sp:
                    committed_sp -= float(sp)

        velocity_sprints.append({"id": sid, "name": s.get("name", ""), "state": "closed"})
        velocity_entries[str(sid)] = {
            "estimated": {"value": round(committed_sp, 1), "text": f"{committed_sp:g} SP"},
            "completed": {"value": round(completed_sp, 1), "text": f"{completed_sp:g} SP"},
        }
        time.sleep(0.2)  # Rate limiting

    if velocity_sprints:
        print(f"    ✅ Computed velocity from {len(velocity_sprints)} sprint reports")
    return {
        "sprints": velocity_sprints,
        "velocityStatEntries": velocity_entries,
        "_fallback": True,
    }


# ---------------------------------------------------------------------------
# GitHub PR file analysis — extract PR refs from ticket comments, check files
# ---------------------------------------------------------------------------
_GH_URL_RE = re.compile(r'github\.com/([^/\s\]\)]+/[^/\s\]\)]+)/pull/(\d+)')

# Agent adoption signals: paths that indicate agent-assisted development
AGENT_SIGNAL_PATHS = [
    "docs/generated/",
]

MAX_PR_FILE_CHECKS = 50  # Hard cap on PR file-list API calls (bounded execution)


def _check_gh_auth():
    """Pre-check gh CLI availability and auth. Returns (ok, status_dict)."""
    import shutil
    if not shutil.which("gh"):
        return False, {
            "ok": False,
            "error": "gh_not_installed",
            "message": "GitHub CLI (gh) is not installed.",
            "fix": "brew install gh && gh auth login",
        }
    try:
        result = subprocess.run(
            ["gh", "auth", "status"],
            capture_output=True, text=True,
            encoding="utf-8", errors="replace",
            timeout=10,
        )
        if result.returncode != 0:
            stderr = result.stderr.strip()
            return False, {
                "ok": False,
                "error": "gh_not_authenticated",
                "message": "GitHub CLI is installed but not authenticated.",
                "detail": stderr[:300] if stderr else "",
                "fix": "gh auth login",
            }
    except subprocess.TimeoutExpired:
        return False, {
            "ok": False,
            "error": "gh_auth_timeout",
            "message": "gh auth status timed out.",
            "fix": "gh auth login",
        }
    return True, {"ok": True}


def _gh_api(endpoint, timeout=15):
    """Call gh api and return parsed JSON, or None on failure."""
    try:
        result = subprocess.run(
            ["gh", "api", endpoint, "--jq", "."],
            capture_output=True, text=True,
            encoding="utf-8", errors="replace",
            timeout=timeout,
        )
        if result.returncode == 0 and result.stdout.strip():
            import json as _json
            return _json.loads(result.stdout)
    except (subprocess.TimeoutExpired, FileNotFoundError, ValueError):
        pass
    return None


def fetch_github_pr_files(tickets, github_org, max_age_hours=24):
    """Extract PR URLs from recent ticket comments, fetch file lists, detect agent signals.

    Also fetches PR author, state, and approver names from GitHub API.
    Only considers comments created within the last max_age_hours (default: 24h).

    Returns list of dicts:
      [{ticket, repo, pr_number, pr_url, pr_author, pr_state, approvers,
        files_total, agent_files, has_agent_signal, comment_date, assignee}]
    """
    print(f"[7] Extracting GitHub PR references from ticket comments (last {max_age_hours}h)...")

    from datetime import datetime, timedelta
    cutoff = datetime.utcnow() - timedelta(hours=max_age_hours)
    cutoff_str = cutoff.strftime("%Y-%m-%dT%H:%M:%S")

    # Step 1: Collect unique PR references from recent ticket comments
    pr_refs = {}  # (repo, pr_num) -> {ticket, assignee, comment_date}
    skipped_old = 0
    for t in tickets:
        key = t.get("key", "")
        assignee = (t.get("fields", {}).get("assignee") or {}).get("displayName", "Unassigned")
        comments = t.get("fields", {}).get("comment", {}).get("comments", [])
        for c in comments:
            body = c.get("body", "")
            created = c.get("created", "")[:19]
            # Skip comments older than cutoff
            if created < cutoff_str:
                skipped_old += 1
                continue
            for match in _GH_URL_RE.finditer(body):
                repo, pr_num = match.group(1), int(match.group(2))
                # Only process PRs from the specified org
                if not repo.startswith(f"{github_org}/"):
                    continue
                ref_key = (repo, pr_num)
                if ref_key not in pr_refs:
                    pr_refs[ref_key] = {
                        "ticket": key, "assignee": assignee,
                        "comment_date": created,
                    }

    unique_prs = list(pr_refs.keys())
    print(f"    Found {len(unique_prs)} unique PR references "
          f"(skipped {skipped_old} older comments)")

    if not unique_prs:
        return []

    # User login → display name cache (bounded: max 2 × MAX_PR_FILE_CHECKS entries)
    _user_cache = {}

    def _resolve_name(login):
        """Resolve GitHub login to display name via user API, with cache."""
        if not login:
            return ""
        if login in _user_cache:
            return _user_cache[login]
        user_data = _gh_api(f"users/{login}")
        name = ""
        if user_data and isinstance(user_data, dict):
            name = user_data.get("name") or login
        else:
            name = login
        _user_cache[login] = name
        return name

    # Step 2: Fetch file lists, PR detail, and reviews (bounded by MAX_PR_FILE_CHECKS)
    results = []
    checked = 0
    for (repo, pr_num) in unique_prs[:MAX_PR_FILE_CHECKS]:
        info = pr_refs[(repo, pr_num)]

        # Fetch PR files
        files_data = _gh_api(f"repos/{repo}/pulls/{pr_num}/files")
        if files_data is None:
            continue
        checked += 1

        filenames = [f.get("filename", "") for f in files_data if isinstance(f, dict)]
        agent_files = [
            fn for fn in filenames
            if any(sig in fn for sig in AGENT_SIGNAL_PATHS)
        ]

        # Fetch PR detail (author, state, merged)
        pr_detail = _gh_api(f"repos/{repo}/pulls/{pr_num}")
        pr_author_login = ""
        pr_author_name = ""
        pr_state = "unknown"
        if pr_detail and isinstance(pr_detail, dict):
            pr_author_login = (pr_detail.get("user") or {}).get("login", "")
            pr_author_name = _resolve_name(pr_author_login)
            if pr_detail.get("merged"):
                pr_state = "merged"
            else:
                pr_state = pr_detail.get("state", "unknown")

        # Fetch reviews (approvers only)
        reviews_data = _gh_api(f"repos/{repo}/pulls/{pr_num}/reviews")
        approvers = []
        if reviews_data and isinstance(reviews_data, list):
            seen_approvers = set()
            for review in reviews_data:
                if review.get("state") == "APPROVED":
                    login = (review.get("user") or {}).get("login", "")
                    if login and login not in seen_approvers:
                        seen_approvers.add(login)
                        approvers.append(_resolve_name(login))

        results.append({
            "ticket": info["ticket"],
            "repo": repo.split("/")[-1] if "/" in repo else repo,
            "repo_full": repo,
            "pr_number": pr_num,
            "pr_url": f"https://github.com/{repo}/pull/{pr_num}",
            "pr_author": pr_author_name,
            "pr_state": pr_state,
            "approvers": approvers,
            "assignee": info["assignee"],
            "comment_date": info["comment_date"],
            "files_total": len(filenames),
            "agent_files": agent_files,
            "agent_file_count": len(agent_files),
            "has_agent_signal": len(agent_files) > 0,
        })

        if checked % 10 == 0:
            print(f"    Checked {checked}/{len(unique_prs)} PRs...")
        time.sleep(0.2)  # Rate limiting

    with_signal = sum(1 for r in results if r["has_agent_signal"])
    print(f"    Checked {checked} PRs: {with_signal} with agent signals, "
          f"{checked - with_signal} without")
    return results


def main():
    parser = argparse.ArgumentParser(
        description="Fetch all raw Jira sprint data and cache to disk."
    )
    parser.add_argument("--board-id", type=int, required=True,
                        help="Jira board ID (rapidViewId)")
    parser.add_argument("--sprint-id", type=int, default=None,
                        help="Specific sprint ID to fetch (for retro)")
    parser.add_argument("--active", action="store_true",
                        help="Fetch all active sprints (for standup)")
    parser.add_argument("--cache-dir", required=True,
                        help="Directory to write cached JSON files")
    parser.add_argument("--extra-fields", default="",
                        help="Additional comma-separated Jira fields to fetch")
    parser.add_argument("--project-key", default=None,
                        help="Jira project key (e.g. CMXOT2). When --active is used, "
                             "identifies the primary sprint matching this project and "
                             "filters tickets to only this project's keys.")
    parser.add_argument("--github-org", default=None,
                        help="GitHub org name (e.g. comcast-modesto) to scan PRs "
                             "referenced in ticket comments for agent adoption signals")
    parser.add_argument("--pr-hours", type=int, default=24,
                        help="Only scan PR comments from the last N hours (default: 24)")

    args = parser.parse_args()

    if not args.sprint_id and not args.active:
        print("ERROR: Provide --sprint-id or --active", file=sys.stderr)
        sys.exit(1)

    pat = load_jira_pat()
    os.makedirs(args.cache_dir, exist_ok=True)
    print(f"📁 Cache directory: {args.cache_dir}")

    # --- Step 1: Sprint metadata ---
    if args.active:
        sprints = fetch_active_sprints(args.board_id, pat)
        if not sprints:
            print("ERROR: No active sprints found", file=sys.stderr)
            sys.exit(1)

        # Identify primary sprint matching project key
        primary_sprint_id = None
        if args.project_key:
            pk_upper = args.project_key.upper()
            # Strategy 1: Direct sprint name prefix match
            for s in sprints:
                sname = s.get("name", "").upper()
                if sname.startswith(pk_upper):
                    primary_sprint_id = s["id"]
                    break
            # Strategy 2: Common project→sprint name mappings
            if not primary_sprint_id:
                prefix_map = {
                    "CMXOT2": "OTX2", "CMXOT3": "OTX-3",
                    "CMXOTR": "OTR", "CMXOTA": "CMXOTA", "CMXOTB": "CMXOTB",
                    "CMXOTF": "OTF", "CMXOTP": "OTP", "CMXOTCP": "CMXPS",
                    "CMXOT1": "CMXOT1",
                }
                mapped = prefix_map.get(pk_upper, "")
                if mapped:
                    for s in sprints:
                        sname = s.get("name", "").upper()
                        if sname.startswith(mapped):
                            primary_sprint_id = s["id"]
                            break
            # Note: if still None, we'll resolve after ticket fetch using ticket-count heuristic
            if primary_sprint_id:
                pname = next(s["name"] for s in sprints if s["id"] == primary_sprint_id)
                print(f"    Primary sprint: {pname} (ID: {primary_sprint_id})")

        # Save sprint-meta with primary sprint annotation
        meta_output = sprints
        if args.project_key:
            meta_output = {
                "sprints": sprints,
                "primary_sprint_id": primary_sprint_id,
                "project_key": args.project_key.upper(),
            }
        save_json(args.cache_dir, "sprint-meta.json", meta_output)
        sprint_ids = [s["id"] for s in sprints]
    else:
        meta = fetch_sprint_meta(args.sprint_id, pat)
        if not meta:
            print("ERROR: Failed to fetch sprint metadata", file=sys.stderr)
            sys.exit(1)
        save_json(args.cache_dir, "sprint-meta.json", meta)
        sprint_ids = [args.sprint_id]

    # --- Step 2: Sprint report (closed sprints only) ---
    if not args.active and args.sprint_id:
        report = fetch_sprint_report(args.board_id, args.sprint_id, pat)
        if report:
            save_json(args.cache_dir, "sprint-report.json", report)

    # --- Step 3-4: Tickets + changelogs ---
    tickets, changelogs = fetch_tickets_with_changelogs(
        sprint_ids, pat, args.extra_fields, project_key=args.project_key)
    save_json(args.cache_dir, "tickets-full.json", tickets)
    save_json(args.cache_dir, "changelogs.json", changelogs)

    # --- Step 3b: Resolve primary sprint via ticket-count heuristic (if not resolved by name) ---
    if args.active and args.project_key and not primary_sprint_id:
        # Count project tickets per sprint via lightweight JQL queries (maxResults=0)
        pk_upper = args.project_key.upper()
        sprint_counts = {}
        for s in sprints:
            sid = s["id"]
            count_data = jira_get(
                f"/rest/api/2/search?jql=project%3D{pk_upper}%20AND%20sprint%3D{sid}&maxResults=0",
                pat)
            if count_data:
                sprint_counts[sid] = count_data.get("total", 0)
        if sprint_counts:
            primary_sprint_id = max(sprint_counts, key=sprint_counts.get)
            pname = next((s["name"] for s in sprints if s["id"] == primary_sprint_id), "?")
            count = sprint_counts[primary_sprint_id]
            print(f"    Primary sprint (by ticket count): {pname} (ID: {primary_sprint_id}, {count} tickets)")
        else:
            primary_sprint_id = sprints[0]["id"]
            print(f"    ⚠️  Could not resolve primary sprint — using first sprint")

        # Update sprint-meta.json with resolved primary
        meta_output = {
            "sprints": sprints,
            "primary_sprint_id": primary_sprint_id,
            "project_key": pk_upper,
        }
        save_json(args.cache_dir, "sprint-meta.json", meta_output)

    # --- Step 5: Board config ---
    board_config = fetch_board_config(args.board_id, pat)
    if board_config:
        save_json(args.cache_dir, "board-config.json", board_config)

    # --- Step 6: Velocity ---
    velocity = fetch_velocity(args.board_id, pat, sprint_id=args.sprint_id)
    if velocity:
        save_json(args.cache_dir, "velocity.json", velocity)

    # --- Step 7: GitHub PR agent adoption scan (optional) ---
    if args.github_org:
        gh_ok, gh_status = _check_gh_auth()
        if gh_ok:
            pr_data = fetch_github_pr_files(tickets, args.github_org, args.pr_hours)
            gh_status["prs_found"] = len(pr_data)
            save_json(args.cache_dir, "github-prs.json", pr_data)
        else:
            print(f"⚠️  GitHub pre-check failed: {gh_status['message']}")
            print(f"   Fix: {gh_status['fix']}")
            save_json(args.cache_dir, "github-prs.json", [])
        save_json(args.cache_dir, "github-prs-status.json", gh_status)
    else:
        print("[7] Skipping GitHub PR scan (no --github-org provided)")

    # --- Summary ---
    print(f"\n📦 Raw data saved: {args.cache_dir}")
    print(f"   {len(tickets)} tickets, {sum(len(v) for v in changelogs.values())} changelog entries")
    files = [f for f in os.listdir(args.cache_dir) if f.endswith(".json")]
    print(f"   Files: {', '.join(sorted(files))}")


if __name__ == "__main__":
    main()
