#!/usr/bin/env bash
# ============================================================================
# Jira Reader — Fetch Ticket Details
# Retrieves comprehensive ticket details in structured JSON.
#
# Usage: bash .github/skills/jira-wiki-reader/scripts/fetch-ticket.sh <TICKET_KEY> [--compact] [--follow-links]
# Example: bash .github/skills/jira-wiki-reader/scripts/fetch-ticket.sh OM-1234
#          bash .github/skills/jira-wiki-reader/scripts/fetch-ticket.sh OM-1234 --compact --follow-links
#
# Options:
#   --compact       Strip {code}/{noformat} blocks, log lines, and truncate
#                   (description: 1000 chars, comments: 500 chars)
#   --follow-links  Fetch one-level-deep summary of linked tickets
#
# Output: JSON object with summary, description, status, priority, type,
#         assignee, reporter, sprint, story points, labels, components,
#         fix versions, dates, parent epic, and acceptance criteria.
# ============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/_lib.sh"

# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------
COMPACT=false
FOLLOW_LINKS=false
TICKET_KEY=""

for arg in "$@"; do
  case "$arg" in
    --compact)
      COMPACT=true
      ;;
    --follow-links)
      FOLLOW_LINKS=true
      ;;
    -*)
      error_json "Unknown option: $arg" \
        "Usage: fetch-ticket.sh <TICKET_KEY> [--compact] [--follow-links]"
      exit 1
      ;;
    *)
      if [ -z "$TICKET_KEY" ]; then
        TICKET_KEY="$(echo "$arg" | tr '[:lower:]' '[:upper:]')"
      fi
      ;;
  esac
done

if [ -z "$TICKET_KEY" ]; then
  error_json "Missing required argument: TICKET_KEY" \
    "Usage: bash .github/skills/jira-wiki-reader/scripts/fetch-ticket.sh <TICKET_KEY> [--compact] [--follow-links]"
  exit 1
fi

validate_ticket_key "$TICKET_KEY"
validate_env

# ---------------------------------------------------------------------------
# Fields to retrieve (minimizes payload size)
# ---------------------------------------------------------------------------
FIELDS="summary,description,status,priority,issuetype,assignee,reporter,created,updated,resolutiondate"
FIELDS+=",labels,components,fixVersions,resolution"
FIELDS+=",customfield_10423"   # Story Points (common field ID — see CONFIGURATION note below)
FIELDS+=",customfield_10007"   # Sprint (common field ID)
FIELDS+=",customfield_18881"   # Epic Link (actual field on this instance)
FIELDS+=",customfield_10008"   # Epic Link (legacy/fallback)
FIELDS+=",customfield_10014"   # Acceptance Criteria (common field ID)
FIELDS+=",parent"
FIELDS+=",subtasks"
FIELDS+=",issuelinks"          # Linked issues (blocks, blocked by, relates to, duplicates, etc.)
FIELDS+=",comment"             # Comments (recent context and decisions)

# ┌─────────────────────────────────────────────────────────────────────────┐
# │ CONFIGURATION: Custom field IDs vary per Jira instance.                 │
# │ Run this to find your actual field IDs:                                 │
# │   curl -s -H "Authorization: Bearer $JIRA_PAT" \                       │
# │     "$JIRA_BASE_URL/rest/api/2/field" | jq '.[] | {id, name}'          │
# │                                                                         │
# │ Then update the customfield_XXXXX values above to match your instance.  │
# └─────────────────────────────────────────────────────────────────────────┘

# ---------------------------------------------------------------------------
# Fetch and transform
# ---------------------------------------------------------------------------
RAW=$(jira_curl "/issue/${TICKET_KEY}?fields=${FIELDS}&expand=names")

if [ "$HAS_JQ" = true ]; then
  RESULT=$(echo "$RAW" | jq --arg compact "$COMPACT" "${JQ_COMPACT_DEF}"'{
    key: .key,
    self_url: .self,
    summary: .fields.summary,
    description: (
      if (.fields.description | type) == "string" then
        if $compact == "true" then compact_text(.fields.description; 1000)
        else .fields.description
        end
      elif .fields.description == null then null
      else (.fields.description | tostring)
      end
    ),
    status: .fields.status.name,
    status_category: .fields.status.statusCategory.name,
    type: .fields.issuetype.name,
    is_subtask: .fields.issuetype.subtask,
    priority: .fields.priority.name,
    assignee: (if .fields.assignee then .fields.assignee.displayName else "Unassigned" end),
    assignee_id: (if .fields.assignee then .fields.assignee.name else null end),
    reporter: (if .fields.reporter then .fields.reporter.displayName else null end),
    labels: (.fields.labels // []),
    components: [.fields.components[]?.name],
    fix_versions: [.fields.fixVersions[]?.name],
    resolution: (.fields.resolution.name // null),
    story_points: (.fields.customfield_10423 // null),
    sprint: (
      if .fields.customfield_10007 then
        if (.fields.customfield_10007 | type) == "array" then
          (.fields.customfield_10007 | last | .name // null)
        elif (.fields.customfield_10007 | type) == "string" then
          (.fields.customfield_10007 | capture("name=(?<n>[^,]+)") | .n // null)
        else
          null
        end
      else null end
    ),
    epic_key: (
      .fields.customfield_18881 //
      .fields.customfield_10008 //
      (if .fields.parent and (.fields.parent.fields.issuetype.name == "Epic") then .fields.parent.key else null end)
    ),
    parent_key: (.fields.parent.key // null),
    parent_summary: (.fields.parent.fields.summary // null),
    acceptance_criteria: (.fields.customfield_10014 // null),
    subtask_count: (.fields.subtasks | length),
    subtasks: [
      .fields.subtasks[]? | {
        key: .key,
        summary: .fields.summary,
        status: .fields.status.name,
        priority: (.fields.priority.name // null),
        type: (.fields.issuetype.name // null)
      }
    ],
    linked_issues: [
      .fields.issuelinks[]? | {
        relationship: (
          if .outwardIssue then .type.outward
          elif .inwardIssue then .type.inward
          else .type.name end
        ),
        direction: (if .outwardIssue then "outward" elif .inwardIssue then "inward" else "unknown" end),
        key: (.outwardIssue // .inwardIssue).key,
        summary: (.outwardIssue // .inwardIssue).fields.summary,
        status: (.outwardIssue // .inwardIssue).fields.status.name,
        priority: ((.outwardIssue // .inwardIssue).fields.priority.name // null),
        type: ((.outwardIssue // .inwardIssue).fields.issuetype.name // null)
      }
    ],
    recent_comments: [
      (.fields.comment.comments // []) | sort_by(.created) | reverse | .[0:5][] | {
        author: .author.displayName,
        created: .created,
        body: (
          if $compact == "true" then compact_text(.body; 500)
          else
            (if (.body | length) > 1000 then (.body[0:1000] + " [truncated]") else .body end)
          end
        )
      }
    ],
    comment_count: ((.fields.comment.total // (.fields.comment.comments | length)) // 0),
    created: .fields.created,
    updated: .fields.updated,
    resolved: (.fields.resolutiondate // null)
  }')

  # --follow-links: fetch one-level-deep summary for each linked ticket
  if [ "$FOLLOW_LINKS" = true ]; then
    LINKED_KEYS=$(echo "$RESULT" | jq -r '[.linked_issues[].key] | unique | .[]' 2>/dev/null)
    if [ -z "$LINKED_KEYS" ]; then
      # No linked issues — add empty array for schema consistency
      RESULT=$(echo "$RESULT" | jq '. + {linked_issue_details: []}')
    else
      # Build JQL for linked keys (bounded: cap at 10 to prevent fan-out)
      LINK_COUNT=0
      JQL_PARTS=""
      for lk in $LINKED_KEYS; do
        if [ $LINK_COUNT -ge 10 ]; then break; fi
        if [ -n "$JQL_PARTS" ]; then JQL_PARTS="${JQL_PARTS},"; fi
        JQL_PARTS="${JQL_PARTS}\"${lk}\""
        LINK_COUNT=$((LINK_COUNT + 1))
      done
      LINK_JQL="key in (${JQL_PARTS})"
      ENCODED_LINK_JQL=$(printf '%s' "$LINK_JQL" | jq -sRr @uri)
      LINK_FIELDS="summary,status,priority,issuetype,assignee,resolution,resolutiondate"
      LINK_RAW=$(jira_curl "/search?jql=${ENCODED_LINK_JQL}&fields=${LINK_FIELDS}&maxResults=10" 2>/dev/null || echo '{"issues":[]}')
      LINK_DETAILS=$(echo "$LINK_RAW" | jq '[
        .issues[]? | {
          key: .key,
          summary: .fields.summary,
          status: .fields.status.name,
          priority: .fields.priority.name,
          type: .fields.issuetype.name,
          assignee: (if .fields.assignee then .fields.assignee.displayName else "Unassigned" end),
          resolution: (.fields.resolution.name // null),
          resolved: (.fields.resolutiondate // null)
        }
      ]' 2>/dev/null || echo '[]')
      # Merge linked details into result
      RESULT=$(echo "$RESULT" | jq --argjson details "$LINK_DETAILS" '. + {linked_issue_details: $details}')
    fi
  fi


  echo "$RESULT"
else
  echo "$RAW"
fi
