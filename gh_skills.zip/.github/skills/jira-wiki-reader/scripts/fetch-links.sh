#!/usr/bin/env bash
# ============================================================================
# Jira Reader — Fetch Linked Issues
# Retrieves all issue links (blocks, is-blocked-by, relates-to, etc.)
#
# Usage: bash .github/skills/jira-wiki-reader/scripts/fetch-links.sh <TICKET_KEY>
# ============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/_lib.sh"

if [ $# -lt 1 ]; then
  error_json "Missing required argument: TICKET_KEY" \
    "Usage: bash .github/skills/jira-wiki-reader/scripts/fetch-links.sh <TICKET_KEY>"
  exit 1
fi

TICKET_KEY="$(echo "$1" | tr '[:lower:]' '[:upper:]')"
validate_ticket_key "$TICKET_KEY"
validate_env

RAW=$(jira_curl "/issue/${TICKET_KEY}?fields=issuelinks")

if [ "$HAS_JQ" = true ]; then
  echo "$RAW" | jq '{
    key: .key,
    links: [
      .fields.issuelinks[] | {
        link_type: .type.name,
        direction: (
          if .outwardIssue then "outward"
          elif .inwardIssue then "inward"
          else "unknown"
          end
        ),
        relationship: (
          if .outwardIssue then .type.outward
          elif .inwardIssue then .type.inward
          else .type.name
          end
        ),
        linked_key: (.outwardIssue // .inwardIssue).key,
        linked_summary: (.outwardIssue // .inwardIssue).fields.summary,
        linked_status: (.outwardIssue // .inwardIssue).fields.status.name,
        linked_type: (.outwardIssue // .inwardIssue).fields.issuetype.name,
        linked_priority: (.outwardIssue // .inwardIssue).fields.priority.name
      }
    ],
    total_links: (.fields.issuelinks | length)
  }'
else
  echo "$RAW"
fi
