#!/usr/bin/env bash
# ============================================================================
# Jira Reader — Fetch Tickets by JQL or Saved Filter
# Executes a JQL query or runs a saved filter and returns matching tickets
# in structured JSON.
#
# Usage:
#   bash .github/skills/jira-wiki-reader/scripts/fetch-jql.sh --jql "<JQL_QUERY>" [--max <N>]
#   bash .github/skills/jira-wiki-reader/scripts/fetch-jql.sh --filter <FILTER_ID> [--max <N>]
#
# Examples:
#   bash .github/skills/jira-wiki-reader/scripts/fetch-jql.sh --jql 'project = CMXOTR AND status = Open'
#   bash .github/skills/jira-wiki-reader/scripts/fetch-jql.sh --filter 12345
#   bash .github/skills/jira-wiki-reader/scripts/fetch-jql.sh --jql 'assignee = currentUser() AND sprint in openSprints()' --max 20
#
# Output: JSON object with total count, query used, and array of ticket summaries.
#
# Hard limits: max results capped at 50 to prevent unbounded responses.
# Read-only: uses GET /rest/api/2/search only.
# ============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/_lib.sh"

# ---------------------------------------------------------------------------
# Constants — bounded behavior
# ---------------------------------------------------------------------------
MAX_RESULTS_CAP=50       # Hard upper bound — never exceed
DEFAULT_MAX_RESULTS=25   # Default if --max not specified

# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------
JQL=""
FILTER_ID=""
MAX_RESULTS="$DEFAULT_MAX_RESULTS"

usage() {
  error_json "Invalid arguments" \
    "Usage: fetch-jql.sh --jql \"<JQL_QUERY>\" [--max <N>] OR fetch-jql.sh --filter <FILTER_ID> [--max <N>]. Max results capped at ${MAX_RESULTS_CAP}."
  exit 1
}

while [ $# -gt 0 ]; do
  case "$1" in
    --jql)
      [ $# -lt 2 ] && usage
      JQL="$2"
      shift 2
      ;;
    --filter)
      [ $# -lt 2 ] && usage
      FILTER_ID="$2"
      shift 2
      ;;
    --max)
      [ $# -lt 2 ] && usage
      MAX_RESULTS="$2"
      shift 2
      ;;
    *)
      usage
      ;;
  esac
done

# Validate: exactly one of --jql or --filter must be provided
if [ -z "$JQL" ] && [ -z "$FILTER_ID" ]; then
  error_json "Missing required argument: --jql or --filter" \
    "Provide either --jql \"<JQL_QUERY>\" or --filter <FILTER_ID>"
  exit 1
fi

if [ -n "$JQL" ] && [ -n "$FILTER_ID" ]; then
  error_json "Conflicting arguments: --jql and --filter cannot be used together" \
    "Provide either --jql OR --filter, not both"
  exit 1
fi

# Validate --max is a positive integer within bounds
if ! [[ "$MAX_RESULTS" =~ ^[0-9]+$ ]] || [ "$MAX_RESULTS" -lt 1 ]; then
  error_json "Invalid --max value: '${MAX_RESULTS}'" \
    "Must be a positive integer between 1 and ${MAX_RESULTS_CAP}"
  exit 1
fi

if [ "$MAX_RESULTS" -gt "$MAX_RESULTS_CAP" ]; then
  MAX_RESULTS="$MAX_RESULTS_CAP"
fi

# Validate filter ID format (numeric only)
if [ -n "$FILTER_ID" ]; then
  if ! [[ "$FILTER_ID" =~ ^[0-9]+$ ]]; then
    error_json "Invalid filter ID: '${FILTER_ID}'" \
      "Filter ID must be a numeric value (e.g., 12345)"
    exit 1
  fi
fi

validate_env

# ---------------------------------------------------------------------------
# Build JQL query
# ---------------------------------------------------------------------------
if [ -n "$FILTER_ID" ]; then
  EFFECTIVE_JQL="filter=${FILTER_ID}"
  QUERY_DESCRIPTION="Saved filter ID: ${FILTER_ID}"
else
  EFFECTIVE_JQL="$JQL"
  QUERY_DESCRIPTION="JQL: ${JQL}"
fi

# URL-encode the JQL
if [ "$HAS_JQ" = true ]; then
  ENCODED_JQL=$(printf '%s' "$EFFECTIVE_JQL" | jq -sRr @uri)
else
  # Basic encoding without jq — covers common JQL characters
  ENCODED_JQL=$(printf '%s' "$EFFECTIVE_JQL" | sed \
    -e 's/ /%20/g' \
    -e 's/"/%22/g' \
    -e 's/=/%3D/g' \
    -e 's/(/%28/g' \
    -e 's/)/%29/g' \
    -e 's/&/%26/g')
fi

# ---------------------------------------------------------------------------
# Fields to retrieve (lightweight — full details via fetch-ticket.sh per key)
# ---------------------------------------------------------------------------
FIELDS="summary,status,issuetype,priority,assignee,reporter,created,updated"
FIELDS+=",labels,components,fixVersions,resolution"
FIELDS+=",customfield_10423"  # Story Points
FIELDS+=",customfield_10007"  # Sprint

# ---------------------------------------------------------------------------
# Fetch
# ---------------------------------------------------------------------------
RAW=$(jira_curl "/search?jql=${ENCODED_JQL}&fields=${FIELDS}&maxResults=${MAX_RESULTS}")

# ---------------------------------------------------------------------------
# Transform output
# ---------------------------------------------------------------------------
if [ "$HAS_JQ" = true ]; then
  echo "$RAW" | jq --arg query "$QUERY_DESCRIPTION" --arg max "$MAX_RESULTS" '{
    query: $query,
    total: .total,
    returned: (.issues | length),
    max_requested: ($max | tonumber),
    capped: ((.total // 0) > ($max | tonumber)),
    tickets: [
      .issues[] | {
        key: .key,
        summary: .fields.summary,
        status: .fields.status.name,
        status_category: .fields.status.statusCategory.name,
        type: .fields.issuetype.name,
        priority: .fields.priority.name,
        assignee: (if .fields.assignee then .fields.assignee.displayName else "Unassigned" end),
        reporter: (if .fields.reporter then .fields.reporter.displayName else "Unknown" end),
        resolution: (.fields.resolution.name // null),
        story_points: (.fields.customfield_10423 // null),
        sprint: (
          if .fields.customfield_10007 then
            if (.fields.customfield_10007 | type) == "array" then
              (.fields.customfield_10007 | last | .name // null)
            elif (.fields.customfield_10007 | type) == "string" then
              (.fields.customfield_10007 | capture("name=(?<n>[^,]+)") | .n) // null
            else null
            end
          else null
          end
        ),
        labels: [.fields.labels[]?],
        components: [.fields.components[]?.name],
        fix_versions: [.fields.fixVersions[]?.name],
        created: .fields.created,
        updated: .fields.updated
      }
    ]
  }'
else
  # Without jq, output raw JSON with a warning
  echo "$RAW"
  echo >&2 "[warn] jq not found — outputting raw Jira search response. Install jq for structured output."
fi
