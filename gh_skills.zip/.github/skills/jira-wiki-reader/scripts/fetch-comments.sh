#!/usr/bin/env bash
# ============================================================================
# Jira Reader — Fetch Comments (Read-Only)
# Retrieves the most recent comments on a ticket.
#
# Usage: bash .github/skills/jira-wiki-reader/scripts/fetch-comments.sh <TICKET_KEY> [MAX_RESULTS] [--extract-refs]
# Default MAX_RESULTS: 10
#
# Options:
#   --extract-refs  Also extract structured references (PRs, builds, tickets,
#                   deployments) from comment bodies and return in a
#                   top-level "references" object.
# ============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/_lib.sh"

# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------
EXTRACT_REFS=false
TICKET_KEY=""
MAX_RESULTS="10"

for arg in "$@"; do
  case "$arg" in
    --extract-refs)
      EXTRACT_REFS=true
      ;;
    -*)
      error_json "Unknown option: $arg" \
        "Usage: fetch-comments.sh <TICKET_KEY> [MAX_RESULTS] [--extract-refs]"
      exit 1
      ;;
    *)
      if [ -z "$TICKET_KEY" ]; then
        TICKET_KEY="$(echo "$arg" | tr '[:lower:]' '[:upper:]')"
      elif [[ "$arg" =~ ^[0-9]+$ ]]; then
        MAX_RESULTS="$arg"
      fi
      ;;
  esac
done

if [ -z "$TICKET_KEY" ]; then
  error_json "Missing required argument: TICKET_KEY" \
    "Usage: bash .github/skills/jira-wiki-reader/scripts/fetch-comments.sh <TICKET_KEY> [MAX_RESULTS] [--extract-refs]"
  exit 1
fi
# Upper bound: cap at 100 to prevent unbounded API calls (non-negotiable B)
if [ "$MAX_RESULTS" -gt 100 ] 2>/dev/null; then MAX_RESULTS=100; fi
validate_ticket_key "$TICKET_KEY"
validate_env

# Use orderBy=-created to get newest first; Jira Data Center supports this parameter
RAW=$(jira_curl "/issue/${TICKET_KEY}/comment?maxResults=${MAX_RESULTS}&orderBy=-created")

if [ "$HAS_JQ" = true ]; then
  RESULT=$(echo "$RAW" | jq '{
    key: "'"${TICKET_KEY}"'",
    total_comments: .total,
    returned: .maxResults,
    comments: [
      .comments[] | {
        id: .id,
        author: .author.displayName,
        author_id: .author.name,
        created: .created,
        updated: .updated,
        body: (
          if (.body | type) == "string" then
            (.body | gsub("\\{[a-z]+\\}"; "") | gsub("\\[~[^]]+\\]"; "") | .[0:2000])
          elif .body == null then null
          else (.body | tostring | .[0:2000])
          end
        )
      }
    ]
  }')

  # --extract-refs: parse PRs, builds, ticket refs, deployments from comment bodies
  if [ "$EXTRACT_REFS" = true ]; then
    REFS=$(echo "$RAW" | jq '{
      references: {
        pull_requests: [
          .comments[].body // "" |
          scan("https://github\\.com/[^/]+/[^/]+/pull/[0-9]+") |
          select(. != null)
        ] | unique,
        build_numbers: [
          .comments[].body // "" |
          scan("[a-zA-Z][a-zA-Z0-9_-]+-[0-9]+\\.[0-9]+\\.[0-9]+") |
          select(. != null)
        ] | unique,
        ticket_refs: [
          .comments[].body // "" |
          scan("[A-Z][A-Z][A-Z0-9_]+-[0-9]{2,}") |
          select(. != null and . != "'"${TICKET_KEY}"'")
        ] | unique,
        deployments: [
          .comments[] |
          select(.body != null) |
          select(.body | test("deployed|deployment|attempted for deployment"; "i")) |
          {
            date: .created,
            author: .author.displayName,
            snippet: (.body | .[0:200])
          }
        ]
      }
    }')
    # Merge references into result
    RESULT=$(echo "$RESULT" "$REFS" | jq -s '.[0] + .[1]')
  fi

  echo "$RESULT"
else
  echo "$RAW"
fi
