#!/usr/bin/env bash
# ============================================================================
# Jira Reader — Fetch Sub-Tasks
# Retrieves all sub-tasks with their current state.
#
# Usage: bash .github/skills/jira-wiki-reader/scripts/fetch-subtasks.sh <TICKET_KEY>
# ============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/_lib.sh"

if [ $# -lt 1 ]; then
  error_json "Missing required argument: TICKET_KEY" \
    "Usage: bash .github/skills/jira-wiki-reader/scripts/fetch-subtasks.sh <TICKET_KEY>"
  exit 1
fi

TICKET_KEY="$(echo "$1" | tr '[:lower:]' '[:upper:]')"
validate_ticket_key "$TICKET_KEY"
validate_env

RAW=$(jira_curl "/issue/${TICKET_KEY}?fields=subtasks")

if [ "$HAS_JQ" = true ]; then
  echo "$RAW" | jq '{
    key: .key,
    subtasks: [
      .fields.subtasks[] | {
        key: .key,
        summary: .fields.summary,
        status: .fields.status.name,
        status_category: .fields.status.statusCategory.name,
        type: .fields.issuetype.name,
        priority: .fields.priority.name
      }
    ],
    total_subtasks: (.fields.subtasks | length),
    completed: ([.fields.subtasks[] | select(.fields.status.statusCategory.name == "Done")] | length),
    in_progress: ([.fields.subtasks[] | select(.fields.status.statusCategory.name == "In Progress")] | length),
    todo: ([.fields.subtasks[] | select(.fields.status.statusCategory.name == "To Do")] | length)
  }'
else
  echo "$RAW"
fi
