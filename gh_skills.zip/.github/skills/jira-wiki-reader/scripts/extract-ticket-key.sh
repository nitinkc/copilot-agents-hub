#!/usr/bin/env bash
# ============================================================================
# Jira Reader — Extract Ticket Key from Text
# Parses Jira URLs, branch names, commit messages, or free text to find
# ticket keys. Returns ALL found keys (deduplicated).
#
# Usage: bash .github/skills/jira-wiki-reader/scripts/extract-ticket-key.sh "<text>"
# Examples:
#   bash .github/skills/jira-wiki-reader/scripts/extract-ticket-key.sh "https://jira.company.com/browse/OM-1234"
#   bash .github/skills/jira-wiki-reader/scripts/extract-ticket-key.sh "feature/OM-1234-add-validation"
#   bash .github/skills/jira-wiki-reader/scripts/extract-ticket-key.sh "$(git log --oneline -10)"
# ============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/_lib.sh"

if [ $# -lt 1 ] || [ -z "$1" ]; then
  error_json "Missing required argument: text to parse" \
    "Usage: bash .github/skills/jira-wiki-reader/scripts/extract-ticket-key.sh \"<text_or_url>\""
  exit 1
fi

INPUT_TEXT="$1"

# Extract all unique ticket keys from the input
KEYS=$(echo "$INPUT_TEXT" | grep -oE "$TICKET_KEY_PATTERN" | sort -u)

if [ -z "$KEYS" ]; then
  error_json "No Jira ticket keys found in the provided text." \
    "Expected format: PROJECT-123 (e.g., OM-1234). Input was: $(echo "$INPUT_TEXT" | head -c 200)"
  exit 1
fi

# Convert to JSON array
KEY_COUNT=$(echo "$KEYS" | wc -l | tr -d ' ')
FIRST_KEY=$(echo "$KEYS" | head -1)

if [ "$HAS_JQ" = true ]; then
  echo "$KEYS" | jq -R -s '{
    keys: (split("\n") | map(select(length > 0))),
    first: (split("\n") | map(select(length > 0)) | first),
    count: (split("\n") | map(select(length > 0)) | length)
  }'
else
  # Manual JSON construction without jq
  JSON_KEYS=$(echo "$KEYS" | awk '{printf "\"%s\",", $0}' | sed 's/,$//')
  echo "{\"keys\": [${JSON_KEYS}], \"first\": \"${FIRST_KEY}\", \"count\": ${KEY_COUNT}}"
fi
