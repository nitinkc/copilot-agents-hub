#!/usr/bin/env bash
# ============================================================================
# Jira Reader — Fetch Confluence Wiki Page
# Retrieves wiki page content referenced in Jira ticket descriptions.
#
# Usage:
#   bash .github/skills/jira-wiki-reader/scripts/fetch-wiki.sh "<CONFLUENCE_URL>"
#   bash .github/skills/jira-wiki-reader/scripts/fetch-wiki.sh --id <PAGE_ID>
#   bash .github/skills/jira-wiki-reader/scripts/fetch-wiki.sh --title "<PAGE_TITLE>" --space "<SPACE_KEY>"
#
# Output: JSON object with title, space, author, created/updated dates,
#         version, labels, and body content (HTML stripped to plain text).
# ============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/_lib.sh"

# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------
PAGE_ID=""
PAGE_TITLE=""
SPACE_KEY=""

if [ $# -lt 1 ]; then
  error_json "Missing required argument" \
    "Usage: fetch-wiki.sh <CONFLUENCE_URL> | --id <PAGE_ID> | --title <TITLE> --space <SPACE>"
  exit 1
fi

case "$1" in
  --id)
    PAGE_ID="${2:?Missing page ID after --id}"
    ;;
  --title)
    PAGE_TITLE="${2:?Missing title after --title}"
    shift 2
    if [ "${1:-}" = "--space" ]; then
      SPACE_KEY="${2:?Missing space key after --space}"
    else
      error_json "Missing --space argument" "Usage: fetch-wiki.sh --title <TITLE> --space <SPACE>"
      exit 1
    fi
    ;;
  *)
    # Assume it's a Confluence URL — extract page ID or space+title
    URL="$1"
    if echo "$URL" | grep -qE 'pageId=[0-9]+'; then
      PAGE_ID=$(echo "$URL" | grep -oE 'pageId=[0-9]+' | head -1 | cut -d= -f2)
    elif echo "$URL" | grep -qE 'spaceKey=[A-Za-z0-9_]+'; then
      SPACE_KEY=$(echo "$URL" | grep -oE 'spaceKey=[A-Za-z0-9_]+' | head -1 | cut -d= -f2)
      if echo "$URL" | grep -qE 'title='; then
        # Extract title, decode + to space
        PAGE_TITLE=$(echo "$URL" | grep -oE 'title=[^&#]+' | head -1 | cut -d= -f2 | sed 's/+/ /g')
        # Handle URL anchor — strip it from the title
        PAGE_TITLE=$(echo "$PAGE_TITLE" | sed 's/#.*//')
      fi
    elif echo "$URL" | grep -qE '/display/[A-Za-z0-9_]+/'; then
      # Pattern: /display/SPACE/Page+Title
      SPACE_KEY=$(echo "$URL" | grep -oE '/display/[A-Za-z0-9_]+/' | head -1 | sed 's|/display/||;s|/||')
      PAGE_TITLE=$(echo "$URL" | sed 's|.*/display/[A-Za-z0-9_]*/||;s|?.*||;s|#.*||;s/+/ /g')
    fi

    if [ -z "$PAGE_ID" ] && { [ -z "$SPACE_KEY" ] || [ -z "$PAGE_TITLE" ]; }; then
      error_json "Could not parse Confluence URL: '$URL'" \
        "Supported formats: viewpage.action?pageId=123, viewpage.action?spaceKey=XF&title=..., /display/SPACE/Title"
      exit 1
    fi
    ;;
esac

validate_wiki_env

# ---------------------------------------------------------------------------
# Fetch page content
# ---------------------------------------------------------------------------
MAX_BODY_LENGTH=50000  # Hard cap on body content length (characters)

if [ -n "$PAGE_ID" ]; then
  RAW=$(wiki_curl "/content/${PAGE_ID}?expand=body.storage,version,space,metadata.labels")
else
  # URL-encode the title for the query
  ENCODED_TITLE=$(printf '%s' "$PAGE_TITLE" | jq -sRr @uri 2>/dev/null || printf '%s' "$PAGE_TITLE" | sed 's/ /%20/g')
  RAW=$(wiki_curl "/content?spaceKey=${SPACE_KEY}&title=${ENCODED_TITLE}&expand=body.storage,version,space,metadata.labels")

  # Unwrap from results array
  if [ "$HAS_JQ" = true ]; then
    RESULT_COUNT=$(echo "$RAW" | jq '.size // 0')
    if [ "$RESULT_COUNT" -eq 0 ]; then
      error_json "No wiki page found with title '${PAGE_TITLE}' in space '${SPACE_KEY}'" \
        "Check the space key and page title. Try browsing: ${WIKI_BASE_URL}/display/${SPACE_KEY}"
      exit 1
    fi
    RAW=$(echo "$RAW" | jq '.results[0]')
  fi
fi

# ---------------------------------------------------------------------------
# Transform to structured output
# ---------------------------------------------------------------------------
if [ "$HAS_JQ" = true ]; then
  echo "$RAW" | jq --argjson maxlen "$MAX_BODY_LENGTH" '{
    page_id: (.id // null),
    title: (.title // null),
    space_key: (.space.key // null),
    space_name: (.space.name // null),
    url: (
      if .space.key and .title then
        ((.space._links.base // "") + "/display/" + .space.key + "/" + (.title | gsub(" "; "+")))
      elif ._links.webui then
        ((.space._links.base // "") + ._links.webui)
      else null end
    ),
    version: (.version.number // null),
    author: (.version.by.displayName // null),
    created: (.version.when // null),
    labels: [(.metadata.labels.results // [])[] | .name],
    body_text: (
      (.body.storage.value // "")
      | gsub("<br\\s*/?>"; "\n")
      | gsub("<li>"; "\n- ")
      | gsub("<p>"; "\n")
      | gsub("<h[1-6][^>]*>"; "\n## ")
      | gsub("</h[1-6]>"; "\n")
      | gsub("<tr>"; "\n| ")
      | gsub("<td[^>]*>|<th[^>]*>"; " | ")
      | gsub("</tr>"; " |")
      | gsub("<[^>]+>"; "")
      | gsub("&amp;"; "&")
      | gsub("&lt;"; "<")
      | gsub("&gt;"; ">")
      | gsub("&nbsp;"; " ")
      | gsub("&quot;"; "\"")
      | gsub("\\n{3,}"; "\n\n")
      | ltrimstr("\n")
      | if length > $maxlen then (.[0:$maxlen] + "\n\n[truncated at " + ($maxlen | tostring) + " characters]") else . end
    ),
    body_length: ((.body.storage.value // "") | length),
    truncated: ((.body.storage.value // "") | length > $maxlen)
  }'
else
  echo "$RAW"
fi
