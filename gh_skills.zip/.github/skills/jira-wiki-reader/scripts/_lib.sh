#!/usr/bin/env bash
# ============================================================================
# Jira Reader — Shared Library
# Sourced by all jira-wiki-reader scripts. Not executed directly.
# Zero external dependencies beyond curl and (optionally) jq.
# ============================================================================

set -euo pipefail

# ---------------------------------------------------------------------------
# Color codes (disabled when not a TTY, e.g., piped to another process)
# ---------------------------------------------------------------------------
if [ -t 1 ]; then
  RED='\033[0;31m'
  YELLOW='\033[0;33m'
  NC='\033[0m'
else
  RED=''
  YELLOW=''
  NC=''
fi

# ---------------------------------------------------------------------------
# Jira instance configuration
# JIRA_BASE_URL is hardcoded — developers do NOT need to set it.
# JIRA_PAT is loaded from environment or persistent env file fallback.
# ---------------------------------------------------------------------------
JIRA_BASE_URL="https://tkts.sys.comcast.net"

# ---------------------------------------------------------------------------
# Confluence wiki configuration
# WIKI_BASE_URL is hardcoded — developers do NOT need to set it.
# WIKI_PAT is loaded from environment or persistent env file fallback.
# ---------------------------------------------------------------------------
WIKI_BASE_URL="https://etwiki.sys.comcast.net"

# ---------------------------------------------------------------------------
# Platform detection and env file resolution
# On WSL, ~/  may be /home/devcontainers (not the Windows user home).
# We search multiple locations to find the env files:
#   1. Environment variable (already set)
#   2. $HOME/.jira-reader.env (native Linux/macOS or WSL home)
#   3. Windows user profile via /mnt/c/Users/<NTID>/ (WSL only)
# ---------------------------------------------------------------------------
IS_WSL=false
if grep -qiE '(microsoft|wsl)' /proc/version 2>/dev/null; then
  IS_WSL=true
fi

# Find the Windows home directory when running in WSL
_resolve_win_home() {
  # 1. Try USERPROFILE if forwarded via WSLENV
  if [ -n "${USERPROFILE:-}" ]; then
    echo "$USERPROFILE" | sed 's|\\|/|g; s|C:|/mnt/c|; s|\r||g'
    return
  fi
  # 2. Try wslvar (available in modern WSL)
  if command -v wslvar &>/dev/null; then
    local wp
    wp=$(wslvar USERPROFILE 2>/dev/null) && [ -n "$wp" ] && {
      echo "$wp" | sed 's|\\|/|g; s|C:|/mnt/c|; s|\r||g'
      return
    }
  fi
  # 3. Scan /mnt/c/Users for the env file directly (bounded: max 20 entries)
  local found
  found=$(find /mnt/c/Users -maxdepth 2 \( -name ".jira-reader.env" -o -name ".wiki-reader.env" \) 2>/dev/null | head -1)
  if [ -n "$found" ]; then
    dirname "$found"
    return
  fi
}

# Source an env file from the first path where it exists
_source_env_file() {
  local filename="$1"
  # 1. Check $HOME (works on macOS, Linux, properly configured WSL)
  if [ -f "${HOME}/${filename}" ]; then
    source "${HOME}/${filename}"
    return
  fi
  # 2. On WSL, check Windows user home
  if [ "$IS_WSL" = true ]; then
    local win_home
    win_home=$(_resolve_win_home)
    if [ -n "$win_home" ] && [ -f "${win_home}/${filename}" ]; then
      source "${win_home}/${filename}"
      return
    fi
  fi
}

# Load JIRA_PAT if not already in environment
if [ -z "${JIRA_PAT:-}" ]; then
  _source_env_file ".jira-reader.env"
fi

# Load WIKI_PAT if not already in environment
if [ -z "${WIKI_PAT:-}" ]; then
  _source_env_file ".wiki-reader.env"
fi

# ---------------------------------------------------------------------------
# Validation: Required environment variables
# ---------------------------------------------------------------------------
validate_env() {
  if [ -z "${JIRA_PAT:-}" ]; then
    local hint="Token setup — create file ~/.jira-reader.env containing exactly: JIRA_PAT=\"<your_token>\" (one line, with quotes)."
    hint+=" Command: echo 'JIRA_PAT=\"<token>\"' > ~/.jira-reader.env && chmod 600 ~/.jira-reader.env"
    hint+=" File location: Mac=/Users/<you>/.jira-reader.env | Linux/WSL=/home/<you>/.jira-reader.env | GitBash=C:\\Users\\<NTID>\\.jira-reader.env"
    if [ "$IS_WSL" = true ]; then
      hint+=" (WSL detected: ~ = /home/<user>, also scans /mnt/c/Users/<NTID>/)"
    fi
    hint+=" Or temporary: export JIRA_PAT=\"<token>\" (lost when terminal closes)."
    hint+=" Generate a token at ${JIRA_BASE_URL}/secure/ViewProfile.jspa?selectedTab=com.atlassian.pats.pats-plugin:jira-user-personal-access-tokens"
    error_json "JIRA_PAT is not set and not found in ~/.jira-reader.env" "$hint"
    exit 1
  fi
}

# ---------------------------------------------------------------------------
# Validation: Wiki PAT
# ---------------------------------------------------------------------------
validate_wiki_env() {
  if [ -z "${WIKI_PAT:-}" ]; then
    local hint="Token setup — create file ~/.wiki-reader.env containing exactly: WIKI_PAT=\"<your_token>\" (one line, with quotes)."
    hint+=" Command: echo 'WIKI_PAT=\"<token>\"' > ~/.wiki-reader.env && chmod 600 ~/.wiki-reader.env"
    hint+=" File location: Mac=/Users/<you>/.wiki-reader.env | Linux/WSL=/home/<you>/.wiki-reader.env | GitBash=C:\\Users\\<NTID>\\.wiki-reader.env"
    if [ "$IS_WSL" = true ]; then
      hint+=" (WSL detected: ~ = /home/<user>, also scans /mnt/c/Users/<NTID>/)"
    fi
    hint+=" Or temporary: export WIKI_PAT=\"<token>\" (lost when terminal closes)."
    hint+=" Generate a token at ${WIKI_BASE_URL}/plugins/personalaccesstokens/usertokens.action"
    error_json "WIKI_PAT is not set and not found in ~/.wiki-reader.env" "$hint"
    exit 1
  fi
}

# ---------------------------------------------------------------------------
# jq availability check with raw fallback
# ---------------------------------------------------------------------------
HAS_JQ=false
if command -v jq &>/dev/null; then
  HAS_JQ=true
fi

# Pretty-print JSON if jq is available; otherwise pass through raw
format_json() {
  if [ "$HAS_JQ" = true ]; then
    jq '.'
  else
    cat
    echo >&2 -e "${YELLOW}[warn] jq not found — outputting raw JSON. Install jq for formatted output.${NC}"
  fi
}

# Apply a jq filter; if jq is absent, output raw JSON with a warning
jq_filter() {
  local filter="$1"
  if [ "$HAS_JQ" = true ]; then
    jq -r "$filter"
  else
    cat
    echo >&2 -e "${YELLOW}[warn] jq not found — cannot apply filter '${filter}'. Outputting raw JSON.${NC}"
  fi
}

# ---------------------------------------------------------------------------
# Compact text processing — reusable jq function definition
# Strips {code}/{noformat} blocks, JSON log lines, and truncates.
# Usage: embed JQ_COMPACT_DEF at the start of a jq filter, then call
#   compact_text(text; max_len) where max_len is the character limit.
# ---------------------------------------------------------------------------
# shellcheck disable=SC2034
JQ_COMPACT_DEF='def compact_text(text; max_len):
  if (text | type) != "string" then text
  else
    (text
      | gsub("\\{code[^}]*\\}[\\s\\S]*?\\{code\\}"; "[code block omitted]")
      | gsub("\\{noformat\\}[\\s\\S]*?\\{noformat\\}"; "[noformat block omitted]")
      | split("\n") | map(select(test("^\\{\"@timestamp\"") | not)) | join("\n")
      | .[0:max_len]
      | if length >= max_len then . + " [truncated]" else . end)
  end;'

# ---------------------------------------------------------------------------
# Structured error output (JSON to stderr)
# ---------------------------------------------------------------------------
error_json() {
  local message="$1"
  local hint="${2:-}"

  if [ "$HAS_JQ" = true ]; then
    jq -n --arg msg "$message" --arg hint "$hint" \
      '{error: $msg} + (if $hint != "" then {hint: $hint} else {} end)' >&2
  else
    if [ -n "$hint" ]; then
      echo "{\"error\": \"${message}\", \"hint\": \"${hint}\"}" >&2
    else
      echo "{\"error\": \"${message}\"}" >&2
    fi
  fi
}

# ---------------------------------------------------------------------------
# Authenticated curl wrapper
# - Silent mode (no progress bar)
# - 15-second timeout
# - Follows redirects
# - Fails on HTTP errors (4xx/5xx)
# - PAT is never echoed or logged
# ---------------------------------------------------------------------------
jira_curl() {
  local endpoint="$1"
  shift

  local url="${JIRA_BASE_URL}/rest/api/2${endpoint}"
  local http_code
  local response_body
  local tmpfile

  tmpfile=$(mktemp)
  trap "rm -f '$tmpfile'" RETURN

  http_code=$(curl -s -o "$tmpfile" -w "%{http_code}" \
    --max-time 15 \
    -L \
    -H "Authorization: Bearer ${JIRA_PAT}" \
    -H "Content-Type: application/json" \
    -H "Accept: application/json" \
    "$@" \
    "$url" 2>/dev/null) || {
      error_json "Network error: curl failed connecting to ${JIRA_BASE_URL}" \
        "Check your network connection and JIRA_BASE_URL value."
      return 1
    }

  response_body=$(cat "$tmpfile")

  case "$http_code" in
    200|201)
      echo "$response_body"
      ;;
    401)
      error_json "Authentication failed (HTTP 401). Your JIRA_PAT may be expired or invalid." \
        "Generate a new PAT at ${JIRA_BASE_URL}/secure/ViewProfile.jspa?selectedTab=com.atlassian.pats.pats-plugin:jira-user-personal-access-tokens — then replace the value in ~/.jira-reader.env (file must contain exactly: JIRA_PAT=\"<new_token>\"). Command: echo 'JIRA_PAT=\"<token>\"' > ~/.jira-reader.env && chmod 600 ~/.jira-reader.env"
      return 1
      ;;
    403)
      error_json "Authorization denied (HTTP 403). Your PAT lacks permission for this resource." \
        "Ensure your PAT has read access to the project. If you need a new PAT: ${JIRA_BASE_URL}/secure/ViewProfile.jspa?selectedTab=com.atlassian.pats.pats-plugin:jira-user-personal-access-tokens — then replace the value in ~/.jira-reader.env (file must contain exactly: JIRA_PAT=\"<new_token>\")."
      return 1
      ;;
    404)
      error_json "Not found (HTTP 404). The ticket or resource does not exist." \
        "Double-check the ticket key and ensure it exists in Jira."
      return 1
      ;;
    *)
      error_json "Jira API returned HTTP ${http_code}." \
        "Response body: $(echo "$response_body" | head -c 500)"
      return 1
      ;;
  esac
}

# ---------------------------------------------------------------------------
# Authenticated Confluence curl wrapper
# - Same safety conventions as jira_curl (silent, 15s timeout, no PAT echo)
# ---------------------------------------------------------------------------
wiki_curl() {
  local endpoint="$1"
  shift

  local url="${WIKI_BASE_URL}/rest/api${endpoint}"
  local http_code
  local response_body
  local tmpfile

  tmpfile=$(mktemp)
  trap "rm -f '$tmpfile'" RETURN

  http_code=$(curl -s -o "$tmpfile" -w "%{http_code}" \
    --max-time 15 \
    -L \
    -H "Authorization: Bearer ${WIKI_PAT}" \
    -H "Content-Type: application/json" \
    -H "Accept: application/json" \
    "$@" \
    "$url" 2>/dev/null) || {
      error_json "Network error: curl failed connecting to ${WIKI_BASE_URL}" \
        "Check your network connection."
      return 1
    }

  response_body=$(cat "$tmpfile")

  case "$http_code" in
    200|201)
      echo "$response_body"
      ;;
    401)
      error_json "Wiki authentication failed (HTTP 401). Your WIKI_PAT may be expired or invalid." \
        "Generate a new token at ${WIKI_BASE_URL}/plugins/personalaccesstokens/usertokens.action — then replace the value in ~/.wiki-reader.env (file must contain exactly: WIKI_PAT=\"<new_token>\"). Command: echo 'WIKI_PAT=\"<token>\"' > ~/.wiki-reader.env && chmod 600 ~/.wiki-reader.env"
      return 1
      ;;
    403)
      error_json "Wiki authorization denied (HTTP 403). Your token lacks permission for this resource." \
        "If you need a new token: ${WIKI_BASE_URL}/plugins/personalaccesstokens/usertokens.action — then replace the value in ~/.wiki-reader.env (file must contain exactly: WIKI_PAT=\"<new_token>\")."
      return 1
      ;;
    404)
      error_json "Wiki page not found (HTTP 404)." \
        "Double-check the page URL or title."
      return 1
      ;;
    *)
      error_json "Confluence API returned HTTP ${http_code}." \
        "Response body: $(echo "$response_body" | head -c 500)"
      return 1
      ;;
  esac
}

# ---------------------------------------------------------------------------
# Ticket key extraction regex pattern
# Matches standard Jira keys: PROJECT-123
# ---------------------------------------------------------------------------
TICKET_KEY_PATTERN='[A-Z][A-Z0-9_]+-[0-9]+'

# Extract the first ticket key from arbitrary text
extract_first_ticket_key() {
  local text="$1"
  echo "$text" | grep -oE "$TICKET_KEY_PATTERN" | head -1
}

# Validate that a string looks like a ticket key
validate_ticket_key() {
  local key="$1"
  if [[ ! "$key" =~ ^[A-Z][A-Z0-9_]+-[0-9]+$ ]]; then
    error_json "Invalid ticket key format: '${key}'" \
      "Expected format: PROJECT-123 (e.g., OM-1234, ECOM-567)"
    return 1
  fi
}
