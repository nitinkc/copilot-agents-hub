#!/usr/bin/env python3
"""
Jira Reader — Python Shared Library
====================================
Shared utilities for Python-based Jira data scripts.
Sourced (imported) by fetch-sprint-data.py and analyze-sprint.py.

Zero external dependencies beyond Python 3.6+ stdlib.
"""
import json
import os
import ssl
import sys
import urllib.request
import urllib.parse
from datetime import datetime, timezone

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
JIRA_BASE_URL = "https://tkts.sys.comcast.net"
BATCH_SIZE = 50          # JQL search page size (Jira default max)
REQUEST_TIMEOUT = 30     # seconds per HTTP request — bounded execution
MAX_BATCHES = 100        # Hard cap: 100 × 50 = 5000 tickets max

# ---------------------------------------------------------------------------
# SSL context (Comcast internal certs — disable verification)
# ---------------------------------------------------------------------------
_SSL_CTX = ssl.create_default_context()
_SSL_CTX.check_hostname = False
_SSL_CTX.verify_mode = ssl.CERT_NONE

# ---------------------------------------------------------------------------
# PAT loading — mirrors _lib.sh logic
# ---------------------------------------------------------------------------
def load_jira_pat():
    """Load Jira Personal Access Token from environment or ~/.jira-reader.env.

    Resolution order:
      1. JIRA_PAT environment variable (already set)
      2. ~/.jira-reader.env file (JIRA_PAT=<value>)

    Returns the PAT string or exits with error.
    """
    pat = os.environ.get("JIRA_PAT", "")
    if pat:
        return pat

    env_file = os.path.expanduser("~/.jira-reader.env")
    if os.path.exists(env_file):
        with open(env_file) as f:
            for line in f:
                line = line.strip()
                if line.startswith("JIRA_PAT="):
                    pat = line.split("=", 1)[1].strip().strip('"').strip("'")
                    if pat:
                        return pat

    print("ERROR: JIRA_PAT not found. Set it in environment or ~/.jira-reader.env", file=sys.stderr)
    sys.exit(1)


# ---------------------------------------------------------------------------
# HTTP client — bounded, single-purpose
# ---------------------------------------------------------------------------
def jira_get(path, pat=None, base_url=None, raw_url=False):
    """HTTP GET against Jira REST API with Bearer auth.

    Args:
        path: API path (e.g., '/rest/api/2/issue/KEY-123') or full URL if raw_url=True.
        pat: Personal Access Token. Loaded automatically if None.
        base_url: Override JIRA_BASE_URL if needed.
        raw_url: If True, treat `path` as a complete URL.

    Returns:
        Parsed JSON dict/list, or None on error.
    """
    if pat is None:
        pat = load_jira_pat()
    url = path if raw_url else f"{base_url or JIRA_BASE_URL}{path}"
    req = urllib.request.Request(url, headers={
        "Authorization": f"Bearer {pat}",
        "Accept": "application/json",
    })
    try:
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT, context=_SSL_CTX) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        print(f"ERROR fetching {url}: {e}", file=sys.stderr)
        return None


# ---------------------------------------------------------------------------
# Timestamp parsing
# ---------------------------------------------------------------------------
def parse_ts(ts_str):
    """Parse a Jira timestamp string to datetime (UTC).

    Handles:
      - ISO 8601 with timezone: '2026-04-08T10:00:00.000+0000'
      - ISO 8601 with Z: '2026-04-08T10:00:00Z'
      - ISO 8601 without tz: '2026-04-08T10:00:00' (assumed UTC)

    Returns datetime or None on failure.
    """
    if not ts_str:
        return None
    try:
        return datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        pass
    try:
        return datetime.strptime(ts_str[:19], "%Y-%m-%dT%H:%M:%S").replace(tzinfo=timezone.utc)
    except (ValueError, TypeError):
        return None


# ---------------------------------------------------------------------------
# JSON I/O helpers
# ---------------------------------------------------------------------------
def save_json(cache_dir, filename, data):
    """Write data as JSON to cache_dir/filename. Creates dir if needed."""
    os.makedirs(cache_dir, exist_ok=True)
    path = os.path.join(cache_dir, filename)
    with open(path, "w") as f:
        json.dump(data, f, indent=2, default=str)
    print(f"  saved {filename}")


def load_json(cache_dir, filename):
    """Read JSON from cache_dir/filename. Returns parsed data."""
    path = os.path.join(cache_dir, filename)
    with open(path) as f:
        return json.load(f)


# ---------------------------------------------------------------------------
# Story points extraction — handles multiple Jira custom field IDs
# ---------------------------------------------------------------------------
SP_FIELDS = ["customfield_10423", "customfield_10002"]

def extract_sp(fields_dict):
    """Extract story points from a Jira issue fields dict.

    Tries multiple custom field IDs (SP field varies by Jira instance).
    Returns float or None.
    """
    for field in SP_FIELDS:
        val = fields_dict.get(field)
        if val is not None:
            try:
                return float(val)
            except (ValueError, TypeError):
                continue
    return None


def extract_sp_from_report_item(report_item):
    """Extract story points from a sprint report issue entry.

    Sprint report uses estimateStatistic.statFieldValue.value.
    Returns float or None.
    """
    try:
        return float(
            report_item.get("estimateStatistic", {})
            .get("statFieldValue", {})
            .get("value")
        )
    except (ValueError, TypeError):
        return None


# ---------------------------------------------------------------------------
# Ticket map builder — canonical ticket structure used by all analyzers
# ---------------------------------------------------------------------------
def build_ticket_map(tickets, sprint_report=None):
    """Build a key→dict map from raw ticket JSON.

    Args:
        tickets: List of raw Jira issue dicts (from tickets-full.json).
        sprint_report: Optional sprint report dict (sprint-report.json) to
            cross-reference story points and completion status.

    Returns:
        dict: {ticket_key: {key, summary, assignee, status, status_cat,
               type, priority, sp, labels, components, fix_versions,
               created, updated, resolved, resolution, epic, description,
               in_completed, in_not_completed, in_punted, added_during}}
    """
    # Build sets from sprint report if available
    comp_keys = set()
    nc_keys = set()
    punt_keys = set()
    added_keys = set()
    report_sp = {}  # key → sp from report

    if sprint_report:
        contents = sprint_report.get("contents", {})
        for i in contents.get("completedIssues", []):
            comp_keys.add(i["key"])
            sp = extract_sp_from_report_item(i)
            if sp is not None:
                report_sp[i["key"]] = sp
        for i in contents.get("issuesNotCompletedInCurrentSprint", []):
            nc_keys.add(i["key"])
            sp = extract_sp_from_report_item(i)
            if sp is not None:
                report_sp[i["key"]] = sp
        for i in contents.get("puntedIssues", []):
            punt_keys.add(i["key"])
            sp = extract_sp_from_report_item(i)
            if sp is not None:
                report_sp[i["key"]] = sp
        added_keys = set(contents.get("issueKeysAddedDuringSprint", {}).keys())

    tm = {}
    for t in tickets:
        k = t["key"]
        f = t.get("fields", {})
        assignee = f.get("assignee")
        assignee_name = assignee.get("displayName", "Unassigned") if assignee else "Unassigned"
        status = f.get("status", {})
        sp = extract_sp(f)
        # Prefer sprint report SP (more reliable)
        if k in report_sp:
            sp = report_sp[k]

        tm[k] = dict(
            key=k,
            summary=f.get("summary", ""),
            assignee=assignee_name,
            status=status.get("name", ""),
            status_cat=status.get("statusCategory", {}).get("name", ""),
            type=f.get("issuetype", {}).get("name", ""),
            priority=f.get("priority", {}).get("name", ""),
            sp=sp,
            labels=f.get("labels", []),
            components=[c.get("name", "") for c in f.get("components", [])],
            fix_versions=[v.get("name", "") for v in f.get("fixVersions", [])],
            created=f.get("created", ""),
            updated=f.get("updated", ""),
            resolved=f.get("resolutiondate", ""),
            resolution=(f.get("resolution") or {}).get("name", ""),
            epic=f.get("customfield_18881", "") or f.get("customfield_10008", "") or "",
            description=f.get("description", "") or "",
            in_completed=k in comp_keys,
            in_not_completed=k in nc_keys,
            in_punted=k in punt_keys,
            added_during=k in added_keys,
        )
    return tm
