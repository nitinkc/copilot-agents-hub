#!/usr/bin/env bash
# ============================================================================
# fetch-epic-tickets.sh — Fetch tickets from a Jira epic with optional filters
#
# Usage:
#   bash .github/skills/jira-wiki-reader/scripts/fetch-epic-tickets.sh <EPIC_KEY> [OPTIONS]
#
# Arguments:
#   EPIC_KEY              Required. The Jira epic key (e.g., CMXOTD-3181)
#
# Options:
#   -o, --output FILE     Output file path (default: /tmp/epic-tickets.json)
#   -s, --status-filter   Comma-separated statuses to EXCLUDE or INCLUDE (default: Closed)
#   -m, --mode            Filter mode: 'exclude' (default, status NOT IN) or 'include' (status IN)
#   -d, --updated-days N  Only include tickets updated in the last N days (e.g., 21)
#   -f, --fields          Comma-separated Jira fields to fetch
#   -q, --extra-jql       Additional JQL AND clause (e.g., "priority = Critical")
#
# Examples:
#   bash .github/skills/jira-wiki-reader/scripts/fetch-epic-tickets.sh CMXOTD-3181
#   bash .github/skills/jira-wiki-reader/scripts/fetch-epic-tickets.sh CMXOTD-3181 -o /tmp/out.json
#   bash .github/skills/jira-wiki-reader/scripts/fetch-epic-tickets.sh CMXOTD-3181 -s "Closed,Canceled,Released"
#   bash .github/skills/jira-wiki-reader/scripts/fetch-epic-tickets.sh CMXOTD-3181 -q "priority IN (Critical, Blocker)"
#   # Fetch recently-closed tickets (last 21 days):
#   bash .github/skills/jira-wiki-reader/scripts/fetch-epic-tickets.sh CMXOTD-3181 \
#     --mode include --status-filter "Closed,Canceled,Resolved,Released,Accepted" \
#     --updated-days 21 --output /tmp/epic-tickets-closed.json
#
# Requires: JIRA_PAT in environment or ~/.jira-reader.env
# Output:   JSON array of ticket objects (key, prefix, summary, status, etc.)
# ============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Source shared Jira auth library (sibling file)
source "$SCRIPT_DIR/_lib.sh"
validate_env

# ── Defaults ──────────────────────────────────────────────────────────────────
OUTPUT_FILE="/tmp/epic-tickets.json"
STATUS_FILTER="Closed"
MODE="exclude"   # exclude = status NOT IN (actionable tickets); include = status IN (closed tickets)
UPDATED_DAYS=""  # empty = no date restriction; N = updated in last N days
EXTRA_JQL=""
FIELDS="key,summary,status,priority,issuetype,assignee,reporter,labels,customfield_10002,created,updated,resolution"

# ── Args ──────────────────────────────────────────────────────────────────────
if [ $# -lt 1 ]; then
  echo "ERROR: EPIC_KEY is required." >&2
  echo "Usage: fetch-epic-tickets.sh <EPIC_KEY> [OPTIONS]" >&2
  exit 1
fi

EPIC_KEY="$1"
shift

while [[ $# -gt 0 ]]; do
  case "$1" in
    -o|--output)        OUTPUT_FILE="$2"; shift 2 ;;
    -s|--status-filter) STATUS_FILTER="$2"; shift 2 ;;
    -m|--mode)          MODE="$2"; shift 2 ;;
    -d|--updated-days)  UPDATED_DAYS="$2"; shift 2 ;;
    -f|--fields)        FIELDS="$2"; shift 2 ;;
    -q|--extra-jql)     EXTRA_JQL="$2"; shift 2 ;;
    *) echo "ERROR: Unknown option: $1" >&2; exit 1 ;;
  esac
done

JIRA_URL="$JIRA_BASE_URL"
PAGE_SIZE=100

# ── Build JQL ─────────────────────────────────────────────────────────────────
# Convert comma-separated statuses to JQL IN/NOT IN clause
STATUS_IN=$(echo "$STATUS_FILTER" | sed 's/,/","/g')
if [ "$MODE" = "include" ]; then
  JQL="\"Epic Link\" = ${EPIC_KEY} AND status IN (\"${STATUS_IN}\")"
else
  JQL="\"Epic Link\" = ${EPIC_KEY} AND status NOT IN (\"${STATUS_IN}\")"
fi
[ -n "$UPDATED_DAYS" ] && JQL="${JQL} AND updated >= -${UPDATED_DAYS}d"
[ -n "$EXTRA_JQL" ] && JQL="${JQL} AND ${EXTRA_JQL}"
JQL="${JQL} ORDER BY updated DESC"

echo "[INFO]  Fetching tickets from epic ${EPIC_KEY}..." >&2

ALL_TICKETS="[]"
START_AT=0
TOTAL=999999  # will be replaced on first fetch

while [ "$START_AT" -lt "$TOTAL" ]; do
  RESPONSE=$(curl -s --max-time 30 \
    -H "Authorization: Bearer ${JIRA_PAT}" \
    -H "Content-Type: application/json" \
    "${JIRA_URL}/rest/api/2/search?jql=$(python3 -c "import urllib.parse; print(urllib.parse.quote('''${JQL}'''))")&fields=${FIELDS}&startAt=${START_AT}&maxResults=${PAGE_SIZE}")

  # Extract total on first page
  PAGE_TOTAL=$(echo "$RESPONSE" | python3 -c "import json,sys; print(json.load(sys.stdin).get('total',0))")
  TOTAL=$PAGE_TOTAL

  # Transform issues to compact format and append
  PAGE_TICKETS=$(echo "$RESPONSE" | python3 -c "
import json, sys
data = json.load(sys.stdin)
tickets = []
for issue in data.get('issues', []):
    f = issue['fields']
    key = issue['key']
    prefix = key.rsplit('-', 1)[0]
    assignee = (f.get('assignee') or {}).get('displayName', 'Unassigned')
    reporter = (f.get('reporter') or {}).get('displayName', 'Unknown')
    status = (f.get('status') or {}).get('name', 'Unknown')
    status_cat = ((f.get('status') or {}).get('statusCategory') or {}).get('name', 'Unknown')
    priority = (f.get('priority') or {}).get('name', 'None')
    issue_type = (f.get('issuetype') or {}).get('name', 'Unknown')
    labels = f.get('labels', [])
    sp = f.get('customfield_10002')
    created = (f.get('created') or '')[:10]
    updated = (f.get('updated') or '')[:10]
    resolution = (f.get('resolution') or {}).get('name') if f.get('resolution') else None
    tickets.append({
        'key': key, 'prefix': prefix, 'summary': f.get('summary',''),
        'status': status, 'status_cat': status_cat, 'priority': priority,
        'type': issue_type, 'assignee': assignee, 'reporter': reporter,
        'labels': labels, 'sp': sp, 'created': created, 'updated': updated,
        'resolution': resolution
    })
print(json.dumps(tickets))
")

  ALL_TICKETS=$(python3 -c "
import json, sys
existing = json.loads(sys.argv[1])
new_page = json.loads(sys.argv[2])
print(json.dumps(existing + new_page))
" "$ALL_TICKETS" "$PAGE_TICKETS")

  START_AT=$((START_AT + PAGE_SIZE))
  echo "[INFO]  Fetched ${START_AT}/${TOTAL}..." >&2
done

# Write output
echo "$ALL_TICKETS" | python3 -m json.tool > "$OUTPUT_FILE"

TICKET_COUNT=$(echo "$ALL_TICKETS" | python3 -c "import json,sys; print(len(json.load(sys.stdin)))")
echo "[INFO]  Wrote ${TICKET_COUNT} tickets to ${OUTPUT_FILE}" >&2
echo "$TICKET_COUNT"
