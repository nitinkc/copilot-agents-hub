---
name: ltg-critical-review
description: Final cross-check and introspection of generated tests using mission-critical application requirements as forcing function. Identify gaps and regenerate missing coverage.
---

# Skill: Critical Review

## Goal
Perform a rigorous cross-check of all generated tests using mission-critical application standards as the forcing function. Identify any remaining gaps, regenerate missing tests, and produce a confidence statement.

## Inputs
- All generated/updated test files
- Test execution results from `ltg-test-execution-loop`
- Test gap report from `ltg-code-analysis`
- Best-practice checklist from `ltg-best-practice-context`

## Steps

### Step 0: Project Context Map

Before cross-checking tests, compare the change against existing project patterns:
- Similar controllers/endpoints and DTO conventions
- Existing error envelope + errorCode taxonomy
- CorrelationId propagation conventions
- Outbound client configuration pattern (central factory/config vs ad hoc)
- Repository query patterns (pagination/caps, uniqueness, rollback)
- Existing test conventions (base classes, naming, stubbing approach, contract testing)

Ensure generated tests align with project conventions. Flag deviations; accept only when they clearly reduce risk.

### Step 1: Mission-Critical Forcing Function Checklist

#### Anti-Pattern Scan
Scan all changed/generated files against the anti-patterns list in `.github/instructions/mission-critical-checklists.instructions.md` under "Code quality anti-patterns". Flag any match as a test gap (the anti-pattern should be prevented or tested). Report using the "Anti-Pattern Findings" table format from "Outcome presentation rules" in the same file. Include the table in the output even if empty (state "Anti-pattern scan: 0 findings").

#### Completeness Cross-Check
For each production code change, verify:
- [ ] Every new/modified public method has at least one test
- [ ] Every new branch/condition has coverage (happy + failure paths)
- [ ] Every new validation rule has a corresponding test
- [ ] Every error code path has an explicit test
- [ ] Every boundary/cap has a test at and beyond the limit

#### Failure Mode Coverage
- [ ] Timeout behavior tested for every outbound call
- [ ] Retry exhaustion behavior tested where retries exist
- [ ] Circuit breaker state transitions tested if applicable
- [ ] Partial failure handling tested (e.g., batch where some succeed, some fail)
- [ ] Null/empty input handling tested for all entry points
- [ ] Malformed input handling tested (invalid JSON, wrong types, truncated data)

#### Data Integrity & Idempotency
- [ ] Duplicate request handling tested where side effects exist
- [ ] Transaction rollback tested for failure scenarios
- [ ] Constraint violation error paths tested (unique, foreign key, etc.)
- [ ] Concurrent access scenarios considered (if applicable to change)

#### Security Behavior
- [ ] Authentication failure (401) tested if auth changes
- [ ] Authorization failure (403) tested if authz changes
- [ ] Input sanitization/validation tested for all user inputs
- [ ] PII/sensitive data handling assertions present where applicable

#### Contract Stability
- [ ] Response schema stability asserted (no accidental field removal)
- [ ] Error envelope format asserted (status + errorCode + correlationId)
- [ ] Backward compatibility preserved (no breaking changes in asserts)

#### Whole-Project Invariant Checklist
Verify changes respect cross-cutting invariants:
- [ ] **Backward compatibility**: no removed/renamed params/fields unless versioned; stable errorCode meanings
- [ ] **Boundedness**: pagination capped; batch/list/string size caps; no unbounded loops/retries
- [ ] **IO safety**: outbound timeouts (connect/read/deadline); bounded retries for safe operations only
- [ ] **Error safety**: consistent safe error envelope (no stack traces, no raw exception text)
- [ ] **Idempotency**: side-effecting operations are replay-safe
- [ ] **Layering**: controller thin; business logic in service; persistence in repo; outbound in client/adapter
- [ ] **Security hygiene**: no secrets logged; SSRF allowlist if URL inputs; strict boundary validation

#### Test Adequacy Matrix
Build: **Change area / risk -> required scenarios -> existing tests -> missing tests**.
Include: happy path, validation failure, boundary/cap, business error (4xx), technical failure (5xx), dependency failure (timeout/5xx/malformed), idempotency/duplicate, error envelope stability.

#### Documentation Awareness
- [ ] Flag when changed behavior likely requires business capabilities doc update
- [ ] Flag when changed dependencies likely require service context or runtime flows doc update
- [ ] Flag when changed APIs/rules likely require machine manifest update
- [ ] Report documentation gaps in output (LTG does not generate docs -- flag only)

### Step 2: Introspection Questions

1. **"What could break in production that isn't tested?"**
   - Network partition during operation
   - Downstream service returning unexpected data
   - Database constraint violations
   - Resource exhaustion (connections, threads)

2. **"What edge cases might a QA engineer find?"**
   - Boundary values (0, 1, max, max+1)
   - Empty collections/strings
   - Unicode/special characters
   - Very large payloads at the limit

3. **"What would an attacker try?"**
   - Invalid/missing auth tokens
   - Malformed requests
   - SQL injection attempts (should fail validation)
   - Oversized payloads

4. **"What assumptions am I making that need tests?"**
   - Dependency availability
   - Data format consistency
   - Clock/time behavior
   - Ordering guarantees

### Step 3: Gap Regeneration

For each identified gap:
1. Document the missing scenario
2. Determine test type (unit/integration/stub/guard)
3. Generate the test following existing patterns
4. Add to the test file with clear documentation of what it proves
5. Run gap-fill tests through the Test Execution skill -- bounded, max 3 iterations
6. If gap-fill tests fail, loop through the full scoped workflow (analysis -> best-practice -> type determination -> generation -> validation -> execution) for gap tests only

### Step 3b: Socratic Self-Check (before confidence assessment)
Execute the 11-question Socratic Self-Check from `.github/instructions/mission-critical-checklists.instructions.md` under "Socratic self-check". If any answer reveals an untested risk, add it as a gap and loop back to Step 3. Report using the "Socratic-Revealed Risks" table format from "Outcome presentation rules" in the same file. Include the table in the Confidence Assessment even if empty (state "Socratic self-check: 0 new risks surfaced").

### Step 4: Produce Confidence Assessment

Stop regenerating when:
- All checklist items satisfied or explicitly out of scope
- No more gaps identified through introspection questions
- Tests provide confidence for production deployment

## Output

1. **Cross-check matrix**: Each checklist item marked [x]/[ ] with justification
2. **Identified gaps**: List of missing test scenarios found during introspection
3. **Documentation gaps**: List of documentation artifacts likely needing updates based on changed behavior (flagged, not generated)
4. **Regenerated tests**: Any additional tests created to fill gaps
5. **Final coverage summary**:
   - Total scenarios covered
   - Mission-critical behaviors verified
   - Known limitations/assumptions
6. **Confidence statement**: Assessment of production-readiness based on test coverage AND execution proof
