---
name: ltg-code-analysis
description: Parse modified Java files (from #changes or git diff) to identify test gaps and extract behaviors/method signatures that require new or updated tests.
---

# Skill: Code Analysis

## Goal
Identify all modified production files, classify them by type, extract behavioral changes, locate existing tests, and determine test gaps.

## Inputs
- `#changes` (preferred) or git diff / list of modified files
- Repository structure under `src/main/java` and `src/test/java`

## Steps

### Step 1: Identify Modified Production Files
- Scan `src/main/java/**/*.java`
- Also check config: `application*.yml/properties` if behavior changes

### Step 2: Classify Each File
By naming and annotations:
- **Controller**: `@RestController` / `@Controller` or class name ends with `Controller`
- **Service**: `@Service` or name ends with `Service`
- **Repository/DAO**: `@Repository` or name ends with `Repository` / `Dao`
- **Outbound Client**: name ends with `Client` / `Gateway` / `Adapter` or in `client/` package
- **Error handling**: `@ControllerAdvice`, `Exception*`, `Error*`
- **Security config**: `WebSecurityConfigurerAdapter`, filters, interceptors
- **DTO/Validation**: DTOs with `@Valid`, `@NotNull`, `@Size`, etc.

### Step 3: Extract Behavioral Changes
- Changed public methods and new branches (if/else added)
- New validation rules, new bounds (`MAX_*`), new fields in DTOs
- New exception mapping or error codes
- Outbound IO changes: new endpoint path, headers, retry/timeout config
- DB query changes: SQL changes, constraints, transaction semantics

### Step 4: Identify Existing Tests
Locate likely tests by convention:
- `XController` -> `XControllerTest` or `XApiIT`
- `XService` -> `XServiceTest`
- `XClient` -> `XClientTest`
- `XRepository` -> `XRepositoryTest` or `*JdbcTest` / `*DataJpaTest`

### Step 5: Determine Gaps
- New class with no tests
- Changed behavior with no updated assertions
- Missing negative cases (validation failures, dependency errors)
- Missing boundary coverage (max sizes, pagination caps)
- Missing timeout/retry cap coverage for outbound calls
- Missing idempotency coverage where side effects exist

## Output
A test gap report per file containing:
- Class type
- Changed behaviors (bullets)
- Existing related tests (paths)
- Missing tests (bullets)
