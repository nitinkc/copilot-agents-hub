---
name: dev-design-blueprint
description: Create a development blueprint from acceptance criteria: API contract, domain rules, data model, dependency plan, error taxonomy, and mission-critical constraints.
---

# Skill: Design Blueprint

## Goal
Create an implementable plan that reduces ambiguity before TDD RED phase.

## Inputs
- Structured requirements from Requirements Intake
- Repository standards from `.github/instructions/`

## Hard Constraints
- Keep it minimal: only what's needed for the next thin slice.
- Prefer additive changes for compatibility.
- Make constraints testable (so tests can prove them in RED).

## Steps

### Step 1: API Contract Sketch
- Endpoint path/method
- Request/response DTO fields (with validation and bounds)
- For nested DTOs, Map values, and Collection elements: mark `@Valid` requirement explicitly in the sketch
- For override/variant types (e.g., per-tenant config): ensure constraints mirror the parent type — no unconstrained bypass paths
- For every stated bound (Javadoc, comments, config metadata): plan the matching runtime constraint (`@Min`/`@Max`/custom)
- Status codes and error envelope mapping (stable errorCode)

### Step 2: Domain Rules
- Invariants and business validations
- Idempotency strategy for side-effecting operations
- Formalize rules discovered during intake into rule inventory entries (see `dimension-extraction.instructions.md`):
  - Rule ID, Rule Name, Rule Type, Description, Applies To Capability, Trigger/Condition, Expected/Failure Behavior, Related API(s)

### Step 3: Persistence Plan (Oracle-minded)
- Entities/records involved
- Uniqueness constraints (for dedupe/idempotency)
- Transaction boundaries (service-level)
- Bounded queries/pagination plan
- Identify entity catalog entries: key entities, logic-bearing attributes, state transitions, data classification (see `dimension-extraction.instructions.md`)

### Step 4: Dependency Integration Plan
- Outbound client adapter responsibilities
- Timeouts, bounded retries, parsing validation
- Correlation propagation

### Step 4b: Dependency Governance (MUST for new/changed dependencies)
- Identify every new or changed dependency (direct and transitive)
- Draft the risk register entry: name, version, known issues/CVE classes, mitigations, verification approach
- Plan build-time or code-time guardrails for risky functionality
- Reference: `dependency-known-issues-gates.instructions.md` under "Design-time enforcement"

### Step 5: Failure Modes Table
- Invalid input -> 400 + errorCode
- Business rule violation -> 4xx + errorCode
- Dependency timeout/5xx -> safe 5xx + errorCode
- Duplicate request -> replay-safe deterministic response

### Step 6: Pre-Gate Quality Checks (silent)

**Anti-pattern risk preview**: Read the anti-patterns list from `.github/instructions/mission-critical-checklists.instructions.md` under "Code quality anti-patterns". For each anti-pattern, ask: "Does this design make it likely the implementation will exhibit this pattern?" If yes, add a risk note to the design output (e.g., "Risk: no pagination specified → unbounded result sets"). See "Anti-pattern risk preview" in the same file for reframing guidance. Report findings using the "Implementation Risk Flags" table format from "Outcome presentation rules" in the same file. Include the table in the Developer Gate output even if empty (state "0 findings").

**Socratic self-check**: Execute the 11-question Socratic Self-Check from `.github/instructions/mission-critical-checklists.instructions.md` under "Socratic self-check", applied to the design. If any answer reveals an uncaptured risk, add it to the Failure Modes Table or constraints before presenting to the developer. Report using the "Socratic-Revealed Risks" table format from "Outcome presentation rules" in the same file. Include the table in the Developer Gate output even if empty (state "0 new risks surfaced").

## Output
- Design decisions list (short bullets)
- DTO fields with constraints (table-like bullets)
- Error taxonomy (errorCode -> HTTP status -> meaning)
- DB uniqueness/dedupe plan (keys and constraints)
- Outbound behaviors (timeouts/retry cap/parsing rules)
- Rule inventory entries (rule ID, name, type, capability, expected/failure behavior) for rules formalized during design
- Entity catalog entries (entity, purpose, key attributes with logic-bearing flags, related capabilities/rules) for entities identified during design

## Developer Gate (MANDATORY)

After producing the output above, present it to the developer with the following explicit action block. Do NOT proceed until the developer responds.

### Present to Developer

Include this action block at the end of the design blueprint:

```
---
## Developer Action Required

Please review the design blueprint above (API contract, domain rules, persistence plan, dependency plan, failure modes, rule inventory, entity catalog) and choose one:

1. **Approve** — design is acceptable; proceed to PLAN (step 3)
2. **Request changes** — specify which design elements need modification (I will update the blueprint and re-present)
3. **Approve with notes** — proceed to PLAN but carry your notes as additional design constraints

Optional:
- Flag any API contract concerns (paths, fields, status codes)
- Suggest different timeout/retry values or idempotency strategies
- Identify missing failure modes or error codes

> Waiting for your response before continuing.
```

### After Developer Responds

| Developer action | Agent behavior |
|---|---|
| **Approve** | Incorporate any final notes, mark design as `completed`, and proceed to PLAN (step 3). Never skip PLAN to jump to BUILD. |
| **Request changes** | Update the blueprint per feedback, re-present the updated design, and wait for approval again. |
| **Approve with notes** | Carry the developer's notes as additional constraints into PLAN (step 3). Mark design as `completed` and proceed. |
| **Flag concerns** | Address flagged concerns in the blueprint, re-present if material changes were made, then proceed to PLAN (step 3). |
