---
name: rca-recommendations
description: >
  Convert RCA findings into actionable, prioritized recommendations. Classifies
  issues by control status (in-control vs external), generates fix proposals,
  prevention plans, and Jira ticket drafts.
---

# Skill: RCA Recommendations

## Goal

Convert validated RCA findings into prioritized, actionable recommendations
with control classification, fix proposals, prevention plans, and
ready-to-file Jira ticket drafts.

## When to Use

- After RCA synthesis to generate actionable fix proposals
- Classify whether issues are within team control
- Design graceful degradation for external issues
- Generate prevention strategies (short/medium/long-term)
- Draft Jira tickets for recommended actions
- Build a complete Action Plan

## Step 0 — Load Template

```
read_file .github/shared/templates/action-plan.md
```

## Input

Evidence from:
- `rca-synthesis` — root cause, FMEA score, Ishikawa classification
- `code-forensics` — error origin file/line, suspicious commits, config findings
- `service-traversal` — propagation chain, patterns detected
- `blast-radius` — impact scope

## Workflow

### Step 1: Control Classification

Classify the root cause and every contributing factor:

| Status | Definition | Examples |
|--------|-----------|---------|
| **IN_CONTROL** | We own the code/config/process | Our bug, our misconfiguration, our missing validation |
| **PARTIAL_CONTROL** | We can mitigate but not eliminate | Upstream SLA not met, but we can add caching/fallback |
| **EXTERNAL** | Entirely outside our control | Vendor outage, third-party API change, infra failure |

### Step 2: Issue Type Classification

| Type | Fix Strategy |
|------|-------------|
| **Bug** | Targeted code change + regression test |
| **Systemic** | Architecture review + phased remediation |
| **Configuration** | Config change + config validation automation |
| **Process** | Process improvement + automation |
| **Data** | Data validation + data quality monitoring |
| **Latent** | Root fix + condition monitoring |

### Step 3: Generate Recommendations

#### For IN_CONTROL Issues

```yaml
immediate_fix:
  description: string             # What to change
  affected_service: string        # serviceName slug
  affected_files: string[]        # Specific files in the source repo
  code_suggestion: string         # Code diff or pseudocode
  config_change: string           # MobileBackOfficeConfig change (if any)
  estimated_effort: string        # Hours/days
  risk_of_fix: "LOW" | "MEDIUM" | "HIGH"

regression_prevention:
  unit_test: string               # Test case description
  integration_test: string        # MockMvc / contract test scenario
  guard_test: string              # ArchUnit constraint (if pattern issue)

monitoring_enhancement:
  new_alert: string               # Alert rule to add
  dashboard_update: string        # Metric/dashboard to create
  log_enhancement: string         # Structured log field to add
```

#### For EXTERNAL Issues

```yaml
graceful_degradation:
  pattern: "CIRCUIT_BREAKER" | "FALLBACK" | "CACHE" | "RETRY_WITH_BACKOFF" | "BULKHEAD" | "GRACEFUL_REJECT"
  description: string
  implementation:
    code_changes: string[]        # Files and approach
    config_changes: string        # Resilience4j / Spring config in MobileBackOfficeConfig

resilience_improvements:
  - type: string                  # Circuit breaker config, timeout tuning, etc.
    current_state: string
    recommended_state: string
    rationale: string

communication_plan:
  internal_escalation: string
  external_vendor_action: string
  customer_communication: string
```

#### For PARTIAL_CONTROL Issues

Generate BOTH in-control fixes (for our part) AND graceful handling (for the external part).

### Step 3b: Edge Case Stress-Test (MANDATORY for ROOT_CAUSE_FIX recommendations)

For each recommendation classified as `ROOT_CAUSE_FIX`, verify it survives these
edge case scenarios. A fix that works for the observed case but fails under production
variants is NOT a root cause fix.

**Mandatory stress-test scenarios:**

| Scenario | Question to answer |
|----------|--------------------|
| **Multi-DC concurrent** | Does the fix work when 6 DCs execute simultaneously? Race conditions? |
| **Retry storm** | If the caller retries 3x, does the fix remain safe? Idempotent? |
| **Data variants** | Does the fix handle NULL, empty string, max-length, special characters? |
| **Partial failure** | What if the fix succeeds in step 1 but fails in step 2? Rollback? |
| **Version coexistence** | During rolling deploy, old and new code run simultaneously. Safe? |
| **Timer/timeout edge** | If the fix changes a timeout, what happens at exactly the boundary? |
| **Scale** | Does the fix work with 1 order? 1000 concurrent orders? 100K backlog? |

**For each scenario**: state SAFE (with reasoning) or VULNERABLE (with the specific failure mode).

**If ANY scenario is VULNERABLE**: either strengthen the fix or add a companion
`DEFENSE_IN_DEPTH` recommendation that covers the gap. Document it explicitly.

**Output required**: An "Edge Case Matrix" table in the recommendation section.
Fixes with unaddressed VULNERABLE scenarios MUST NOT be classified as ROOT_CAUSE_FIX.

### Step 4: Prevention Framework

| Timeframe | Actions |
|-----------|---------|
| **Short-term** (this sprint) | Immediate fix, regression tests, monitoring |
| **Medium-term** (this quarter) | Architecture improvements, process changes |
| **Long-term** (architectural) | Systemic resilience, platform improvements |

### Step 5: Jira Ticket Drafts

For each actionable recommendation, draft a ticket:

```yaml
jira_ticket:
  title: string
  type: "Bug" | "Story" | "Task" | "Spike"
  priority: "P1-Critical" | "P2-High" | "P3-Medium" | "P4-Low"
  severity: "S1-Blocker" | "S2-Critical" | "S3-Major" | "S4-Minor"
  description: string             # Include root cause, evidence, and fix approach
  acceptance_criteria:
    - criterion: string
  labels: ["rca", "<error_category>", "<incident_id>"]
  components: string[]
  estimated_story_points: int
```

### Step 6: Recurring Pattern Check

Assess whether this failure matches a known recurring pattern:
- Check ELK for same error pattern in last 30 days
- Check if same configLabel/service has had similar incidents
- If recurring and unresolved → escalation flag

### Step 7: Generate Action Plan

Fill the `.github/shared/templates/action-plan.md` template with all findings.

## Output Contract

```yaml
recommendation_result:
  classification:
    control_status: "IN_CONTROL" | "PARTIAL_CONTROL" | "EXTERNAL"
    issue_type: "BUG" | "SYSTEMIC" | "CONFIGURATION" | "PROCESS" | "DATA" | "LATENT"
    summary: string
  recommendations:
    in_control: InControlRecommendation[]
    external: ExternalHandling[]
  prevention:
    short_term: Action[]
    medium_term: Action[]
    long_term: Action[]
  jira_tickets: JiraTicket[]
  recurring_pattern:
    matches_known: boolean
    pattern_description: string
    previous_occurrences: int
    escalation_needed: boolean
```

## Quality Rules

- **Actionable over aspirational**: Every recommendation must be implementable.
- **Fix the system, not the symptom**: Address root cause, not just the error.
- **Defense in depth**: One fix is never enough — recommend multiple layers.
- **Graceful degradation for everything external**: If we can't fix it, we handle it.
- **Every Jira ticket gets acceptance criteria**: No vague tickets.

### Root Cause Fix vs Symptom Mitigation Classification (MANDATORY)

Every recommendation MUST be classified as one of:

| Classification | Definition | Examples | Acceptable alone? |
|---|---|---|---|
| **ROOT_CAUSE_FIX** | Eliminates the condition that caused the failure | Upgrade framework to version with fix, correct code logic, fix data source | YES |
| **SYMPTOM_MITIGATION** | Prevents the failure from propagating but does not eliminate it | Add try-catch, add null check before framework call, add circuit breaker | NO — must accompany a ROOT_CAUSE_FIX |
| **DEFENSE_IN_DEPTH** | Additional protection layer beyond the root cause fix | Add monitoring, add guard test, add integration test | NO — supplements ROOT_CAUSE_FIX |

**Enforcement**:
- At least ONE recommendation MUST be classified as `ROOT_CAUSE_FIX`.
- If ALL recommendations are `SYMPTOM_MITIGATION`, the investigation is INCOMPLETE.
  Loop back to Phase 4 (Code Forensics) or Phase 5 (RCA Synthesis) to find the actual root cause.
- "Add try-catch" or "add null check" is NEVER a root cause fix for an NPE inside framework code.
  The root cause fix is: why does the framework reach that state, and how to prevent it.
- When the root cause is a framework/library bug:
  - ROOT_CAUSE_FIX = upgrade to the version that contains the fix, OR backport the fix.
  - SYMPTOM_MITIGATION = add defensive code around the framework call (acceptable as interim).
  - Both should be recommended, with ROOT_CAUSE_FIX having higher priority.

### Multi-Instance / Multi-DC Contention Pattern (known pattern)

When investigation reveals errors correlated across multiple DCs within the same
time window (< 5 seconds), check for database contention:

1. **Same-second errors across DCs** → shared database with row-level locking contention.
2. **ORA-01013 (user requested cancel)** → query/statement timeout due to lock wait.
3. **Flowable `LOCK_TIME_` update contention** → multiple async executors across DCs
   competing for the same job or process instance lock.
4. **Missing null check after DB lookup during cascade delete** → state was deleted by
   another instance between the existence check and the operation.

Recommendations for this pattern:
- ROOT_CAUSE_FIX: Partition async executor lock ownership per DC/instance (Flowable `lockOwner` config).
- ROOT_CAUSE_FIX: Upgrade framework to version with null-safety fixes.
- SYMPTOM_MITIGATION: Add idempotency guards in process deletion code.
- DEFENSE_IN_DEPTH: Add per-DC monitoring of `LOCK_TIME_` contention (Oracle wait events).
