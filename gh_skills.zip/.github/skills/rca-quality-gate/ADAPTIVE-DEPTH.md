# Adaptive Depth Algorithm — Tiered Investigation

> Prevents both **analysis paralysis** (over-investigating simple incidents) and
> **under-investigation** (shallow analysis of complex incidents).

## Three Tiers

### Tier 1: Quick (Target: < 30 seconds)
**When**: Incident matches a known pattern with high confidence.

```yaml
tier_1_criteria:  # ALL must be true
  - error_matches_known_pattern: true
  - pattern_confidence: ">= 0.90"
  - affected_services: "<= 1"
  - customer_facing: false
  - data_integrity_risk: "NONE"

tier_1_workflow:
  skills_used: ["elk-log-search", "error-taxonomy"]
  frameworks: ["Five Whys (3 levels max)"]
  critics: NONE
  gates: ["Gate 1: Problem Definition only"]
  output: "Quick triage result + known fix reference"
```

### Tier 2: Standard (Target: 1-3 minutes)
**When**: Moderate complexity, limited blast radius.

```yaml
tier_2_criteria:  # ANY triggers Tier 2
  - affected_services: "2-5"
  - customer_facing: true AND error_frequency.last_24h < 100
  - pattern_confidence: "0.50 - 0.89"
  - involves_cross_service_traversal: true

tier_2_workflow:
  skills_used: ["elk-log-search", "error-taxonomy", "blast-radius",
                "service-traversal", "rca-synthesis", "rca-recommendations"]
  frameworks: ["Five Whys", "FMEA", "Swiss Cheese", "ACH Matrix"]
  critics: ["Evidence audit (single pass)"]
  gates: ["Gate 1", "Gate 3", "Gate 4"]
  revision_cycles: 1
  output: "Standard RCA report"
```

### Tier 3: Deep (Target: 5-10 minutes)
**When**: High-severity, complex, novel, or conflicting evidence.

```yaml
tier_3_criteria:  # ANY triggers Tier 3
  - severity: "P1-Critical" OR "P2-High"
  - affected_services: "> 5"
  - data_integrity_risk: "MEDIUM" OR "HIGH"
  - pattern_confidence: "< 0.50" (novel pattern)
  - conflicting_evidence: true
  - multiple_independent_root_causes: true
  - involves_external_dependency: true AND customer_facing: true

tier_3_workflow:
  skills_used: ALL skills
  frameworks: ALL 7 + ACH + Abductive Verification
  critics: ALL 3 (Devil's Advocate + Evidence + Framework) + meta-review
  gates: ALL 5 gates
  revision_cycles: "Up to 3"
  additional:
    - abductive_forward_verification: true
    - pre_mortem_analysis: true
    - code_investigation: "deep"
    - effectiveness_planning: true
  output: "Full RCA package with critic audit trail"
```

## Tier Classification Algorithm

```
FUNCTION classify_tier(incident_intake):

  # Check Tier 3 triggers first
  IF incident_intake.initial_severity IN ["P1-Critical", "P2-High"]:
    RETURN TIER_3
  IF incident_intake.blast_radius.affected_services > 5:
    RETURN TIER_3
  IF incident_intake.data_integrity_risk IN ["MEDIUM", "HIGH"]:
    RETURN TIER_3
  IF incident_intake.pattern_match.confidence < 0.50:
    RETURN TIER_3

  # Check Tier 1 (all must be true)
  IF (incident_intake.pattern_match.confidence >= 0.90
      AND incident_intake.blast_radius.affected_services <= 1
      AND NOT incident_intake.customer_facing
      AND incident_intake.data_integrity_risk == "NONE"):
    RETURN TIER_1

  # Default: Tier 2
  RETURN TIER_2
```

## Tier Escalation Rules

Tiers can escalate MID-INVESTIGATION. **Never de-escalate.**

```yaml
escalation_triggers:
  tier_1_to_tier_2:
    - "Traversal reveals additional affected services"
    - "Error frequency is higher than initial assessment"
    - "Customer impact discovered during investigation"

  tier_2_to_tier_3:
    - "Evidence audit flags insufficient confidence (< 0.60)"
    - "Conflicting evidence discovered during synthesis"
    - "Blast radius exceeds 5 services after full traversal"
    - "Data integrity risk upgraded during code investigation"
    - "Devil's advocate challenge rated STRONG or DEVASTATING"
```

## Tier-Specific Workflow Summary

| Aspect | Tier 1 | Tier 2 | Tier 3 |
|--------|--------|--------|--------|
| Phases | 0, 1, 5 | 0-6 | 0-7 (all) |
| Gates | Gate 1 | Gates 1, 3, 4 | All 5 gates |
| Frameworks | Five Whys (3 levels) | Five Whys, FMEA, Swiss Cheese, ACH | All 7 + ACH |
| Forward Verification | No | No | Yes |
| Critics | None | Evidence (1 pass) | All 3 + meta-reviewer |
| Revision Cycles | 0 | 1 | Up to 3 |
| Pre-Mortem | No | No | Yes |
| Effectiveness Plan | No | Brief | Full Phase 7 |
| Debiasing | None | Confirmation check | All bias checks |
