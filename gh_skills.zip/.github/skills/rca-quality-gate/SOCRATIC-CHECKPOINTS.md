# Socratic Checkpoints — Investigation Quality Gates

> Five quality gates placed between investigation phases. Each gate uses
> structured Socratic questioning to verify the investigation is on track
> before proceeding. Gates are fast and deterministic.

## Gate Architecture

```
Phase 0: Intake
    ↓
  [GATE 1: Problem Definition] ← "Do we know what we're investigating?"
    ↓
Phase 1: Log Retrieval
    ↓
  [GATE 2: Evidence Sufficiency] ← "Do we have enough data to proceed?"
    ↓
Phase 2: Traversal
    ↓
  [GATE 3: Hypothesis Formation] ← "Do we have competing hypotheses, not just one?"
    ↓
Phase 3: Code Investigation
Phase 4: Synthesis
    ↓
  [GATE 4: Root Cause Validation] ← "Does the root cause survive challenge?"
    ↓
Phase 4b: Critic Review
    ↓
  [GATE 5: Remediation Verification] ← "Does the fix address the root cause?"
    ↓
Phase 5: Recommendations
Phase 6: Validation
Phase 7: Effectiveness Planning
```

---

## Gate 1: Problem Definition

**Position**: After intake, before log retrieval.
**Active for**: ALL tiers.

### Questions (ALL must be answered)

```yaml
gate_1_questions:
  clarifying:
    - "Can we state the problem in one sentence without jargon?"
    - "What is the observable symptom — not the assumed cause?"
    - "Who or what reported this? (User, alert, monitoring, engineer)"
  scope:
    - "What is the time window? (When did it start? Is it ongoing?)"
    - "Which service(s) are involved? (Known, not assumed)"
    - "What identifiers do we have? (GlobalTrackingId, threadContextId, trace ID)"
  completeness:
    - "Is there anything we're assuming that we haven't verified?"
```

### Pass Criteria
```yaml
gate_1_pass:
  required:
    - problem_statement: "Clear, one sentence"
    - time_window: "Defined (even if approximate)"
    - at_least_one_identifier: "GlobalTrackingId OR threadContextId OR (serviceName + timestamp)"
  fail_action: "Ask user for missing information before proceeding"
```

---

## Gate 2: Evidence Sufficiency

**Position**: After log retrieval, before traversal.
**Active for**: Tier 2, Tier 3.

### Questions

```yaml
gate_2_questions:
  data_quality:
    - "Did the ELK query return results? If not — wrong index? Wrong time window?"
    - "Do returned logs contain GlobalTrackingId/threadContextId for cross-service traversal?"
    - "Is the stack trace complete or truncated?"
  coverage:
    - "Have we retrieved logs from the REPORTED service AND its immediate neighbors?"
    - "Do we have context logs (before/after the error)?"
    - "Do we know the error frequency (first time? recurring? spike?)?"
  blind_spots:
    - "Are there services in the chain that don't log to order-tech-* index?"
    - "Could there be errors we're NOT seeing because of log level filtering?"
    - "Have we checked nginx-prod-* for upstream perspective?"
```

### Pass Criteria
```yaml
gate_2_pass:
  required:
    - primary_error_log: "At least one ERROR-level log with stack trace or error code"
    - traversal_identifiers: "GlobalTrackingId or threadContextId for cross-service linking"
    - error_categorized: "Error classified per error-taxonomy skill"
  warning_if_missing:
    - context_logs: "Pre/post error context"
    - error_frequency: "Historical frequency data"
  fail_action: "Widen search (time range, additional index patterns, service filter)"
```

---

## Gate 3: Hypothesis Formation

**Position**: After traversal, before code investigation.
**Active for**: Tier 2, Tier 3.

### Questions

```yaml
gate_3_questions:
  hypothesis_diversity:
    - "How many hypotheses? (Min 3 required for Tier 2+)"
    - "Are hypotheses genuinely different, or variations of the same idea?"
    - "Have we considered a hypothesis from EACH Ishikawa dimension?"
  assumption_check:
    - "What are we ASSUMING about the traversal path?"
    - "Is the 'origin service' truly the origin, or could there be a deeper layer?"
    - "Are we anchoring on the first error we found?"
  evidence_vs_assumption:
    - "For each hypothesis, what SUPPORTS and what CONTRADICTS it?"
    - "Which hypothesis would we pursue if we started from a different service?"
```

### Pass Criteria
```yaml
gate_3_pass:
  required:
    - hypothesis_count: ">= 3 (Tier 2+), >= 1 (Tier 1)"
    - origin_service_identified: "Traversal reached a leaf or depth limit"
    - blast_radius_computed: "Affected services counted"
  fail_action: "Generate additional hypotheses using Ishikawa dimensions"
```

---

## Gate 4: Root Cause Validation

**Position**: After synthesis, before critic review.
**Active for**: Tier 2, Tier 3.

### Questions

```yaml
gate_4_questions:
  evidence_grounding:
    - "Can we point to a SPECIFIC log entry, code line, or config value for the root cause?"
    - "Is EVERY Why in Five Whys backed by evidence, or are some inferred?"
    - "Have we run forward verification (abductive)?"
  logical_consistency:
    - "Does Five Whys root cause match Fault Tree minimal cut set?"
    - "Does FMEA severity match observed blast radius?"
    - "Are there contradictions between any frameworks?"
  alternative_consideration:
    - "Did ACH matrix produce the same winner as Five Whys?"
    - "What is the strongest argument AGAINST this root cause?"
    - "What would change our mind?"
  confidence_calibration:
    - "What is our evidence-based confidence level? (Not gut feel)"
```

### Pass Criteria
```yaml
gate_4_pass:
  required:
    - root_cause_has_evidence: "Grade B or better (strong inference or direct)"
    - five_whys_consistent_with_ach: "No major contradictions"
    - forward_verification: "CONFIRMED or PARTIALLY_CONFIRMED (not CONTRADICTED)"
    - confidence: ">= 0.60"
  fail_action: "Return to Phase 3 (Code) or Phase 2 (Traversal) for more evidence"
```

---

## Gate 5: Remediation Verification

**Position**: After critic review, before final recommendations.
**Active for**: Tier 3 (advisory for Tier 2).

### Questions

```yaml
gate_5_questions:
  root_cause_alignment:
    - "Does the fix address the ROOT cause (Why 5) or just the SYMPTOM (Why 1)?"
    - "If the root cause recurred, would the same incident happen again despite the fix?"
    - "Does the fix address ALL contributing factors from Ishikawa?"
  defense_in_depth:
    - "For each breached Swiss Cheese layer, is there a corresponding recommendation?"
    - "Does the prevention plan include short/medium/long term actions?"
    - "Have we recommended monitoring/alerting improvements, not just code fixes?"
  risk_assessment:
    - "What could go wrong with the proposed fix? (Pre-mortem on the fix)"
    - "Is there a rollback plan?"
    - "Does the fix introduce new failure modes?"
  external_handling:
    - "If EXTERNAL, do we have a graceful degradation strategy?"
    - "Have we recommended what to request from the external party?"
```

### Pass Criteria
```yaml
gate_5_pass:
  required:
    - fix_addresses_root_cause: "Not just the symptom"
    - rollback_plan_exists: "For code/config changes"
    - prevention_covers_breached_layers: "Swiss Cheese breaches addressed"
  fail_action: "Return to recommendations for more comprehensive remediation"
```

---

## Chain-of-Thought Preamble (All Phases)

Applied by the incident-investigator agent before each phase:

```
BEFORE producing output, reason through these steps:
1. UNDERSTAND: What exactly am I being asked to do in this phase?
2. PLAN: What information do I need and where do I find it?
3. EXECUTE: Carry out the investigation step by step.
4. VERIFY: Does my output make logical sense? Contradictions?
5. CHALLENGE: What could be wrong with my conclusion? What am I assuming?
6. PRESENT: Clearly separate FACTS from INFERENCES from HYPOTHESES.
```
