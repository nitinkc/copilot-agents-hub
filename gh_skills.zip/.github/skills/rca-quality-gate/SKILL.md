---
name: rca-quality-gate
description: >
  Adversarial critique and quality gate for RCA findings. Combines three
  parallel critics (Devil's Advocate, Evidence Sufficiency, Framework
  Completeness) with a meta-reviewer that computes composite confidence
  and makes accept/revise/reject decisions. Enforces Socratic checkpoints
  between investigation phases and adaptive investigation depth (Tier 1/2/3).
---

# Skill: RCA Quality Gate

## Goal

Adversarially critique an RCA through three independent reviewers plus a
meta-reviewer, enforce Socratic quality gates between phases, and determine
whether findings meet the evidence bar for the investigation tier.

## When to Use

- After `rca-synthesis` produces a root cause analysis (Phase 4b in the workflow)
- When the investigation tier is **Tier 2** (single evidence audit pass) or
  **Tier 3** (full adversarial critique with revision cycles)
- When validating that an RCA is ready for stakeholder presentation
- To apply Socratic quality gates between investigation phases

**Not needed for Tier 1** — quick triage skips adversarial critique.

## Step 0 — Load Dependencies

```
read_file .github/skills/rca-quality-gate/ADAPTIVE-DEPTH.md
read_file .github/skills/rca-quality-gate/SOCRATIC-CHECKPOINTS.md
read_file .github/skills/rca-synthesis/COGNITIVE-BIASES.md
read_file .github/skills/rca-synthesis/ACH-MATRIX.md
```

## Input

This skill expects the complete output from `rca-synthesis`:
- Five Whys chain with evidence references
- Ishikawa assessment
- Fault Tree with minimal cut sets
- FMEA scores (S × O × D → RPN)
- Event Timeline
- Cynefin classification
- Swiss Cheese layer analysis
- ACH matrix result (if Tier 2+)
- Abductive verification result (if Tier 3)
- All collected evidence from elk-log-search, service-traversal, code-forensics

## Workflow

### Step 1: Determine Critique Depth

Based on investigation tier (set during Phase 0):

| Tier | Critique Depth |
|------|---------------|
| **Tier 1** | Skip — no critique needed |
| **Tier 2** | Step 3 only (Evidence Audit, single pass) |
| **Tier 3** | Steps 2-5 (full adversarial critique, up to 3 revision cycles) |

### Step 2: Devil's Advocate Critique (Tier 3 only)

**Purpose**: Attack the proposed root cause. Construct the strongest possible
case for alternative explanations. This is adversarial by design.

#### 2a. Assumption Extraction

For each Why in the Five Whys chain:
- What is assumed but not directly evidenced?
- What causal link is asserted without proof?
- What alternative explanations exist for the same evidence?

Rate each assumption: LOW / MEDIUM / HIGH criticality.

#### 2b. Alternative Hypothesis Construction

For each HIGH criticality assumption, construct a plausible alternative:

```yaml
alternative_hypotheses:
  - id: "ALT-1"
    assumption_challenged: string
    alternative: string
    supporting_evidence:
      - "Evidence item from ELK logs"
      - "Evidence item from code investigation"
    evidence_strength: "WEAK" | "MODERATE" | "STRONG"
```

#### 2c. Evidence Contradiction Search

For each piece of evidence cited in the RCA:
1. Could this evidence be explained differently? (Alternative interpretation)
2. Is there counter-evidence we're ignoring? (Omission check)
3. Is the temporal ordering actually causal? (Correlation ≠ causation)
4. Is there a confounding variable? (Third factor causing both)

#### 2d. Strongest Counter-Case

Construct the single strongest alternative explanation:

```yaml
strongest_counter_case:
  alternative_root_cause: string
  argument: string
  evidence_for: Evidence[]
  evidence_against: Evidence[]   # Be honest about weaknesses
  confidence: float
  what_would_confirm_this: string  # What additional evidence would prove this
```

#### 2e. Cognitive Bias Challenges

Apply debiasing probes from `COGNITIVE-BIASES.md`:

- **Anchoring**: Was the first error log given disproportionate weight?
- **Confirmation**: Did we only search for supporting evidence?
- **Availability**: Is this favored because a similar incident happened recently?
- **Narrative**: Is the Five Whys story TOO clean?
- **Hindsight**: Knowing the outcome, does it seem "obvious"?

#### 2f. Falsification Criteria

Define what would falsify the proposed root cause:

```yaml
falsification_criteria:
  - criterion: "If X is the root cause, then Y should also be true"
    testable: boolean
    test_method: "ELK query / code check / config check"
```

**Output**: Challenge strength — WEAK / MODERATE / STRONG / DEVASTATING.

### Step 3: Evidence Sufficiency Audit (Tier 2+)

**Purpose**: Verify every claim traces back to concrete evidence. Grade the
evidence chain and identify gaps.

#### 3a. Evidence Chain Audit

For each claim in the RCA, trace to evidence:

```yaml
evidence_chain_audit:
  - claim: string
    evidence_type: "DIRECT" | "INFERENCE" | "HYPOTHESIS"
    evidence_ref: "ELK log reference / code file:line / config key"
    grade: "A" | "B" | "C" | "D" | "F"
    # A = Direct observation in ELK logs
    # B = Strong inference (timing + correlation)
    # C = Weak inference (timing only)
    # D = Hypothesis (logical but no evidence)
    # F = No evidence at all
    gap: string?  # What's missing
```

#### 3b. Missing Evidence Checklist

Systematically check for evidence that SHOULD have been collected:

| Category | Question | Status |
|---|---|---|
| Metrics | CPU/memory/thread-pool metrics checked? | COLLECTED / NOT_COLLECTED / NOT_AVAILABLE |
| Configuration | Timeout/retry/circuit-breaker configs verified? | ... |
| Deployment | Recent deployments to ALL affected services checked? | ... |
| Historical | Error frequency for last 7/30 days? | ... |
| Concurrent | Other incidents/deployments in same time window? | ... |
| Negative | Services that DIDN'T fail — why were they resilient? | ... |

#### 3c. Causal Link Strength

For each link in the Five Whys chain:

```yaml
causal_link_grades:
  - link: "Why 1 → Why 2"
    type: "NECESSARY_AND_SUFFICIENT" | "NECESSARY_NOT_SUFFICIENT" |
          "CONTRIBUTING" | "CORRELATIONAL" | "SPECULATIVE"
    strength: float  # 0.0-1.0
    what_would_strengthen: string
```

#### 3d. Confidence Calibration

```yaml
confidence_calibration:
  total_claims: int
  grade_A_claims: int    # Direct evidence
  grade_B_claims: int    # Strong inference
  grade_C_claims: int    # Weak inference
  grade_D_claims: int    # Hypothesis only
  grade_F_claims: int    # No evidence
  evidence_coverage: float      # (A+B) / total_claims
  critical_gaps: int            # D or F claims on the critical path
  composite_confidence: float   # Weighted score
```

**Confidence thresholds:**
- ≥ 0.85: **HIGH** — Sufficient evidence for action.
- 0.70-0.84: **MODERATE** — Actionable but flag uncertainties.
- 0.50-0.69: **LOW** — Needs additional investigation.
- < 0.50: **INSUFFICIENT** — Reject RCA, return to investigation.

### Step 4: Framework Completeness Audit (Tier 3 only)

**Purpose**: Verify every framework was properly applied, no steps skipped,
and cross-validation is consistent.

#### 4a. Per-Framework Audit

For each of the 7 frameworks, verify:

| Framework | Audit Checks |
|---|---|
| Five Whys | Min 3 levels? Evidence at every level? Forks explored? Stopped at actionable cause? |
| Ishikawa | All 6 dimensions assessed? Each backed by evidence? Primary justified? |
| Fault Tree | Top event matches symptom? All branches developed? Gate logic correct? Cut sets identified? |
| FMEA | All 3 scores justified? Calibrated per FMEA-SCORING.md? RPN math correct? |
| Swiss Cheese | All 12 layers assessed? Each has evidence? Breaches have recommendations? |
| Cynefin | Domain classified? Justified? Approach matches domain? |
| Event Timeline | Timestamps precise? Inception point identified? Propagation speed calculated? |

#### 4b. Cross-Framework Consistency

```yaml
cross_validation:
  five_whys_vs_fault_tree: "Root cause matches minimal cut set?"
  ishikawa_vs_cynefin: "Primary factor aligns with domain classification?"
  swiss_cheese_vs_five_whys: "Breached layers explain why root cause wasn't caught?"
  fmea_vs_blast_radius: "FMEA severity matches actual blast radius?"
  ach_vs_five_whys: "ACH winner matches Five Whys root cause?"
  overall: "CONSISTENT" | "MINOR_INCONSISTENCIES" | "MAJOR_CONTRADICTIONS"
```

#### 4c. Reasoning Quality

```yaml
reasoning_quality:
  circular_reasoning_detected: boolean
  tautology_detected: boolean
  scope_creep_detected: boolean
  appropriate_abstraction: boolean
  actionability_verified: boolean
```

### Step 5: Meta-Review & Decision (Tier 3, advisory for Tier 2)

**Purpose**: Aggregate all critique results and make the accept/revise/reject decision.

#### 5a. Composite Confidence

```
composite_confidence =
  (0.45 × evidence_confidence) +     # Evidence quality most important
  (0.35 × adversarial_survival) +    # Surviving challenge is next
  (0.20 × framework_completeness)    # Completeness is supporting

Where:
  evidence_confidence = from Step 3d
  adversarial_survival = 1.0 if WEAK, 0.7 if MODERATE, 0.4 if STRONG, 0.1 if DEVASTATING
  framework_completeness = (complete_frameworks / total_frameworks)
```

#### 5b. Decision Logic

```
IF composite_confidence >= 0.80:
  IF no CRITICAL convergent issues:
    DECISION = ACCEPT
  ELSE:
    DECISION = REVISE (address only critical issues)

ELSE IF composite_confidence >= 0.60:
  IF revision_cycle < 3:
    DECISION = REVISE
    revision_targets = convergent issues + critical divergent issues
  ELSE:
    DECISION = ACCEPT_WITH_CAVEATS
    caveats = all unresolved issues

ELSE:  # confidence < 0.60
  IF revision_cycle < 3:
    DECISION = REVISE (deep)
    revision_targets = ALL issues
  ELSE:
    DECISION = REJECT
    reason = "Insufficient confidence after 3 revision cycles"
```

**Maximum 3 revision cycles.** Convergent issues (flagged by 2+ critics) take
priority over divergent issues (single critic).

#### 5c. Revision Guidance (if REVISE)

```yaml
revision_guidance:
  phases_to_revisit: ["Phase 1: Log Retrieval", "Phase 4: Synthesis"]
  specific_actions:
    - action: "Query ELK for historical frequency at same time window"
      reason: "Evidence critic flagged missing recurrence data"
      expected_impact: "Confirms or refutes recurrence pattern"
    - action: "Re-evaluate Why 3 with alternative hypothesis from ACH"
      reason: "Devil's advocate provided moderately strong alternative"
```

#### 5d. Convergence Detection

Compare with previous review cycles:
- If no new issues found and persistent issues unchanged → converged
- If converged for 2 consecutive cycles → stop regardless of confidence

## Output Contract

```yaml
rca_quality_gate_result:
  decision: "ACCEPT" | "ACCEPT_WITH_CAVEATS" | "REVISE" | "REJECT"
  composite_confidence: float
  confidence_level: "HIGH" | "MODERATE" | "LOW" | "INSUFFICIENT"

  # Critique summary
  evidence_grade: "A" | "B" | "C" | "D" | "F"
  devil_advocate_challenge: "WEAK" | "MODERATE" | "STRONG" | "DEVASTATING"
  framework_completeness: "COMPLETE" | "MINOR_GAPS" | "SIGNIFICANT_GAPS"
  total_issues: int
  critical_issues: int
  convergent_issues: Issue[]     # Flagged by 2+ critics

  # If ACCEPT / ACCEPT_WITH_CAVEATS
  accepted_root_cause: string?
  caveats: string[]?
  human_review_required: boolean  # Always true for P1/P2

  # If REVISE
  revision_guidance: RevisionGuidance?
  revision_cycle: int

  # If REJECT
  rejection_reason: string?
  partial_findings: string?

  # Audit trail
  critic_summaries:
    devils_advocate: string
    evidence: string
    framework: string
  decision_rationale: string

  # Anti-automation-bias (always included)
  key_assumptions: string[]
  evidence_gaps: string[]
  alternative_hypotheses: string[]
  suggested_verification_steps: string[]
```

## Investigation Depth Gate (MANDATORY — all tiers)

Before proceeding past Phase 5b, answer these three questions. If any answer is NO,
loop back to the specified phase before proceeding to recommendations.

1. **"Did I trace the exception to the ACTUAL null dereference / assertion /
   state error — even if it's inside framework code?"**
   If NO → loop to Phase 4 (Code Investigation). "It's inside the framework" is
   NOT an acceptable stopping point — read the framework source at the deployed version.

2. **"Are my recommendations fixing the ROOT CAUSE or just catching the symptom?"**
   If all recommendations are try-catch/null-check → loop to Phase 4 to find WHY
   the null/exception occurs. Adding a guard is SYMPTOM_MITIGATION, not ROOT_CAUSE_FIX.

3. **"Did I check whether this is a known bug in the deployed framework version?"**
   If NO and the exception originates in framework code → loop to Phase 4 Step 10
   (framework version check: search release notes, JIRA, CVE databases).

## Related Skills

| Skill | Relationship |
|---|---|
| `rca-synthesis` | Upstream — produces the RCA this skill critiques |
| `rca-recommendations` | Downstream — receives the ACCEPTED RCA |
| `elk-log-search` | Used during revision cycles to gather additional evidence |
| `error-taxonomy` | Referenced for error classification validation |
