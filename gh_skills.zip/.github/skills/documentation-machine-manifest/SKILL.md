---
name: documentation-machine-manifest
description: Generate or update machine-readable service documentation for automation, LLM impact analysis, and knowledge graph ingestion. Includes endpoint catalog, dependencies, invariants, impact tags, change-impact mapping, and Mermaid dependency graph.
---
# Documentation Machine Manifest

## Use this when
- APIs, dependencies, rules, or ownership changed
- building or refreshing docs for automation/LLM consumption
- preparing dependency maps or org-wide knowledge graph inputs

## Files to generate/update
- `docs/generated/machine/service-manifest.yaml`
- `docs/generated/machine/dependency-graph.mmd`
- `docs/generated/machine/change-impact-map.yaml`
- `docs/generated/machine/rule-inventory.yaml`
- `docs/generated/machine/entity-catalog.yaml`
- `docs/generated/machine/api-contract-catalog.yaml`

## Manifest content (recommended schema)
- service:
  - name
  - purpose
  - owners/team
  - bounded-context/domain
  - environments/criticality tier
  - contract-specs: <list of machine-readable contract specs with type and path (OpenAPI, WSDL, .proto, AsyncAPI, BPMN XML)>
- capabilities:
  - id (stable, e.g., CAP-ORDER-CREATE)
  - name
  - business summary
  - business value
  - business rule IDs (references to rule inventory)
  - impact keywords/tags
- apis:
  - endpoint id
  - method
  - path
  - capability id(s)
  - request/response summary
  - key validations/bounds
  - error codes
  - idempotency rule
  - downstream systems touched
  - datastore tables/entities touched (high level)
- dependencies:
  - backend name
  - type (HTTP/DB/queue/etc)
  - purpose
  - timeout/retry expectations
  - criticality / fallback notes
- invariants:
  - compatibility rules
  - dedupe/idempotency rules
  - safety/bounds rules
- impact-tags:
  - requirement phrases/keywords that likely indicate repo impact
- change-impact map:
  - requirement phrase -> impacted capabilities/apis/components/dependencies/docs/tests

## Rule inventory (machine-readable)
File: `docs/generated/machine/rule-inventory.yaml`
Schema per rule:
- ruleId: stable identifier (e.g., RULE-IDEMPOTENCY-001)
- ruleName: human-readable name
- ruleType: business | validation | compatibility | security | operational
- description: what the rule enforces
- appliesToCapability: capability ID(s)
- triggerCondition: when the rule activates
- expectedBehavior: correct outcome
- failureBehavior: what happens on violation
- relatedApis: endpoint(s)
- relatedCodeAreas: packages/classes
- relatedTests: test classes/methods
- notes: edge cases or exceptions

## Entity catalog (machine-readable)
File: `docs/generated/machine/entity-catalog.yaml`
Schema per entity:
- entity: domain object name
- purpose: why it exists
- attributes:
  - name: attribute name
  - type: data type
  - whyItMatters: role in business logic, routing, or compatibility
  - usedInRules: rule ID(s)
  - compatibilitySensitivity: High | Medium | Low
- stateTransitions: valid state changes (if applicable)
- dataClassification: public | internal | confidential | restricted
- relatedCapabilities: capability ID(s)
- relatedApis: endpoint(s)
- relatedPersistence: table(s), store(s), queue(s)
- relatedDependencies: downstream systems

## Contract spec reference
When a machine-readable contract spec exists for an API (OpenAPI, WSDL, .proto, AsyncAPI, BPMN XML), it is the authoritative source of truth for that interface's contract.
- Include spec type and path in the service manifest under `contract-specs`.
- API details in the manifest and API contract catalog should be consistent with the spec.
- If documentation and the spec diverge, the spec is authoritative for contract details (schemas, methods, endpoints, validation).
- When no spec exists, document the API fully in the machine API contract catalog (`docs/generated/machine/api-contract-catalog.yaml`).

## API contract catalog (machine-readable)
File: `docs/generated/machine/api-contract-catalog.yaml`
Schema per API contract entry:
- contractId: stable identifier (e.g., API-ORDER-CREATE)
- apiName: human-readable name
- protocol: REST | SOAP | gRPC | JMS | Kafka | AMQP | BPMN | internal
- contractSpecType: OpenAPI | WSDL | proto | AsyncAPI | BPMN-XML | none
- contractSpecPath: path to the spec file (or null if none)
- endpoint: method + path / operation / topic / service-task-id
- capabilityIds: capability ID(s)
- direction: inbound | outbound
- requestSummary: key request fields and types
- responseSummary: key response fields and types
- validations: key validation rules and bounds
- errorCodes: error code taxonomy for this API
- idempotencyRule: deduplication strategy (or none)
- downstreamSystems: backends touched
- datastoreTargets: tables/queues/stores touched
- ownership: team/owner
- compatibilitySensitivity: High | Medium | Low
- notes: additional context

This catalog provides a single place to find any API the service exposes or consumes, regardless of protocol. It complements protocol-specific specs (OpenAPI, WSDL, etc.) by providing a normalized view across all integration points.

## Mermaid dependency graph
Generate a readable graph showing:
- this service
- inbound actors/upstreams
- endpoints or capability groups
- downstream dependencies and datastores
Keep labels stable and concise.

## Quality rules
- Prefer high-signal structured fields over large free-text blobs.
- Use stable IDs for capabilities/endpoints/dependencies/rules/entities when possible.
- Keep it useful for both humans and automation.
- Every capability should reference its business rule IDs.
- Every rule should reference at least one capability and at least one test.
- Every entity with logic-bearing attributes should reference the rules that use those attributes.
- When a machine-readable contract spec exists (OpenAPI, WSDL, .proto, AsyncAPI), ensure manifest API entries are consistent with it.
- Every API endpoint should appear in the API contract catalog with protocol and contract spec reference.
