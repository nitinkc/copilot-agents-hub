---
name: blast-radius
description: >
  Determine the full impact scope of a production error: which services,
  datacenters, channels, customers, and business processes are affected.
  Maps technical failures to business impact.
---

# Skill: Blast Radius Assessment

## Goal

Determine the full impact scope of a production error — services, datacenters,
channels, customers, and business processes affected — and map technical
failure to quantified business impact.

## Inputs

| Input | Source | Required |
|---|---|---|
| Error anchor (service + error, GlobalTrackingId, or error pattern) | Prior skill or user | Yes |
| Time window | User or derived from error timestamps | Yes |
| Error classification | `error-taxonomy` skill | No |

## When to Use

- Assess the full impact of a production error
- Determine how many services, DCs, and channels are affected
- Map technical failure to business/customer impact
- Scope an incident before committing to full RCA
- Answer: "how bad is this?"

## Step 0 — Load Dependencies

```
read_file .github/skills/elk-log-search/SKILL.md
read_file .github/skills/elk-log-search/FIELD-REFERENCE.md
read_file .github/skills/error-taxonomy/SKILL.md
```

## Workflow

### Step 1: Establish the Error Anchor

Start from one of:
- A specific service + error
- A GlobalTrackingId
- An error pattern (exception class, error message)
- A time window with spike

### Step 2: Service Spread Analysis

**Query 1 — Which services have correlated errors?**

If you have a GlobalTrackingId:
```bash
ELK=".github/skills/elk-log-search/scripts/elk-query.sh"
$ELK trace <GlobalTrackingId>
```

If you have a service + error pattern:
```bash
# Get all services with ERROR in the time window
ELK=".github/skills/elk-log-search/scripts/elk-query.sh"
$ELK raw --body '{"size":0,"query":{"bool":{"filter":[{"range":{"@timestamp":{"gte":"now-1h"}}},{"term":{"level.keyword":"ERROR"}}]}},"aggs":{"by_service":{"terms":{"field":"serviceName.keyword","size":50,"order":{"_count":"desc"}},"aggs":{"by_dc":{"terms":{"field":"datacenter.keyword"}},"by_channel":{"terms":{"field":"SalesChannel.keyword"}},"sample_error":{"top_hits":{"size":1,"_source":["LogEventMessage","statusCode","configLabel"]}}}}}}'
```

### Step 3: Datacenter Distribution

```json
{
  "size": 0,
  "query": { "bool": { "filter": [
    {"range": {"@timestamp": {"gte": "now-1h"}}},
    {"term": {"level.keyword": "ERROR"}},
    {"wildcard": {"serviceName.keyword": "*<service-slug>*"}}
  ]}},
  "aggs": {
    "by_dc": {
      "terms": {"field": "datacenter.keyword"},
      "aggs": {
        "error_count": {"value_count": {"field": "@timestamp"}}
      }
    }
  }
}
```

**Interpret**:
- All DCs affected equally → systemic issue (code bug, config)
- One DC only → infrastructure, deployment, or DC-specific issue
- Pattern matches DC deployment order → rolling deployment issue

### Step 4: Channel Distribution

```json
{
  "size": 0,
  "query": { "bool": { "filter": [
    {"range": {"@timestamp": {"gte": "now-1h"}}},
    {"term": {"level.keyword": "ERROR"}},
    {"wildcard": {"serviceName.keyword": "*<service-slug>*"}}
  ]}},
  "aggs": {
    "by_channel": {"terms": {"field": "SalesChannel.keyword"}},
    "by_tenant": {"terms": {"field": "TenantId.keyword"}}
  }
}
```

### Step 5: Customer-Facing Assessment

A service is customer-facing if it's in the critical path:
- Gateway services (`*customer-gateway*`, `*gateway*`)
- Order-creation services (`*order*`, `*cart*`, `*checkout*`)
- Account services (`*account*`, `*subscriber*`)
- Payment services (`*payment*`, `*billing*`)
- Provisioning services (`*provisioning*`)

Check if error status codes propagate to API_RESPONSE:
```json
{
  "size": 0,
  "query": { "bool": { "filter": [
    {"range": {"@timestamp": {"gte": "now-1h"}}},
    {"term": {"logType.keyword": "API_RESPONSE"}},
    {"terms": {"status.keyword": ["500","502","503","504"]}},
    {"wildcard": {"serviceName.keyword": "*<service-slug>*"}}
  ]}},
  "aggs": {
    "by_status": {"terms": {"field": "status.keyword"}}
  }
}
```

### Step 5b: Order Type & Process Definition Analysis (workflow services)

For workflow services (`wkfl-*`), order type and process definition are critical
blast-radius dimensions. These are NOT top-level ELK fields — they live inside
the `message` JSON at `context.instanceVariables` and `context.processDefinitionId`.

**Strategy**: Sample 50+ error documents and extract from the JSON `message` field
using a post-processing script. Aggregation on `message.keyword` won't work because
messages are unique.

```bash
# Get 50 error samples and extract order type + process definition
ELK=".github/skills/elk-log-search/scripts/elk-query.sh"
$ELK raw --body '{"size":50,"query":{"bool":{"must":[{"wildcard":{"serviceName.keyword":"*<service-slug>*"}},{"term":{"level.keyword":"ERROR"}},{"range":{"@timestamp":{"gte":"now-2h"}}}]}},"_source":["message","@timestamp","datacenter"]}' 2>/dev/null \
| python3 -c "
import json,sys,collections
data = json.loads(sys.stdin.read())
hits = data.get('rawResponse',{}).get('hits',{}).get('hits',[])
procs = collections.Counter()
order_types = collections.Counter()
actions = collections.Counter()
uris = collections.Counter()
for h in hits:
    try:
        inner = json.loads(h['_source'].get('message','{}'))
        ctx = inner.get('context',{})
        ivars = ctx.get('instanceVariables',{})
        pid = ctx.get('processDefinitionId','')
        if pid: procs[pid.split(':')[0]] += 1
        ot = ivars.get('orderType','')
        if ot: order_types[ot] += 1
        act = ivars.get('action','') or ivars.get('origAction','')
        if act: actions[act] += 1
    except: pass
print('Process Definitions:')
for k,v in procs.most_common(10): print(f'  {k}: {v}')
print()
print('Order Types:')
for k,v in order_types.most_common(10): print(f'  {k}: {v}')
print()
print('Actions:')
for k,v in actions.most_common(10): print(f'  {k}: {v}')
"
```

Also aggregate the API endpoints (URI patterns) from the same service's
API_REQUEST/API_RESPONSE logs at ERROR level to understand which flows are failing:

```json
{
  "size": 0,
  "query": { "bool": { "filter": [
    {"range": {"@timestamp": {"gte": "now-2h"}}},
    {"term": {"level.keyword": "ERROR"}},
    {"wildcard": {"serviceName.keyword": "*<service-slug>*"}},
    {"terms": {"logType.keyword": ["API_REQUEST", "API_RESPONSE"]}}
  ]}},
  "aggs": {
    "by_uri": {"terms": {"field": "uri.keyword", "size": 20}}
  }
}
```

**Output required**: Process definitions (table), Order types (table), Actions
(table), API endpoints affected (table). If the service is NOT a workflow service,
note "N/A — not a workflow service" rather than skipping.

### Step 6: Dependency Chain Assessment

Check if the error is propagating to/from other services:

```json
{
  "size": 20,
  "query": { "bool": { "filter": [
    {"range": {"@timestamp": {"gte": "now-1h"}}},
    {"terms": {"logType.keyword": ["FEIGN_RESPONSE", "DOWNSTREAM_RESPONSE"]}},
    {"terms": {"statusCode.keyword": ["INTERNAL_SERVER_ERROR", "BAD_GATEWAY", "SERVICE_UNAVAILABLE", "GATEWAY_TIMEOUT"]}}
  ], "must": [
    {"match": {"message": "<failing-service-slug>"}}
  ]}},
  "_source": ["@timestamp", "serviceName", "logType", "statusCode", "uri", "message"]
}
```

This shows which services are failing when calling the affected service.

### Step 7: Data Integrity Assessment

If the error is on a write path (POST/PUT/PATCH):
- Were any partial writes completed before the error?
- Are there orphaned records?
- Are process instances stuck?

```json
{
  "size": 10,
  "query": { "bool": { "filter": [
    {"range": {"@timestamp": {"gte": "now-1h"}}},
    {"term": {"level.keyword": "ERROR"}},
    {"wildcard": {"serviceName.keyword": "*<service-slug>*"}},
    {"terms": {"method.keyword": ["POST", "PUT", "PATCH"]}}
  ]}},
  "_source": ["@timestamp", "serviceName", "method", "uri", "statusCode", "LogEventMessage", "GlobalTrackingId"]
}
```

### Step 8: Error Spread Velocity (MANDATORY — BLOCKING)

**This step is NOT optional.** Velocity (rate of change) is often more diagnostic than
volume (total count). A service with 100 errors/hour that has always had 100 errors/hour
is very different from one that jumped from 0 to 100 in 5 minutes.

**Required queries** (execute BOTH):

**Query A — Current velocity (error count per time bucket):**
{
  "size": 0,
  "query": { "bool": { "filter": [
    {"range": {"@timestamp": {"gte": "now-2h"}}},
    {"term": {"level.keyword": "ERROR"}},
    {"wildcard": {"serviceName.keyword": "*<service-slug>*"}}
  ]}},
  "aggs": {
    "error_over_time": {
      "date_histogram": {"field": "@timestamp", "fixed_interval": "5m"},
      "aggs": {
        "by_dc": {"terms": {"field": "datacenter.keyword"}}
      }
    }
  }
}
```

**Interpret**:
- Sudden spike → deployment or external event
- Gradual increase → resource exhaustion, degradation
- Periodic → batch job, cron, time-based trigger

**Query B — Prior window comparison (same duration, shifted back):**
Run the SAME aggregation query with a shifted time range (e.g., `now-4h` to `now-2h`
if the current window is `now-2h`). Compare totals. This distinguishes **new onset**
from **chronic baseline noise**.

**Velocity classification (MANDATORY output):**
| Pattern | Evidence | `error_velocity` | `prior_window_comparison.trend` |
|---------|----------|-----------------|--------------------------------|
| Current >> Prior (>3x) | Spike in histogram | `spike` | `increasing` |
| Current > Prior (1.5-3x) | Gradual rise across buckets | `gradual` | `increasing` |
| Regular peaks in histogram | Repeating pattern | `periodic` | `stable` |
| Current ≈ Prior | Flat histogram | `stable` | `stable` |
| Prior = 0, Current > 0 | No errors in prior window | `spike` | `new_onset` |

**BLOCKING**: If velocity query fails or returns no data, retry with a wider time
range (4h). Do NOT skip velocity and default to "stable" — that masks real spikes.

## Impact Severity Matrix

| Services | Customer-Facing? | Data Risk | Severity |
|----------|-----------------|-----------|----------|
| 1 | No | None | Low |
| 1 | Yes | None | Medium |
| 2–5 | No | None | Medium |
| 2–5 | Yes | None | High |
| Any | Any | Medium+ | High |
| 5+ | Yes | Any | Critical |
| Any | Any | High | Critical |

## Output Contract

```yaml
blast_radius:
  affected_services:
    - service: string             # serviceName slug
      error_type: string          # Error category
      error_count: int
      customer_facing: boolean
  affected_service_count: int
  affected_datacenters: string[]
  dc_specific: boolean            # true if only some DCs affected
  affected_channels: string[]
  affected_tenants: string[]
  # Workflow-specific dimensions (from message JSON extraction)
  process_definitions: string[]   # e.g. ["salesChangeOrderItemV2", "entitlement"]
  order_types: string[]           # e.g. ["SALES", "CHANGE", "CANCEL"]
  actions: string[]               # e.g. ["CANCEL", "ACTIVATE", "SUSPEND"]
  api_endpoints_affected: string[] # URIs from API_REQUEST/API_RESPONSE at ERROR
  customer_facing: boolean
  data_integrity_risk: "NONE" | "LOW" | "MEDIUM" | "HIGH"
  data_integrity_details: string
  error_velocity: "spike" | "gradual" | "periodic" | "stable"
  prior_window_comparison:        # Same query for prior equal-length window
    prior_error_count: int
    trend: "increasing" | "decreasing" | "stable" | "new_onset"
  timeline:
    first_error: ISO8601
    latest_error: ISO8601
    duration_minutes: int
  overall_severity: "Low" | "Medium" | "High" | "Critical"
  configLabel_involved: string[]  # Which builds are involved
  evidence_items:                 # All ELK query results tagged with relevance
    - query_description: string   # Human-readable: what was queried
      relevance: "PRIMARY" | "SECONDARY" | "INDEPENDENT"
      # PRIMARY: directly proves/disproves a hypothesis
      # SECONDARY: corroborates another finding or narrows scope
      # INDEPENDENT: background context (baseline, prior window comparison)
      result_summary: string      # 1-line finding from the query
```

**Evidence tagging rule**: When writing evidence to session memory or overflow files,
tag each entry. Phases 5-6 use relevance tags to weight evidence in hypothesis evaluation.
PRIMARY evidence gets 3x weight in ACH Matrix scoring vs INDEPENDENT baseline data.
