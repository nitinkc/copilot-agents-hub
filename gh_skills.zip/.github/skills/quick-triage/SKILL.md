---
name: quick-triage
description: >
  Rapid severity assessment of a production error without full RCA. Retrieves
  logs, classifies the error, assesses blast radius, and provides severity +
  recommendation — typically under 2 minutes.
---

# Skill: Quick Triage

## Goal

Rapidly assess severity and blast radius of a production error and recommend
an action (INVESTIGATE_NOW, MONITOR, or IGNORE) — target under 2 minutes.

## Inputs

| Input | Source | Required |
|---|---|---|
| Error message, alert text, or log snippet | User or monitoring system | Yes |
| Service name | User or inferred from logs | No |
| Time of occurrence | User or alert timestamp | No |
| Identifiers (GlobalTrackingId, OrderId, account) | User-provided | No |

## When to Use

- Quickly assess if an error is critical
- Triage an incoming incident/alert
- Get a fast read on a production issue
- Determine severity before full investigation
- Assess whether to INVESTIGATE_NOW or MONITOR

## Step 0 — Load Dependencies

```
read_file .github/skills/elk-log-search/SKILL.md
read_file .github/skills/error-taxonomy/SKILL.md
read_file .github/skills/rca-synthesis/FMEA-SCORING.md
```

## Workflow (target: < 2 minutes)

### Step 1: Collect Signal

Gather from the user:
- Error message, alert text, or log snippet
- Service name (if known)
- Time of occurrence (if known)
- Any identifiers: GlobalTrackingId, OrderId, account number

### Step 1b: Check All Systems of Record (MANDATORY before querying ELK)

Before spending queries on ELK, check whether this error has already been
investigated or is a known issue. This prevents duplicate investigations and
provides instant context.

1. **Prior RCA reports**: Search `docs/generated/rca/` for matching service or error pattern:
   ```bash
   grep -rl "<service-slug>\|<error-keyword>" docs/generated/rca/ 2>/dev/null | head -5
   ```

2. **Jira (recent tickets for same service)**: Check if an incident ticket already exists:
   ```bash
   # If jira-wiki-reader skill is available:
   bash .github/skills/jira-wiki-reader/scripts/fetch-jql.sh \
     --jql "project = CMXOTR AND component = <service-slug> AND created >= -30d ORDER BY created DESC" --max 5
   ```

3. **Session memory**: Check `/memories/session/` for any in-progress investigation
   that overlaps with this service or error pattern.

4. **Known issues list**: Check `.github/shared/known-issues.md` if it exists.

**If a prior RCA exists for the same error pattern**: Report it immediately.
The triage result should reference the prior RCA and note whether the fix was
applied (check configLabel version vs. the version in the prior RCA).

### Step 2: Query ELK for Primary Error

```bash
ELK=".github/skills/elk-log-search/scripts/elk-query.sh"

# If service is known:
$ELK errors --service <service-slug> --hours 1 --size 10

# If tracking ID is known:
$ELK trace <GlobalTrackingId>

# If only error text is known:
$ELK search --query "<error_text>" --hours 1 --size 10
```

### Step 3: Classify Error

Using the `error-taxonomy` skill classification rules:
1. Extract the root exception class from the `message` JSON.
2. Map to category (CONNECTION, TIMEOUT, DATA, AUTH, RESOURCE, EXTERNAL, BUSINESS, INFRA).
3. Map to subcategory.
4. Assign initial severity using the severity mapping table.

### Step 4: Assess Blast Radius (quick)

Run two aggregation queries:

```bash
# How many services have this error?
$ELK top-errors --hours 1 --top 20

# Is it DC-specific? Use elk-query.sh with --agg or raw:
$ELK search --service <service-slug> --level ERROR --hours 1 --size 0 --agg datacenter:10
# Or for multi-dimension agg (DC + channel in one query):
$ELK raw --body '{"size":0,"query":{"bool":{"filter":[{"range":{"@timestamp":{"gte":"now-1h"}}},{"term":{"level.keyword":"ERROR"}},{"wildcard":{"serviceName.keyword":"*<service-slug>*"}}]}},"aggs":{"by_dc":{"terms":{"field":"datacenter.keyword"}},"by_channel":{"terms":{"field":"SalesChannel.keyword"}}}}'
```

Quick blast radius checklist:
- [ ] How many services affected? (1 = isolated, >5 = wide impact)
- [ ] Customer-facing? (check if service is a gateway or order-creation path)
- [ ] DC-specific or all DCs?
- [ ] Channel-specific or all channels?

### Step 5: Frequency Check

```bash
# Is this new or recurring?
$ELK errors --service <service-slug> --hours 24 --size 5
$ELK errors --service <service-slug> --hours 168 --size 5
```

Classify:
- **first_occurrence**: No matching errors in last 7 days
- **recurring**: Same error pattern seen regularly
- **spike**: Error rate significantly above normal

### Step 6: Quick FMEA Score

Apply simplified FMEA from `FMEA-SCORING.md`:
- S = severity from error taxonomy + blast radius
- O = from frequency check
- D = how was this detected? (alert=low D, customer report=high D)
- RPN = S × O × D

### Step 7: Recommendation

| RPN | Frequency | Customer-Facing | Recommendation |
|-----|-----------|-----------------|----------------|
| >200 | Any | Any | **INVESTIGATE_NOW** |
| 100-200 | spike | Yes | **INVESTIGATE_NOW** |
| 100-200 | recurring | Yes | **INVESTIGATE_SOON** |
| 100-200 | Any | No | **INVESTIGATE_SOON** |
| 50-100 | spike | Any | **INVESTIGATE_SOON** |
| 50-100 | recurring | No | **MONITOR** |
| <50 | first | No | **MONITOR** |
| <50 | recurring | No | **IGNORE** (if known benign) |

## Output Format

```yaml
triage_result:
  severity: "P1-Critical" | "P2-High" | "P3-Medium" | "P4-Low"
  error_category: string          # From error-taxonomy
  error_subcategory: string
  blast_radius:
    services_affected: int
    customer_facing: boolean
    datacenters: string[]         # Which DCs affected
    channels: string[]            # Which SalesChannels affected
  frequency: "first_occurrence" | "recurring" | "spike"
  fmea_quick:
    severity: int
    occurrence: int
    detection: int
    rpn: int
  recommendation: "INVESTIGATE_NOW" | "INVESTIGATE_SOON" | "MONITOR" | "IGNORE"
  summary: string                 # One-paragraph assessment
  next_skill: string              # Which skill to invoke next
```

**Next skill routing**:
- INVESTIGATE_NOW → `rca-synthesis` (full RCA) or `service-traversal` (if multi-service)
- INVESTIGATE_SOON → `blast-radius` (scope first, then decide)
- MONITOR → no further skill needed, set up alert
- IGNORE → no action
