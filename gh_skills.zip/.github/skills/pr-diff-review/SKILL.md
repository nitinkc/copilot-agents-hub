---
name: pr-diff-review
description: >
  Diff-level code review for mission-critical PRs. Evaluates each changed file across
  7 dimensions — correctness, code quality, safety/security, concurrency/performance,
  data/state management, test quality, and reuse/duplication. Produces categorized
  findings with severity and file-level evidence.
user-invocable: true
disable-model-invocation: true
---
# PR Diff-Level Review

Evaluate every changed file in a PR across 7 mandatory dimensions.
Each finding must have file-level evidence and a severity classification.

### Cross-cutting: Code Generation Discipline and Validation Completeness
The following `copilot-instructions.md` principles apply **across all 7 dimensions** — flag violations wherever found:

**Code generation discipline (non-negotiable H)** — check across ALL dimensions:
- zero new dependencies, boundary symmetry, defensive defaults, test completeness symmetry, error chain integrity, resource acquisition symmetry, singleton safety, API surface stability

**Contracts and defensive checks (non-negotiable C)** — check across ALL dimensions:
- cascade validation, constraint propagation, doc-code invariant consistency

See `copilot-instructions.md` non-negotiables C and H for full definitions.

## Severity Classification
Use the 4-level severity classification (Critical / High / Medium / Low) defined in
`.github/instructions/pr-code-review.instructions.md` under "Risk classification".
That instruction file is the single source of truth for severity definitions.

## Dimension A — Correctness
For each changed file:
- Does the logic implement the stated/inferred intent?
- Are edge cases handled? (null, empty, boundary, overflow, negative, concurrent)
- Are error paths safe and consistent with project error taxonomy?
- Are new branches/conditions covered by tests in this PR?
- What input would make this code produce a wrong result?
- Are return values, futures, and I/O outcomes checked (never ignored)?
- Are all code paths reachable? Flag dead code introduced.

## Dimension B — Code Quality
- Naming clarity and consistency with repo conventions
- Duplication or near-duplication with existing code
- Complexity: cyclomatic, cognitive, nesting depth
- Method/class length relative to project norms
- Dead code or unreachable paths introduced
- Magic numbers/strings without constants or config (`SCREAMING_SNAKE_CASE` expected)
- Boolean parameters that should be enums or named config
- Affirmative conditionals preferred (`isValid` not `!isInvalid`)
- Guard clauses with explicit cases (no catch-all `else`)
- Null-safe utilities (`StringUtils.isBlank()`, `CollectionUtils.isEmpty()`) over direct null checks

## Dimension C — Safety and Security
- Input validation on new/modified endpoints (size, format, nulls, allow-lists)
- Safe error responses (no stack traces, no secret leaks, RFC7807-style envelope)
- Log redaction (no Authorization headers, tokens, PII)
- SQL injection risk (prepared statements only, no string concatenation)
- SSRF risk (URL inputs validated against allowlist)
- Deserialization safety
- New secrets or credentials introduced in code/config
- Backward compatibility: removed/renamed endpoints, fields, error codes
- OWASP Top 10 alignment for any new attack surface
- Expression Language method invocations reviewed and justified

## Dimension D — Concurrency, Performance, and Integration Compliance
Rule sources — load when the changed file matches the pattern:
- `outbound-http-resttemplate.instructions.md` — for client/gateway/adapter files
- `jdbc-oracle.instructions.md` — for repository/DAO files
- `flowable-java-delegates.instructions.md` — for delegate/listener files

General (all files):
- Thread safety of new shared state (no shared mutable state preferred)
- No manual thread creation; parallelism bounded and cancellation-aware
- No unbounded executors/queues
- Resource leaks (unclosed connections, streams, executors)

Outbound HTTP (client/gateway/adapter files):
- Timeouts configured: connect + read + overall deadline (all three required)
- Retries bounded with backoff, idempotency-safe
- Error mapping to typed domain exceptions (not raw HTTP exceptions)
- Structured logging: endpoint, outcome, latency, correlationId
- Trace/correlation ID propagated in outbound headers

Database/Repository (repository/DAO files):
- Prepared statements only (no string concatenation for SQL)
- Result sets bounded (pagination, LIMIT, FETCH FIRST — no unbounded queries)
- N+1 query risk on new associations/joins
- Connection pool sizing impact of new query patterns
- Null handling: nullable columns handled explicitly

BPMN (delegate/listener files):
- No mutable instance fields in singleton delegates
- Process variable access via typed accessors (not raw string maps)
- Service task failures caught by boundary error events

Cache operations:
- Cache invalidation correctness
- TTL explicitly set
- Key deterministic and bounded length

## Dimension E — Data and State Management
- Database migration safety (backward-compatible with old code running simultaneously?)
- Data migration reversibility
- Transaction boundary correctness (especially in Flowable BPMN context)
- Idempotency of side-effecting operations (Idempotency-Key/requestId + dedupe)
- Eventual consistency implications
- PII/sensitive data handling compliance
- Max sizes enforced: payloads, page sizes, batch sizes, headers, uploaded files

## Dimension F — Test Quality (for changed/added tests)
- Tests verify behavior, not implementation details
- Negative and failure cases present
- Assertions are specific and meaningful (not just `assertNotNull`)
- Test names describe the scenario, not the method
- No hardcoded sleeps or flaky patterns (deterministic)
- Test completeness symmetry: every positive assertion has a negative counterpart; every constraint has a violation test
- Mock boundaries are appropriate (not over-mocked)
- Integration test scope matches change scope
- Contract test updates for API changes
- No real external network calls (use stubs/mocks)
- Aligned with existing project test style/utilities

## Dimension G — Reuse and Duplication
For each new class/method introduced in the PR, search the repo for functional equivalents.

### What to search for
1. **Existing utilities** — string/date/collection helpers the PR reimplements
2. **Base classes and interfaces** — abstract controllers, services, mappers the PR should extend
3. **Shared error handling** — existing exception hierarchy and error envelope patterns
4. **Configuration patterns** — existing config property classes and profiles
5. **Test fixtures and builders** — existing test helpers, builders, MockMvc setup patterns
6. **Mapper/transformer patterns** — existing DTO mapping conventions and libraries
7. **Outbound client patterns** — existing RestTemplate/WebClient wrappers and retry configs
8. **Validation patterns** — existing constraint annotations and validator base classes
9. **Resilience patterns** — existing circuit breaker, retry, bulkhead configurations
10. **Observability patterns** — existing metrics, tracing, log correlation setup

### Classification
- **Exact duplicate** — functionally identical code already exists → Critical/High
- **Near duplicate** — similar logic with minor differences → Medium
- **Could extend existing** — base class/interface available but not used → Medium
- **Genuinely new** — no equivalent exists (acknowledge and pass)

### Microservice independence caveat
Some duplication is acceptable to preserve microservice independence and avoid coupling.
If duplication is justified for isolation, acknowledge it explicitly as a finding with `Low` severity
and rationale. If the pattern appears 3+ times across the repo, propose shared extraction.

## Output
- Findings list: one entry per finding with severity, dimension (A–G), file:line, description, evidence
- Dimension coverage summary: which dimensions produced findings, which were clean
- Highest-risk files: ranked by finding count and max severity
- Reuse opportunities: existing code that should be leveraged (from Dimension G)
- Recommended actions: prioritized by severity

## Risk Score Contribution
This skill feeds into `pr-risk-scoring` across multiple dimensions:
- **Correctness risk** (20%) ← Dimension A findings
- **Security risk** (15%) ← Dimension C findings
- **Test confidence gap** (15%) ← Dimension F findings
- **Data/state management risk** (10%) ← Dimension E findings
- **Pattern deviation risk** (5%) ← Dimension G reuse violations

### When invoked as Phase 2 of `pr-code-review` agent
Produce the same analysis but format as the **Top Findings** + **Reuse Opportunities** sections of the Change Fit Report.
Findings feed directly into the Phase 5 risk scoring dimensions listed above.

## Constraints
- Evaluate ALL 7 dimensions for EVERY changed file. Never skip a dimension.
- Every finding must have file:line evidence. Generic findings are prohibited.
- Use the severity classification from `.github/instructions/pr-code-review.instructions.md` under "Risk classification". Do not invent custom severity levels.
- If a dimension produces no findings for a file, move on silently. Do not log "no findings" per-file per-dimension.
- Reuse findings (Dim G) must distinguish "unjustified duplicate" from "acceptable microservice isolation". Default to Medium, not Critical, unless the duplication is exact and in the same repo.
- Maximum 3 findings per dimension per file to prevent finding bloat. Consolidate related issues.
