---
name: tech-debt-analysis
description: Evaluate technical debt and code quality issues that static analysis tools like SonarQube cannot detect, covering Spring Boot anti-patterns, API design, JPA, dependencies, modernization, and concurrency.
---

# Skill: Tech Debt Analysis

## Goal
Identify technical debt and code quality issues beyond what static analysis tools catch. Produce categorized, scored findings with remediation guidance.

## Inputs
- Target codebase (Spring Boot microservice source)
- Repository standards from `.github/instructions/`
- Playbook defaults from `.github/shared/playbook-defaults.yaml`
- Output format rules from `audit-output.instructions.md`
- SonarQube results (if available, to avoid duplicate findings)

## Rule Sources (MANDATORY — load before auditing)

Load these instruction files with `read_file`. They define the rules; this skill defines the AUDIT METHODOLOGY (what to search for, how to score).

| Instruction file | Rules used in |
|-----------------|---------------|
| `copilot-instructions.md` non-negotiables A–H + Java Clean Code | Steps 1, 4, 7, 8, 9 |
| `spring-boot-22-mvc-rest.instructions.md` | Step 1 (controller/MVC rules) |
| `development-process.instructions.md` | Step 4 (dev process compliance) |
| `mission-critical-checklists.instructions.md` | Step 9 (anti-pattern scan) |

The instruction files are the single source of truth for what the rules ARE. This skill defines HOW to check compliance — the search patterns, diagnostic procedures, and scoring criteria.

## Hard Constraints
- Do not duplicate findings that SonarQube already reports (basic code smells, cognitive complexity, duplications, known vulnerability patterns).
- Focus on architectural and design-level debt that requires human judgment.
- Do not redefine rules that exist in instruction files — reference them.

## Steps

### Step 1: Spring Boot Anti-Patterns

**Rule source**: `copilot-instructions.md` non-negotiables C (contracts), D (error handling), H (code generation discipline); `spring-boot-22-mvc-rest.instructions.md` (controller rules).

Search for and evaluate:

**Injection Anti-Patterns** — search patterns:
- `@Autowired` on fields (not constructors) → field injection
- `@Autowired` on setter methods → setter injection
- `@Value` on fields → should use `@ConfigurationProperties`

**Service Layer Anti-Patterns** — search patterns:
- Classes with 10+ public methods or 500+ lines → god services
- Controllers with logic beyond mapping + validation + delegation → fat controllers
- Entities with only getters/setters → anemic domain models
- `@Transactional` on private methods → Spring proxy won't intercept
- Missing `@Transactional(readOnly=true)` on read-only operations

**Configuration Anti-Patterns** — search patterns:
- Hardcoded URLs, ports, credentials, timeouts in Java code
- Magic numbers without named constants
- Secrets in `application.yml` committed to git
- `@ConfigurationProperties` classes missing `@Validated`

**Validation Anti-Patterns** — check compliance with non-negotiables C and H; search patterns:
- `@Valid` missing on nested DTO fields, `Map` value types, `Collection` element types
- `@Min` without `@Max` (or vice versa) on the same field
- Override/child/per-tenant types not mirroring parent constraints
- Default values that violate their own field's declared constraints
- Javadoc stating bounds (e.g., "max 10000") with no matching `@Max` annotation

**Exception Handling Anti-Patterns** — check compliance with non-negotiable D; search patterns:
- `catch (Exception`, `catch (Throwable` → overly broad catches
- Catch blocks with only logging and no re-throw/domain error conversion
- Missing `@ControllerAdvice` for centralized error handling
- Inconsistent error response formats (not using RFC 7807)

### Step 2: API Design Quality

Evaluate REST API design against these standards:

**RESTful Design**:
- Consistent URL naming (plural nouns, lowercase, kebab-case for multi-word)
- Proper HTTP method usage (GET for reads, POST for creates, PUT/PATCH for updates, DELETE)
- Proper HTTP status codes (not returning 200 for everything)
- Missing pagination for list endpoints (search for List<> returns without Pageable)
- Missing sorting/filtering support on collection endpoints
- Standard: REST API Design Rulebook (Mark Masse), Microsoft REST API Guidelines

**API Contract Quality**:
- Missing OpenAPI/Swagger annotations on controller methods
- Missing request validation (@Valid, @NotNull, @Size, etc.)
- Exposing JPA entities directly in API responses (should use DTOs)
- Missing API versioning strategy
- Inconsistent response envelope patterns
- Missing Content-Type and Accept header handling
- Standard: OpenAPI Specification 3.1

**Error Response Consistency**:
- Different error formats from different endpoints
- Missing error codes or machine-readable error identifiers
- Stack traces leaking in error responses
- Standard: RFC 7807 (Problem Details for HTTP APIs)

### Step 3: Database & JPA Anti-Patterns

**Query Performance**:
- N+1 query patterns (entities with eager FETCH or missing @BatchSize)
- Missing @EntityGraph for complex queries with joins
- SELECT * patterns (not using projections for read-only queries)
- Missing database indexes for frequently queried columns
- Large result sets without pagination
- Standard: Vlad Mihalcea's JPA Performance Guidelines

**Schema Management**:
- Missing Flyway/Liquibase migrations (schema changes without versioning)
- Destructive migrations without backward compatibility
- Missing database constraints that are only enforced in Java code
- Orphaned columns/tables from old features
- Standard: Evolutionary Database Design (Martin Fowler)

**Entity Design**:
- Missing @Version for optimistic locking on concurrent-access entities
- Bidirectional relationships without proper cascade and orphanRemoval
- Using @GeneratedValue(strategy=AUTO) instead of explicit SEQUENCE/IDENTITY
- Large entities that should be split (table-per-class vs joined)
- Missing audit columns (createdAt, updatedAt, createdBy)
- Standard: JPA Best Practices (Thorben Janssen)

### Step 4: Java Code Quality & Modernization

**Rule source**: `copilot-instructions.md` Java Clean Code Principles section.

**Clean Code violations** — check compliance with each principle; search patterns:
- Negated conditionals: `!is`, `!has`, `!can` → should use affirmative checks
- Catch-all `else` branches → should use guard clauses with named early returns
- `== null`, `!= null` → should use `StringUtils.isBlank()`, `CollectionUtils.isEmpty()`, `ObjectUtils.isEmpty()`
- String/numeric literals in logic → should be `SCREAMING_SNAKE_CASE` constants
- Logic duplicated in 2+ places → should be extracted to named helper
- Callers re-checking conditions already evaluated in a delegated method → Tell Don't Ask violation

**Java Modernization Opportunities**:
- Classes that should be records (immutable DTOs with only getters)
- Switch statements that should use pattern matching
- Instanceof checks that should use pattern matching
- Classes that could use sealed interfaces
- Traditional for-loops that should be Stream API
- Anonymous classes that should be lambdas

### Step 5: Dependency Management

- Outdated major versions of critical dependencies (Spring Boot, Flowable, etc.)
- Unused dependencies in build file (declared but not imported anywhere)
- Dependency version conflicts or forced resolutions
- Missing BOM (Bill of Materials) for dependency version management
- Dependencies with known CVEs not flagged by OWASP Dependency Check
- Test dependencies leaking into production classpath
- Standard: Gradle/Maven Dependency Management Best Practices

### Step 6: Code Organization & Naming

- Packages not following hexagonal structure (api/application/domain/infrastructure)
- Utility classes that should be broken up or converted to extensions
- Inconsistent naming conventions across the codebase
- God packages with 20+ classes at the same level
- Missing package-info.java documentation
- Standard: Clean Code (Robert C. Martin), Package Principles

### Step 7: Concurrency & Thread Safety

**Rule source**: `copilot-instructions.md` non-negotiable E (concurrency discipline).

**Shared Mutable State** — search patterns:
- Non-thread-safe collections in singletons (`HashMap`, `ArrayList` in `@Service`/`@Component` fields)
- `static` mutable fields without `ConcurrentHashMap` or `AtomicLong`
- Spring singleton beans with mutable instance fields

**Manual Thread & Executor Violations** — check compliance with non-negotiable E; search patterns:
- `new Thread(` → manual thread creation
- `Executors.newCachedThreadPool()` → unbounded thread pool
- `LinkedBlockingQueue` without capacity parameter → unbounded queue

**Async Processing**:
- @Async methods without custom executor configuration (default SimpleAsyncTaskExecutor creates unbounded threads)
- Missing @Async exception handling (AsyncUncaughtExceptionHandler)
- CompletableFuture chains without proper timeout handling
- Missing thread pool sizing configuration for production workloads

**Database Concurrency**:
- Missing optimistic locking (@Version) on entities with concurrent writes
- Lost update scenarios (read-modify-write without locking)
- Missing @Retryable on OptimisticLockException handlers
- Long-running transactions holding database locks
- Standard: Vlad Mihalcea's JPA Concurrency Guide

### Step 8: Bounded Execution & Control Flow

**Rule source**: `copilot-instructions.md` non-negotiables A (simple, analyzable control flow) and B (bounded execution and resources).

**Control Flow Violations** — check compliance with non-negotiable A; search patterns:
- Methods calling themselves → recursion
- Methods with >3 levels of nested `if`/`for`/`try`/`catch` → deep nesting
- `Method.invoke`, `ServiceLoader`, dynamic proxies beyond Spring framework → hidden control flow
- Stream pipelines with >5 chained operations → obscured intent

**Bounded Execution Violations** — check compliance with non-negotiable B; search patterns:
- `while(true)`, `for` without max iterations → unbounded loops
- Retry logic without explicit max count → unbounded retries
- `HashMap`/`ArrayList` growing from external input without `@Size(max=)` → unbounded collections
- `HashMap`-based caches without eviction → unbounded caches (should use Caffeine with `.maximumSize()`)
- Paginated endpoints without max page size → unbounded result sets
- Parallel requests where fan-out count is driven by external input → unbounded fan-out

### Step 9: Resource & Error Integrity

**Rule source**: `copilot-instructions.md` non-negotiables C (contracts), D (error handling), and code generation discipline H (resource acquisition symmetry, error chain integrity).

**Resource Closure Violations** — check compliance with code generation discipline; search patterns:
- `InputStream`, `Connection`, `ResultSet`, `BufferedReader` created outside `try-with-resources`
- `finally` blocks missing close calls for non-AutoCloseable resources
- Lock acquisition without guaranteed release in `finally`

**Error Chain Integrity** — check compliance with non-negotiable D; search patterns:
- `throw new XxxException(msg)` without cause parameter → lost cause chain
- `catch` blocks with only logging and no re-throw/conversion → swallowed exceptions
- Ignored return values from `Future.get()`, `OutputStream.write()`, `File.delete()`
- `catch (Exception e)` when only specific exceptions are expected → overly broad

**Doc-Code Invariant Consistency** — check compliance with non-negotiable C; search patterns:
- Javadoc/comments stating bounds (e.g., "max 10000", "timeout 30s") with no matching runtime constraint
- Configuration metadata descriptions stating limits not enforced in code

**Anti-pattern scan**: Load `mission-critical-checklists.instructions.md` and scan the codebase against each anti-pattern. Report findings using the outcome presentation rules defined in that file.

## Output

Write your findings to `docs/generated/audit/01-TECHNICAL-DEBT.md` immediately upon completing this phase. Do NOT defer writing to a later consolidation phase — the file must be written now to survive context compaction.

The file must follow the finding format defined in `audit-output.instructions.md`. Group findings by sub-category. Include a
summary table at the top:

```markdown
## Summary

| Sub-Category | 🔴 Critical | 🟠 High | 🟡 Medium | 🟢 Low | Total |
|---|---|---|---|---|---|
| Spring Boot Anti-Patterns | {n} | {n} | {n} | {n} | {n} |
| API Design | {n} | {n} | {n} | {n} | {n} |
| Database/JPA | {n} | {n} | {n} | {n} | {n} |
| Modernization | {n} | {n} | {n} | {n} | {n} |
| Dependencies | {n} | {n} | {n} | {n} | {n} |
| Code Organization | {n} | {n} | {n} | {n} | {n} |
| Concurrency & Thread Safety | {n} | {n} | {n} | {n} | {n} |
| Bounded Execution & Control Flow | {n} | {n} | {n} | {n} | {n} |
| Resource & Error Integrity | {n} | {n} | {n} | {n} | {n} |
| **Total** | **{n}** | **{n}** | **{n}** | **{n}** | **{n}** |

**Category Health Score**: {score}/100
```

Use finding IDs prefixed with `TD-` (e.g., TD-001, TD-002).
