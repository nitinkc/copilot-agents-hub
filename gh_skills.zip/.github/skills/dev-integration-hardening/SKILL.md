---
name: dev-integration-hardening
description: Add the required integration and hardening coverage: DB constraints/rollback tests, outbound failure behavior tests, security behavior tests, and guard tests. No performance tests.
user-invocable: true
disable-model-invocation: true
---

# Skill: Integration & Hardening

## Goal
After a slice is green, ensure the change is robust for mission-critical operation by adding integration and hardening tests that cross component boundaries.

## Inputs
- Green test suite from TDD Loop
- Design blueprint (dependency plan, failure modes table)

## Steps

### Step 1: Repository/DB Integration Tests
- Unique constraints for dedupe/idempotency
- Rollback behavior
- Bounded queries/pagination caps

### Step 2: Outbound Client Stub Tests
- Timeout enforcement (delayed stub)
- Retry cap enforcement
- Parsing safety (malformed/partial payloads)
- Safe error mapping

### Step 3: API Integration Behavior
- MockMvc tests for error envelope stability (status + errorCode + correlationId)
- Validation determinism

### Step 4: Security Behavior Tests (if applicable)
- 401/403 behaviors
- SSRF allowlist checks if URL input exists
- Input cap enforcement (payload/page/batch)

### Step 5: Guard Tests (only if needed)
- Layering rules
- Forbidden API usage bans
- Test pairing (new controllers/services/clients must have tests)

## Output
- Hardening checklist with which items were added
- Gaps remaining (if any) and why
