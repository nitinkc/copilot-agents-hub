---
name: ltg-best-practice-context
description: Load repository instruction guidelines and map them to test requirements for mission-critical Spring Boot microservices (boundedness, safe errors, idempotency, compatibility).
---

# Skill: Best Practice Context

## Goal
Load repository standards and convert them into concrete, code-controlled test obligations that generated tests must satisfy.

## Inputs
- `.github/copilot-instructions.md`
- `.github/shared/playbook-defaults.yaml` (`stackDefaults`, `instructionApplyTo`)
- `.github/instructions/*.instructions.md` (especially testing, HTTP, JDBC, error handling)

## Steps

### Step 1: Read and Apply Repo Standards
- Deterministic tests (no sleeps)
- Bounded waits only
- Safe error envelope
- Idempotency rules for side-effecting operations
- Backward compatibility rules (additive-only unless versioned)

### Step 2: Translate Standards into Test Obligations
- **Validation rules** -> tests for 400 + field-level errors
- **Error mapping rules** -> tests asserting stable errorCode and no stack traces
- **Bounds** -> tests at boundary values:
  - Max pageSize
  - Max payload/list sizes
  - Max string lengths
- **Outbound HTTP rules** -> tests for:
  - Timeout enforced
  - Retry cap enforced
  - Parsing safety on malformed payloads
- **JDBC/Oracle rules** -> tests for:
  - Unique constraint dedupe behavior (duplicate-key path)
  - Rollback behavior (transaction boundaries)
  - Bounded queries (pagination/caps)

### Step 3: Keep Everything Code-Controlled
- Only require tests and guard tests that run locally via `mvn test`
- Do not depend on CI-only features

## Output
For each modified file, a best-practice checklist that the generated tests will prove.
