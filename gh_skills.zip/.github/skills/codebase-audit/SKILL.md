---
name: codebase-audit
description: Audit toolkit with templates for executive summaries, finding reports, action items, and health scorecards for Spring Boot microservices with Flowable BPMN.
---

# Skill: Codebase Audit

## Goal
Provide templates, scoring systems, and reference checklists for periodic codebase health audits.

## Inputs
- Phase output files already written to `docs/generated/audit/` by phases 1–5:
  - `01-TECHNICAL-DEBT.md` (from tech-debt-analysis skill)
  - `02-FLOWABLE-BPMN.md` (from flowable-audit skill)
  - `03-ARCHITECTURE.md` (from architecture-review skill)
  - `04-TEST-QUALITY.md` (from test-quality-analysis skill)
  - `05-BUSINESS-PERSPECTIVE.md` (from business-perspective-review skill)
- Standards checklists from standards-evaluation skill
- Output format rules from `audit-output.instructions.md`

## Phase 0 — Pre-Scan Setup

When invoked for Phase 0, this skill provides the project profiling procedure. Phase 0 does NOT produce a numbered audit file — it creates the output directory (`docs/generated/audit/`), identifies the tech stack, maps package structure, and logs the project profile to session memory. Numbered findings files start with Phase 1.

## Consolidation Procedure (Phase 6)

When invoked for Phase 6 (Consolidation), read back the 5 phase files from disk using `read_file`. Do NOT rely on conversation history or session memory for findings — the files on disk are the authoritative source.

## Available Templates

### 1. Executive Summary Template
Use [Executive Summary](templates/executive-summary-template.md) for the
00-EXECUTIVE-SUMMARY.md output file.

### 2. Action Items Template
Use [Action Items](templates/action-items-template.md) for the
07-ACTION-ITEMS.md consolidated backlog output.

### 3. Security Consolidation Template
Use [Security Consolidation](templates/security-consolidation-template.md) for the
06-SECURITY-COMPLIANCE.md output file. Consolidates security-relevant findings from
all phase files, re-indexed with SC- prefix, and maps to OWASP Top 10 checklist.

### 4. Health Score Calculator
Scoring methodology for overall codebase health:

**Category Weights**:
| Category | Weight | Rationale |
|---|---|---|
| Architecture | 25% | Hardest to fix, highest long-term impact |
| Technical Debt | 20% | Daily developer productivity impact |
| Test Quality | 20% | Safety net for all changes |
| Flowable/BPMN | 15% | Process reliability and business continuity |
| Security | 10% | Risk-weighted, critical items have outsized impact |
| Business/Ops | 10% | Customer-facing and operational concerns |

**Severity Deductions** (from starting score of 100):
| Severity | Points Deducted | Rationale |
|---|---|---|
| 🔴 Critical | -15 | Production risk, must fix immediately |
| 🟠 High | -8 | Significant quality issue, next sprint |
| 🟡 Medium | -4 | Plan within next quarter |
| 🟢 Low | -1 | Nice-to-have improvement |

**Health Grades**:
| Score Range | Grade | Interpretation |
|---|---|---|
| 90-100 | A | Excellent — minor improvements only |
| 80-89 | B | Good — some attention needed |
| 70-79 | C | Acceptable — several areas need work |
| 60-69 | D | Below standard — significant investment needed |
| 0-59 | F | Critical — immediate action required |

**Scoring Algorithm**:

1. **Per-category scoring** — For each of the 6 categories:
   - Start with a baseline of **100 points**.
   - For each finding in that category's phase file(s), deduct severity points (Critical −15, High −8, Medium −4, Low −1).
   - Category score = max(0, baseline − total deductions).

2. **Category-to-phase mapping**:
   | Category | Source File(s) |
   |---|---|
   | Architecture | `03-ARCHITECTURE.md` (AR- findings) |
   | Technical Debt | `01-TECHNICAL-DEBT.md` (TD- findings) |
   | Test Quality | `04-TEST-QUALITY.md` (TQ- findings) |
   | Flowable/BPMN | `02-FLOWABLE-BPMN.md` (FL- findings) |
   | Security | `06-SECURITY-COMPLIANCE.md` (SC- findings only) |
   | Business/Ops | `05-BUSINESS-PERSPECTIVE.md` (BP- findings) |

3. **Security scoring — no double-counting**: Security findings originate in phase files 01–05 and are re-indexed with the `SC-` prefix in `06-SECURITY-COMPLIANCE.md`. Deduct each security finding **only once**, against the Security category using the SC- consolidated list. Do NOT also deduct the same finding in its source phase category.

4. **Weighted final score**:
   ```
   Final Score = (Architecture × 0.25) + (TechDebt × 0.20) + (TestQuality × 0.20)
               + (Flowable × 0.15) + (Security × 0.10) + (Business × 0.10)
   ```
   Result: 0–100, rounded to nearest integer.

5. **Worked example**:
   - Architecture: 100 − (1×15 + 2×8) = 69 → weighted: 69 × 0.25 = 17.25
   - Technical Debt: 100 − (0×15 + 1×8 + 3×4) = 80 → weighted: 80 × 0.20 = 16.00
   - Test Quality: 100 − (0×15 + 0×8 + 2×4 + 5×1) = 87 → weighted: 87 × 0.20 = 17.40
   - Flowable: 100 (no findings) → weighted: 100 × 0.15 = 15.00
   - Security: 100 − (1×15 + 1×8) = 77 → weighted: 77 × 0.10 = 7.70
   - Business: 100 − (0×15 + 1×8 + 1×4) = 88 → weighted: 88 × 0.10 = 8.80
   - **Final Score**: 17.25 + 16.00 + 17.40 + 15.00 + 7.70 + 8.80 = **82** (Grade B)

### 5. Industry Standards Quick Reference

For detailed industry standard checklists (OWASP Top 10, 12-Factor App, ISO 25010,
Spring Boot production readiness), use the `standards-evaluation` skill.
