---
name: requirements-intake-clarify
description: Convert raw requirement text into a structured summary with business goal, actors, use cases, assumptions, and targeted clarification questions.
---

# Skill: Requirements Intake & Clarification

## Goal
Turn a raw requirement, ticket, or request into a structured summary with a clear business goal, actors, use cases, assumptions, and targeted clarification questions.

## Inputs
- Raw requirement text (ticket, email, meeting note, feature request, bug report, or support context)
- Any linked requirement snippets or referenced documents

## Hard Constraints
- Do not assume unclear business rules — flag them as open questions.
- Ask only targeted questions that materially reduce risk or unblock design.
- Do not produce more than 10 clarification questions per intake.
- Do not jump into code generation or solution design.
- Label every assumption explicitly so stakeholders can confirm or reject.

## Steps

### Step 1: Restate Business Goal
Restate the request in plain business language — one or two sentences that a non-technical stakeholder would understand.

### Step 2: Identify Core Elements
Identify and document:
- **Business problem**: What pain or opportunity does this address?
- **Desired outcome**: What does success look like?
- **Primary actor(s)**: Who triggers or benefits from this capability?
- **Trigger/event**: What initiates the flow (API call, scheduled event, user action)?
- **Success condition**: What observable result confirms the outcome?

### Step 3: Identify Missing Information
Scan for gaps:
- **Business rules**: Are decision criteria explicit? Are thresholds/limits defined?
- **Edge cases**: What happens at boundaries (empty input, max size, duplicates)?
- **Data/state transitions**: What data is created, read, updated, or deleted? What states exist?
- **Dependencies/ownership**: Who owns the upstream/downstream systems? Are contracts defined?
- **Security/data handling**: Does this involve PII, auth changes, or data classification changes?

### Step 4: Ask Targeted Clarification Questions
Produce a numbered list of clarification questions. Each question must:
- Change acceptance criteria if answered differently
- Reduce business or technical risk
- Unblock design or development
- Clarify ownership, data, compatibility, or failure handling

### Step 5: Label Assumptions
List all assumptions made during intake. Mark each as:
- **SAFE** — low risk if wrong, can be corrected later
- **RISKY** — blocks design or implementation if wrong, needs stakeholder confirmation

## Output
- **Requirement Summary** — plain-language restatement
- **Core Elements** — business goal, actor(s), trigger, success condition
- **Business Dimensions** — capability ID, business value, preliminary business rule IDs, key entities, requirement keywords (from `dimension-extraction.instructions.md`)
- **Use-Case List** — initial list of use cases / scenarios identified
- **Assumptions** — each labeled SAFE or RISKY
- **Clarification Questions** — numbered, max 10, each with rationale
- **Missing Information** — gaps that could not be resolved from the input