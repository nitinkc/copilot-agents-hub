---
name: flowable-audit
description: Audit Flowable BPMN process definitions, service task implementations, variable management, error handling, versioning, timer/event patterns, testing, and Spring Boot integration.
---

# Skill: Flowable Audit

## Goal
Audit BPMN process definitions and their Java implementations for quality, safety, and operational readiness. Produce scored findings with remediation guidance.

## Inputs
- Target codebase (Spring Boot microservice with Flowable BPMN)
- `.bpmn20.xml` files in `src/main/resources/processes/` (and subdirectories)
- JavaDelegate, TaskListener, ExecutionListener implementations
- Flowable configuration classes and properties
- Process test files (`@FlowableTest` or process deployment tests)
- Output format rules from `audit-output.instructions.md`

## Rule Sources (MANDATORY — load before auditing)

Load these instruction files with `read_file`. They define the rules; this skill defines the AUDIT METHODOLOGY (what to search for, how to score).

| Instruction file | Rules used in |
|-----------------|---------------|
| `flowable-standards.instructions.md` | All steps (process structure, naming, error handling, versioning) |
| `flowable-bpmn-modeling.instructions.md` | Steps 1, 3, 4 (process definition quality, events, gateways) |
| `flowable-java-delegates.instructions.md` | Step 2 (delegate implementation patterns) |
| `flowable-bpmn-java-missioncritical.instructions.md` | Steps 1, 2, 5 (mission-critical safety rules) |
| `copilot-instructions.md` non-negotiables A, B, D | Steps 2, 3, 5 (bounded execution, error handling) |

The instruction files are the single source of truth for what the rules ARE. This skill defines HOW to check compliance — the search patterns, diagnostic procedures, and scoring criteria.

## Steps

### Step 1: Process Definition Quality

**Structural Anti-Patterns**:
- **Monolithic processes**: Single process with 20+ tasks → should be decomposed
  into sub-processes or call activities
- **Missing error boundary events**: Service tasks without error handling → process
  hangs on failure instead of recovering
- **Missing timer boundary events**: Long-running tasks without timeouts → process
  can stall indefinitely with no escalation
- **Missing compensation handlers**: Saga-pattern processes without compensation →
  no rollback capability when later steps fail
- **Dead paths**: Sequence flows that can never be reached (unreachable tasks)
- **Missing default flows**: Exclusive gateways without default sequence flow →
  process throws exception if no condition matches
- **Implicit exclusive gateways**: Multiple outgoing flows from a task without
  an explicit gateway → unclear routing semantics
- Standard: BPMN 2.0 Specification, Flowable Best Practices

**Process Naming & Documentation**:
- Process definitions missing `name` attribute (only technical `id`)
- Tasks missing `name` attribute (unnamed boxes in diagrams)
- Missing documentation elements on complex gateways and decision points
- Process IDs not following consistent naming convention
- Missing category/namespace for process organization
- Standard: BPMN Modeling Guidelines (Camunda/Flowable community)

**Gateway Patterns**:
- Parallel gateways without matching join gateways → token accumulation
- Inclusive gateways without proper synchronization
- Complex gateway conditions that should be simplified with DMN tables
- Nested gateway patterns that could be flattened
- Standard: Workflow Patterns (van der Aalst)

### Step 2: Service Task Implementation Quality

**JavaDelegate Anti-Patterns**:
- **Stateful delegates**: Instance fields that store state → NOT thread-safe
  (Flowable may reuse delegate instances across threads)
  ```java
  // 🔴 ANTI-PATTERN: stateful delegate
  public class MyDelegate implements JavaDelegate {
      private String result; // Thread-unsafe!
  }
  ```
- **Fat delegates**: Single delegate doing too much (>50 lines of execute())
  → should delegate to Spring services
- **Direct database access**: Delegates accessing repositories directly
  instead of going through service layer
- **Missing error handling**: Delegates that don't catch and wrap exceptions
  → unclear BpmnError codes
- **Hardcoded BpmnError codes**: Error codes as string literals instead of
  constants or enums
- Standard: Flowable JavaDelegate Best Practices

**Expression Delegates vs JavaDelegates**:
- When to use `delegateExpression` (Spring bean reference) vs `class` (FQCN):
  - Prefer `delegateExpression` → Spring manages lifecycle, enables DI
  - Flag any `flowable:class` usage → no Spring DI, harder to test
- Inline `${expression}` in process definitions for complex logic →
  should be in Java code for testability

**Listener Patterns**:
- ExecutionListeners with side effects that aren't idempotent
- TaskListeners that modify process variables without documentation
- Missing listeners for audit/logging on sensitive process steps
- Standard: Event-Driven Process Patterns

### Step 3: Process Variable Management

**Variable Scope Issues**:
- Variables set at process scope that should be local to a subprocess
- Large objects stored as process variables (serialization overhead)
- Sensitive data (PII, credentials) stored in process variables without
  encryption → visible in Flowable Admin/history tables
- Variable naming inconsistency across process definitions
- Missing variable documentation in process definition

**Serialization Concerns**:
- Complex Java objects as variables (non-serializable or fragile serialization)
- Missing `@JsonIgnoreProperties(ignoreUnknown = true)` on variable DTOs
  → deserialization breaks when class changes
- Large variable payloads that should use references (IDs) instead of full objects
- Standard: Flowable Variable Handling Guide

**Variable Type Safety**:
- Variables cast without null checks or type verification
- String-typed variables that should be strongly typed
- Missing variable validation at process start

### Step 4: Error Handling & Compensation

**Error Boundary Events**:
- Service tasks that can throw exceptions without error boundary events
- Error boundary events that catch generic errors instead of specific BpmnErrors
- Missing escalation events for business-level issues vs technical errors
- Missing signal events for inter-process communication error cases

**Compensation Patterns**:
- Multi-step processes without compensation handlers (saga pattern)
- Compensation activities that don't fully reverse the original action
- Missing compensation for external API calls (no rollback strategy)
- Standard: Saga Pattern (Chris Richardson), Flowable Compensation Guide

**Dead Letter Handling**:
- Failed jobs without alerting/monitoring
- Missing retry configuration on service tasks
- No dead letter queue pattern for permanently failed executions
- Missing async continuation configuration for long-running tasks

### Step 5: Process Versioning & Migration

- Multiple versions of the same process deployed without migration strategy
- Running instances on old versions with no plan to migrate or complete
- Process definition changes that break running instances
- Missing process instance migration tests
- No documentation of version differences and migration paths
- Standard: Flowable Process Instance Migration Guide

### Step 6: Timer & Event Patterns

- Timer events with hardcoded durations instead of configurable values
- Missing timer expressions validation (ISO 8601 format)
- Signal/message events without proper correlation keys → wrong instance receives
- Message catch events without timeout → process hangs indefinitely waiting
- Missing intermediate timer events for SLA tracking
- Standard: ISO 8601 Duration Format, BPMN Timer Event Specification

### Step 7: Process Testing Quality

- Process definitions without ANY test coverage
- Tests that only verify happy path → missing error and boundary event testing
- Tests that don't assert process variable state after completion
- Missing assertions on process history (audit trail verification)
- Tests that deploy all processes instead of only the one under test
- Missing Flowable Test configuration:
  ```java
  // Should have process-specific test deployment
  @Deployment(resources = "processes/specific-process.bpmn20.xml")
  ```
- Tests that don't verify timer and async behaviors
- Standard: Flowable Testing Guide, Test Pyramid for BPMN

### Step 8: Flowable-Spring Boot Integration

**Configuration**:
- Missing or default Flowable database configuration
- Flowable history level not explicitly configured (should be AUDIT or FULL for production)
- Missing async executor configuration for production workloads
- Missing Flowable Admin/REST API security in production profiles
- Flowable auto-deployment enabled in production (should be controlled)

**Spring Integration**:
- Flowable services (@Service) not participating in Spring transaction management
- Missing @Transactional coordination between Flowable and application data
- Spring beans referenced in process definitions not matching actual bean names
- Missing health indicators for Flowable engine status

**Observability**:
- Missing Flowable metrics exposure via Micrometer
- Missing process instance correlation IDs in MDC logging
- No alerting on failed jobs or stuck process instances
- Missing Flowable Admin UI deployment for process monitoring

## Quick Reference Checklists

### Process Definition Checklist

For each .bpmn20.xml file, evaluate:

**Structure**:
- [ ] Process has both `id` and human-readable `name`
- [ ] All tasks have descriptive `name` attributes
- [ ] Total tasks ≤ 15 (recommend subprocesses if more)
- [ ] No dead/unreachable paths
- [ ] All exclusive gateways have default sequence flows
- [ ] All parallel forks have matching joins
- [ ] Complex decisions use DMN tables instead of gateway conditions
- [ ] Documentation elements on non-obvious gateways

**Error Handling**:
- [ ] Every service task has an error boundary event
- [ ] Error events catch specific BpmnErrors (not generic)
- [ ] Long-running tasks have timer boundary events
- [ ] Compensation handlers exist for saga-pattern processes
- [ ] Escalation events for business-level issues

**Variables**:
- [ ] Variables documented at process level
- [ ] No large objects stored directly (use references)
- [ ] No sensitive data (PII/credentials) in variables
- [ ] Variable scoping is as narrow as possible
- [ ] Variable DTOs handle unknown properties gracefully

**Operations**:
- [ ] Async continuation configured for long-running tasks
- [ ] Retry configuration explicit (not relying on defaults)
- [ ] Process history level appropriate (AUDIT for production)
- [ ] Monitoring/alerting for stuck instances
- [ ] Version migration strategy documented

### JavaDelegate Quality Checklist

For each JavaDelegate implementation:
- [ ] Stateless (no instance fields storing mutable state)
- [ ] Uses delegateExpression (Spring managed, not flowable:class)
- [ ] Delegates to Spring services (not fat execute() methods)
- [ ] Exception handling wraps in BpmnError with meaningful codes
- [ ] BpmnError codes are constants/enums, not string literals
- [ ] Unit testable without Flowable engine
- [ ] Proper logging with process instance context (MDC)

### Process Test Completeness Matrix

For each process, tests should cover:
| Path Type | Required | Description |
|---|---|---|
| Happy path | ✅ Required | Start to successful completion |
| All gateway branches | ✅ Required | Each exclusive/inclusive gateway condition |
| Error boundaries | ✅ Required | Service task failures trigger boundary events |
| Timer boundaries | ⚠️ Recommended | Timeout behaviors with clock manipulation |
| Compensation | ⚠️ Recommended | Rollback/compensation flows |
| Async behavior | ⚠️ Recommended | Job executor, async continuations |
| Variable assertions | ✅ Required | Verify variable state at each milestone |
| History assertions | ⚠️ Recommended | Audit trail verification |
| Migration | ⚠️ If versioned | Instance migration between versions |

### Flowable-Spring Boot Configuration Checklist

```yaml
# application.yml — production configuration
flowable:
  database-schema-update: false          # Never auto-update in prod
  async-executor-activate: true          # Enable async for production
  history-level: audit                   # AUDIT or FULL for prod
  process:
    definition-cache-limit: 1000         # Tune based on process count
  idm:
    enabled: false                       # Disable if using external IdP
  rest:
    app:
      authentication-mode: verify-privilege  # Secure REST API

spring:
  datasource:
    hikari:
      maximum-pool-size: 20             # Tune for Flowable workload
      connection-timeout: 30000
```

## Output

Write your findings to `docs/generated/audit/02-FLOWABLE-BPMN.md` immediately upon completing this phase. Do NOT defer writing to a later consolidation phase — the file must be written now to survive context compaction.

The file must follow the finding format defined in `audit-output.instructions.md`.
Use finding IDs prefixed with `FL-` (e.g., FL-001, FL-002).

Include a process inventory table at the top:
```markdown
## Process Inventory

| Process ID | Name | Version | Tasks | Gateways | Boundary Events | Test Coverage |
|---|---|---|---|---|---|---|
| {id} | {name} | {v} | {n} | {n} | {n} | {Yes/Partial/No} |
```

Then the summary table and individual findings grouped by sub-category.
