---
name: dev-test-plan
description: Map each acceptance criterion to the minimal test suite and define thin slices. Includes unit, MockMvc, provider contracts (if used), outbound stub tests, and repository tests. No performance tests.
user-invocable: true
disable-model-invocation: true
---

# Skill: Test Plan

## Goal
For each acceptance criterion, choose the smallest test seam, define required negative/boundary coverage, and define the implementation order (thin slices).

## Inputs
- Acceptance criteria from Requirements Intake
- Design blueprint from Design Blueprint

## Hard Constraints
- Start with the smallest, fastest test that forces correct design.
- Do not over-test internals; assert stable outcomes.
- No performance/load tests.

## Steps

### Step 1: Map ACs to Test Types
- Controller/API behavior AC -> MockMvc tests (+ contract verification if used)
- Business rule AC -> Unit tests (Mockito)
- DB invariant AC -> Repository integration test (embedded DB)
- Outbound dependency AC -> Stub test (WireMock/MockWebServer)

### Step 2: Define Mandatory Scenario Checklist
For each test file (as applicable):
- Happy path
- Validation failure (400) with deterministic structure
- Boundary cases for caps/limits
- Dependency failures (timeouts/5xx/malformed payloads)
- Idempotency/duplicates for side-effecting operations
- Safe error envelope (stable errorCode, no stack traces)

### Step 3: Define Thin-Slice Order
Order: AC1 -> AC2 -> ... (smallest first)

## Output
- Test files to create/update
- Scenario list per test file
- Thin-slice order with rationale

## Developer Gate (MANDATORY)

After producing the output above, present it to the developer with the following explicit action block. Do NOT proceed until the developer responds.

### Present to Developer

Include this action block at the end of the test plan:

```
---
## Developer Action Required

Please review the test plan above (test files, scenario checklists, thin-slice order) and choose one:

1. **Approve** — test plan covers all ACs; proceed to BUILD/TDD (step 4)
2. **Request changes** — specify missing scenarios or adjustments (I will update the plan and re-present)
3. **Approve with notes** — proceed to BUILD but carry your notes as additional test focus areas

Optional:
- Identify any scenarios you want added or removed
- Suggest reordering the thin-slice sequence
- Flag specific edge cases or failure modes to prioritize

> Waiting for your response before continuing.
```

### After Developer Responds

| Developer action | Agent behavior |
|---|---|
| **Approve** | Incorporate any final notes, mark test plan as `completed`, and proceed to BUILD/TDD (step 4). |
| **Request changes** | Update the test plan per feedback, re-present the updated plan, and wait for approval again. |
| **Approve with notes** | Carry the developer's notes as additional test focus areas into BUILD (step 4). Mark plan as `completed` and proceed. |
| **Flag scenarios** | Add flagged scenarios to the plan, re-present if material changes were made, then proceed to BUILD (step 4). |
