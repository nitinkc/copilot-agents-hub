#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────
# tableau-query.sh — Tableau Server query tool (PAT or SSO auth)
#
# Auth: Personal Access Token (primary) or browser SSO cookies (fallback)
# API:  Tableau REST API v3.25
#
# Setup (PAT — recommended):
#   1. Go to Tableau Server > My Account Settings > Personal Access Tokens
#   2. Create a token (name + secret)
#   3. Run: tableau-query.sh set-pat
#   4. Follow the prompt to enter token name and secret
#
# Setup (SSO — fallback):
#   1. Run: tableau-query.sh login
#   2. Browser opens for Comcast SSO authentication
#
# Usage:
#   tableau-query.sh check                    # verify auth
#   tableau-query.sh workbooks                # list all workbooks
#   tableau-query.sh views <workbook-name>    # list views in workbook
#   tableau-query.sh export <view-id>         # export view as CSV
#   tableau-query.sh export-by-name <workbook> <view>  # export by names
#   tableau-query.sh search <term>            # search workbooks
#   tableau-query.sh stuck-orders             # BPM stuck orders summary
#   tableau-query.sh fallout                  # fallout summary
# ─────────────────────────────────────────────────────────────────
set -euo pipefail

readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly TABLEAU_INSTANCE="${TABLEAU_INSTANCE:-ts3.comcast.com}"
readonly TABLEAU_BASE="https://${TABLEAU_INSTANCE}"
readonly TABLEAU_SITE="${TABLEAU_SITE:-xMobility}"
readonly API_VERSION="3.25"
readonly API_BASE="${TABLEAU_BASE}/api/${API_VERSION}"
readonly CONFIG_DIR="$HOME/.ordertech-tableau"
readonly PAT_FILE="${CONFIG_DIR}/pat.json"
readonly SESSION_FILE="${CONFIG_DIR}/session.json"
readonly COOKIE_FILE="${CONFIG_DIR}/tableau.cookie"
readonly TIMEOUT=60
readonly MAX_PAGE_SIZE=100

# ─── Helpers ─────────────────────────────────────────────────────

die()  { echo "[ERROR] $*" >&2; exit 1; }
warn() { echo "[WARN] $*" >&2; }
info() { echo "[INFO] $*" >&2; }

ensure_config_dir() {
  if [[ ! -d "$CONFIG_DIR" ]]; then
    mkdir -p "$CONFIG_DIR"
    chmod 700 "$CONFIG_DIR"
  fi
}

# ─── PAT Management ─────────────────────────────────────────────

save_pat() {
  local name="$1" secret="$2"
  ensure_config_dir
  cat > "$PAT_FILE" <<PATJSON
{"tokenName":"${name}","tokenSecret":"${secret}","site":"${TABLEAU_SITE}"}
PATJSON
  chmod 600 "$PAT_FILE"
  info "PAT saved to $PAT_FILE"
}

load_pat() {
  [[ -f "$PAT_FILE" ]] || return 1
  cat "$PAT_FILE"
}

# ─── Session Management ─────────────────────────────────────────

save_session() {
  local token="$1" site_id="$2" user_id="$3"
  ensure_config_dir
  cat > "$SESSION_FILE" <<SESSJSON
{"token":"${token}","siteId":"${site_id}","userId":"${user_id}","created":"$(date -u +%Y-%m-%dT%H:%M:%SZ)"}
SESSJSON
  chmod 600 "$SESSION_FILE"
}

load_session() {
  [[ -f "$SESSION_FILE" ]] || return 1
  local token
  token="$(cat "$SESSION_FILE" | python3 -c "import json,sys; print(json.load(sys.stdin)['token'])" 2>/dev/null)" || return 1
  [[ -n "$token" ]] || return 1
  echo "$token"
}

load_site_id() {
  [[ -f "$SESSION_FILE" ]] || return 1
  cat "$SESSION_FILE" | python3 -c "import json,sys; print(json.load(sys.stdin)['siteId'])" 2>/dev/null
}

# ─── Authentication ──────────────────────────────────────────────

# Sign in with PAT → returns auth token
signin_pat() {
  local pat_json
  pat_json="$(load_pat)" || die "No PAT configured. Run: $0 set-pat"

  local name secret site
  name="$(echo "$pat_json" | python3 -c "import json,sys; print(json.load(sys.stdin)['tokenName'])")"
  secret="$(echo "$pat_json" | python3 -c "import json,sys; print(json.load(sys.stdin)['tokenSecret'])")"
  site="$(echo "$pat_json" | python3 -c "import json,sys; print(json.load(sys.stdin)['site'])")"

  local response
  response="$(curl -s --max-time "$TIMEOUT" -X POST \
    "${API_BASE}/auth/signin" \
    -H "Content-Type: application/json" \
    -H "Accept: application/json" \
    -d "{
      \"credentials\": {
        \"personalAccessTokenName\": \"${name}\",
        \"personalAccessTokenSecret\": \"${secret}\",
        \"site\": { \"contentUrl\": \"${site}\" }
      }
    }" 2>&1)" || die "Failed to connect to Tableau Server"

  # Check for error
  if echo "$response" | python3 -c "import json,sys; d=json.load(sys.stdin); 'error' in d and sys.exit(0); sys.exit(1)" 2>/dev/null; then
    local detail
    detail="$(echo "$response" | python3 -c "import json,sys; print(json.load(sys.stdin)['error']['detail'])")"
    die "Sign-in failed: $detail"
  fi

  # Extract session info
  local token site_id user_id
  token="$(echo "$response" | python3 -c "import json,sys; print(json.load(sys.stdin)['credentials']['token'])")"
  site_id="$(echo "$response" | python3 -c "import json,sys; print(json.load(sys.stdin)['credentials']['site']['id'])")"
  user_id="$(echo "$response" | python3 -c "import json,sys; print(json.load(sys.stdin)['credentials']['user']['id'])")"

  save_session "$token" "$site_id" "$user_id"
  echo "$token"
}

# Get a valid auth token (reuse existing or sign in fresh)
get_auth_token() {
  # Try existing session first
  local token
  token="$(load_session 2>/dev/null)" || true
  if [[ -n "$token" ]]; then
    # Verify it's still valid with a lightweight call
    local site_id
    site_id="$(load_site_id)"
    local check
    check="$(curl -s --max-time 10 -o /dev/null -w "%{http_code}" \
      -H "X-Tableau-Auth: $token" \
      "${API_BASE}/sites/${site_id}/workbooks?pageSize=1" 2>/dev/null)" || true
    if [[ "$check" == "200" ]]; then
      echo "$token"
      return 0
    fi
    info "Session expired, re-authenticating..."
  fi

  # Sign in fresh
  signin_pat
}

# Authenticated API call
tableau_api() {
  local method="$1" endpoint="$2"
  shift 2
  local token
  token="$(get_auth_token)"
  local site_id
  site_id="$(load_site_id)"

  # Replace {siteId} placeholder in endpoint
  endpoint="${endpoint//\{siteId\}/$site_id}"

  curl -s --max-time "$TIMEOUT" -X "$method" \
    -H "X-Tableau-Auth: $token" \
    -H "Accept: application/json" \
    "$@" \
    "${API_BASE}/${endpoint}" 2>&1
}

# ─── Commands ────────────────────────────────────────────────────

cmd_set_pat() {
  ensure_config_dir
  echo "Enter your Tableau Personal Access Token details."
  echo "  (From: Tableau Server > My Account Settings > Personal Access Tokens)"
  echo ""
  read -rp "Token Name: " pat_name
  read -rsp "Token Secret: " pat_secret
  echo ""
  [[ -n "$pat_name" ]] || die "Token name required"
  [[ -n "$pat_secret" ]] || die "Token secret required"
  save_pat "$pat_name" "$pat_secret"
  # Verify by signing in
  info "Verifying..."
  local token
  token="$(signin_pat)" || die "PAT verification failed"
  info "Authenticated successfully. Token valid."
  # Sign out
  curl -s --max-time 10 -X POST \
    -H "X-Tableau-Auth: $token" \
    "${API_BASE}/auth/signout" >/dev/null 2>&1 || true
}

cmd_login() {
  if [[ -f "${SCRIPT_DIR}/tableau-sso-login.py" ]]; then
    info "Starting SSO login..."
    python3 "${SCRIPT_DIR}/tableau-sso-login.py" "$@"
  else
    die "SSO login script not found. Use: $0 set-pat (for PAT auth)"
  fi
}

cmd_check() {
  # Check PAT file
  if [[ -f "$PAT_FILE" ]]; then
    echo "PAT: configured"
  else
    echo "PAT: not configured"
  fi

  # Check session
  if [[ -f "$SESSION_FILE" ]]; then
    local created
    created="$(cat "$SESSION_FILE" | python3 -c "import json,sys; print(json.load(sys.stdin)['created'])" 2>/dev/null)" || true
    echo "Session: $SESSION_FILE (created: ${created:-unknown})"
  else
    echo "Session: none"
  fi

  # Try auth
  local token
  token="$(get_auth_token 2>/dev/null)" || true
  if [[ -n "$token" ]]; then
    echo "Auth: valid"
    local site_id
    site_id="$(load_site_id)"
    # Get user info
    local user_id
    user_id="$(cat "$SESSION_FILE" | python3 -c "import json,sys; print(json.load(sys.stdin)['userId'])" 2>/dev/null)" || true
    if [[ -n "$user_id" ]]; then
      local user_info
      user_info="$(curl -s --max-time 10 \
        -H "X-Tableau-Auth: $token" \
        -H "Accept: application/json" \
        "${API_BASE}/sites/${site_id}/users/${user_id}" 2>/dev/null)" || true
      local username
      username="$(echo "$user_info" | python3 -c "import json,sys; print(json.load(sys.stdin)['user']['name'])" 2>/dev/null)" || true
      [[ -n "$username" ]] && echo "User: $username"
    fi
    echo "Site: ${TABLEAU_SITE} (${site_id})"
    echo "Server: ${TABLEAU_INSTANCE}"
  else
    echo "Auth: FAILED — run '$0 set-pat' or '$0 login'"
  fi
}

cmd_workbooks() {
  local filter="${1:-}"
  local page=1
  local all_done=false
  local first_page=true

  while [[ "$all_done" == "false" ]]; do
    local endpoint="sites/{siteId}/workbooks?pageSize=${MAX_PAGE_SIZE}&pageNumber=${page}"

    local response
    response="$(tableau_api GET "$endpoint")"

    python3 -c "
import json, sys
data = json.loads(sys.stdin.read())
pag = data.get('pagination', {})
total = int(pag.get('totalAvailable', 0))
wbs = data.get('workbooks', {}).get('workbook', [])
filter_term = '${filter}'.lower()
# Client-side filter (case-insensitive)
if filter_term:
    wbs = [w for w in wbs if filter_term in w['name'].lower()]
if not wbs:
    if ${first_page:+1} == 1 and not filter_term:
        print('[NO WORKBOOKS FOUND]')
    elif ${first_page:+1} == 1 and filter_term:
        pass  # might find matches on later pages
    sys.exit(0)
if ${first_page:+1} == 1:
    if filter_term:
        print(f'Matching: {len(wbs)}+ workbooks (filter: {filter_term})')
    else:
        print(f'Total: {total} workbooks')
    print()
    print(f'{\"ID\":<38} {\"Name\":<50} {\"Project\":<20} {\"Updated\"}')
    print('─' * 130)
for w in wbs:
    wid = w['id']
    name = w['name'][:48]
    project = w.get('project', {}).get('name', '?')[:18]
    updated = w.get('updatedAt', '?')[:10]
    print(f'{wid}  {name:<50} {project:<20} {updated}')
# Signal if more pages
orig_count = len(data.get('workbooks', {}).get('workbook', []))
if orig_count < ${MAX_PAGE_SIZE}:
    print('__DONE__', file=sys.stderr)
" <<< "$response" 2>/tmp/tableau_page_status || true

    first_page=false
    if grep -q '__DONE__' /tmp/tableau_page_status 2>/dev/null; then
      all_done=true
    fi
    page=$((page + 1))
    # Safety: max 10 pages (1000 workbooks)
    if [[ $page -gt 10 ]]; then
      all_done=true
    fi
  done
}

cmd_views() {
  local workbook_name="$1"
  [[ -n "$workbook_name" ]] || die "Usage: $0 views <workbook-name>"

  # Find workbook by name
  local encoded
  encoded="$(python3 -c "import urllib.parse; print(urllib.parse.quote('$workbook_name'))")"
  local response
  response="$(tableau_api GET "sites/{siteId}/workbooks?filter=name:eq:${encoded}")"

  local wb_id
  wb_id="$(echo "$response" | python3 -c "
import json, sys
data = json.loads(sys.stdin.read())
wbs = data.get('workbooks', {}).get('workbook', [])
if not wbs:
    print('NOT_FOUND')
else:
    print(wbs[0]['id'])
")"

  if [[ "$wb_id" == "NOT_FOUND" ]]; then
    # Try fuzzy match
    response="$(tableau_api GET "sites/{siteId}/workbooks?filter=name:has:${encoded}")"
    echo "$response" | python3 -c "
import json, sys
data = json.loads(sys.stdin.read())
wbs = data.get('workbooks', {}).get('workbook', [])
if not wbs:
    print('[NOT FOUND] No workbook matching: $workbook_name')
    sys.exit(1)
print(f'No exact match for \"$workbook_name\". Did you mean:')
for w in wbs:
    print(f'  - {w[\"name\"]}')
" && return 0 || return 1
  fi

  # Get views
  response="$(tableau_api GET "sites/{siteId}/workbooks/${wb_id}/views")"
  echo "$response" | python3 -c "
import json, sys
data = json.loads(sys.stdin.read())
views = data.get('views', {}).get('view', [])
print(f'Workbook: $workbook_name')
print(f'Views: {len(views)}')
print()
print(f'{\"ID\":<38} {\"Name\":<40} {\"Content URL\"}')
print('─' * 110)
for v in views:
    vid = v['id']
    name = v['name'][:38]
    curl = v.get('contentUrl', '?')
    print(f'{vid}  {name:<40} {curl}')
"
}

cmd_export() {
  local view_id="$1"
  local output="${2:-}"
  [[ -n "$view_id" ]] || die "Usage: $0 export <view-id> [output-file]"

  local token
  token="$(get_auth_token)"
  local site_id
  site_id="$(load_site_id)"

  if [[ -n "$output" ]]; then
    curl -s --max-time "$TIMEOUT" \
      -H "X-Tableau-Auth: $token" \
      "${API_BASE}/sites/${site_id}/views/${view_id}/data" \
      -o "$output" 2>&1
    local lines
    lines="$(wc -l < "$output")"
    info "Exported ${lines} rows to ${output}"
  else
    curl -s --max-time "$TIMEOUT" \
      -H "X-Tableau-Auth: $token" \
      "${API_BASE}/sites/${site_id}/views/${view_id}/data" 2>&1
  fi
}

cmd_export_by_name() {
  local workbook_name="$1"
  local view_name="$2"
  local output="${3:-}"
  [[ -n "$workbook_name" ]] || die "Usage: $0 export-by-name <workbook> <view> [output-file]"
  [[ -n "$view_name" ]] || die "Usage: $0 export-by-name <workbook> <view> [output-file]"

  # Find workbook
  local encoded
  encoded="$(python3 -c "import urllib.parse; print(urllib.parse.quote('$workbook_name'))")"
  local response
  response="$(tableau_api GET "sites/{siteId}/workbooks?filter=name:eq:${encoded}")"
  local wb_id
  wb_id="$(echo "$response" | python3 -c "
import json, sys
data = json.loads(sys.stdin.read())
wbs = data.get('workbooks', {}).get('workbook', [])
if not wbs:
    print('')
else:
    print(wbs[0]['id'])
")"
  [[ -n "$wb_id" ]] || die "Workbook not found: $workbook_name"

  # Find view
  response="$(tableau_api GET "sites/{siteId}/workbooks/${wb_id}/views")"
  local view_id
  view_id="$(echo "$response" | python3 -c "
import json, sys
data = json.loads(sys.stdin.read())
views = data.get('views', {}).get('view', [])
target = '$view_name'.lower()
for v in views:
    if v['name'].lower() == target:
        print(v['id'])
        sys.exit(0)
# Fuzzy match
for v in views:
    if target in v['name'].lower():
        print(v['id'])
        sys.exit(0)
print('')
")"
  [[ -n "$view_id" ]] || die "View not found: $view_name (in workbook: $workbook_name)"

  cmd_export "$view_id" "$output"
}

cmd_search() {
  local term="$1"
  [[ -n "$term" ]] || die "Usage: $0 search <term>"
  cmd_workbooks "$term"
}

# ─── Shortcut Commands (domain-specific) ─────────────────────────

cmd_stuck_orders() {
  local output="${1:-}"
  info "Fetching BPM stuck orders data..."

  # View ID for "BPM stuck order overall"
  local view_id="a74d9a33-c4da-44ce-98ec-33e0bee6321f"

  if [[ -n "$output" ]]; then
    cmd_export "$view_id" "$output"
  else
    local tmpfile="/tmp/tableau_stuck_orders_$$.csv"
    cmd_export "$view_id" "$tmpfile"

    python3 -c "
import csv, sys
from collections import Counter, defaultdict

with open('$tmpfile', 'r') as f:
    reader = csv.DictReader(f)
    rows = list(reader)

def parse_int(s):
    try:
        return int(str(s).replace(',', '').strip())
    except (ValueError, TypeError):
        return 0

# Filter: use only 'All' time rows, exclude 'All' app/process/activity summary rows
by_app = Counter()
by_process = Counter()
by_activity = Counter()

for r in rows:
    if r.get('Day of Start_Time', '') != 'All':
        continue
    app = r.get('APP', '?')
    proc = r.get('PROCESS_NAME', '?')
    act = r.get('ACTIVITY_ID', '?')
    count = parse_int(r.get('Number of Records', 0))
    # Skip the Tableau summary 'All' aggregation rows
    if app == 'All' or proc == 'All' or act == 'All':
        continue
    by_app[app] += count
    by_process[proc] += count
    by_activity[act] += count

total_records = sum(by_app.values())

print(f'=== BPM Stuck Orders Overall ===')
print(f'Total stuck: {total_records}')
print()
print(f'--- By Application ---')
for app, count in by_app.most_common(20):
    pct = count / total_records * 100 if total_records else 0
    print(f'  {count:>6}  ({pct:5.1f}%)  {app}')
print()
print(f'--- By Process (top 15) ---')
for proc, count in by_process.most_common(15):
    pct = count / total_records * 100 if total_records else 0
    print(f'  {count:>6}  ({pct:5.1f}%)  {proc}')
print()
print(f'--- By Activity (top 15) ---')
for act, count in by_activity.most_common(15):
    pct = count / total_records * 100 if total_records else 0
    print(f'  {count:>6}  ({pct:5.1f}%)  {act}')
" 2>&1
    rm -f "$tmpfile"
  fi
}

cmd_stuck_detail() {
  local output="${1:-}"
  info "Fetching BPM stuck order details..."

  local view_id="13cb7486-7867-48ee-8576-8593aa99ebc1"

  if [[ -n "$output" ]]; then
    cmd_export "$view_id" "$output"
  else
    local tmpfile="/tmp/tableau_stuck_detail_$$.csv"
    cmd_export "$view_id" "$tmpfile"

    python3 -c "
import csv, sys
from collections import Counter

with open('$tmpfile', 'r') as f:
    reader = csv.DictReader(f)
    rows = list(reader)

print(f'=== BPM Stuck Order Detail ===')
print(f'Total rows: {len(rows)}')
print()

# Group by APP + ACTIVITY_ID with exception summary
by_app_activity = Counter()
exceptions = {}
for r in rows:
    key = (r.get('APP', '?'), r.get('ACTIVITY_ID', '?'))
    by_app_activity[key] += 1
    exc = r.get('EXCEPTION_MSG', '')[:120]
    if exc and key not in exceptions:
        exceptions[key] = exc

print(f'{\"Count\":>6}  {\"App\":<30} {\"Activity\":<45} Exception (truncated)')
print('─' * 140)
for (app, act), count in by_app_activity.most_common(25):
    exc = exceptions.get((app, act), '')[:60]
    print(f'{count:>6}  {app:<30} {act:<45} {exc}')
" 2>&1
    rm -f "$tmpfile"
  fi
}

cmd_fallout_summary() {
  local output="${1:-}"
  info "Fetching fallout summary..."

  local view_id="e7719d54-0d41-49c7-9048-e2d35a354c29"

  if [[ -n "$output" ]]; then
    cmd_export "$view_id" "$output"
  else
    local tmpfile="/tmp/tableau_fallout_$$.csv"
    cmd_export "$view_id" "$tmpfile"

    python3 -c "
import csv, sys
from collections import Counter

with open('$tmpfile', 'r') as f:
    reader = csv.DictReader(f)
    rows = list(reader)

by_app = Counter()
for r in rows:
    app = r.get('APP', '?')
    if app == 'All':
        continue
    by_app[app] += int(str(r.get('No Of Records', 0)).replace(',','').strip() or '0')

total = sum(by_app.values())
print(f'=== Fallout Summary ===')
print(f'Total fallouts: {total}')
print()
for app, count in by_app.most_common():
    pct = count / total * 100 if total else 0
    print(f'  {count:>6}  ({pct:5.1f}%)  {app}')
" 2>&1
    rm -f "$tmpfile"
  fi
}

cmd_fallout() {
  local app_filter="${1:-}"
  local output="${2:-}"
  info "Fetching fallout details (detail + overall views)..."

  # Detail view: per-instance rows with BUSINESS_KEY, EXCEPTION_MSG, etc.
  local detail_view="13cb7486-7867-48ee-8576-8593aa99ebc1"
  # Overall view: has PROCESS_NAME per ACTIVITY_ID+APP
  local overall_view="a74d9a33-c4da-44ce-98ec-33e0bee6321f"

  local detail_csv="/tmp/tableau_fallout_detail_$$.csv"
  local overall_csv="/tmp/tableau_fallout_overall_$$.csv"
  cmd_export "$detail_view" "$detail_csv"
  cmd_export "$overall_view" "$overall_csv"

  if [[ -n "$output" ]]; then
    # Merge and write to output file
    python3 -c "
import csv, sys

process_map = {}
with open('$overall_csv') as f:
    for r in csv.DictReader(f):
        key = (r.get('APP',''), r.get('ACTIVITY_ID',''))
        pn = r.get('PROCESS_NAME','')
        if pn and pn != 'All':
            process_map[key] = pn

app_filter = '${app_filter}'.strip()
with open('$detail_csv') as f:
    rows = list(csv.DictReader(f))
if app_filter:
    rows = [r for r in rows if r.get('APP','').upper() == app_filter.upper()]
rows.sort(key=lambda x: x.get('START_TIME',''))

with open('$output', 'w', newline='') as out:
    w = csv.writer(out)
    w.writerow(['APP','PROCESS_NAME','ACTIVITY_ID','BUSINESS_KEY','PROCESS_INSTANCE_ID','START_TIME','EXCEPTION_MSG'])
    for r in rows:
        app = r.get('APP','')
        act = r.get('ACTIVITY_ID','')
        pn = process_map.get((app, act), '')
        w.writerow([app, pn, act, r.get('BUSINESS_KEY',''), r.get('PROCESS_INSTANCE_ID',''), r.get('START_TIME',''), r.get('EXCEPTION_MSG','')])
print(f'Wrote {len(rows)} rows to $output')
" 2>&1
  else
    python3 -c "
import csv, sys
from collections import Counter

# Build PROCESS_NAME lookup from overall view
process_map = {}
with open('$overall_csv') as f:
    for r in csv.DictReader(f):
        key = (r.get('APP',''), r.get('ACTIVITY_ID',''))
        pn = r.get('PROCESS_NAME','')
        if pn and pn != 'All':
            process_map[key] = pn

# Load detail rows
app_filter = '${app_filter}'.strip()
with open('$detail_csv') as f:
    rows = list(csv.DictReader(f))
if app_filter:
    rows = [r for r in rows if r.get('APP','').upper() == app_filter.upper()]
rows.sort(key=lambda x: x.get('START_TIME',''))

# Summary header
by_app = Counter()
for r in rows:
    by_app[r.get('APP','?')] += 1
total = len(rows)
filter_label = f' (filter: {app_filter})' if app_filter else ''
print(f'=== Fallout Detail{filter_label} ===')
print(f'Total: {total} stuck instances')
if not app_filter:
    print()
    for app, count in by_app.most_common():
        pct = count / total * 100 if total else 0
        print(f'  {count:>5}  ({pct:5.1f}%)  {app}')
print()

# Detail table
hdr = '{:<26} {:<30} {:<22} {:<40} {:<50} {}'.format('START_TIME','APP','PROCESS_NAME','ACTIVITY_ID','BUSINESS_KEY','EXCEPTION_MSG')
print(hdr)
print('\u2500' * 220)
for r in rows:
    app = r.get('APP','')
    act = r.get('ACTIVITY_ID','')
    pn = process_map.get((app, act), '?')
    bk = r.get('BUSINESS_KEY','')[:48]
    ts = r.get('START_TIME','')[:24]
    exc = r.get('EXCEPTION_MSG','')[:100]
    print('{:<26} {:<30} {:<22} {:<40} {:<50} {}'.format(ts, app, pn, act, bk, exc))
" 2>&1
  fi
  rm -f "$detail_csv" "$overall_csv"
}

cmd_signout() {
  local token
  token="$(load_session 2>/dev/null)" || { info "No active session."; return 0; }
  curl -s --max-time 10 -X POST \
    -H "X-Tableau-Auth: $token" \
    "${API_BASE}/auth/signout" >/dev/null 2>&1 || true
  rm -f "$SESSION_FILE"
  info "Signed out."
}

# ─── Usage ───────────────────────────────────────────────────────

usage() {
  cat <<EOF
Usage: $(basename "$0") <command> [args...]

Authentication:
  set-pat                          Configure Personal Access Token
  login                            SSO browser login (fallback)
  check                            Verify authentication status
  signout                          Sign out current session

Discovery:
  workbooks [filter]               List workbooks (optional name filter)
  views <workbook-name>            List views in a workbook
  search <term>                    Search workbooks by name

Data Export:
  export <view-id> [output]        Export view as CSV (stdout or file)
  export-by-name <wb> <view> [out] Export view by workbook+view name

Domain Shortcuts:
  stuck-orders [output]            BPM stuck orders summary
  stuck-detail [output]            BPM stuck orders with exceptions
  fallout [app] [output]           Fallout detail (all attrs, optional app filter)
  fallout-summary [output]         Fallout counts by app

Options:
  TABLEAU_INSTANCE=<host>          Override server (default: ts3.comcast.com)
  TABLEAU_SITE=<site>              Override site (default: xMobility)

Examples:
  $(basename "$0") set-pat
  $(basename "$0") check
  $(basename "$0") workbooks
  $(basename "$0") search "stuck"
  $(basename "$0") views "Bpaas stuck order"
  $(basename "$0") stuck-orders
  $(basename "$0") stuck-orders /tmp/stuck.csv
  $(basename "$0") fallout
  $(basename "$0") fallout BPM_ASCNDN_BILLING_ORDER
  $(basename "$0") fallout BPM_ASCNDN_BILLING_ORDER /tmp/ascndn.csv
  $(basename "$0") export-by-name "Bpaas stuck order" "BPM stuck order overall"
  $(basename "$0") export a74d9a33-c4da-44ce-98ec-33e0bee6321f /tmp/data.csv
EOF
}

# ─── Main ────────────────────────────────────────────────────────

main() {
  local cmd="${1:-help}"
  shift || true

  case "$cmd" in
    set-pat)          cmd_set_pat "$@" ;;
    login)            cmd_login "$@" ;;
    check)            cmd_check "$@" ;;
    signout|logout)   cmd_signout "$@" ;;
    workbooks|wb)     cmd_workbooks "$@" ;;
    views)            cmd_views "$@" ;;
    export)           cmd_export "$@" ;;
    export-by-name)   cmd_export_by_name "$@" ;;
    search)           cmd_search "$@" ;;
    stuck-orders)     cmd_stuck_orders "$@" ;;
    stuck-detail)     cmd_stuck_detail "$@" ;;
    fallout)          cmd_fallout "$@" ;;
    fallout-summary)  cmd_fallout_summary "$@" ;;
    help|--help|-h)   usage ;;
    *)                die "Unknown command: $cmd (try: $0 help)" ;;
  esac
}

main "$@"
