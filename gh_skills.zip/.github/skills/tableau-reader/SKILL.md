---
name: tableau-reader
description: Read-only Tableau Server data retrieval for dashboards, views, and CSV exports. Uses Personal Access Tokens (primary) or browser SSO cookies (fallback). Fetches workbook listings, view data, and domain-specific BPM stuck order and fallout summaries.
---

# Skill: Tableau Reader

## Goal

Retrieve structured dashboard data from Tableau Server so agents can correlate production metrics with incident investigations, quantify stuck order volumes, identify top error patterns by application/process/activity, and track fallout trends — without mutating Tableau state.

## Inputs

- A workbook name or search term: `"Bpaas stuck order"`, `"Collection"`, `"Promo"`
- OR a view ID (UUID) for direct export
- OR a domain shortcut: `stuck-orders`, `stuck-detail`, `fallout`
- OR natural language describing what dashboard data to find (agent selects appropriate command)

## Prerequisites

**Config Directory**: `~/.ordertech-tableau/` (mode 700)
- `pat.json` — Personal Access Token credentials (mode 600)
- `session.json` — Cached auth session token (auto-managed)

**API**: Tableau REST API v3.25 at `https://ts3.comcast.com`
- Site: `xMobility`
- CSV export via `GET /api/3.25/sites/{siteId}/views/{viewId}/data`

### Authentication Setup

**PAT (Primary — recommended)**:

1. **Create the token on Tableau Server**:
   - Open `https://ts3.comcast.com` in a browser and sign in
   - Click your user icon (top-right) → **My Account Settings**
   - Scroll to **Personal Access Tokens**
   - Enter a token name (e.g., `copilot-agent`) and click **Create new token**
   - **Copy the token secret immediately** — it is shown only once

2. **Configure via interactive prompt** (easiest):
   ```bash
   bash .github/skills/tableau-reader/scripts/tableau-query.sh set-pat
   ```
   Prompts for token name and secret, saves to `~/.ordertech-tableau/pat.json`, then verifies by signing in.

3. **Or create the file manually** (for automation / non-interactive):
   ```bash
   mkdir -p ~/.ordertech-tableau && chmod 700 ~/.ordertech-tableau
   cat > ~/.ordertech-tableau/pat.json << 'EOF'
   {"tokenName":"<your-token-name>","tokenSecret":"<your-token-secret>","site":"xMobility"}
   EOF
   chmod 600 ~/.ordertech-tableau/pat.json
   ```
   Replace `<your-token-name>` and `<your-token-secret>` with actual values.

**pat.json format** (single-line JSON, mode 600):
```json
{"tokenName":"copilot-agent","tokenSecret":"abc123...xyz","site":"xMobility"}
```

| Field | Value | Notes |
|---|---|---|
| `tokenName` | Name you gave the token in Tableau | e.g. `copilot-agent` |
| `tokenSecret` | Secret shown at creation time | Shown once — copy immediately |
| `site` | `xMobility` | Must match the Tableau site |

**Token rotation**: PATs expire per server policy. When `tableau-query.sh check` shows `Auth: FAILED`, create a new token on the server and re-run `set-pat`.

**SSO (Fallback)**: Not yet implemented. Will use Playwright-based browser login similar to `snow-sso-login.py`.

### Auth Verification

```bash
bash .github/skills/tableau-reader/scripts/tableau-query.sh check
```

Reports: PAT status, session status, auth validity, user, site, server.
Sessions auto-refresh from PAT when expired — no manual intervention needed.

## Procedure

### Step 1 — Verify Authentication

Before any query, verify Tableau auth is working:

```bash
bash .github/skills/tableau-reader/scripts/tableau-query.sh check
```

Expected: `Auth: valid` with user and site info.
If `Auth: FAILED`: run `set-pat` to reconfigure credentials.

### Step 2 — Determine Query Type

| User Need | Command | Notes |
|---|---|---|
| Current stuck order counts | `stuck-orders` | Aggregated by app, process, activity |
| Stuck order error details | `stuck-detail` | Per-instance with exception messages |
| Fallout summary | `fallout` | By app with time window breakdown |
| Find a dashboard | `search <term>` | Case-insensitive workbook name search |
| List views in workbook | `views <workbook-name>` | Shows view IDs for direct export |
| Export any view as CSV | `export <view-id> [output]` | Raw CSV data |
| Export by workbook+view name | `export-by-name <wb> <view>` | Resolves view ID automatically |
| List all workbooks | `workbooks` | 238 workbooks on xMobility site |

### Step 3 — Execute Query

**Domain shortcuts** (pre-configured for "Bpaas stuck order" workbook):

```bash
# Stuck orders — aggregated counts (excludes Tableau "All" summary rows)
bash .github/skills/tableau-reader/scripts/tableau-query.sh stuck-orders

# Stuck order detail — per-instance with exception messages
bash .github/skills/tableau-reader/scripts/tableau-query.sh stuck-detail

# Fallout summary — by app and time window
bash .github/skills/tableau-reader/scripts/tableau-query.sh fallout
```

**Discovery commands**:

```bash
# Search workbooks (case-insensitive client-side filter)
bash .github/skills/tableau-reader/scripts/tableau-query.sh search "Collection"

# List views in a specific workbook
bash .github/skills/tableau-reader/scripts/tableau-query.sh views "Bpaas stuck order"
```

**Raw export** (for workbooks without domain shortcuts):

```bash
# By view ID (from views command output)
bash .github/skills/tableau-reader/scripts/tableau-query.sh export <view-id> /tmp/output.csv

# By workbook + view name
bash .github/skills/tableau-reader/scripts/tableau-query.sh export-by-name "My Workbook" "My View" /tmp/output.csv
```

### Step 4 — Interpret Results

**stuck-orders output format**:
- Total stuck count (deduplicated — "All" summary rows excluded)
- By Application: count, percentage, app name (top 20)
- By Process: count, percentage, process name (top 15)
- By Activity: count, percentage, activity name (top 15)

**stuck-detail output format**:
- Total distinct rows
- Table: Count | App | Activity | Exception (truncated)
- Sorted by count descending — top error patterns first

**fallout output format**:
- Total fallouts (sum excluding "All" row)
- By app: count, percentage

### Step 5 — CSV Post-Processing (optional)

Domain shortcuts output formatted summaries. For custom analysis, export to CSV and process:

```bash
# Export raw CSV for custom analysis
bash .github/skills/tableau-reader/scripts/tableau-query.sh stuck-orders /tmp/stuck.csv

# Then filter/analyze with standard tools
head -5 /tmp/stuck.csv
python3 -c "import csv; [print(r) for r in csv.DictReader(open('/tmp/stuck.csv'))]" | head
```

## Known Workbook Catalog (key dashboards)

| Workbook | ID | Key Views | Use Case |
|---|---|---|---|
| Bpaas stuck order | `8aa26a3c-a8df-43f1-a0b6-f2a229e98f7f` | BPM stuck order overall, BPM Stuck Order (detail), Fallout Summary | Stuck order monitoring, error triage |
| BPM Instance Dashboard | `c50c8a87-6e51-466c-abcf-cce09478fddc` | — | BPM instance health |
| Collection Stuck State | `40792a76-61d8-4cea-9963-76bc8ee4068f` | — | Collection order stuck state |
| Case_Mgmt_Open_Report | `d1abb991-ec4a-4deb-b84e-20360ec2f34f` | — | Open case management |
| DailyMBCHealthCheck | `f4dab3cf-19c3-4975-bc26-b47140144269` | — | MBC daily health |
| XM360_API_Error_Classification | `a69f5cc7-7ce8-452d-a33b-c8631eb2380e` | — | API error classification |
| Order Summary | `d9cdd54c-7410-4ee5-b661-02c77e7f1c3b` | — | Order overview |

## Known Issues

1. **"BPM trend" view** (`dc2f6f4f-48da-473c-a0d7-cc1a49364148`): Returns XML error "data sources are not connected". This view's datasource is broken on the server — skip it.
2. **CSV number formatting**: Tableau exports numbers with commas (e.g., `"3,049"`). The script handles this with `parse_int()` — commas are stripped before numeric operations.
3. **Timeout**: Default 60s per API call. For large exports, increase with `TIMEOUT=120`.

## Bounds & Safety

- **Max page size**: 100 workbooks per API page (configurable via `MAX_PAGE_SIZE`)
- **Max pagination**: 10 pages (1,000 workbooks max per listing)
- **Timeout**: 60 seconds per API call (configurable via `TIMEOUT` env var)
- **Auth**: PAT credentials stored in `~/.ordertech-tableau/pat.json` (mode 600, directory mode 700)
- **Session caching**: Auth token cached in `session.json` with `created_at` timestamp. Auto-refreshes from PAT on expiry.
- **Read-only**: No write/modify operations. Export and list only.
- **No secrets in output**: PAT secret never printed. Session tokens are ephemeral.

## Output Format

All commands output to stdout. Domain shortcuts produce formatted summaries.
Raw exports produce CSV (pipe to file with output argument or redirect).

Error output goes to stderr with `[ERROR]` prefix.
Info messages go to stderr with `[INFO]` prefix.
