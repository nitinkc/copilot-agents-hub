---
name: story-quality-invest
description: Evaluate and improve user stories using INVEST and mission-critical readiness criteria.
---

# Skill: Story Quality (INVEST)

## Goal
Evaluate each user story against INVEST criteria and mission-critical readiness standards, identify weaknesses, and recommend improvements and slice sizes.

## Inputs
- One or more user stories (from acceptance-criteria-gherkin or provided directly)
- Acceptance criteria associated with each story
- Known constraints and business rules

## Hard Constraints
- Evaluate every story — do not skip any.
- Do not rewrite stories without explaining what changed and why.
- Slice recommendations must produce testable increments, not arbitrary splits.
- Do not mark a story as "ready" if failure behavior is undefined.

## Steps

### Step 1: Evaluate Against INVEST
For each user story, assess:
- **Independent**: Can it be developed and delivered without waiting for other stories?
- **Negotiable**: Is it flexible enough to allow design discussion, not implementation-prescriptive?
- **Valuable**: Does it deliver clear user or business value?
- **Estimable**: Is there enough information to estimate effort?
- **Small**: Can it be completed in a single iteration/sprint?
- **Testable**: Are acceptance criteria clear and deterministic enough to write tests?

### Step 2: Check Mission-Critical Readiness
Also evaluate:
- **Backward compatibility**: Does the story acknowledge impact on existing consumers?
- **Business rule clarity**: Are decision criteria explicit, not implied?
- **Failure behavior defined**: Are error paths and safe error responses specified?
- **Observability/support impact**: Does this change affect monitoring, alerting, or support workflows?
- **Security/data handling**: Does this introduce or modify PII handling, auth, or data classification?

### Step 3: Identify Weaknesses
For each story, list concrete weaknesses found in steps 1–2. Classify each as:
- **Blocker**: Cannot proceed to development without resolution
- **Improvement**: Story would benefit from refinement but is not blocked
- **Minor**: Cosmetic or stylistic improvement

### Step 4: Recommend Improvements
For each weakness:
- Suggest a specific rewrite or addition to the story.
- If the story is too large, recommend a slicing strategy that produces testable increments.

### Step 5: Recommend Slice Size
For each story:
- Estimate slice complexity: **XS** (trivial), **S** (small), **M** (medium), **L** (large — should be split).
- If L or larger, recommend specific sub-stories.

## Output
For each story:
- **Current story text**
- **INVEST assessment** (pass/fail per criterion with brief rationale)
- **Mission-critical readiness** (pass/flag per criterion)
- **Weaknesses** (classified as blocker/improvement/minor)
- **Improved story** (rewritten if needed)
- **Recommended slice size** (XS/S/M/L with justification)