---
name: documentation-industry-validation
description: Critically validate architecture and service documentation against industry-recognized practices: audience-specific documentation, context/container views, quality/invariant capture, decision records, and actionable operational guidance.
---
# Documentation Industry Validation

## Goal
Check whether the documentation system is fit for enterprise mission-critical use.

## Validation dimensions
1) Audience separation
- business, technical, operations, and machine audiences all have usable entry points
2) Architecture coverage
- context/service boundaries are documented
- runtime behavior and major failure paths are documented
- technical component map exists
3) Quality and rules coverage
- key invariants and non-functional rules are documented
- operational rules and release/rollback guidance exist
- rule inventory exists with stable IDs, cross-referenced to capabilities and tests
4) Decision traceability
- ADR structure exists and important design decisions are captured
5) Machine readability
- manifests and impact maps exist and are structured enough for automation/LLMs
- machine-readable rule inventory and entity catalog exist
6) Dimension coverage (from `dimension-extraction.instructions.md`)
- business dimensions: capabilities have goal, actor, trigger, outcome, business value, rule IDs
- logic dimensions: rules cataloged with stable IDs, validations and decision points documented
- data dimensions: entities cataloged with logic-bearing attributes, state transitions, data classification
- integration dimensions: APIs, backends, DB tables documented; machine-readable contract specs referenced when available
- risk/operability dimensions: compatibility/timeout sensitivity, safe failure modes, observability
- traceability dimensions: capabilities linked to docs, tests, code areas, requirement keywords

## Review questions
- Can a business reader understand what this service does?
- Can an architect understand where it fits and what it depends on?
- Can a developer find the right code quickly?
- Can an operator reason about failure and recovery?
- Can an LLM infer likely repo impact from a requirement phrase?
- Are business rules formally cataloged with stable IDs and traced to capabilities and tests?
- Are key entities and their logic-bearing attributes documented and linked to rules?
- Are all API contracts (regardless of protocol) cataloged with their contract spec references?
- When machine-readable specs exist (OpenAPI, WSDL, .proto, AsyncAPI), are they referenced as authoritative sources?

## Output
Produce a short validation report:
- strengths
- gaps
- priority fixes
- recommended next document(s) to add or strengthen

## File-Existence Verification (MANDATORY)

As part of validation, verify that all required documentation files exist on disk. Use the checklist from `documentation-living-views/SKILL.md` under "File-Existence Verification Gate" (28 required files).

Report: `[All N/28 required files present]` or `[MISSING: file1, file2, ...]`

**Feedback loop**: If missing files are found, this is a **blocking validation failure**, not a "low-priority gap." The calling workflow MUST generate the missing files before proceeding to the next step. Do not categorize required files as optional or lower-priority.
