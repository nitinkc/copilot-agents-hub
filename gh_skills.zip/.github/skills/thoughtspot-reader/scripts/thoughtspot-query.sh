#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────
# thoughtspot-query.sh — ThoughtSpot V1 API query tool (SSO auth)
#
# Auth: Comcast SSO cookies (JSESSIONID + clientId + route)
# API:  ThoughtSpot V1 (/callosum/v1/ + /callosum/v1/tspublic/v1/)
#
# Setup:
#   1. Run: thoughtspot-query.sh login --install   (first time only)
#   2. Run: thoughtspot-query.sh login             (opens browser for SSO)
#   3. Run: thoughtspot-query.sh check             (verify auth)
#
# Usage:
#   thoughtspot-query.sh check                          # verify auth
#   thoughtspot-query.sh login [--install|--headed]     # SSO login
#   thoughtspot-query.sh set-cookie                     # manual cookie paste
#   thoughtspot-query.sh system-info                    # instance info
#   thoughtspot-query.sh search <term>                  # search metadata
#   thoughtspot-query.sh liveboards                     # list liveboards
#   thoughtspot-query.sh answers                        # list saved answers
#   thoughtspot-query.sh tables                         # list tables/worksheets
#   thoughtspot-query.sh liveboard-data <guid>          # get liveboard data
#   thoughtspot-query.sh answer-data <guid>             # get answer data
#   thoughtspot-query.sh export-liveboard <guid> [out]  # export as CSV
#   thoughtspot-query.sh export-answer <guid> [out]     # export as CSV
#   thoughtspot-query.sh search-data "<query>" <src>    # TQL search query
#   thoughtspot-query.sh describe-table <name>          # show table columns from brain
#   thoughtspot-query.sh resolve-guid <name>             # live API GUID lookup (if brain is stale)
# ─────────────────────────────────────────────────────────────────
set -euo pipefail

readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly TS_INSTANCE="${TS_INSTANCE:-salestechts.xfinity.com}"
readonly TS_BASE="https://${TS_INSTANCE}"
# This instance runs older ThoughtSpot (V1 API only, no REST API v2)
readonly API_BASE="${TS_BASE}/callosum/v1"
# Data query endpoints live under tspublic/v1 (searchdata, pinboarddata)
readonly DATA_API_BASE="${TS_BASE}/callosum/v1/tspublic/v1"
readonly CURL_OPTS="-ksS"  # -k for internal SSL cert
readonly CONFIG_DIR="$HOME/.ordertech-thoughtspot"
readonly COOKIE_FILE="${CONFIG_DIR}/cookies.txt"
readonly BROWSER_STATE_DIR="${CONFIG_DIR}/browser-state"
readonly TIMEOUT="${TIMEOUT:-60}"
readonly MAX_RESULTS="${MAX_RESULTS:-200}"

# ─── PII Column Blocklist ─────────────────────────────────────────
# Columns that must NEVER appear in SELECT (output) position.
# They CAN be used freely as WHERE filters with literal values.
# GUIDs/UUIDs, aggregate counts (*_count), zip codes are NOT PII.
readonly PII_COLUMNS=(
  # Phone / device identifiers (exact values only, not *_count)
  'iccid' 'imei' 'imsi' 'mdn'
  'portin mdn' 'portin_mdn' 'ported mdn' 'mdn_id'
  # Contact
  'phone'
)
# Allowlist: columns containing PII keywords but that are safe (counts, flags)
readonly PII_ALLOWLIST=(
  'mdn_count' 'mdn count' 'matching_mdn' 'matching mdn'
  'biller_mdn' 'biller mdn' 'network_mdn' 'network mdn'
  'hazard desc' 'error msg txt' 'guid' 'uuid'
  'customerkey' 'customer key' 'subscriberkey' 'subscriber key'
  'zip'
)

# ─── Helpers ─────────────────────────────────────────────────────

die()  { echo "[ERROR] $*" >&2; exit 1; }
warn() { echo "[WARN] $*" >&2; }
info() { echo "[INFO] $*" >&2; }

ensure_config_dir() {
  if [[ ! -d "$CONFIG_DIR" ]]; then
    mkdir -p "$CONFIG_DIR"
    chmod 700 "$CONFIG_DIR"
  fi
}

# ─── Cookie Management ───────────────────────────────────────────

load_cookies() {
  [[ -f "$COOKIE_FILE" ]] || die "No cookie file found. Run: $0 login"
  local cookies
  cookies="$(cat "$COOKIE_FILE")"
  [[ -n "$cookies" ]] || die "Cookie file is empty. Run: $0 login"
  echo "$cookies"
}

save_cookies() {
  local cookies="$1"
  ensure_config_dir
  printf '%s' "$cookies" > "$COOKIE_FILE"
  chmod 600 "$COOKIE_FILE"
  info "Cookies saved to $COOKIE_FILE"
}

# Build curl cookie header from stored cookies
cookie_header() {
  load_cookies
}

# ─── API Helpers ─────────────────────────────────────────────────

# Make an authenticated GET request
api_get() {
  local endpoint="$1"
  local cookies
  cookies="$(load_cookies)"
  curl $CURL_OPTS --max-time "$TIMEOUT" \
    -H "Accept: application/json" \
    -H "Content-Type: application/json" \
    -H "X-Requested-With: XMLHttpRequest" \
    -b "$cookies" \
    "${API_BASE}${endpoint}"
}

# Make an authenticated POST request with JSON body
api_post() {
  local endpoint="$1"
  local body="${2:-{}}"
  local cookies
  cookies="$(load_cookies)"
  curl $CURL_OPTS --max-time "$TIMEOUT" \
    -H "Accept: application/json" \
    -H "Content-Type: application/json" \
    -H "X-Requested-With: XMLHttpRequest" \
    -b "$cookies" \
    -d "$body" \
    "${API_BASE}${endpoint}"
}

# Make an authenticated POST request and save response to file
api_post_file() {
  local endpoint="$1"
  local body="$2"
  local output="$3"
  local cookies
  cookies="$(load_cookies)"
  curl $CURL_OPTS --max-time "$TIMEOUT" \
    -H "Content-Type: application/json" \
    -H "X-Requested-With: XMLHttpRequest" \
    -b "$cookies" \
    -d "$body" \
    -o "$output" \
    "${API_BASE}${endpoint}"
}

# ─── Commands ────────────────────────────────────────────────────

cmd_check() {
  echo "ThoughtSpot Connection Check"
  echo "═══════════════════════════════════════════"
  echo "  Instance: $TS_INSTANCE"
  echo "  API Base: $API_BASE"

  # Check cookie file
  if [[ ! -f "$COOKIE_FILE" ]]; then
    echo "  Cookies:  MISSING"
    echo "  Auth:     NOT CONFIGURED"
    echo ""
    echo "  Run: $0 login"
    exit 1
  fi

  local age_s age_h
  if [[ "$(uname)" == "Darwin" ]]; then
    age_s=$(( $(date +%s) - $(stat -f %m "$COOKIE_FILE") ))
  else
    age_s=$(( $(date +%s) - $(stat -c %Y "$COOKIE_FILE") ))
  fi
  age_h=$(( age_s / 3600 ))
  echo "  Cookies:  present (age: ${age_h}h)"

  # Test API connectivity using V1 session/info
  local response http_code
  local cookies
  cookies="$(cat "$COOKIE_FILE")"
  http_code="$(curl -ksS --max-time 15 -o /dev/null -w "%{http_code}" \
    -H "Accept: application/json" \
    -H "X-Requested-With: XMLHttpRequest" \
    -b "$cookies" \
    "${API_BASE}/session/info" 2>/dev/null)" || http_code="000"

  if [[ "$http_code" == "200" ]]; then
    echo "  Auth:     VALID (HTTP $http_code)"
    # Get user info
    response="$(curl -ksS --max-time 15 \
      -H "Accept: application/json" \
      -H "X-Requested-With: XMLHttpRequest" \
      -b "$cookies" \
      "${API_BASE}/session/info" 2>/dev/null)" || true
    if [[ -n "$response" ]]; then
      local user display
      user="$(echo "$response" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('userName','unknown'))" 2>/dev/null)" || user="unknown"
      display="$(echo "$response" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('userDisplayName',''))" 2>/dev/null)" || display=""
      echo "  User:     $user ($display)"
    fi
  elif [[ "$http_code" == "401" || "$http_code" == "403" ]]; then
    echo "  Auth:     EXPIRED (HTTP $http_code)"
    echo ""
    echo "  Session expired. Run: $0 login"
    exit 1
  else
    echo "  Auth:     FAILED (HTTP $http_code)"
    echo ""
    echo "  Cannot reach ThoughtSpot. Check VPN and run: $0 login"
    exit 1
  fi
  echo "═══════════════════════════════════════════"
}

cmd_login() {
  local mode="${1:-}"

  if [[ "$mode" == "--install" ]]; then
    info "Installing Playwright and Chromium..."
    python3 -m pip install playwright 2>&1 | tail -3
    python3 -m playwright install chromium 2>&1 | tail -3
    info "Done. Now run: $0 login"
    return 0
  fi

  # Run the SSO login script
  local login_script="${SCRIPT_DIR}/thoughtspot-sso-login.py"
  if [[ ! -f "$login_script" ]]; then
    die "Login script not found: $login_script"
  fi

  if [[ "$mode" == "--headed" ]]; then
    python3 "$login_script" --headed || die "SSO login failed. Try: $0 login --headed"
  else
    python3 "$login_script" || die "SSO login failed. Try: $0 login --headed"
  fi
  info "Login successful. Verifying..."
  cmd_check
}

cmd_set_cookie() {
  echo "Manual cookie setup for ThoughtSpot"
  echo "─────────────────────────────────────"
  echo ""
  echo "1. Open https://${TS_INSTANCE} in Chrome/Firefox"
  echo "2. Sign in via Comcast SSO"
  echo "3. Open DevTools (F12) → Network tab"
  echo "4. Click any API request to ${TS_INSTANCE}"
  echo "5. Copy the Cookie header value (contains JSESSIONID and clientId)"
  echo ""
  echo "Paste the full cookie string (then press Enter):"
  read -r cookie_val
  if [[ -z "$cookie_val" ]]; then
    die "No cookie provided."
  fi
  save_cookies "$cookie_val"
  info "Verifying cookie..."
  cmd_check
}

cmd_system_info() {
  local response
  response="$(api_get "/system/config")" || die "Failed to get system info"
  echo "$response" | python3 -c "
import json, sys
d = json.load(sys.stdin)
print('ThoughtSpot System Info')
print('═' * 45)
print(f\"  SAML:       {d.get('samlEnabled', 'unknown')}\")
print(f\"  Cluster:    {d.get('mixpanelConfig', {}).get('clusterName', 'unknown')}\")
print(f\"  Cluster ID: {d.get('mixpanelConfig', {}).get('clusterId', 'unknown')}\")
print(f\"  Support:    {d.get('supportEmail', 'unknown')}\")
print('═' * 45)
" 2>/dev/null || echo "$response" | python3 -m json.tool 2>/dev/null || echo "$response"
}

cmd_search() {
  local term="$1"
  [[ -n "$term" ]] || die "Usage: $0 search <term>"

  # Search pinboards (liveboards)
  local pb_response
  pb_response="$(api_get "/metadata/list?type=PINBOARD_ANSWER_BOOK&batchsize=$MAX_RESULTS&pattern=$term")" || true

  # Search answers
  local ans_response
  ans_response="$(api_get "/metadata/list?type=QUESTION_ANSWER_BOOK&batchsize=$MAX_RESULTS&pattern=$term")" || true

  # Search tables
  local tbl_response
  tbl_response="$(api_get "/metadata/list?type=LOGICAL_TABLE&batchsize=$MAX_RESULTS&pattern=$term")" || true

  # Combine and display
  python3 -c "
import json, sys

results = []
for label, raw in [('LIVEBOARD', '''$pb_response'''), ('ANSWER', '''$ans_response'''), ('TABLE', '''$tbl_response''')]:
    try:
        data = json.loads(raw)
        for h in data.get('headers', []):
            results.append((label, h.get('name','?'), h.get('id',''), h.get('authorName','')))
    except:
        pass

if not results:
    print('No results found.')
    sys.exit(0)

print(f'Found {len(results)} result(s) matching \"$term\":')
print('')
print(f'{\"Type\":<12} {\"Name\":<55} {\"GUID\":<38} {\"Author\"}')
print('─' * 130)
for typ, name, guid, author in results[:50]:
    print(f'{typ:<12} {name[:53]:<55} {guid:<38} {author}')
" 2>/dev/null
}

cmd_liveboards() {
  local response
  response="$(api_get "/metadata/list?type=PINBOARD_ANSWER_BOOK&batchsize=$MAX_RESULTS")" || die "Failed to list liveboards"

  echo "$response" | python3 -c "
import json, sys
data = json.load(sys.stdin)
headers = data.get('headers', [])
if not headers:
    print('No liveboards found.')
    sys.exit(0)
print(f'Liveboards ({len(headers)} found):')
print('')
print(f'{\"Name\":<55} {\"GUID\":<38} {\"Author\"}')
print('─' * 120)
for h in headers:
    name = h.get('name', 'untitled')[:53]
    guid = h.get('id', '')
    author = h.get('authorName', '')
    print(f'{name:<55} {guid:<38} {author}')
" 2>/dev/null || echo "$response" | python3 -m json.tool 2>/dev/null || echo "$response"
}

cmd_answers() {
  local response
  response="$(api_get "/metadata/list?type=QUESTION_ANSWER_BOOK&batchsize=$MAX_RESULTS")" || die "Failed to list answers"

  echo "$response" | python3 -c "
import json, sys
data = json.load(sys.stdin)
headers = data.get('headers', [])
if not headers:
    print('No answers found.')
    sys.exit(0)
print(f'Saved Answers ({len(headers)} found):')
print('')
print(f'{\"Name\":<55} {\"GUID\":<38} {\"Author\"}')
print('─' * 120)
for h in headers:
    name = h.get('name', 'untitled')[:53]
    guid = h.get('id', '')
    author = h.get('authorName', '')
    print(f'{name:<55} {guid:<38} {author}')
" 2>/dev/null || echo "$response" | python3 -m json.tool 2>/dev/null || echo "$response"
}

cmd_tables() {
  local response
  response="$(api_get "/metadata/list?type=LOGICAL_TABLE&batchsize=$MAX_RESULTS")" || die "Failed to list tables"

  echo "$response" | python3 -c "
import json, sys
data = json.load(sys.stdin)
headers = data.get('headers', [])
if not headers:
    print('No tables/worksheets found.')
    sys.exit(0)
print(f'Tables/Worksheets ({len(headers)} found):')
print('')
print(f'{\"Name\":<55} {\"GUID\":<38} {\"Type\":<15} {\"Author\"}')
print('─' * 130)
for h in headers:
    name = h.get('name', 'untitled')[:53]
    guid = h.get('id', '')
    sub_type = h.get('type', '')
    author = h.get('authorName', '')
    print(f'{name:<55} {guid:<38} {sub_type:<15} {author}')
" 2>/dev/null || echo "$response" | python3 -m json.tool 2>/dev/null || echo "$response"
}

cmd_columns() {
  local pattern="${1:-}"
  local url="/metadata/list?type=LOGICAL_COLUMN&batchsize=$MAX_RESULTS"
  if [[ -n "$pattern" ]]; then
    url="${url}&pattern=${pattern}"
  fi
  local response
  response="$(api_get "$url")" || die "Failed to list columns"

  echo "$response" | python3 -c "
import json, sys
data = json.load(sys.stdin)
headers = data.get('headers', [])
if not headers:
    print('No columns found.')
    sys.exit(0)
print(f'Columns ({len(headers)} found):')
print('')
print(f'{\"Column Name\":<45} {\"GUID\":<38} {\"Owner\"}')
print('─' * 110)
for h in headers:
    name = h.get('name', 'untitled')[:43]
    guid = h.get('id', '')
    owner = h.get('owner', '')[:30]
    print(f'{name:<45} {guid:<38} {owner}')
" 2>/dev/null || echo "$response" | python3 -m json.tool 2>/dev/null || echo "$response"
}

cmd_liveboard_data() {
  local guid="$1"
  [[ -n "$guid" ]] || die "Usage: $0 liveboard-data <liveboard-guid>"

  local cookies response
  cookies="$(load_cookies)"
  # pinboarddata endpoint at tspublic/v1 — id must go in URL query params
  response="$(curl --globoff $CURL_OPTS --max-time "$TIMEOUT" \
    -H "X-Requested-With: XMLHttpRequest" \
    -H "Accept: application/json" \
    -b "$cookies" -X POST \
    "${DATA_API_BASE}/pinboarddata?id=${guid}&batchsize=${MAX_RESULTS}&formattype=COMPACT")" || die "Failed to get liveboard data"

  echo "$response" | python3 -c "
import json, sys
raw = sys.stdin.read()
data = json.loads(raw)
# V1 pinboarddata returns a dict keyed by viz GUID
if isinstance(data, dict):
    vizs = [(k, v) for k, v in data.items() if isinstance(v, dict)]
    print(f'Liveboard data: {len(vizs)} visualization(s)')
    print('═' * 60)
    for i, (viz_id, viz) in enumerate(vizs):
        name = viz.get('name', viz_id[:20])
        col_names = viz.get('columnNames', [])
        rows = viz.get('data', [])
        print(f'\\n  [{i+1}] {name}')
        print(f'      Columns: {len(col_names)}  Rows: {len(rows)}')
        if col_names:
            print(f'      Headers: {\", \".join(str(c) for c in col_names[:8])}{\"...\" if len(col_names)>8 else \"\"}')
        if rows:
            for row in rows[:5]:
                vals = [r.get('v', '') if isinstance(r, dict) else r for r in row]
                print(f'      {vals}')
            if len(rows) > 5:
                print(f'      ... ({len(rows)-5} more rows)')
    print('')
else:
    print(json.dumps(data, indent=2))
" 2>/dev/null || echo "$response" | python3 -m json.tool 2>/dev/null || echo "$response"
}

cmd_answer_data() {
  local guid="$1"
  [[ -n "$guid" ]] || die "Usage: $0 answer-data <answer-guid>"

  local response
  response="$(api_get "/metadata/details?type=QUESTION_ANSWER_BOOK&id=$guid")" || die "Failed to get answer details"

  echo "$response" | python3 -c "
import json, sys
data = json.load(sys.stdin)
print(json.dumps(data, indent=2)[:5000])
" 2>/dev/null || echo "$response" | python3 -m json.tool 2>/dev/null || echo "$response"
}

cmd_export_liveboard() {
  local guid="$1"
  local output="${2:-/tmp/thoughtspot-liveboard-export.pdf}"
  [[ -n "$guid" ]] || die "Usage: $0 export-liveboard <guid> [output-file]"

  info "Exporting liveboard $guid to $output ..."
  # V1 export uses GET with transient_pinboard_content or id param
  curl $CURL_OPTS --max-time "$TIMEOUT" \
    -H "X-Requested-With: XMLHttpRequest" \
    -b "$(load_cookies)" \
    "${API_BASE}/export/pinboard/pdf?id=$guid" \
    -o "$output" || die "Export failed"
  info "Exported to: $output ($(wc -c < "$output" | tr -d ' ') bytes)"
  echo "$output"
}

cmd_export_answer() {
  local guid="$1"
  local output="${2:-/tmp/thoughtspot-answer-export.csv}"
  [[ -n "$guid" ]] || die "Usage: $0 export-answer <guid> [output-file]"

  info "Exporting answer $guid to $output ..."
  curl $CURL_OPTS --max-time "$TIMEOUT" \
    -H "X-Requested-With: XMLHttpRequest" \
    -H "Accept: text/csv" \
    -b "$(load_cookies)" \
    "${API_BASE}/answer/data?id=$guid&batchsize=10000" \
    -o "$output" || die "Export failed"
  info "Exported to: $output ($(wc -c < "$output" | tr -d ' ') bytes)"
  echo "$output"
}

# Check the SELECT columns (output) of a query against the PII blocklist.
# Columns used only as filters with = 'value' are excluded from the check
# because they don't appear in query output.
# Exits with code 2 if any PII column appears in SELECT (non-filter) position.
_assert_no_pii_in_output() {
  local query="$1"
  local query_lower
  query_lower="$(echo "$query" | tr '[:upper:]' '[:lower:]')"

  # Strip filter expressions: [col] = 'value' or [col] = value
  # This removes PII columns that are used purely as filter predicates
  local stripped
  stripped="$(echo "$query_lower" | sed -E "s/\\[[^]]+\\][[:space:]]*=[[:space:]]*'[^']*'//g" \
    | sed -E "s/\\[[^]]+\\][[:space:]]*(!=|<>|>=|<=|>|<|in)[[:space:]]*[^][]*//g" \
    | sed -E "s/\\[[^]]+\\][[:space:]]*=[[:space:]]*[^][[:space:]]+//g")"

  # Extract remaining column names from [brackets] — these are SELECT columns
  local select_cols=()
  while IFS= read -r col_name; do
    [[ -n "$col_name" ]] && select_cols+=("$col_name")
  done < <(echo "$stripped" | grep -oE '\[[^]]+\]' | sed 's/^\[//;s/\]$//')

  [[ ${#select_cols[@]} -eq 0 ]] && return 0

  local blocked=()
  for col_name in "${select_cols[@]}"; do
    # Check allowlist first — if the full column name matches any allowlist entry, it's safe
    local allowed=false
    for allow in "${PII_ALLOWLIST[@]}"; do
      if [[ "$col_name" == *"$allow"* ]]; then
        allowed=true
        break
      fi
    done
    [[ "$allowed" == "true" ]] && continue

    # Check if column name matches any PII pattern
    for pii in "${PII_COLUMNS[@]}"; do
      if [[ "$col_name" == *"$pii"* ]]; then
        blocked+=("$col_name")
        break
      fi
    done
  done

  if [[ ${#blocked[@]} -gt 0 ]]; then
    echo "[PII-BLOCK] Query rejected — PII column(s) in output: ${blocked[*]}" >&2
    echo "[PII-BLOCK] These columns return personal data to the LLM context." >&2
    echo "[PII-BLOCK] Use as filter only: [column] = 'value'" >&2
    echo "[PII-BLOCK] Or use aggregates: count, sum, average." >&2
    exit 2
  fi
}

cmd_search_data() {
  local query="$1"
  local source_guid="$2"
  [[ -n "$query" ]] || die "Usage: $0 search-data \"<TQL query>\" <data-source-guid>"
  [[ -n "$source_guid" ]] || die "Usage: $0 search-data \"<TQL query>\" <data-source-guid>"

  # PII output guard — block PII columns in SELECT position
  _assert_no_pii_in_output "$query"

  local cookies response
  cookies="$(load_cookies)"
  # URL-encode query safely (pipe avoids shell quoting issues with embedded quotes)
  local encoded_query
  encoded_query="$(printf '%s' "$query" | python3 -c "import urllib.parse, sys; print(urllib.parse.quote(sys.stdin.read()))")"
  # V1 tspublic searchdata: params go in URL (form body ignored by this API)
  response="$(curl --globoff $CURL_OPTS --max-time "$TIMEOUT" \
    -H "X-Requested-With: XMLHttpRequest" \
    -H "Accept: application/json" \
    -b "$cookies" -X POST \
    "${DATA_API_BASE}/searchdata?query_string=${encoded_query}&data_source_guid=${source_guid}&batchsize=${MAX_RESULTS}&formattype=COMPACT")" || die "Search data failed"

  echo "$response" | python3 -c "
import json, sys
data = json.load(sys.stdin)
if isinstance(data, dict):
    col_names = data.get('columnNames', data.get('column_names', []))
    rows = data.get('data', data.get('data_rows', []))
    print(f'Search results: {len(col_names)} columns, {len(rows)} rows')
    print('═' * 60)
    if col_names:
        print(f'  Headers: {\", \".join(str(c) for c in col_names[:10])}{\"...\" if len(col_names)>10 else \"\"}')
    print('')
    for row in rows[:30]:
        if isinstance(row, list):
            vals = [r.get('v', '') if isinstance(r, dict) else r for r in row]
            print(f'  {vals}')
        else:
            print(f'  {row}')
    if len(rows) > 30:
        print(f'  ... ({len(rows)-30} more rows)')
else:
    print(json.dumps(data, indent=2))
" 2>/dev/null || echo "$response" | python3 -m json.tool 2>/dev/null || echo "$response"
}

# ─── Describe Table (from brain) ─────────────────────────────────

cmd_describe_table() {
  local table_name="$1"
  [[ -n "$table_name" ]] || die "Usage: $0 describe-table <table-name>"

  local brain_file="${SCRIPT_DIR}/../ts-brain.json"
  [[ -f "$brain_file" ]] || die "Brain file not found: $brain_file. Run build-brain.py first."

  python3 - "$brain_file" "$table_name" << 'PYEOF'
import json, sys
brain_file, target = sys.argv[1], sys.argv[2].lower()
brain = json.load(open(brain_file))
matches = [t for t in brain["tables"] if target in t["name"].lower()]
if not matches:
    print(f"No table matching '{target}' found.", file=sys.stderr)
    sys.exit(1)
for t in matches:
    print(f"Table: {t['name']}")
    print(f"GUID:  {t['guid']}")
    desc = t.get("description", "")
    if desc:
        print(f"Description: {desc}")
    safe = t.get("safe_columns", [])
    pii = t.get("pii_columns", [])
    print(f"Safe columns ({len(safe)}):")
    for c in safe:
        n = c if isinstance(c, str) else c.get("name", "")
        print(f"  {n}")
    if pii:
        print(f"PII columns ({len(pii)}) — use in WHERE only:")
        for c in pii:
            n = c if isinstance(c, str) else c.get("name", "")
            print(f"  {n}")
    print()
PYEOF
}

# ─── Resolve GUID (live API fallback) ────────────────────────────

cmd_resolve_guid() {
  local table_name="$1"
  [[ -n "$table_name" ]] || die "Usage: $0 resolve-guid <table-name-substring>"

  local response
  response="$(api_get "/metadata/list?type=LOGICAL_TABLE&batchsize=$MAX_RESULTS")" || die "Failed to list tables"

  echo "$response" | python3 -c "
import json, sys
target = sys.argv[1].lower()
data = json.load(sys.stdin)
matches = [(h['name'], h['id']) for h in data.get('headers', [])
           if target in h.get('name', '').lower()]
if not matches:
    print(f'No table matching \'{target}\' found.', file=sys.stderr)
    sys.exit(1)
for name, guid in matches:
    print(f'{guid}  {name}')
" "$table_name"
}

# ─── Main ────────────────────────────────────────────────────────

main() {
  local cmd="${1:-help}"
  shift || true

  case "$cmd" in
    check)            cmd_check ;;
    login)            cmd_login "${1:-}" ;;
    set-cookie)       cmd_set_cookie ;;
    system-info)      cmd_system_info ;;
    search)           cmd_search "${1:-}" ;;
    liveboards)       cmd_liveboards ;;
    answers)          cmd_answers ;;
    tables)           cmd_tables ;;
    columns)          cmd_columns "${1:-}" ;;
    liveboard-data)   cmd_liveboard_data "${1:-}" ;;
    answer-data)      cmd_answer_data "${1:-}" ;;
    export-liveboard) cmd_export_liveboard "${1:-}" "${2:-}" ;;
    export-answer)    cmd_export_answer "${1:-}" "${2:-}" ;;
    search-data)      cmd_search_data "${1:-}" "${2:-}" ;;
    describe-table)   cmd_describe_table "${1:-}" ;;
    resolve-guid)     cmd_resolve_guid "${1:-}" ;;
    help|--help|-h)
      echo "Usage: $0 <command> [args...]"
      echo ""
      echo "Commands:"
      echo "  check                          Verify auth status"
      echo "  login [--install|--headed]     SSO login via Playwright"
      echo "  set-cookie                     Manual cookie paste"
      echo "  system-info                    Instance info"
      echo "  search <term>                  Search metadata by name"
      echo "  liveboards                     List all liveboards"
      echo "  answers                        List all saved answers"
      echo "  tables                         List tables/worksheets"
      echo "  columns [pattern]              List available columns"
      echo "  liveboard-data <guid>          Get liveboard visualization data"
      echo "  answer-data <guid>             Get saved answer data"
      echo "  export-liveboard <guid> [out]  Export liveboard as PDF"
      echo "  export-answer <guid> [out]     Export answer as CSV"
      echo "  search-data \"<query>\" <src>    Run TQL search against data source"
      echo "  describe-table <name>            Show table GUID + columns from brain"
      echo "  resolve-guid <name>              Live API lookup — get current GUID for a table"
      echo ""
      echo "TQL query syntax:"
      echo "  Use [Column Name] for column references"
      echo "  Example: search-data \"[Tenant Id] [Status Cd]\" <worksheet-guid>"
      echo ""
      echo "Environment:"
      echo "  TS_INSTANCE   ThoughtSpot host (default: salestechts.xfinity.com)"
      echo "  TIMEOUT       API call timeout in seconds (default: 60)"
      echo "  MAX_RESULTS   Max metadata results (default: 200)"
      ;;
    *)
      die "Unknown command: $cmd. Run: $0 help"
      ;;
  esac
}

main "$@"
