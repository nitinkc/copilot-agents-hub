#!/usr/bin/env python3
"""
Build ThoughtSpot brain: fetches all tables + columns from the live instance
and writes ts-brain.json to the skill folder.
"""
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

TS_INSTANCE = "salestechts.xfinity.com"
TS_BASE = f"https://{TS_INSTANCE}"
API_BASE = f"{TS_BASE}/callosum/v1"
COOKIE_FILE = Path.home() / ".ordertech-thoughtspot" / "cookies.txt"
OUT_FILE = Path(__file__).parent / "ts-brain.json"  # overridden below

# ── PII column detection ──────────────────────────────────────────────────────
# OUTPUT-only PII: columns that should NOT appear in SELECT position
# because they return raw personal data (account numbers, phone numbers,
# device identifiers). GUIDs/UUIDs and aggregate counts are NOT PII.
# Columns can still be used freely as filter (WHERE) inputs.

# Allowlist: patterns that contain PII keywords but are safe (counts, flags, etc.)
PII_ALLOWLIST = [
    "mdn_count", "mdn count",         # aggregate counts, not actual MDNs
    "matching_mdn", "matching mdn",
    "biller_mdn", "biller mdn",
    "network_mdn", "network mdn",
    "phone_nbr_count", "phone count",
    "hazard desc",                     # description text, not personal data
    "error msg txt",                   # error messages, not personal data
    "guid",                            # GUIDs/UUIDs are OK per policy
    "uuid",                            # UUIDs are OK per policy
    "customerkey", "customer key",     # opaque keys, OK
    "subscriberkey", "subscriber key", # opaque keys, OK
    "auth guid", "authenticid",        # auth reference IDs, OK
    "zip",                             # zip codes are not PII in this context
]

# PII keywords: if found in column name AND not allowlisted → PII
PII_KEYWORDS = [
    "iccid",
    "imsi",
    "imei",
    "mdn",
    "portin mdn",
    "portin_mdn",
    "ported mdn",
    "phone",
]

# Tables to exclude from the brain (unused, empty, or deprecated)
EXCLUDED_TABLES = {
    "stxm_s3_ai_workbench_telemetry_tb",
    "stwa_Buyflow_Analytics_ws",
    "stxm_s3_bizeventCreditCheck_tb_delete",
}


def classify_pii(col_name: str) -> bool:
    """Return True if column contains raw PII that should not be in SELECT output."""
    lower = col_name.lower()
    # Check allowlist first — if any allowlist pattern matches, it's safe
    for allow in PII_ALLOWLIST:
        if allow in lower:
            return False
    # Check PII keywords
    for keyword in PII_KEYWORDS:
        if keyword in lower:
            return True
    return False


def curl_get(path: str, cookies: str) -> dict:
    url = f"{API_BASE}{path}"
    result = subprocess.run(
        ["curl", "--globoff", "-ksS", "--max-time", "30",
         "-H", "X-Requested-With: XMLHttpRequest",
         "-H", "Accept: application/json",
         "-b", cookies, url],
        capture_output=True, text=True, timeout=35
    )
    return json.loads(result.stdout)


def fetch_all_pages(path_prefix: str, cookies: str, page_size=200) -> list:
    """Paginate through a metadata/list endpoint until empty."""
    items = []
    offset = 0
    while True:
        path = f"{path_prefix}&batchsize={page_size}&offset={offset}"
        data = curl_get(path, cookies)
        batch = data.get("headers", [])
        if not batch:
            break
        items.extend(batch)
        print(f"  fetched {len(items)} so far (offset={offset})...", file=sys.stderr)
        if len(batch) < page_size:
            break
        offset += page_size
    return items


def main(out_path: Path):
    if not COOKIE_FILE.exists():
        print(f"[ERROR] Cookie file not found: {COOKIE_FILE}", file=sys.stderr)
        sys.exit(1)
    cookies = COOKIE_FILE.read_text().strip()

    # ── Step 1: fetch all tables ──────────────────────────────────────────────
    print("Fetching tables...", file=sys.stderr)
    table_data = curl_get(
        "/metadata/list?type=LOGICAL_TABLE&category=ALL&batchsize=200", cookies
    )
    raw_tables = table_data.get("headers", [])
    print(f"  {len(raw_tables)} tables found", file=sys.stderr)

    # Build lookup: guid → table meta (skip excluded tables)
    tables_by_guid = {}
    skipped = 0
    for t in raw_tables:
        name = t.get("name", "")
        if name in EXCLUDED_TABLES:
            skipped += 1
            continue
        guid = t.get("id", "")
        tables_by_guid[guid] = {
            "name":   name,
            "guid":   guid,
            "pii_columns": [],
            "safe_columns": [],
        }
    if skipped:
        print(f"  {skipped} excluded tables skipped", file=sys.stderr)

    # ── Step 2: fetch ALL columns (paginate) ─────────────────────────────────
    print("Fetching all columns (paginating)...", file=sys.stderr)
    all_cols = fetch_all_pages(
        "/metadata/list?type=LOGICAL_COLUMN&category=ALL", cookies
    )
    print(f"  {len(all_cols)} total columns fetched", file=sys.stderr)

    # ── Step 3: join columns → tables + classify PII ─────────────────────────
    orphan_count = 0
    for col in all_cols:
        owner_guid = col.get("owner", "")
        col_name = col.get("name", "")
        if owner_guid not in tables_by_guid:
            orphan_count += 1
            continue

        is_pii = classify_pii(col_name)
        if is_pii:
            tables_by_guid[owner_guid]["pii_columns"].append(col_name)
        else:
            tables_by_guid[owner_guid]["safe_columns"].append(col_name)

    if orphan_count:
        print(f"  {orphan_count} columns had no matching table (skipped)", file=sys.stderr)

    # ── Step 4: load existing descriptions (preserve them across refreshes) ──
    existing_descriptions: dict = {}
    if out_path.exists():
        try:
            existing_brain = json.loads(out_path.read_text())
            for t in existing_brain.get("tables", []):
                desc = t.get("description", "")
                if desc:
                    existing_descriptions[t["name"]] = desc
        except Exception:
            pass  # stale or corrupted file — ignore

    # ── Step 5: sort and build output ────────────────────────────────────────
    tables_list = sorted(tables_by_guid.values(), key=lambda t: t["name"])
    for t in tables_list:
        t["description"] = existing_descriptions.get(t["name"], "")

    brain = {
        "generated":  datetime.now(timezone.utc).isoformat(),
        "instance":   TS_INSTANCE,
        "pii_rule": "PII columns must NOT appear in SELECT (output). They CAN be used in WHERE filters with literal values.",
        "tables": tables_list,
    }

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(brain, indent=2))
    print(f"\nBrain written to: {out_path}", file=sys.stderr)

    # Summary
    total_pii = sum(len(t["pii_columns"]) for t in tables_list)
    total_safe = sum(len(t["safe_columns"]) for t in tables_list)
    print(f"  Tables: {len(tables_list)}", file=sys.stderr)
    print(f"  Safe columns:  {total_safe}", file=sys.stderr)
    print(f"  PII columns:   {total_pii}", file=sys.stderr)


if __name__ == "__main__":
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else \
          Path("/Volumes/MyDrive/git-ot-main/OrderTechLeads/.github/skills/thoughtspot-reader/ts-brain.json")
    main(out)
