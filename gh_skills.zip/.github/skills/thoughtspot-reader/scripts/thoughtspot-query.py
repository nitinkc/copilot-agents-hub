#!/usr/bin/env python3
"""
thoughtspot-query.py — ThoughtSpot V1 API query tool (SSO auth)

Cross-platform Python port of thoughtspot-query.sh.
Works on macOS, Linux, and Windows without Git Bash/WSL.

Auth: Comcast SSO cookies (JSESSIONID + clientId + route)
API:  ThoughtSpot V1 (/callosum/v1/ + /callosum/v1/tspublic/v1/)

Setup:
  1. python3 thoughtspot-query.py login --install   (first time only)
  2. python3 thoughtspot-query.py login              (opens browser for SSO)
  3. python3 thoughtspot-query.py check              (verify auth)
"""
from __future__ import print_function

import json
import os
import re
import ssl
import subprocess
import sys
import time
from pathlib import Path

try:
    from urllib.request import Request, urlopen
    from urllib.parse import quote as url_quote
    from urllib.error import URLError, HTTPError
except ImportError:
    # Python 2 fallback (should not happen, but be safe)
    from urllib2 import Request, urlopen, URLError, HTTPError
    from urllib import quote as url_quote

# ─── Configuration ───────────────────────────────────────────────────────────

SCRIPT_DIR = Path(__file__).resolve().parent
TS_INSTANCE = os.environ.get("TS_INSTANCE", "salestechts.xfinity.com")
TS_BASE = "https://{}".format(TS_INSTANCE)
API_BASE = "{}/callosum/v1".format(TS_BASE)
DATA_API_BASE = "{}/callosum/v1/tspublic/v1".format(TS_BASE)
TIMEOUT = int(os.environ.get("TIMEOUT", "60"))
MAX_RESULTS = int(os.environ.get("MAX_RESULTS", "200"))

CONFIG_DIR = Path.home() / ".ordertech-thoughtspot"
COOKIE_FILE = CONFIG_DIR / "cookies.txt"

# Disable SSL verification for internal certs (matches curl -k)
SSL_CTX = ssl.create_default_context()
SSL_CTX.check_hostname = False
SSL_CTX.verify_mode = ssl.CERT_NONE

# ─── PII Column Blocklist ────────────────────────────────────────────────────
# Columns that must NEVER appear in SELECT (output) position.
# They CAN be used freely as WHERE filters with literal values.
# GUIDs/UUIDs, aggregate counts (*_count), zip codes are NOT PII.

PII_COLUMNS = [
    # Phone / device identifiers (exact values only, not *_count)
    "iccid", "imei", "imsi", "mdn",
    "portin mdn", "portin_mdn", "ported mdn", "mdn_id",
    # Contact
    "phone",
]

# Allowlist: columns containing PII keywords but that are safe (counts, flags)
PII_ALLOWLIST = [
    "mdn_count", "mdn count", "matching_mdn", "matching mdn",
    "biller_mdn", "biller mdn", "network_mdn", "network mdn",
    "hazard desc", "error msg txt", "guid", "uuid",
    "customerkey", "customer key", "subscriberkey", "subscriber key",
    "zip",
]

# ─── Helpers ─────────────────────────────────────────────────────────────────


def die(msg):
    print("[ERROR] {}".format(msg), file=sys.stderr)
    sys.exit(1)


def warn(msg):
    print("[WARN] {}".format(msg), file=sys.stderr)


def info(msg):
    print("[INFO] {}".format(msg), file=sys.stderr)


def ensure_config_dir():
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    # chmod 700 on Unix; no-op on Windows (NTFS ignores POSIX bits)
    try:
        CONFIG_DIR.chmod(0o700)
    except OSError:
        pass


# ─── Cookie Management ──────────────────────────────────────────────────────


def load_cookies():
    """Load cookie string from file. Dies if missing or empty."""
    if not COOKIE_FILE.is_file():
        die("No cookie file found. Run: {} login".format(sys.argv[0]))
    cookies = COOKIE_FILE.read_text().strip()
    if not cookies:
        die("Cookie file is empty. Run: {} login".format(sys.argv[0]))
    return cookies


def save_cookies(cookies):
    """Save cookie string to file with restricted permissions."""
    ensure_config_dir()
    COOKIE_FILE.write_text(cookies)
    try:
        COOKIE_FILE.chmod(0o600)
    except OSError:
        pass
    info("Cookies saved to {}".format(COOKIE_FILE))


# ─── HTTP Helpers ────────────────────────────────────────────────────────────


def _request(url, method="GET", body=None, headers=None, timeout=None):
    """Make an HTTP request and return (status_code, response_body_str).
    Returns (0, error_msg) on connection failure."""
    if timeout is None:
        timeout = TIMEOUT
    hdrs = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "X-Requested-With": "XMLHttpRequest",
    }
    if headers:
        hdrs.update(headers)
    data = body.encode("utf-8") if body else None
    req = Request(url, data=data, headers=hdrs, method=method)
    try:
        resp = urlopen(req, timeout=timeout, context=SSL_CTX)
        return (resp.getcode(), resp.read().decode("utf-8", errors="replace"))
    except HTTPError as e:
        body_text = ""
        try:
            body_text = e.read().decode("utf-8", errors="replace")
        except Exception:
            pass
        return (e.code, body_text)
    except (URLError, OSError) as e:
        return (0, str(e))


def api_get(endpoint, timeout=None):
    """Authenticated GET to the metadata API."""
    cookies = load_cookies()
    url = "{}{}".format(API_BASE, endpoint)
    code, body = _request(url, "GET", headers={"Cookie": cookies}, timeout=timeout)
    if code == 0:
        die("API request failed: {}".format(body))
    return body


def api_post(endpoint, body="{}", timeout=None):
    """Authenticated POST to the metadata API."""
    cookies = load_cookies()
    url = "{}{}".format(API_BASE, endpoint)
    code, resp = _request(url, "POST", body=body, headers={"Cookie": cookies}, timeout=timeout)
    if code == 0:
        die("API request failed: {}".format(resp))
    return resp


def data_api_post(endpoint, timeout=None):
    """Authenticated POST to the tspublic/v1 data API (URL-param style)."""
    cookies = load_cookies()
    url = "{}{}".format(DATA_API_BASE, endpoint)
    code, resp = _request(url, "POST", headers={"Cookie": cookies}, timeout=timeout)
    if code == 0:
        die("API request failed: {}".format(resp))
    return resp


def api_download(endpoint, output_path, accept="application/octet-stream"):
    """Authenticated GET/POST that saves the response body to a file."""
    cookies = load_cookies()
    url = "{}{}".format(API_BASE, endpoint)
    hdrs = {
        "Accept": accept,
        "X-Requested-With": "XMLHttpRequest",
        "Cookie": cookies,
    }
    req = Request(url, headers=hdrs)
    try:
        resp = urlopen(req, timeout=TIMEOUT, context=SSL_CTX)
        data = resp.read()
        Path(output_path).write_bytes(data)
        return len(data)
    except (HTTPError, URLError, OSError) as e:
        die("Download failed: {}".format(e))
        return 0  # unreachable


# ─── PII Guard ───────────────────────────────────────────────────────────────


def assert_no_pii_in_output(query):
    """Block PII columns in SELECT (output) position. Exit code 2 if found.
    Columns used as WHERE filters (with = 'value') are stripped first."""
    q = query.lower()
    # Strip filter expressions:  [col] = 'value',  [col] = value,  [col] != ..., etc.
    stripped = re.sub(r"\[[^\]]+\]\s*=\s*'[^']*'", "", q)
    stripped = re.sub(r"\[[^\]]+\]\s*(?:!=|<>|>=|<=|>|<|in)\s*[^\[\]]*", "", stripped)
    stripped = re.sub(r"\[[^\]]+\]\s*=\s*[^\[\]\s]+", "", stripped)

    # Extract remaining column names from [brackets] — these are SELECT columns
    select_cols = re.findall(r"\[([^\]]+)\]", stripped)
    if not select_cols:
        return

    blocked = []
    for col_name in select_cols:
        # Check allowlist first
        if any(allow in col_name for allow in PII_ALLOWLIST):
            continue
        # Check PII blocklist
        if any(pii in col_name for pii in PII_COLUMNS):
            blocked.append(col_name)

    if blocked:
        print("[PII-BLOCK] Query rejected — PII column(s) in output: {}".format(
            ", ".join(blocked)), file=sys.stderr)
        print("[PII-BLOCK] These columns return personal data to the LLM context.", file=sys.stderr)
        print("[PII-BLOCK] Use as filter only: [column] = 'value'", file=sys.stderr)
        print("[PII-BLOCK] Or use aggregates: count, sum, average.", file=sys.stderr)
        sys.exit(2)


# ─── Commands ────────────────────────────────────────────────────────────────


def cmd_check():
    print("ThoughtSpot Connection Check")
    print("=" * 43)
    print("  Instance: {}".format(TS_INSTANCE))
    print("  API Base: {}".format(API_BASE))

    if not COOKIE_FILE.is_file():
        print("  Cookies:  MISSING")
        print("  Auth:     NOT CONFIGURED")
        print()
        print("  Run: {} login".format(sys.argv[0]))
        sys.exit(1)

    # Cookie age
    age_s = int(time.time() - COOKIE_FILE.stat().st_mtime)
    age_h = age_s // 3600
    print("  Cookies:  present (age: {}h)".format(age_h))

    # Test API connectivity
    cookies = COOKIE_FILE.read_text().strip()
    url = "{}/session/info".format(API_BASE)
    code, body = _request(url, "GET", headers={"Cookie": cookies}, timeout=15)

    if code == 200:
        print("  Auth:     VALID (HTTP {})".format(code))
        try:
            d = json.loads(body)
            user = d.get("userName", "unknown")
            display = d.get("userDisplayName", "")
            print("  User:     {} ({})".format(user, display))
        except (json.JSONDecodeError, ValueError):
            pass
    elif code in (401, 403):
        print("  Auth:     EXPIRED (HTTP {})".format(code))
        print()
        print("  Session expired. Run: {} login".format(sys.argv[0]))
        sys.exit(1)
    else:
        print("  Auth:     FAILED (HTTP {})".format(code))
        print()
        print("  Cannot reach ThoughtSpot. Check VPN and run: {} login".format(sys.argv[0]))
        sys.exit(1)

    print("=" * 43)


def cmd_login(mode=""):
    if mode == "--install":
        info("Installing Playwright and Chromium...")
        subprocess.run([sys.executable, "-m", "pip", "install", "playwright"],
                       check=True, timeout=120)
        subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"],
                       check=True, timeout=120)
        info("Done. Now run: {} login".format(sys.argv[0]))
        return

    login_script = SCRIPT_DIR / "thoughtspot-sso-login.py"
    if not login_script.is_file():
        die("Login script not found: {}".format(login_script))

    cmd = [sys.executable, str(login_script)]
    if mode == "--headed":
        cmd.append("--headed")
    result = subprocess.run(cmd, timeout=600)
    if result.returncode != 0:
        die("SSO login failed. Try: {} login --headed".format(sys.argv[0]))

    info("Login successful. Verifying...")
    cmd_check()


def cmd_set_cookie():
    print("Manual cookie setup for ThoughtSpot")
    print("-" * 37)
    print()
    print("1. Open https://{} in Chrome/Firefox".format(TS_INSTANCE))
    print("2. Sign in via Comcast SSO")
    print("3. Open DevTools (F12) > Network tab")
    print("4. Click any API request to {}".format(TS_INSTANCE))
    print("5. Copy the Cookie header value (contains JSESSIONID and clientId)")
    print()
    print("Paste the full cookie string (then press Enter):")
    try:
        cookie_val = input().strip()
    except (EOFError, KeyboardInterrupt):
        die("No cookie provided.")
    if not cookie_val:
        die("No cookie provided.")
    save_cookies(cookie_val)
    info("Verifying cookie...")
    cmd_check()


def cmd_system_info():
    response = api_get("/system/config")
    try:
        d = json.loads(response)
        print("ThoughtSpot System Info")
        print("=" * 45)
        print("  SAML:       {}".format(d.get("samlEnabled", "unknown")))
        mp = d.get("mixpanelConfig", {})
        print("  Cluster:    {}".format(mp.get("clusterName", "unknown")))
        print("  Cluster ID: {}".format(mp.get("clusterId", "unknown")))
        print("  Support:    {}".format(d.get("supportEmail", "unknown")))
        print("=" * 45)
    except (json.JSONDecodeError, ValueError):
        print(response)


def _format_metadata_list(response, type_label):
    """Parse a metadata/list response and print a table."""
    try:
        data = json.loads(response)
    except (json.JSONDecodeError, ValueError):
        print(response)
        return
    headers = data.get("headers", [])
    if not headers:
        print("No {} found.".format(type_label))
        return
    print("{} ({} found):".format(type_label, len(headers)))
    print()
    print("{:<55} {:<38} {}".format("Name", "GUID", "Author"))
    print("-" * 120)
    for h in headers:
        name = h.get("name", "untitled")[:53]
        guid = h.get("id", "")
        author = h.get("authorName", "")
        print("{:<55} {:<38} {}".format(name, guid, author))


def cmd_search(term):
    if not term:
        die("Usage: {} search <term>".format(sys.argv[0]))

    # Search pinboards, answers, tables
    types = [
        ("LIVEBOARD", "PINBOARD_ANSWER_BOOK"),
        ("ANSWER", "QUESTION_ANSWER_BOOK"),
        ("TABLE", "LOGICAL_TABLE"),
    ]
    results = []
    for label, api_type in types:
        try:
            raw = api_get("/metadata/list?type={}&batchsize={}&pattern={}".format(
                api_type, MAX_RESULTS, url_quote(term)))
            data = json.loads(raw)
            for h in data.get("headers", []):
                results.append((label, h.get("name", "?"), h.get("id", ""),
                                h.get("authorName", "")))
        except Exception:
            pass

    if not results:
        print("No results found.")
        return

    print('Found {} result(s) matching "{}":'.format(len(results), term))
    print()
    print("{:<12} {:<55} {:<38} {}".format("Type", "Name", "GUID", "Author"))
    print("-" * 130)
    for typ, name, guid, author in results[:50]:
        print("{:<12} {:<55} {:<38} {}".format(typ, name[:53], guid, author))


def cmd_liveboards():
    resp = api_get("/metadata/list?type=PINBOARD_ANSWER_BOOK&batchsize={}".format(MAX_RESULTS))
    _format_metadata_list(resp, "Liveboards")


def cmd_answers():
    resp = api_get("/metadata/list?type=QUESTION_ANSWER_BOOK&batchsize={}".format(MAX_RESULTS))
    _format_metadata_list(resp, "Saved Answers")


def cmd_tables():
    resp = api_get("/metadata/list?type=LOGICAL_TABLE&batchsize={}".format(MAX_RESULTS))
    try:
        data = json.loads(resp)
    except (json.JSONDecodeError, ValueError):
        print(resp)
        return
    headers = data.get("headers", [])
    if not headers:
        print("No tables/worksheets found.")
        return
    print("Tables/Worksheets ({} found):".format(len(headers)))
    print()
    print("{:<55} {:<38} {:<15} {}".format("Name", "GUID", "Type", "Author"))
    print("-" * 130)
    for h in headers:
        name = h.get("name", "untitled")[:53]
        guid = h.get("id", "")
        sub_type = h.get("type", "")
        author = h.get("authorName", "")
        print("{:<55} {:<38} {:<15} {}".format(name, guid, sub_type, author))


def cmd_columns(pattern=""):
    url = "/metadata/list?type=LOGICAL_COLUMN&batchsize={}".format(MAX_RESULTS)
    if pattern:
        url += "&pattern={}".format(url_quote(pattern))
    resp = api_get(url)
    try:
        data = json.loads(resp)
    except (json.JSONDecodeError, ValueError):
        print(resp)
        return
    headers = data.get("headers", [])
    if not headers:
        print("No columns found.")
        return
    print("Columns ({} found):".format(len(headers)))
    print()
    print("{:<45} {:<38} {}".format("Column Name", "GUID", "Owner"))
    print("-" * 110)
    for h in headers:
        name = h.get("name", "untitled")[:43]
        guid = h.get("id", "")
        owner = h.get("owner", "")[:30]
        print("{:<45} {:<38} {}".format(name, guid, owner))


def cmd_liveboard_data(guid):
    if not guid:
        die("Usage: {} liveboard-data <liveboard-guid>".format(sys.argv[0]))
    url = "/pinboarddata?id={}&batchsize={}&formattype=COMPACT".format(guid, MAX_RESULTS)
    resp = data_api_post(url)
    try:
        data = json.loads(resp)
    except (json.JSONDecodeError, ValueError):
        print(resp)
        return

    if isinstance(data, dict):
        vizs = [(k, v) for k, v in data.items() if isinstance(v, dict)]
        print("Liveboard data: {} visualization(s)".format(len(vizs)))
        print("=" * 60)
        for i, (viz_id, viz) in enumerate(vizs):
            name = viz.get("name", viz_id[:20])
            col_names = viz.get("columnNames", [])
            rows = viz.get("data", [])
            print()
            print("  [{}] {}".format(i + 1, name))
            print("      Columns: {}  Rows: {}".format(len(col_names), len(rows)))
            if col_names:
                hdr = ", ".join(str(c) for c in col_names[:8])
                if len(col_names) > 8:
                    hdr += "..."
                print("      Headers: {}".format(hdr))
            if rows:
                for row in rows[:5]:
                    vals = [r.get("v", "") if isinstance(r, dict) else r for r in row]
                    print("      {}".format(vals))
                if len(rows) > 5:
                    print("      ... ({} more rows)".format(len(rows) - 5))
        print()
    else:
        print(json.dumps(data, indent=2))


def cmd_answer_data(guid):
    if not guid:
        die("Usage: {} answer-data <answer-guid>".format(sys.argv[0]))
    resp = api_get("/metadata/details?type=QUESTION_ANSWER_BOOK&id={}".format(guid))
    try:
        data = json.loads(resp)
        print(json.dumps(data, indent=2)[:5000])
    except (json.JSONDecodeError, ValueError):
        print(resp)


def cmd_export_liveboard(guid, output=""):
    if not guid:
        die("Usage: {} export-liveboard <guid> [output-file]".format(sys.argv[0]))
    if not output:
        output = os.path.join(os.environ.get("TEMP", os.environ.get("TMPDIR", "/tmp")),
                              "thoughtspot-liveboard-export.pdf")
    info("Exporting liveboard {} to {} ...".format(guid, output))
    size = api_download("/export/pinboard/pdf?id={}".format(guid), output,
                        accept="application/pdf")
    info("Exported to: {} ({} bytes)".format(output, size))
    print(output)


def cmd_export_answer(guid, output=""):
    if not guid:
        die("Usage: {} export-answer <guid> [output-file]".format(sys.argv[0]))
    if not output:
        output = os.path.join(os.environ.get("TEMP", os.environ.get("TMPDIR", "/tmp")),
                              "thoughtspot-answer-export.csv")
    info("Exporting answer {} to {} ...".format(guid, output))
    size = api_download("/answer/data?id={}&batchsize=10000".format(guid), output,
                        accept="text/csv")
    info("Exported to: {} ({} bytes)".format(output, size))
    print(output)


def cmd_search_data(query, source_guid):
    if not query:
        die("Usage: {} search-data \"<TQL query>\" <data-source-guid>".format(sys.argv[0]))
    if not source_guid:
        die("Usage: {} search-data \"<TQL query>\" <data-source-guid>".format(sys.argv[0]))

    # PII output guard
    assert_no_pii_in_output(query)

    encoded_query = url_quote(query)
    url = "/searchdata?query_string={}&data_source_guid={}&batchsize={}&formattype=COMPACT".format(
        encoded_query, source_guid, MAX_RESULTS)
    resp = data_api_post(url)

    try:
        data = json.loads(resp)
    except (json.JSONDecodeError, ValueError):
        print(resp)
        return

    if isinstance(data, dict):
        col_names = data.get("columnNames", data.get("column_names", []))
        rows = data.get("data", data.get("data_rows", []))
        print("Search results: {} columns, {} rows".format(len(col_names), len(rows)))
        print("=" * 60)
        if col_names:
            hdr = ", ".join(str(c) for c in col_names[:10])
            if len(col_names) > 10:
                hdr += "..."
            print("  Headers: {}".format(hdr))
        print()
        for row in rows[:30]:
            if isinstance(row, list):
                vals = [r.get("v", "") if isinstance(r, dict) else r for r in row]
                print("  {}".format(vals))
            else:
                print("  {}".format(row))
        if len(rows) > 30:
            print("  ... ({} more rows)".format(len(rows) - 30))
    else:
        print(json.dumps(data, indent=2))


def cmd_describe_table(table_name):
    if not table_name:
        die("Usage: {} describe-table <table-name>".format(sys.argv[0]))

    brain_file = SCRIPT_DIR.parent / "ts-brain.json"
    if not brain_file.is_file():
        die("Brain file not found: {}. Run build-brain.py first.".format(brain_file))

    with open(str(brain_file), "r") as f:
        brain = json.load(f)

    target = table_name.lower()
    matches = [t for t in brain["tables"] if target in t["name"].lower()]
    if not matches:
        print("No table matching '{}' found.".format(table_name), file=sys.stderr)
        sys.exit(1)

    for t in matches:
        print("Table: {}".format(t["name"]))
        print("GUID:  {}".format(t["guid"]))
        desc = t.get("description", "")
        if desc:
            print("Description: {}".format(desc))
        safe = t.get("safe_columns", [])
        pii = t.get("pii_columns", [])
        print("Safe columns ({}):".format(len(safe)))
        for c in safe:
            name = c if isinstance(c, str) else c.get("name", "")
            print("  {}".format(name))
        if pii:
            print("PII columns ({}) — use in WHERE only:".format(len(pii)))
            for c in pii:
                name = c if isinstance(c, str) else c.get("name", "")
                print("  {}".format(name))
        print()


def cmd_resolve_guid(table_name):
    if not table_name:
        die("Usage: {} resolve-guid <table-name-substring>".format(sys.argv[0]))

    resp = api_get("/metadata/list?type=LOGICAL_TABLE&batchsize={}".format(MAX_RESULTS))
    try:
        data = json.loads(resp)
    except (json.JSONDecodeError, ValueError):
        die("Invalid response from API")
        return

    target = table_name.lower()
    matches = [(h["name"], h["id"]) for h in data.get("headers", [])
               if target in h.get("name", "").lower()]
    if not matches:
        print("No table matching '{}' found.".format(table_name), file=sys.stderr)
        sys.exit(1)

    for name, guid in matches:
        print("{}  {}".format(guid, name))


# ─── Main ────────────────────────────────────────────────────────────────────


def print_help():
    prog = sys.argv[0]
    print("Usage: {} <command> [args...]".format(prog))
    print()
    print("Commands:")
    print("  check                          Verify auth status")
    print("  login [--install|--headed]     SSO login via Playwright")
    print("  set-cookie                     Manual cookie paste")
    print("  system-info                    Instance info")
    print("  search <term>                  Search metadata by name")
    print("  liveboards                     List all liveboards")
    print("  answers                        List all saved answers")
    print("  tables                         List tables/worksheets")
    print("  columns [pattern]              List available columns")
    print("  liveboard-data <guid>          Get liveboard visualization data")
    print("  answer-data <guid>             Get saved answer data")
    print("  export-liveboard <guid> [out]  Export liveboard as PDF")
    print("  export-answer <guid> [out]     Export answer as CSV")
    print('  search-data "<query>" <src>    Run TQL search against data source')
    print("  describe-table <name>          Show table GUID + columns from brain")
    print("  resolve-guid <name>            Live API lookup — get current GUID")
    print()
    print("TQL query syntax:")
    print("  Use [Column Name] for column references")
    print('  Example: search-data "[Tenant Id] [Status Cd]" <worksheet-guid>')
    print()
    print("Environment:")
    print("  TS_INSTANCE   ThoughtSpot host (default: salestechts.xfinity.com)")
    print("  TIMEOUT       API call timeout in seconds (default: 60)")
    print("  MAX_RESULTS   Max metadata results (default: 200)")


def main():
    args = sys.argv[1:]
    cmd = args[0] if args else "help"
    rest = args[1:]

    commands = {
        "check":            lambda: cmd_check(),
        "login":            lambda: cmd_login(rest[0] if rest else ""),
        "set-cookie":       lambda: cmd_set_cookie(),
        "system-info":      lambda: cmd_system_info(),
        "search":           lambda: cmd_search(rest[0] if rest else ""),
        "liveboards":       lambda: cmd_liveboards(),
        "answers":          lambda: cmd_answers(),
        "tables":           lambda: cmd_tables(),
        "columns":          lambda: cmd_columns(rest[0] if rest else ""),
        "liveboard-data":   lambda: cmd_liveboard_data(rest[0] if rest else ""),
        "answer-data":      lambda: cmd_answer_data(rest[0] if rest else ""),
        "export-liveboard": lambda: cmd_export_liveboard(
            rest[0] if rest else "", rest[1] if len(rest) > 1 else ""),
        "export-answer":    lambda: cmd_export_answer(
            rest[0] if rest else "", rest[1] if len(rest) > 1 else ""),
        "search-data":      lambda: cmd_search_data(
            rest[0] if rest else "", rest[1] if len(rest) > 1 else ""),
        "describe-table":   lambda: cmd_describe_table(rest[0] if rest else ""),
        "resolve-guid":     lambda: cmd_resolve_guid(rest[0] if rest else ""),
        "help":             lambda: print_help(),
        "--help":           lambda: print_help(),
        "-h":               lambda: print_help(),
    }

    handler = commands.get(cmd)
    if handler:
        handler()
    else:
        die("Unknown command: {}. Run: {} help".format(cmd, sys.argv[0]))


if __name__ == "__main__":
    main()
