#!/usr/bin/env python3
"""
thoughtspot-sso-login.py — Automated SSO cookie refresh for ThoughtSpot

Uses Playwright (headless Chromium) with persistent browser state so
Comcast Azure AD SSO only needs to be completed once interactively.
Subsequent runs reuse the saved session and refresh the cookie headlessly.

Cookie capture strategy:
  - Primary: CDP Network.responseReceivedExtraInfo → raw Set-Cookie headers
  - Fallback 1: Playwright response.headers_array() on SAML callback URL
  - Fallback 2: context.cookies() after SSO redirect completes

The key is capturing cookies from the SAML POST callback response
(/callosum/v1/saml/login) which sets JSESSIONID, clientId, route.

Flow:
  1. First run: opens visible Chromium → user completes Azure AD SSO/MFA
  2. Playwright saves session to ~/.ordertech-thoughtspot/browser-state/
  3. Later runs: headless → Azure AD auto-renews → no interaction needed
  4. If session expires, falls back to visible browser automatically

Prerequisites:
    pip3 install playwright
    python3 -m playwright install chromium

Usage:
    python3 thoughtspot-sso-login.py                  # login (default)
    python3 thoughtspot-sso-login.py --headed         # force visible browser
    python3 thoughtspot-sso-login.py --verify         # test saved cookie
    python3 thoughtspot-sso-login.py --install        # install dependencies
"""

import argparse
import os
import shutil
import sys
import time
from pathlib import Path

# ── Constants ────────────────────────────────────────────────────────────────
CONFIG_DIR = Path.home() / ".ordertech-thoughtspot"
BROWSER_STATE_DIR = CONFIG_DIR / "browser-state"
COOKIE_FILE = CONFIG_DIR / "cookies.txt"

TS_INSTANCE = os.environ.get("TS_INSTANCE", "salestechts.xfinity.com")
TS_BASE_URL = "https://" + TS_INSTANCE

# SAML callback URL pattern — this is where cookies are SET
SAML_CALLBACK_PATTERN = "/callosum/v1/saml/login"

# Session cookies we need (at minimum JSESSIONID + clientId)
SESSION_COOKIES = {"JSESSIONID", "clientId"}
# Bonus cookies to capture if available
OPTIONAL_COOKIES = {"route", "SERVERID", "userGUID", "isFirstLogin", "token", "SESSION"}
# These cookies are noise — never save
IGNORE_COOKIES = {"mp_f14b3a7f47b202a3ca8e03397df2ff48_mixpanel"}

NAV_TIMEOUT_MS = 90_000          # 90s for initial page load (VPN + SSO redirects)
SSO_WAIT_TIMEOUT_MS = 300_000    # 5 min for user to complete MFA
POST_LOGIN_SETTLE_S = 3          # seconds to wait after redirect
VERIFY_TIMEOUT_S = 30            # timeout for cookie verification request

USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15"
)


# ── Install ──────────────────────────────────────────────────────────────────
def install_deps():
    """Install Playwright and Chromium."""
    import subprocess
    print("Installing playwright...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "playwright"])
    print("\nInstalling Chromium browser...")
    subprocess.check_call([sys.executable, "-m", "playwright", "install", "chromium"])
    print("\nDone! You can now run:")
    print("  python3 thoughtspot-sso-login.py")


# ── Cookie verification ─────────────────────────────────────────────────────
def verify_cookie():
    """Verify a saved cookie works by making a test REST API v2 call.
    Returns True if the cookie is valid, False otherwise."""
    import subprocess

    if not COOKIE_FILE.exists():
        print("  ✗ Cookie file missing: {}".format(COOKIE_FILE))
        return False

    cookie_val = COOKIE_FILE.read_text().strip()
    if not cookie_val:
        print("  ✗ Cookie file empty: {}".format(COOKIE_FILE))
        return False

    # Use V1 session info endpoint
    test_url = "{}/callosum/v1/session/info".format(TS_BASE_URL)

    try:
        result = subprocess.run(
            [
                "curl", "-ksS", "--max-time", str(VERIFY_TIMEOUT_S),
                "-o", "/dev/null", "-w", "%{http_code}",
                "-H", "Accept: application/json",
                "-H", "X-Requested-With: XMLHttpRequest",
                "-b", cookie_val,
                test_url,
            ],
            capture_output=True, text=True, timeout=VERIFY_TIMEOUT_S + 5
        )
        http_code = result.stdout.strip()
        if http_code == "200":
            print("  ✓ Cookie valid (HTTP 200)")
            return True
        else:
            print("  ✗ Cookie invalid (HTTP {})".format(http_code))
            return False
    except Exception as e:
        print("  ✗ Verification failed: {}".format(e))
        return False


# ── Nuke browser state ──────────────────────────────────────────────────────
def _nuke_browser_state():
    """Remove corrupted browser state directory."""
    if BROWSER_STATE_DIR.exists():
        size_mb = sum(f.stat().st_size for f in BROWSER_STATE_DIR.rglob('*') if f.is_file()) / (1024 * 1024)
        print("  Nuking browser state ({:.1f} MB)...".format(size_mb))
        shutil.rmtree(BROWSER_STATE_DIR)
    BROWSER_STATE_DIR.mkdir(parents=True, exist_ok=True)


# ── Parse Set-Cookie header ──────────────────────────────────────────────────
def _parse_set_cookie(header_value):
    """Parse a single Set-Cookie header into (name, value).
    Returns None if not parseable."""
    if "=" not in header_value:
        return None
    # Take only name=value part (before any ; attributes)
    name_val = header_value.strip().split(";")[0]
    if "=" not in name_val:
        return None
    name, val = name_val.split("=", 1)
    return (name.strip(), val.strip())


# ── Extract cookies from browser context (fallback) ─────────────────────────
def _extract_cookies_from_context(context):
    """Fallback: extract cookies via Playwright context.cookies() API."""
    url_cookies = context.cookies(TS_BASE_URL)
    cookie_map = {}
    for c in url_cookies:
        if c["name"] not in IGNORE_COOKIES:
            cookie_map[c["name"]] = c["value"]
    return cookie_map


# ── Build cookie string from map ────────────────────────────────────────────
def _build_cookie_string(cookie_map):
    """Build a cookie header string, validating we have session cookies."""
    if not cookie_map:
        return None, "no cookies captured"
    
    # Check if we have the critical session cookies
    have_session = SESSION_COOKIES.issubset(set(cookie_map.keys()))
    if not have_session:
        missing = SESSION_COOKIES - set(cookie_map.keys())
        return None, "missing required cookies: {}".format(missing)
    
    cookie_str = "; ".join("{}={}".format(k, v) for k, v in cookie_map.items())
    return cookie_str, None


# ── SSO Login flow ──────────────────────────────────────────────────────────
def do_login(headed=False):
    """Perform SSO login via Playwright with CDP cookie capture.

    Cookie capture strategy (in priority order):
      1. CDP Network.responseReceivedExtraInfo → raw Set-Cookie headers
         (captures cookies from SAML POST callback before browser processes them)
      2. Playwright context.cookies() after page settles on TS domain
         (fallback if CDP events were missed)

    Recovery chain:
      1. Headless (if browser state exists — Azure AD session may auto-renew)
      2. Headed (user completes MFA)
      3. Nuke state + Headed (corrupted state recovery)
    """
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("[ERROR] Playwright not installed. Run:")
        print("  python3 -m pip install playwright")
        print("  python3 -m playwright install chromium")
        sys.exit(1)

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    BROWSER_STATE_DIR.mkdir(parents=True, exist_ok=True)

    # Determine approach order
    has_state = any(BROWSER_STATE_DIR.iterdir()) if BROWSER_STATE_DIR.exists() else False

    if headed:
        attempts = [("headed", True)]
    elif has_state:
        attempts = [("headless", False), ("headed", True), ("nuke+headed", True)]
    else:
        attempts = [("headed", True)]

    for attempt_name, use_headed in attempts:
        print("  Attempting SSO login: {} ...".format(attempt_name))

        if attempt_name == "nuke+headed":
            _nuke_browser_state()

        try:
            with sync_playwright() as p:
                browser = p.chromium.launch_persistent_context(
                    user_data_dir=str(BROWSER_STATE_DIR),
                    headless=not use_headed,
                    user_agent=USER_AGENT,
                    accept_downloads=False,
                    ignore_https_errors=True,
                    viewport={"width": 1280, "height": 800},
                )

                page = browser.pages[0] if browser.pages else browser.new_page()

                # ── CDP-based cookie capture (primary strategy) ──────────
                # This captures Set-Cookie headers at the network layer,
                # before they're processed by the browser cookie jar.
                # Works reliably for SAML POST callbacks with HttpOnly cookies.
                cdp_cookies = {}
                cdp_session = None
                try:
                    cdp_session = browser.new_cdp_session(page)
                    cdp_session.send("Network.enable")

                    def on_response_extra_info(params):
                        """CDP event: fires for every response with full headers."""
                        headers = params.get("headers", {})
                        # Look for Set-Cookie in response headers
                        # CDP gives headers as a dict with the actual header name
                        for header_name, header_value in headers.items():
                            if header_name.lower() == "set-cookie":
                                # Can be multiple cookies separated by newlines
                                for line in header_value.split("\n"):
                                    parsed = _parse_set_cookie(line)
                                    if parsed and parsed[0] not in IGNORE_COOKIES:
                                        cdp_cookies[parsed[0]] = parsed[1]
                                        if parsed[0] in SESSION_COOKIES:
                                            print("  ✓ CDP captured: {} (len={})".format(
                                                parsed[0], len(parsed[1])))

                    cdp_session.on("Network.responseReceivedExtraInfo", on_response_extra_info)
                    print("  CDP network interception active")
                except Exception as e:
                    print("  CDP unavailable ({}), using fallback".format(e))

                # ── Also intercept via Playwright response event (backup) ─
                response_cookies = {}

                def handle_response(response):
                    """Playwright response handler — backup cookie capture."""
                    url = response.url
                    if TS_INSTANCE not in url:
                        return
                    try:
                        # headers_array() returns list of {name, value} dicts
                        # preserving multiple Set-Cookie headers
                        all_headers = response.headers_array()
                        for h in all_headers:
                            if h["name"].lower() == "set-cookie":
                                parsed = _parse_set_cookie(h["value"])
                                if parsed and parsed[0] not in IGNORE_COOKIES:
                                    response_cookies[parsed[0]] = parsed[1]
                    except Exception:
                        pass

                page.on("response", handle_response)

                # ── Navigate to ThoughtSpot (triggers SSO redirect) ──────
                print("  Navigating to {} ...".format(TS_BASE_URL))
                page.goto(TS_BASE_URL, timeout=NAV_TIMEOUT_MS, wait_until="domcontentloaded")

                # ── Wait for SSO completion ──────────────────────────────
                max_wait = SSO_WAIT_TIMEOUT_MS // 1000 if use_headed else 30
                if use_headed:
                    print("  Waiting for SSO completion (up to 5 minutes)...")
                    print("  → Complete Azure AD login in the browser window")

                poll_interval = 2
                elapsed = 0
                login_complete = False

                while elapsed < max_wait:
                    time.sleep(poll_interval)
                    elapsed += poll_interval

                    # Check if CDP already captured session cookies
                    if SESSION_COOKIES.issubset(set(cdp_cookies.keys())):
                        print("  ✓ All session cookies captured via CDP")
                        login_complete = True
                        break

                    # Check current URL — are we back on ThoughtSpot?
                    try:
                        current_url = page.url
                    except Exception:
                        break

                    if TS_INSTANCE not in current_url:
                        continue  # Still on Azure AD

                    # We're on ThoughtSpot domain — check if authenticated
                    # Look for the app shell (ThoughtSpot loads a SPA after auth)
                    try:
                        # If we can see the page title or app content, auth worked
                        title = page.title()
                        if title and "thoughtspot" in title.lower():
                            login_complete = True
                            break
                        # Also check if URL has hash route (SPA loaded)
                        if "#/" in current_url or "/home" in current_url:
                            login_complete = True
                            break
                    except Exception:
                        pass

                # ── Post-login settle ────────────────────────────────────
                if login_complete:
                    time.sleep(POST_LOGIN_SETTLE_S)

                # ── Collect all captured cookies ─────────────────────────
                # Priority: CDP > response headers > context.cookies()
                final_cookies = {}

                # Layer 1: context.cookies() (always available)
                ctx_cookies = _extract_cookies_from_context(browser)
                final_cookies.update(ctx_cookies)
                if ctx_cookies:
                    print("  Context cookies: {}".format(list(ctx_cookies.keys())))

                # Layer 2: Response header capture (overrides context)
                if response_cookies:
                    final_cookies.update(response_cookies)
                    print("  Response cookies: {}".format(list(response_cookies.keys())))

                # Layer 3: CDP capture (highest priority — most reliable)
                if cdp_cookies:
                    final_cookies.update(cdp_cookies)
                    print("  CDP cookies: {}".format(list(cdp_cookies.keys())))

                # Clean up CDP
                if cdp_session:
                    try:
                        cdp_session.detach()
                    except Exception:
                        pass

                browser.close()

                # ── Build and save cookie string ─────────────────────────
                cookie_str, error = _build_cookie_string(final_cookies)
                if cookie_str:
                    COOKIE_FILE.parent.mkdir(parents=True, exist_ok=True)
                    COOKIE_FILE.write_text(cookie_str)
                    COOKIE_FILE.chmod(0o600)
                    print("  ✓ Cookies saved ({} cookies: {})".format(
                        len(final_cookies), list(final_cookies.keys())
                    ))
                    return True
                else:
                    print("  ✗ Cookie capture failed: {}".format(error))
                    if final_cookies:
                        print("    Got: {}".format(list(final_cookies.keys())))
                    continue

        except Exception as e:
            print("  ✗ Attempt '{}' failed: {}".format(attempt_name, e))
            continue

    print("\n[ERROR] All login attempts failed.")
    print("  Manual fallback: run 'thoughtspot-query.sh set-cookie'")
    return False


# ── Main ────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="ThoughtSpot SSO login")
    parser.add_argument("--headed", action="store_true", help="Force visible browser")
    parser.add_argument("--verify", action="store_true", help="Verify saved cookie")
    parser.add_argument("--install", action="store_true", help="Install dependencies")
    args = parser.parse_args()

    if args.install:
        install_deps()
        return

    if args.verify:
        ok = verify_cookie()
        sys.exit(0 if ok else 1)

    # Perform login
    success = do_login(headed=args.headed)
    if not success:
        sys.exit(1)

    # Verify after login
    if not verify_cookie():
        print("[WARN] Cookie saved but verification failed. Try: --headed")
        sys.exit(1)

    print("\n  ✓ ThoughtSpot SSO login complete.")


if __name__ == "__main__":
    main()
