---
name: thoughtspot-reader
description: Read-only ThoughtSpot data retrieval for liveboards, answers, search queries, and table data. Uses Comcast SSO browser cookies with V1 API. Fetches metadata, runs search queries, and lists available content. Contains a pre-built schema brain (ts-brain.json) for dynamic query composition with automatic PII protection.
---

# Skill: ThoughtSpot Reader

## Goal

Retrieve structured data from ThoughtSpot (`salestechts.xfinity.com`) so agents can access sales analytics, reporting data, table contents, and liveboard visualizations — without mutating ThoughtSpot state.

## Inputs

- A liveboard name or search term: `"Order Summary"`, `"Fallout"`, `"SalesTech"`
- OR a liveboard/answer GUID for direct data export
- OR a ThoughtSpot search query (TQL-style): `[revenue] [region]` against a data source
- OR natural language describing what data to find (agent selects appropriate command)

## Prerequisites

**Config Directory**: `~/.ordertech-thoughtspot/` (mode 700 on Unix; on Windows, a normal directory)
- `cookies.txt` — Browser session cookies (`JSESSIONID` + `clientId`) (mode 600 on Unix)
- `browser-state/` — Playwright persistent browser state for SSO re-use

**Platform**: macOS, Linux, and Windows. All scripts are Python — no bash/shell dependency.

**Instance**: `salestechts.xfinity.com`
**API**: ThoughtSpot V1 at `https://salestechts.xfinity.com/callosum/v1/` (metadata) and `https://salestechts.xfinity.com/callosum/v1/tspublic/v1/` (data queries)

### Authentication Setup (Comcast SSO via Playwright)

ThoughtSpot uses Comcast SSO (Azure AD SAML). The REST API requires session cookies obtained after SSO login.

**First-time setup** (installs Playwright + Chromium):
```bash
python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py login --install
```

**Login** (opens browser for SSO if needed):
```bash
python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py login
```

**Flow**:
1. First run: opens visible Chromium → user completes Azure AD SSO/MFA
2. Playwright saves session to `~/.ordertech-thoughtspot/browser-state/`
3. Later runs: headless → Azure AD auto-renews → no interaction needed
4. If session expires, falls back to visible browser automatically

### Auth Verification

```bash
python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py check
```

Reports: cookie status, session validity, user info, instance.
Sessions auto-refresh from stored browser state when expired.

### SSO Cookie Refresh (AUTOMATIC — agents run this without asking)

When `thoughtspot-query.py` fails with "No cookie file" or "Session expired", the agent MUST
automatically refresh the cookie **without asking the user**:

1. **Verify first**:
   ```bash
   python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py check
   ```

2. **Auto-refresh** (headless if prior session exists):
   ```bash
   python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py login
   ```

3. **If Playwright is not installed**, install then retry:
   ```bash
   python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py login --install
   python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py login
   ```

4. **HARD STOP only if all automated attempts fail.** Only then tell the user to set cookies manually:
   ```bash
   python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py set-cookie
   ```

## Hard Constraints

- **Read-only**: No script performs PUT, DELETE, or state-mutating POST operations.
- **Cookie security**: Cookies stored in `~/.ordertech-thoughtspot/cookies.txt` with `chmod 600`. Never log or echo cookie values.
- **Timeout**: All curl calls have a 60-second timeout (`--max-time 60`).
- **No new dependencies**: Only `python3` (3.6+) is required. No `curl`, `jq`, or bash dependency — uses Python stdlib (`urllib`, `json`, `pathlib`). Playwright is optional (for automated SSO).
- **Cross-platform**: Works on macOS, Linux, and Windows without Git Bash or WSL.
- **Fail-safe**: If the cookie is missing or the API returns an error, the script exits with a non-zero code.

## PII Guard — MANDATORY

**The `search-data` command enforces a PII blocklist at the script level.**
Any query containing a blocked column exits with code 2 before making a network call.
PII data never reaches the LLM context.

**Blocked column categories** (enforced in `thoughtspot-query.py`):
- Phone/device: `iccid`, `imei`, `imsi`, `portin mdn`, `ported mdn`
- Contact: `phone`

**NOT blocked** (safe to SELECT):
- GUIDs/UUIDs: `customer guid`, `auth guid`, `cust guid`, etc.
- Aggregate counts: `mdn_count`, `biller_mdn_count`, `matching_mdn_count`, etc.
- Descriptions/text: `hazard desc`, `error msg txt`
- Zip codes: `zip`, `zip cd`, `zip4`
- Opaque keys: `customerkey`, `subscriberkey`

**Agent rules**:
1. NEVER put PII columns (from the blocked list above) in SELECT position. Use them only as WHERE filters with literal values.
2. If `search-data` exits with code 2 (`[PII-BLOCK]`), do NOT retry with the same columns. Rephrase as an aggregate or use PII column as filter only.
3. PII values as filter inputs are fine — pass them directly in the query string (e.g., `[Mdn] = '2125551234'`).
4. Prefer summary/aggregate queries: counts by type, groupings by region/channel/status — not individual records.

## Schema Brain — Dynamic Query Composition

**File**: `.github/skills/thoughtspot-reader/ts-brain.json`

The brain is a pre-built schema catalog generated from the live ThoughtSpot instance.
Load it to compose TQL queries for any natural language ask — without needing to query ThoughtSpot metadata at runtime.

### Brain structure

```
ts-brain.json
├── generated          ISO timestamp of last refresh
├── instance           salestechts.xfinity.com
├── pii_rule           "PII columns must NOT appear in SELECT. CAN be used in WHERE."
└── tables[]
    ├── name           worksheet/table name
    ├── description    what data this table contains and when to use it
    ├── guid           ThoughtSpot GUID (use as <source-guid> in search-data)
    ├── safe_columns[] plain string list — column names safe to SELECT
    └── pii_columns[]  plain string list — use in WHERE filters only
```

### How to use the brain for query composition

**Step A — Identify the table** using the keyword map below. The map includes GUIDs so you do NOT need to open the brain file for table selection.

**Step B — Get column names** for the target table only (do NOT load the full brain):
```bash
python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py describe-table <table-name>
```
This outputs the GUID + safe/PII column names as plain text (~50 lines). **Never `read_file` the full brain** — it's 83KB / ~24K tokens that mostly contain irrelevant tables.

Quick keyword-to-table map with GUIDs:

| User asks about | Table | GUID |
|---|---|---|
| Hazards / reconciliation / data mismatch / lean recon | `orderly_ws` | `6cea1e1d-5b53-435b-aa26-a19fa79c5389` |
| Hazard raw details by domain | `stxm_s3_lean_hazard_details_domain_tb` | `98ae8cea-e1fa-48b1-bf3c-4e07ef963ce1` |
| Lean recon orders (status, channel, intent) | `stxm_s3_lean_reconorder_tb` | `6e815fd0-ede0-4ec2-9d61-a4d2ef9075ae` |
| Lean recon order timelines / step durations | `stxm_s3_lean_reconorder_timeline_current_tb` | `c847c7ef-d7ca-45da-bfa4-4570773bf259` |
| Order verification / end-to-end order state | `stxm_s3_orderVerify_ws` | `dfcac438-9635-49c8-8e2c-be5413d0c55c` |
| BPaaS provisioning attempts / errors | `stxm_s3_bpaasProvisioningNew_ws` | `8da56339-a38c-4d6a-8ec9-14f7e955499d` |
| BPaaS fallout events / auto-resolvable | `stxm_s3_bpaasFalloutNew_ws` | `80f3eff1-3e36-4577-8ba3-3a2a589a3816` |
| Order fallout summary by channel / biller error | `stxc_Fallout_ws` | `56a4068b-de1c-4b54-a753-cb53a0b4f5d5` |
| Order volume by type / channel mix | `stxc_Orders_ws` | `859ce858-234b-44af-acba-4c5883673879` |
| Core order cancel / hold / safe connection data | `stxm_s3_order_tb` | `a1628571-965e-434e-8759-c7e59e62ac40` |
| Order item attributes (contract buyout, trade-in) | `stxm_s3_orderItem_tb` | `ac632a16-bcb4-47d4-b8ae-b1112b011bce` |
| Order fallout internal (with workflow + fallout start) | `stxm_s3_ot_orders_internal_tb` | `62d43509-aac4-4335-a990-09dd91eeb111` |
| Order summary external (channel, retry count) | `stxm_s3_ot_orders_tb` | `decc4db6-84ae-4dea-b19f-77a4961443c8` |
| Device swap timelines / fraud review | `stxm_s3_device_swap_timeline_tb` | `e414bb20-c34c-4a85-83bf-1411e5795e8e` |
| XM port-in requests / trading partner | `stxm_s3_xmportin_ws` | `f75b8278-8d78-483a-9f1c-da407da8c7f2` |
| XM daily plan/device/feature transactions | `stxm_s3_xm_etl_comcast_daily_transaction_tb` | `001a7eed-7811-4c3c-8b38-3cdf506f9714` |
| Buyflow errors / error codes / session | `stwa_BuyflowErrors_ws` | `bb35dece-e7ed-4ebd-a613-600f8a6457cb` |
| Buyflow offers / LOB / product | `stwa_Offers_ws` | `358c22ab-a2c2-4e10-9d7e-ae33ec479d4f` |
| CRM orders / order action keys | `stxm_s3_ot_crm_orders_tb` | `a78e321f-864f-4735-8386-ad3ab39f2643` |
| Activation lines + promo + tenure | `stxm_s3_ot_activ_lines_orders_crm_rssx_promo_tenure_tb` | `7619e036-2062-469f-81c5-63698412c5b1` |
| Order fact flags (fallout, force-billed, chat) | `stxm_s3_ot_fact_tb` | `03f28642-5210-4507-9741-c08cfedefe55` |
| Developer SDLC / PR metrics | `ordertech_dev_sdlc_metrics` | `34d072c8-7e67-4685-bee9-25f6f92ae216` |
| Team SDLC / sprint velocity | `ordertech_team_sdlc_metrics` | `15aad4a1-d1e9-42a0-95f4-0b919b2b7d15` |
| Data pipeline quality / failed records | `CBM4XOE_DataQuality` | `a82fa988-fd9c-416b-98ee-9ef43d43fcac` |
| Network support chat topics (LLM-classified) | `stxm_network_unsupervised_tb` | `ed0a70ff-e02c-42d4-a238-199c50cd7cd3` |
| IOP care interactions / resolution codes | `stxm_s3_ingestion_iop_data_tb` | `334d2dbe-cc70-479b-acdb-a4883d38aba0` |
| Subscribers with multiple orders | `Subscriber_having_more_than_1_order_vw` | `f63eabd5-7db0-431e-915b-e710e0e5db66` |

**Step C — Compose a TQL query** using only `safe_columns` for SELECT.
PII columns can be used freely as WHERE filters with literal values:

```
# Safe aggregate — all from safe_columns
"[hazard_Hazard Type] [hazard_Domain] count [hazard_Active Hazard]"

# PII as filter — safe columns selected, PII column used in WHERE with literal value
"[hazard_Hazard Type] count [hazard_Active Hazard] [hazard_Mdn] = '2125551234'"
                                                    ^^^^^^^^^^^^   ^^^^^^^^^^^
                                              pii_column (filter)  literal value (OK)
```

**Step D — Run the query**:
```bash
python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py \
  search-data "<composed query>" "<table-guid>"
```

The script blocks PII column names in SELECT position (exit code 2).
PII values in WHERE filters pass through — the script only checks output columns.

### Refreshing the brain

Run when tables or columns change in ThoughtSpot:
```bash
python3 .github/skills/thoughtspot-reader/scripts/build-brain.py
# or with explicit output path:
python3 .github/skills/thoughtspot-reader/scripts/build-brain.py .github/skills/thoughtspot-reader/ts-brain.json
```



### Step 1 — Verify Connectivity

Before any query, verify the session is valid:
```bash
python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py check
```
If it reports expired or fails, follow the SSO Cookie Refresh procedure above.

### Step 2 — Determine Query Type

| User Need | Command | Notes |
|---|---|---|
| Check auth status | `check` | Validates cookies, shows user info |
| Login / refresh cookies | `login` | SSO via Playwright |
| Search for content (liveboards, answers, tables) | `search <term>` | Searches metadata by name |
| List liveboards | `liveboards` | All liveboards visible to user |
| List saved answers | `answers` | All saved answers |
| List tables/worksheets | `tables` | Data sources available |
| List columns | `columns [pattern]` | Column names for search queries |
| Get liveboard data | `liveboard-data <guid>` | JSON data for all visualizations |
| Get answer data | `answer-data <guid>` | JSON data for a saved answer |
| Export liveboard as PDF | `export-liveboard <guid> [output]` | PDF export |
| Export answer as CSV | `export-answer <guid> [output]` | CSV export |
| Run a search query | `search-data "<query>" <source-guid>` | TQL search against a data source |
| Describe table from brain | `describe-table <name>` | Offline — shows GUID + columns from brain file |
| Resolve GUID from live API | `resolve-guid <name>` | Live API fallback if brain GUIDs are stale |
| Get system info | `system-info` | Instance config |

All commands use the same invocation pattern:
```bash
python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py <command> [args...]
```

> **Stale GUID fallback**: If a `search-data` query fails with a GUID error, run `resolve-guid <table-name>` to get the current GUID from the live API. Then retry the query with the updated GUID.

### Step 3 — Execute Query

**Discovery commands**:
```bash
# Search for content by name (liveboards, answers, worksheets)
python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py search "order"

# List all liveboards
python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py liveboards

# List all saved answers
python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py answers

# List all tables/worksheets (data sources)
python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py tables

# List columns matching a pattern (needed for search-data queries)
python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py columns "order"
```

**Data retrieval**:
```bash
# Get liveboard visualization data (JSON)
python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py liveboard-data <liveboard-guid>

# Get saved answer data (JSON)
python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py answer-data <answer-guid>

# Export liveboard as CSV
python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py export-liveboard <liveboard-guid> /tmp/lb.csv

# Export answer as CSV
python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py export-answer <answer-guid> /tmp/answer.csv
```

**Search queries** (ThoughtSpot search syntax):
```bash
# Run a search against a data source
python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py search-data "[revenue] [region] top 10" <worksheet-guid>

# Search with date filter
python3 .github/skills/thoughtspot-reader/scripts/thoughtspot-query.py search-data "[order count] [date].detailed [last 7 days]" <worksheet-guid>
```

### Step 4 — ThoughtSpot Search Syntax Reference

ThoughtSpot uses a natural-language-like search syntax:

| Pattern | Example | Notes |
|---|---|---|
| Column reference | `[revenue]` | Square brackets for column names |
| Filter | `[region] = 'West'` | Equality filter |
| Top N | `top 10` | Limit results |
| Sort | `sort by [revenue] descending` | Ordering |
| Date filter | `[date] = last 7 days` | Relative date |
| Aggregation | `average [revenue]` | Built-in aggregation |
| Group by | `[revenue] [region]` | Implicit group by |

### Step 5 — Interpret Results

**search output**: List of metadata objects with name, GUID, type, author, last modified.

**liveboard-data output**: JSON with visualization data arrays — column headers + row data per visualization.

**answer-data output**: JSON with column headers and data rows for the answer.

**export-* output**: CSV file saved to the specified path.

**search-data output**: JSON with column headers and matching data rows from the data source.

## Metadata Types

| Type | API value | Description |
|---|---|---|
| Liveboard | `LIVEBOARD` | Dashboard with multiple visualizations |
| Answer | `ANSWER` | Single saved search/chart |
| Table | `LOGICAL_TABLE` | Worksheet, table, or view (data source) |
| Column | `LOGICAL_COLUMN` | Individual column in a table |
| Connection | `DATA_SOURCE` | External data connection |

## Known Instance Details

| Property | Value |
|---|---|
| Instance URL | `https://salestechts.xfinity.com` |
| API Base (metadata) | `https://salestechts.xfinity.com/callosum/v1` |
| API Base (data) | `https://salestechts.xfinity.com/callosum/v1/tspublic/v1` |
| Auth method | Comcast SSO (Azure AD SAML) → session cookies |
| Required cookies | `JSESSIONID`, `clientId` |
| Session duration | ~7 days with `remember_me`, ~3 hours without |

## Bounds & Safety

- **Max results per search**: 100,000 rows (ThoughtSpot default)
- **Timeout**: 60 seconds per API call (configurable via `TIMEOUT` env var)
- **Auth**: Cookies stored in `~/.ordertech-thoughtspot/cookies.txt` (mode 600, directory mode 700)
- **Browser state**: Persistent Playwright state for SSO auto-renew in `browser-state/`
- **Read-only**: No write/modify operations. Search, export, and list only.
- **No secrets in output**: Cookies never printed. Session info is ephemeral.

## Output Format

All commands output to stdout. Structured data is JSON. Exports write to file.
Error messages go to stderr with `[ERROR]` prefix.
Info messages go to stderr with `[INFO]` prefix.
Exit code 0 = success, non-zero = failure.
