---
name: test-quality-analysis
description: Evaluate test quality beyond coverage numbers including test design, missing test categories, anti-patterns, Spring Boot test slices, Flowable process tests, mutation testing, and contract testing.
---

# Skill: Test Quality Analysis

## Goal
Evaluate test quality (not just quantity) — are tests testing the right things, in the right way, at the right level? Produce categorized findings on test gaps and anti-patterns.

## Inputs
- Target codebase (Spring Boot microservice source and test source)
- Repository standards from `.github/instructions/`
- Playbook defaults from `.github/shared/playbook-defaults.yaml`
- Output format rules from `audit-output.instructions.md`
- SonarQube coverage report (if available, for baseline numbers)

## Rule Sources (MANDATORY — load before auditing)

Load these instruction files with `read_file`. They define the rules; this skill defines the AUDIT METHODOLOGY (what to search for, how to score).

| Instruction file | Rules used in |
|-----------------|---------------|
| `testing-and-determinism.instructions.md` | Steps 1, 2, 3, 4 (test expectations, mandatory scenarios, determinism) |
| `testing-microservices.instructions.md` | Steps 2, 4 (test types, slices, microservice testing) |
| `copilot-instructions.md` code generation discipline | Step 1 (test completeness symmetry) |
| `mission-critical-checklists.instructions.md` | Step 7 (anti-pattern scan + Socratic) |
| `flowable-standards.instructions.md` | Step 5 (BPMN test expectations) |

The instruction files are the single source of truth for what the rules ARE. This skill defines HOW to check compliance — the search patterns, diagnostic procedures, and scoring criteria.

## Hard Constraints
- SonarQube already reports line/branch coverage numbers. Focus on what the numbers do not reveal: test meaningfulness, missing scenarios, and fragility.

## Steps

### Step 1: Test Quality Assessment (Beyond Coverage Numbers)

**Are Tests Testing Behavior or Implementation?**
Search for anti-patterns:
- Tests that verify method calls were made (verify(mock).method()) without
  checking outcomes → testing implementation, not behavior
- Tests that mirror the implementation step-by-step → will break on any refactoring
- Tests that only assert "no exception thrown" → not verifying actual behavior
- Tests with no assertions at all (just calling the method)
- Standard: Test-Driven Development (Kent Beck), Growing Object-Oriented Software (GOOS)

**Assertion Quality**:
- Using assertEquals for complex objects (should use AssertJ fluent assertions)
- Missing assertion messages for debugging failures
- Testing too many things in one test (multiple unrelated assertions)
- Using assertTrue(condition) instead of specific assertions (assertThat(x).isEqualTo(y))
- Standard: AssertJ Best Practices

**Test Naming**:
- Tests named test1, test2, testMethod (should describe behavior)
- Recommended pattern: `should{ExpectedBehavior}When{Condition}`
- Missing @DisplayName annotations for readable test output
- Standard: BDD-style Test Naming

**Test Independence**:
- Tests that depend on execution order (@TestMethodOrder without necessity)
- Shared mutable state between tests (static fields, shared test fixtures)
- Tests that depend on external services being available
- Tests that depend on specific database state from other tests

**Test Completeness Symmetry** — check compliance with code generation discipline from `copilot-instructions.md`; search patterns:
- Service/controller test classes with only success-path tests → missing error/edge cases
- Fields with `@Min`/`@Max`/`@Size`/`@NotNull` but no test submitting invalid values
- `@Max(100)` tested with 50 but not 100 (at limit) and 101 (past limit) → boundary gap
- Positive-only assertions: valid input passes but no test proves invalid input fails
- POST/PUT endpoints without idempotency/duplicate tests
- Outbound calls without timeout/deadline tests

### Step 2: Missing Test Categories

Evaluate which test types exist and which are missing:

**Test Pyramid Assessment**:
| Level | Test Type | Present? | Count | Coverage Quality |
|---|---|---|---|---|
| Unit | Service/domain logic tests | {Y/N} | {n} | {assessment} |
| Unit | Controller tests (@WebMvcTest) | {Y/N} | {n} | {assessment} |
| Unit | Repository tests (@DataJpaTest) | {Y/N} | {n} | {assessment} |
| Integration | Full context (@SpringBootTest) | {Y/N} | {n} | {assessment} |
| Integration | Testcontainers (real DB) | {Y/N} | {n} | {assessment} |
| Contract | API contract tests (Pact/SCC) | {Y/N} | {n} | {assessment} |
| BPMN | Flowable process tests | {Y/N} | {n} | {assessment} |
| E2E | End-to-end API tests | {Y/N} | {n} | {assessment} |
| Performance | Load/stress tests (JMH/Gatling) | {Y/N} | {n} | {assessment} |
| Security | Security-focused tests | {Y/N} | {n} | {assessment} |
| Mutation | Mutation tests (PIT) | {Y/N} | {n} | {assessment} |
| Guard | Architectural fitness tests (ArchUnit) | {Y/N} | {n} | {assessment} |

Standard: Test Pyramid (Martin Fowler), Practical Test Pyramid (Ham Vocke)

**Architectural Guard Test Assessment** — check compliance with `copilot-instructions.md` ("Add code-based guard tests") and `testing-and-determinism.instructions.md`:
- Are ArchUnit or equivalent convention tests present?
- Do they enforce package dependency rules, controller thinness, transactional boundaries, no field injection, and no forbidden patterns (recursion, manual threads, unbounded collections)?
- Are guard tests run as part of the standard test suite (not a separate profile)?

**Critical Missing Tests**:
For each untested or under-tested area, assess:
- Risk level if this breaks in production
- Effort to add adequate test coverage
- Recommended test approach and tools

### Step 3: Test Anti-Patterns

**Over-Mocking**:
- Tests where more than 3 dependencies are mocked → indicates class has too many deps
- Mocking return values of mocks (mock.getX().getY()) → fragile mock chains
- Mocking concrete classes instead of interfaces
- Using @MockBean when a simple mock would suffice (slow Spring context loading)
- Standard: Mockito Best Practices, "Don't Mock What You Don't Own"

**Flaky Test Indicators**:
- Tests with Thread.sleep() → timing-dependent
- Tests depending on system time (LocalDateTime.now()) without clock injection
- Tests with random data generation without seed control
- Tests depending on file system state or network availability
- Tests using @DirtiesContext (indicates shared state problems)

**Test Configuration Issues**:
- @SpringBootTest loading full context when a slice test would suffice
  - Controller tests should use @WebMvcTest (loads only web layer)
  - Repository tests should use @DataJpaTest (loads only JPA layer)
  - Service tests should use plain JUnit + Mockito (no Spring context)
- Missing test profiles (application-test.yml)
- Slow test suite (>5 minutes for unit tests → indicates wrong test types)
- Missing Testcontainers for database-dependent tests (using H2 instead of real DB)

**Test Data Management**:
- Hardcoded test data scattered across test classes (should use builders/fixtures)
- Missing test data factories (Builder pattern or Object Mother)
- SQL scripts for test data that are hard to maintain
- Standard: Test Data Builder Pattern

### Step 4: Spring Boot Test Slice Analysis

**Slice Usage Assessment**:
For each test class, evaluate whether it uses the appropriate slice:

| Test Class | Current Annotation | Recommended | Issue |
|---|---|---|---|
| {class} | @SpringBootTest | @WebMvcTest | Only tests controller |
| {class} | @SpringBootTest | Plain JUnit | Only tests service logic |

**Common Misuses**:
- @SpringBootTest for testing a single service class → overkill, use plain JUnit
- @WebMvcTest with @MockBean for every service → indicates controller is doing too much
- @DataJpaTest without Testcontainers → H2 hides real database behavior
- Missing @AutoConfigureTestDatabase(replace=NONE) when using Testcontainers

### Step 5: Flowable Process Test Coverage

**Process Definition Test Assessment**:
For each .bpmn20.xml file, check:
- Does a corresponding test class exist?
- Does it test the happy path (start to end)?
- Does it test error boundary events?
- Does it test timer boundary events?
- Does it test exclusive gateway conditions (all branches)?
- Does it verify process variables at each step?
- Does it test async continuation behavior?
- Does it test process instance migration (if version > 1)?

**Flowable Test Anti-Patterns**:
- Deploying ALL process definitions in every test class
- Not using `@Deployment` to scope process definitions per test
- Testing process logic through API calls instead of direct process testing
- Not asserting process history events for audit verification
- Missing clock manipulation for timer testing
- Standard: Flowable Testing Best Practices

### Step 6: Mutation Testing Readiness

**PIT (pitest) Assessment**:
- Is pitest configured in the build?
- If not, recommend configuration:
  ```xml
  <!-- Maven pom.xml -->
  <plugin>
      <groupId>org.pitest</groupId>
      <artifactId>pitest-maven</artifactId>
      <version>1.15.0</version>
      <configuration>
          <targetClasses>
              <param>com.{org}.{context}.domain.*</param>
              <param>com.{org}.{context}.application.*</param>
          </targetClasses>
          <mutators>
              <mutator>DEFAULTS</mutator>
              <mutator>STRONGER</mutator>
          </mutators>
      </configuration>
  </plugin>
  ```
- Identify classes with high cyclomatic complexity but only assertEquals-style tests
  → highest value mutation testing targets
- Estimate mutation score based on test quality assessment
- Standard: Mutation Testing (pitest.org)

### Step 7: Contract Testing Assessment

**API Contract Tests**:
- Are there consumer-driven contract tests (Pact or Spring Cloud Contract)?
- For each API endpoint consumed by other services:
  - Is there a contract test?
  - Does it verify request/response schemas?
  - Does it verify error responses?
- For each API endpoint this service consumes:
  - Is there a provider contract verification?
  - Is it run in CI/CD?
- Standard: Consumer-Driven Contracts (Martin Fowler)

**Flowable Process Contracts**:
- Are process start variables documented and validated?
- Are process output variables documented and tested?
- Are message/signal correlation contracts tested?

## Output

Write your findings to `docs/generated/audit/04-TEST-QUALITY.md` immediately upon completing this phase. Do NOT defer writing to a later consolidation phase — the file must be written now to survive context compaction.

The file must follow the finding format defined in `audit-output.instructions.md`.
Use finding IDs prefixed with `TQ-` (e.g., TQ-001, TQ-002).

Include a test pyramid visualization:
```markdown
## Test Pyramid Status

        /  E2E  \        Count: {n} | Status: {✅/⚠️/🛑}
       / Contract \       Count: {n} | Status: {✅/⚠️/🛑}
      /Integration \      Count: {n} | Status: {✅/⚠️/🛑}
     /  BPMN Tests  \     Count: {n} | Status: {✅/⚠️/🛑}
    /   Unit Tests   \    Count: {n} | Status: {✅/⚠️/🛑}
   /___________________\

Total Tests: {n} | Estimated Execution Time: {n}s
JaCoCo Line Coverage: {n}% | Estimated Mutation Score: {n}%
```
