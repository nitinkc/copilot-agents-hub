---
name: service-traversal
description: >
  Trace error propagation across OrderTech microservice boundaries using
  DAG-based traversal. Follows errors upstream and downstream through
  GlobalTrackingId, threadContextId, and FEIGN/DOWNSTREAM log pairs.
---

# Skill: Service Traversal

## Goal

Trace request propagation across microservice boundaries using DAG-based
traversal. Supports two modes:
- **error mode** (default): follows error signals to find the origin of a failure
- **full mode**: follows ALL logs for a transaction regardless of status — used
  for behavioral investigations where responses are 200 OK but values are wrong

## Inputs

| Input | Source | Required |
|---|---|---|
| Starting node (service + error, GlobalTrackingId, or trace anchor) | Prior skill or user | Yes |
| Time window | User or derived from error timestamps | Yes |
| Traversal mode | `error` (default) or `full` | No |
| Error classification | `error-taxonomy` skill | No (error mode only) |
| Traversal depth override | User (default: 5) | No |

## When to Use

- Trace an error across multiple services (error mode)
- Trace the full call chain for a transaction with wrong behavior (full mode)
- Understand error propagation direction and pattern
- Find the origin service (deepest root cause)
- Find the service that computed/set a specific value (full mode)
- Detect cascade failures, circuit breaker trips, retry storms
- Build the error propagation chain for RCA

## Step 0 — Load Dependencies

```
read_file .github/skills/elk-log-search/SKILL.md
read_file .github/skills/elk-log-search/INVESTIGATION-BRAIN.md
read_file .github/skills/service-traversal/DAG-ALGORITHM.md
read_file .github/skills/error-taxonomy/SKILL.md
```

INVESTIGATION-BRAIN.md provides ELK field semantics (sections 1–3),
query building (section 4), and anti-patterns (section 7).

## Traversal Configuration

```yaml
max_depth: 5                     # Maximum service layers (typically sufficient for OrderTech)
max_breadth_per_layer: 10        # Max services to investigate per layer
time_tolerance_ms: 5000          # Max time skew between related calls
detect_patterns: true
total_timeout_sec: 300           # 5 minute max for full traversal
```

## Mode Selection

| Situation | Mode | Why |
|---|---|---|
| 5xx errors, exceptions, timeouts | `error` | Filter to error signals — faster, less noise |
| Wrong value in response, unexpected behavior, 200 OK but bad data | `full` | Transaction succeeded — errors won't show it |
| "Why did field X return Y?" | `full` | Need to see every service that touched the data |
| Latency investigation (no errors) | `full` | Slow responses return 200 |

**Mode affects Steps 2–4 only.** In `full` mode, Steps 2–3 query ALL logTypes
for the GlobalTrackingId instead of filtering on error statusCodes. Steps 5–8
still apply (pattern detection and error code consistency work for both modes).

## Workflow

### Step 0b: BPMN Service Detection (before Step 1)

BPMN services (`wkfl-*` slug pattern) use Flowable process instances with
`businessKey` as the primary correlation identifier. GlobalTrackingId and
threadContextId are shared across the ecosystem and return millions of
records for these services, making them unreliable as primary trace keys.

**Detection**: If the service slug contains `wkfl-` (case-insensitive), activate
BPMN trace mode.

**BPMN trace mode procedure**:
1. Extract `businessKey` from Phase 1 log samples. Look for it in:
   - Structured field `businessKey` (rare — not indexed in all services)
   - Nested JSON inside `message` field: parse `message` as JSON, check
     `context.businessKey`, `instanceVariables.businessKey`, or match pattern
     `"businessKey":"<uuid>"` via regex
   - If Phase 1 log sample contains `instanceVariables`, the businessKey is
     typically the `itemId` field value (a UUID)
2. If businessKey extracted → use it as the **primary trace key** for Steps 2–4.
   Query pattern: `{"query_string": {"query": "\"<businessKey>\"", "fields": ["message"]}}`.
   This scopes traversal to a single Flowable process instance instead of the
   full ecosystem.
3. If businessKey unavailable → use the **graduated fallback chain** (NOT GlobalTrackingId):

   | Priority | Key | Scope | When to use |
   |----------|-----|-------|-------------|
   | 1 (best) | `businessKey` | Single process instance | Extracted from JSON or regex |
   | 2 | `orderId` | Single order (may span multiple process instances) | businessKey absent but orderId found |
   | 3 | `parentBusinessKey` | Parent order scope | Neither businessKey nor orderId found |
   | 4 | `threadContextId` | Single service thread | No BPMN keys found — scoped to service, not ecosystem |
   | 5 (avoid) | `GlobalTrackingId` | **Entire ecosystem — DO NOT USE for wkfl-* services** | Only if ALL above are empty AND combined with `serviceName` filter |

   **Rule**: GlobalTrackingId is NEVER used alone for wkfl-* services. If forced to
   use it (priority 5), MUST combine with `serviceName.keyword` wildcard filter to
   prevent ecosystem-wide noise. Log:
   `[BPMN trace mode: no process-scoped key found — using threadContextId as fallback]`
   or `[BPMN trace mode: DEGRADED — no usable key, using GlobalTrackingId + serviceName filter]`

   The `elk-query.sh bpmn-context` command outputs a `recommended_trace` object that
   selects the best available key automatically. Use its `key` and `values` fields
   directly instead of implementing fallback logic manually.

**BPMN trace mode also extracts** (from the same log samples):
- `processDefinitionId` (e.g., `insuranceOrderItem:14`) — identifies the BPMN process
- `action` (e.g., `CANCEL`, `ADD`) — identifies the order action type
- `parentBusinessKey` / `orderId` — identifies the parent order

These fields feed Phase 4 (Code Forensics) and Phase 5 (RCA Synthesis).
Extract them once here; do not re-query in later phases.

**One-command alternative**: If `elk-query.sh bpmn-context` is available, use it:
```bash
elk-query.sh bpmn-context --service <slug> --hours <N>
```
This extracts businessKey, processDefinitionId, and action from recent ERROR
entries in a single request, replacing manual JSON parsing of Phase 1 samples.

### Step 1: Establish the Starting Node

From the input, extract:
- `serviceName` (which service)
- `GlobalTrackingId` (cross-service correlation — use BOTH spellings)
- `threadContextId` (in-service correlation)
- `businessKey` (BPMN process correlation — **primary for wkfl-* services**, see Step 0b)
- `@timestamp` (when)
- `logType` (what type of log entry)
- `statusCode` / `status` (what happened — may be 200 in full mode)
- `configLabel` (which build version)
- `datacenter` (which DC)

**In full mode**, also note:
- The specific field/value the user says is wrong
- The expected value (if known)
- Which service's response contained the wrong value (this is the starting node)

### Step 2: Downstream Investigation

**Question**: What services did this service call?

**Error mode** — query for FEIGN/DOWNSTREAM responses with error status:

```bash
ELK=".github/skills/elk-log-search/scripts/elk-query.sh"
$ELK raw --body '{"size":30,"query":{"bool":{"filter":[{"range":{"@timestamp":{"gte":"<timestamp - 30s>","lte":"<timestamp + 5s>"}}},{"wildcard":{"serviceName.keyword":"*<service-slug>*"}},{"terms":{"logType.keyword":["FEIGN_RESPONSE","DOWNSTREAM_RESPONSE"]}},{"terms":{"statusCode.keyword":["INTERNAL_SERVER_ERROR","BAD_GATEWAY","SERVICE_UNAVAILABLE","GATEWAY_TIMEOUT","REQUEST_TIMEOUT"]}}]}},"_source":["@timestamp","serviceName","logType","statusCode","uri","duration","message","GlobalTrackingId","threadContextId","datacenter","configLabel"],"sort":[{"@timestamp":{"order":"asc"}}]}'
```

**Full mode** — query ALL FEIGN/DOWNSTREAM pairs (no status filter):

```bash
$ELK raw --body '{"size":50,"query":{"bool":{"filter":[{"range":{"@timestamp":{"gte":"<timestamp - 30s>","lte":"<timestamp + 5s>"}}},{"wildcard":{"serviceName.keyword":"*<service-slug>*"}},{"terms":{"logType.keyword":["FEIGN_REQUEST","FEIGN_RESPONSE","DOWNSTREAM_REQUEST","DOWNSTREAM_RESPONSE"]}}]}},"_source":["@timestamp","serviceName","logType","statusCode","status","uri","duration","message","GlobalTrackingId","threadContextId","datacenter","configLabel"],"sort":[{"@timestamp":{"order":"asc"}}]}'
```

In full mode, parse the `message` JSON for request/response bodies — the wrong
value may be visible in a FEIGN_RESPONSE body coming from a downstream service.

### Step 3: Upstream Investigation

**Question**: What services called this service around the same time?

Use GlobalTrackingId to find all services in the same trace:

```bash
ELK=".github/skills/elk-log-search/scripts/elk-query.sh"
$ELK raw --body '{"size":50,"query":{"bool":{"filter":[{"range":{"@timestamp":{"gte":"<timestamp - 30s>","lte":"<timestamp + 5s>"}}}],"should":[{"match":{"GlobalTrackingId":"<tracking_id>"}},{"term":{"globaltrackingid.keyword":"<tracking_id>"}}],"minimum_should_match":1,"must_not":[{"wildcard":{"serviceName.keyword":"*<current-service>*"}}]}},"_source":["@timestamp","serviceName","logType","statusCode","uri","level","message","GlobalTrackingId","configLabel","datacenter"],"sort":[{"@timestamp":{"order":"asc"}}]}'
```

Group results by `serviceName` to identify upstream callers.
In error mode, only services with errors become traversal nodes.
In full mode, ALL services become traversal nodes — the goal is to
see every service that touched the transaction.

### Step 4: Iterate (BFS)

Follow the DAG-ALGORITHM.md bidirectional BFS:
1. Process each node from the queue.
2. For each, run downstream (Step 2) and upstream (Step 3) queries.
3. **Error mode**: add discovered error nodes to the queue.
   **Full mode**: add ALL discovered nodes to the queue.
4. Track visited services to detect cycles.
5. Stop at `max_depth` or when no new nodes are found.

**Full mode additional step**: At each node, parse `message` JSON for
request/response bodies. Search for the specific field/value the user flagged.
Track which service first INTRODUCED the wrong value into the chain — that
service is where the value was computed or fetched from its data source.

### Step 5: Pattern Detection

At each node, check for failure patterns:

| Pattern | ELK Signal | Query Hint |
|---------|-----------|------------|
| **CASCADE** | Error count ↑ geometrically upstream | Agg by service, compare counts |
| **CIRCUIT_BREAKER_OPEN** | `message` contains "CircuitBreaker" or "CallNotPermitted" | `query_string` on message |
| **TIMEOUT_PROPAGATION** | Decreasing time budget across layers | Compare `duration` values |
| **RETRY_STORM** | Same GlobalTrackingId + uri appears >3 times | Count by trackingId+uri |
| **RESOURCE_EXHAUSTION** | "RejectedExecution", "pool", "OutOfMemory" | `query_string` on message |
| **PARTIAL_FAILURE** | Error in some DCs, success in others | Agg by datacenter.keyword |
| **BPMN_PROCESS_ERROR** | "BpmnError", "FlowableException" | `query_string` on message |

### Step 6: Identify Origin Service

Apply the origin identification algorithm:
1. Find error leaf nodes (have errors but no downstream error children).
2. If single leaf → origin (confidence 0.95).
3. If multiple leaves → rank by earliest timestamp, deepest depth, non-timeout, non-external.
4. Report the origin with confidence score.

### Step 6b: Second Traversal — Anchoring Check (Tier 2+)

To counter anchoring bias, perform a SECOND traversal from a DIFFERENT starting point:
- Start from the **OPPOSITE end** of the chain (if first was origin→surface, second is surface→origin),
  OR from a **LATERAL service** (shared dependency, different consumer of same upstream).
- Actively seek evidence that **CONTRADICTS** the primary hypothesis — not to confirm it.
- If contradictory evidence found, add/revise hypotheses before proceeding.

### Step 7: Error Code Consistency Check (before designating root node)

Before designating a candidate service as the origin/root node (from Step 6),
verify that its error code matches the primary error message seen in the upstream
calling service. A mismatch indicates a **concurrent secondary issue**, not a
single propagation chain.

**Procedure:**
1. Extract the error code/message from the candidate root node's ERROR log entries
   (e.g., `404 NOT_FOUND`, `XOMSBILLER_5002`, `NullPointerException`).
2. Extract the error code/message from the upstream service that called the candidate
   (from FEIGN_RESPONSE or DOWNSTREAM_RESPONSE log entries, or from the upstream's
   own ERROR logs referencing the same GlobalTrackingId).
3. Compare:
   - **Match** (same error code propagated): confirms propagation chain — candidate
     remains the root node. Proceed to Step 8.
   - **Mismatch** (different error codes): the candidate's error is a **concurrent
     secondary issue** happening at the same time, NOT the cause of the upstream error.
     Demote this candidate and re-evaluate Step 6 with remaining nodes.
4. If ALL leaf candidates are demoted by mismatch, the origin is likely **within**
   the upstream service itself (the error was generated locally, not propagated from
   downstream). Flag for Phase 4 code investigation at the upstream service.

**Example from real investigation:**
- Phase 3 found `promotion-service` returning 404 → candidate root node.
- Upstream `wkfl-billing-order` error was `NullPointerException` in `DiscountPromotionService`.
- 404 ≠ NPE → mismatch → 404 was concurrent secondary issue.
- Actual root cause was in `wkfl-billing-order` itself (discovered in Phase 4 code forensics).

**In full mode**: Compare the response value from the candidate service against
the value the upstream service forwarded. If the upstream transformed or ignored
the candidate's response, the candidate may not be the value source.

### Step 8: Build Propagation Chain

Produce an ordered chain from origin (deepest cause) to surface (user-visible):

```
[origin-service] ──type──▶ [intermediate-service] ──type──▶ [surface-service]
  (ROOT CAUSE)               (PROPAGATION)                   (SYMPTOM)
```

## Output Contract

```yaml
traversal_result:
  mode: "error" | "full"
  status: "complete" | "depth_limited" | "timeout" | "partial"
  origin_service:
    service: string               # serviceName slug
    configLabel: string           # Exact build
    error_category: string        # From error-taxonomy (error mode)
    confidence: float             # 0.0-1.0
  # Full mode only — tracks where a specific value was set/derived:
  value_source:                   # null in error mode
    field: string                 # The field the user flagged
    actual_value: string          # What was returned
    expected_value: string        # What user expected (if provided)
    set_by_service: string        # Service that first produced this value
    set_by_configLabel: string    # Build version
    evidence: string              # Log entry or response body showing value
  propagation_chain:
    - layer: int
      service: string
      configLabel: string
      error: string               # Brief error description (error mode)
      summary: string             # Request/response summary (full mode)
      timestamp: ISO8601
      direction: "origin" | "upstream" | "downstream"
      propagation_type: "DIRECT" | "CASCADE" | "TIMEOUT" | "CIRCUIT_BREAKER" | "DATA_PASS_THROUGH"
  patterns_detected: string[]    # MUST use formal enum values from list below — no hybrid terms
  # Valid pattern enum values (may co-occur — list all that apply):
  #   CASCADE, TIMEOUT_PROPAGATION, CIRCUIT_BREAKER_OPEN, RETRY_STORM,
  #   RESOURCE_EXHAUSTION, PARTIAL_FAILURE, BPMN_PROCESS_ERROR
  # Example: ["TIMEOUT_PROPAGATION", "CASCADE"] — NOT "TIMEOUT_CASCADE"
  blast_radius:
    affected_services: string[]
    affected_service_count: int
    affected_datacenters: string[]
    customer_facing: boolean
  traversal_metadata:
    depth_reached: int
    services_visited: int
    total_queries_executed: int
```

## Failure Modes

- **Cycle detected**: Break cycle, annotate, explore non-cyclic branches.
- **Depth limit reached**: Return `depth_limited`, list frontier services.
- **Missing GlobalTrackingId**: Fallback to time-window + service-name queries.
- **No correlation across services**: Report as `GAP` in the chain.
- **Lower env index**: If `--env lower`, use `order-tech-lower-*` index (Section 1 of INVESTIGATION-BRAIN.md).

## Behavioral Investigation Workflow (Full Mode)

When the user reports wrong behavior (not errors), execute this sequence using `full` mode:

1. **COLLECT IDENTIFIERS**: Get transaction ID, account, tracking ID, or order ID.
   Get which field/value is wrong and what the user expected.
2. **PULL FULL TRANSACTION LOGS**: Use `elk-query.sh trace <id>` or custom query.
   Pull ALL levels (not just ERROR) — the transaction likely returned 200 OK.
   Parse `message` JSON → `context` → request/response bodies.
3. **BUILD FULL CALL CHAIN**: Traverse ALL services the transaction touched.
   At each service, extract the request and response bodies.
   Find where the flagged value FIRST appears or CHANGES.
4. **IDENTIFY THE VALUE SOURCE**: The service that INTRODUCED or COMPUTED the wrong
   value is the target. Check: downstream call? DB lookup? DRL rule? Config? Request input?
5. **CODE + CONFIG FORENSICS**: Use `code-forensics` skill to checkout the exact deployed
   commit for the value-source service. Find the code path: controller → service → computation.
   Check DRL rules (MspRuleConfig) and config (MobileBackOfficeConfig).
6. **VERDICT**:
   - Value is CORRECT: explain the business rule that produced it.
   - Value is WRONG due to DATA: bad input from upstream or external source.
   - Value is WRONG due to CODE: missing guard, wrong calculation, stale logic.
   - Value is WRONG due to CONFIG: wrong config value, DRL rule mismatch.
   - Value is WRONG due to STALE DATA: cache, eventual consistency, timing.
