# DAG Traversal Algorithm — OrderTech Cross-Service Error Tracing

## Purpose

Deterministic algorithm for traversing error propagation across OrderTech's
592+ microservices. Uses ELK's GlobalTrackingId, threadContextId, and logType
pairs to follow errors upstream and downstream through service boundaries.

## Algorithm: Bidirectional BFS with Pattern Detection

### Pseudocode

```
ALGORITHM: OrderTechErrorTraversal
INPUT:
  origin_error: ELKLogEntry        # The starting error from elk-log-search
  config: TraversalConfig          # Depth, breadth, timeout settings
OUTPUT:
  propagation_dag: DAG             # Complete error propagation graph
  origin_service: string           # Deepest root cause service
  patterns: Pattern[]              # Detected failure patterns

FUNCTION traverse(origin_error, config):
  visited = Set()                  # Services already investigated
  queue = Queue()                  # BFS frontier
  dag = DAG()                      # Result graph

  root_node = create_node(origin_error)
  dag.add_node(root_node)
  queue.enqueue((root_node, 0))    # (node, depth)

  WHILE queue IS NOT EMPTY:
    (current_node, depth) = queue.dequeue()

    IF depth > config.max_depth:
      current_node.mark_as("DEPTH_LIMITED")
      CONTINUE

    IF current_node.service IN visited:
      current_node.mark_as("CYCLE_DETECTED")
      CONTINUE

    visited.add(current_node.service)

    # ── DOWNSTREAM INVESTIGATION ──
    # Query ELK for FEIGN_RESPONSE/DOWNSTREAM_RESPONSE from this service
    # with error statusCode in the same threadContextId
    downstream = query_elk_downstream(current_node)
    breadth_count = 0

    FOR EACH ds IN downstream:
      IF breadth_count >= config.max_breadth_per_layer: BREAK
      IF ds.has_errors():
        ds_node = create_node(ds)
        dag.add_edge(current_node, ds_node, type="SYNC_DOWNSTREAM")
        queue.enqueue((ds_node, depth + 1))
        breadth_count += 1

    # ── UPSTREAM INVESTIGATION ──
    # Use GlobalTrackingId to find the calling service
    upstream = query_elk_upstream(current_node)

    FOR EACH us IN upstream:
      IF us.service IN visited: CONTINUE
      IF us.has_errors():
        us_node = create_node(us)
        dag.add_edge(us_node, current_node, type="SYNC_UPSTREAM")
        queue.enqueue((us_node, depth + 1))

    # ── PATTERN DETECTION ──
    IF config.detect_patterns:
      patterns = detect_patterns(current_node, dag)
      current_node.annotate(patterns)

  origin_service = identify_origin(dag)
  RETURN TraversalResult(dag, origin_service, patterns)
```

### ELK-Specific Traversal Queries

**Downstream calls from a service** (what did it call?):
```json
{
  "query": { "bool": { "filter": [
    { "range": { "@timestamp": { "gte": "<node_timestamp - 5s>", "lte": "<node_timestamp + 30s>" } } },
    { "wildcard": { "serviceName.keyword": "*<service-slug>*" } },
    { "terms": { "logType.keyword": ["FEIGN_RESPONSE", "DOWNSTREAM_RESPONSE"] } },
    { "terms": { "statusCode.keyword": ["INTERNAL_SERVER_ERROR", "BAD_GATEWAY", "SERVICE_UNAVAILABLE", "GATEWAY_TIMEOUT"] } }
  ]}},
  "_source": ["@timestamp", "serviceName", "logType", "statusCode", "uri", "duration", "message", "GlobalTrackingId", "threadContextId"],
  "size": 20
}
```

**Upstream callers** (who called this service?):
```json
{
  "query": { "bool": { "filter": [
    { "range": { "@timestamp": { "gte": "<node_timestamp - 30s>", "lte": "<node_timestamp>" } } }
  ], "must": [
    { "match": { "GlobalTrackingId": "<tracking_id>" } }
  ], "must_not": [
    { "wildcard": { "serviceName.keyword": "*<current-service>*" } }
  ]}},
  "_source": ["@timestamp", "serviceName", "logType", "statusCode", "uri", "duration", "message", "GlobalTrackingId"],
  "size": 50
}
```

### Origin Identification

```
FUNCTION identify_origin(dag):
  # The origin is the deepest node with errors but no downstream error children
  error_leaves = dag.nodes
    .filter(n => n.has_error AND n.downstream_error_count == 0)
    .sort_by(n => n.timestamp ASC)  # Earliest error first

  IF error_leaves.length == 1:
    RETURN (error_leaves[0], confidence=0.95)

  IF error_leaves.length > 1:
    # Prefer: earliest timestamp > deepest depth > non-timeout > non-external
    ranked = error_leaves.sort_by(
      n => (n.timestamp, -n.depth, n.is_timeout ? 1 : 0, n.is_external ? 1 : 0)
    )
    RETURN (ranked[0], confidence=0.7)

  RETURN (dag.deepest_node(), confidence=0.5)
```

## Traversal Configuration

```yaml
traversal_config:
  max_depth: 5                     # Maximum layers deep (5 is typical for OrderTech)
  max_breadth_per_layer: 10        # Max services per layer
  time_tolerance_ms: 5000          # Max time skew between related calls
  detect_patterns: true            # Run pattern detection at each layer
  timeout_per_layer_sec: 60        # Per-layer investigation timeout
  total_timeout_sec: 300           # Total investigation timeout (5 min)
  include_warnings: false          # Include WARN-level (true for deep investigation)
  slow_threshold_ms: 3000          # What counts as "slow"
```

## Pattern Detection

At each traversed layer, detect these failure patterns:

### CASCADE
- **Signal**: Error count increases geometrically upstream.
- **ELK check**: Aggregate ERROR count per service in the chain.
- **Indicator**: Service N has 1 error, N-1 has 10, N-2 has 100.

### CIRCUIT_BREAKER_OPEN
- **Signal**: `message` contains `CircuitBreakerOpenException` or `CallNotPermittedException`.
- **ELK check**: `query_string` on `message` for circuit breaker exceptions.
- **Indicator**: Downstream calls stop after threshold.

### TIMEOUT_PROPAGATION
- **Signal**: Timeouts at multiple layers with decreasing remaining time.
- **ELK check**: Compare `duration` values across layers.
- **Indicator**: Layer 3 timeout = 30s, Layer 2 = 29.8s, Layer 1 = 29.5s.

### RETRY_STORM
- **Signal**: Same operation retried multiple times.
- **ELK check**: Count entries with same GlobalTrackingId + same uri pattern.
- **Indicator**: >3 identical requests within seconds.

### RESOURCE_EXHAUSTION
- **Signal**: Thread pool, connection pool, or memory errors.
- **ELK check**: `message` containing "RejectedExecution", "pool", "OutOfMemory".

### PARTIAL_FAILURE
- **Signal**: Same request succeeds on some DCs, fails on others.
- **ELK check**: Aggregate errors by `datacenter.keyword` for same service.
- **Indicator**: Error in wc-g2, success in po-g2 for same operation.

### BPMN_PROCESS_ERROR
- **Signal**: Flowable boundary error event triggered.
- **ELK check**: `message` containing "BpmnError", "FlowableException", process
  instance in error state.
- **Indicator**: `BpmnError` with error code.

## Edge Types

| Type | Description |
|------|-------------|
| `SYNC_DOWNSTREAM` | Service A called Service B, B returned error |
| `SYNC_UPSTREAM` | Service A was called by Service B, B has error |
| `ASYNC_GAP` | Event published but no consumer log found |
| `SHARED_RESOURCE` | Services share DB/cache, both affected |

## Cycle Detection

OrderTech services can have circular call patterns (A→B→C→A via different paths).
When a cycle is detected:
1. Log the cycle path for reporting.
2. Do NOT traverse further on the cyclic branch.
3. Explore non-cyclic branches from cycle nodes.
4. Report the cycle in the DAG output.
