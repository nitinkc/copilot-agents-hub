---
name: pr-risk-scoring
description: Produce a composite risk score for a PR using 8 weighted dimensions. Maps phase findings to evidence-based scores, computes weighted composite, determines merge verdict, and recommends review routing. Includes mandatory Socratic self-check before finalizing.
user-invocable: true
disable-model-invocation: true
---
# PR Risk Scoring and Verdict

Produce an evidence-based composite risk score for a PR and determine the merge verdict.

## Inputs
- Findings from all prior phases (diff review + reuse, change fit + cross-service + traceability, deployment readiness)
- Phase Summary Blocks from phases 0–4
- Session memory state (if large review)

## Step 1 — Map Findings to Dimensions

Assign each finding to one or more of the 8 scoring dimensions:

| Dimension | Weight | What feeds it |
|---|---|---|
| Correctness risk | 20% | Diff review: logic errors, missing edge cases, dead code, ignored returns |
| Backward compatibility risk | 15% | Change fit: removed/renamed API fields, changed error codes, broken contracts |
| Security risk | 15% | Diff review: injection, SSRF, secret exposure, missing validation, OWASP |
| Operational risk | 10% | Deployment readiness: rollback blast, migration risk, monitoring gaps, SLO impact |
| Test confidence gap | 15% | Diff review + change fit: production changes without tests, missing negative paths |
| Pattern deviation risk | 5% | Change fit: convention violations, architectural misalignment, new unsanctioned patterns |
| Cross-service impact risk | 10% | Change fit: downstream consumers affected, contract compatibility, coordinated deployment, integration point changes (HTTP, DB, BPMN, messaging, cache) |
| Data/state management risk | 10% | Diff review: migration safety, transaction boundaries, idempotency, PII handling |

## Step 2 — Score Each Dimension (1–5)

For each dimension, assign a score based on evidence:

| Score | Meaning | Criteria |
|---|---|---|
| 1 | Minimal risk | No findings, or Low-only findings with clear mitigations |
| 2 | Low risk | Medium findings only, all with straightforward fixes |
| 3 | Moderate risk | High findings present, or multiple Medium findings in the same area |
| 4 | High risk | Critical finding present, or High findings with unclear mitigation path |
| 5 | Severe risk | Multiple Critical findings, or Critical + no test coverage + no rollback path |

**Rules:**
- A single Critical finding in any dimension forces that dimension to score ≥ 4.
- A dimension with zero findings scores 1.
- Test confidence gap dimension: if any production file has zero corresponding test changes, minimum score is 2.
- Jira-unavailable traceability penalty: if Dimension H was scored with Jira unavailable (capped at 2 due to fetch failure), increase the Pattern Deviation dimension score by +1 (capped at 5) as a traceability risk surcharge. Note in the score table: `⚠️ Pattern Deviation +1 (Jira-unavailable traceability penalty)`. This penalty is removed if the lead says "retry Jira" and the re-fetch succeeds.
- Scores must be justified with specific finding references (not generic reasoning).

## Step 3 — Compute Composite Score

```
composite = Σ (weight_i × score_i) for all 8 dimensions
```

Round to one decimal place.

## Step 4 — Determine Verdict

| Composite Range | Verdict | Meaning |
|---|---|---|
| 1.0–1.9 | **APPROVE** | Safe to merge. Minor suggestions only. |
| 2.0–2.9 | **APPROVE WITH CONDITIONS** | Safe to merge after addressing specified conditions. |
| 3.0–3.9 | **REQUEST CHANGES** | Must address findings before merge. |
| 4.0–5.0 | **BLOCK** | Critical issues. Do not merge. |

**Override rules:**
- Any single Critical finding → verdict cannot be APPROVE (minimum APPROVE WITH CONDITIONS).
- Any unresolved security Critical → verdict must be BLOCK.
- Test-free production changes → verdict cannot be APPROVE (minimum APPROVE WITH CONDITIONS).
- No Critical findings + all High findings have clear fixes → eligible for APPROVE WITH CONDITIONS even if composite reaches 3.0.

## Step 5 — Review Routing Recommendation

| Composite Range | Routing |
|---|---|
| < 2.0 | Peer review sufficient |
| 2.0–3.0 | Senior reviewer required |
| 3.0–4.0 | Senior + domain specialist review |
| > 4.0 | Architecture review board + mandatory security review |

## Step 6 — Socratic Self-Check (mandatory)

Execute the full 11-question Socratic Self-Check defined in `.github/instructions/mission-critical-checklists.instructions.md` under "Socratic self-check". That file is the single source of truth for these questions.

If any answer reveals a risk not already captured:
- Add it as a new finding to the appropriate dimension.
- Re-score the affected dimension.
- Recompute the composite.
- Re-evaluate the verdict.

Report using the "Socratic-Revealed Risks" table format from "Outcome presentation rules" in the same file. Include the table in the risk scoring output and note any dimensions that were re-scored. State "Socratic self-check: 0 new risks surfaced" if none.

## Output

### Risk Score Table
| Dimension | Weight | Score (1-5) | Evidence |
|---|---|---|---|
| Correctness risk | 20% | [score] | [finding references] |
| Backward compatibility risk | 15% | [score] | [finding references] |
| Security risk | 15% | [score] | [finding references] |
| Operational risk | 10% | [score] | [finding references] |
| Test confidence gap | 15% | [score] | [finding references] |
| Pattern deviation risk | 5% | [score] | [finding references] |
| Cross-service impact risk | 10% | [score] | [finding references] |
| Data/state management risk | 10% | [score] | [finding references] |
| **Composite** | 100% | **[weighted]** | |

### Verdict Block
- **Verdict**: APPROVE | APPROVE WITH CONDITIONS | REQUEST CHANGES | BLOCK
- **Rationale**: 2–3 sentences explaining the verdict based on evidence.
- **Override applied**: yes/no (which override rule triggered)
- **Review routing**: peer | senior | specialist | architecture board
- **Socratic self-check result**: clean | [new risks found and incorporated]

### Required Actions (for non-APPROVE verdicts)
Numbered list, prioritized: Critical → High → Medium. Each action references specific finding(s).

### Conditions (for APPROVE WITH CONDITIONS)
Numbered list of specific, verifiable conditions that must be met before merge.

## Constraints
- Score ALL 8 dimensions. Never skip a dimension, even if no findings feed it (score 1 with "no findings").
- Every score must cite specific finding references — generic rationale is prohibited.
- The Socratic Self-Check (Step 6) is non-skippable. If it reveals new risks, re-score and re-compute.
- Override rules are mandatory — do not produce a verdict that violates any override.
- Do not round composite scores (use one decimal place). Do not round severity down.
- Maximum one re-score cycle per Socratic self-check. If re-scoring triggers another self-check finding, capture it but do not loop again.
