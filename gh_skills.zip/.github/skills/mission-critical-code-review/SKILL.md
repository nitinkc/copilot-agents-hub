---
name: mission-critical-code-review
description: Whole-project mission-critical code review playbook. Use when asked to review/finalize/quality-gate changes. Produces a Change Fit Report (changes -> project patterns/invariants -> tests -> documentation). Can recommend or generate missing tests/docs when permitted. Trigger phrases: "mission critical code review", "change fit report", "whole project review", "quality gate", "review before commit".
---
# Mission-Critical Code Review (Whole-Project Context)

## When to use
- Before commit / before PR
- When asked: "review this", "final check", "quality gate", "anything missing?"
- When code/tests/docs were generated and must be validated for mission-critical completeness

## Inputs
Prefer:
1) Requirements / acceptance criteria / constraints
2) #changes or git diff (to identify the change set)
3) Project source tree (to compare against existing conventions)

## Output format (must)
Return a Change Fit Report with:
1) Change Summary
2) Project Fit Assessment
3) Invariant Check Results
4) Test Coverage Matrix
5) Documentation Coverage Matrix
6) Recommendations/Fix Plan (tests first, docs second)
7) Any generation performed + remaining blockers

## Procedure
### Step 1 — Change Summary
- list changed files and classify each by role
- infer the behavioral change(s)
- if requirements are not provided, summarize likely intent and ask probing questions only when ambiguity/risk is high

### Step 2 — Project Fit Assessment
Search and compare against existing project patterns:
- endpoints/DTOs
- error taxonomy
- correlation handling
- outbound client configuration
- repository patterns
- documentation patterns and existing docs levels
- testing conventions/utilities

### Step 3 — Invariant checks
Verify change respects compatibility, boundedness, IO safety, error safety, idempotency, layering, and security hygiene.

### Step 4 — Test Coverage Matrix
Build:
- change/risk -> required scenarios -> existing tests -> missing tests
Include happy, validation, boundary, business/technical error, outbound failure, duplicate/idempotency scenarios as applicable.

### Step 5 — Documentation Coverage Matrix
Build:
- change/risk -> required doc levels/artifacts -> current status -> missing items
Check whether business, technical, and machine audiences are all served.

### Step 6 — Fix plan
If gaps exist:
1) add/extend tests first
2) update/generate docs second
3) only then suggest minimal code refactors if blocked by design

## Constraints
- No performance/load tests.
- No Thread.sleep.
- No real external network calls in tests.
- Avoid PowerMock unless unavoidable.


## Documentation check
Also review whether the change requires updates to business/context/runtime/technical docs, governance overlays, and machine-readable manifests. Missing documentation for changed behavior, dependencies, or rules is a review finding.

Additionally check dimension coverage (from `dimension-extraction.instructions.md`):
- rule inventory: are new/changed business or operational rules cataloged with stable IDs?
- entity/attribute catalog: are new/changed entities with logic-bearing attributes documented?
- API contract catalog: are new/changed API endpoints documented with protocol and contract spec reference?
- traceability: are capabilities linked to docs, tests, code areas, and requirement keywords?
- contract spec consistency: do machine-readable specs (OpenAPI, WSDL, .proto, AsyncAPI) match documented API contracts?
