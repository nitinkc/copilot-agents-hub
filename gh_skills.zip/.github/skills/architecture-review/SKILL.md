---
name: architecture-review
description: Evaluate architecture and cross-cutting concerns for Spring Boot microservices including hexagonal compliance, resilience, observability, security, and performance.
---

# Skill: Architecture Review

## Goal
Evaluate architectural compliance and cross-cutting concerns that static analysis cannot detect. Produce scored findings with remediation guidance per evaluation area.

## Inputs
- Target codebase (Spring Boot microservice source)
- Repository standards from `.github/instructions/`
- Playbook defaults from `.github/shared/playbook-defaults.yaml`
- Output format rules from `audit-output.instructions.md`

## Rule Sources (MANDATORY — load before auditing)

Load these instruction files with `read_file`. They define the rules; this skill defines the AUDIT METHODOLOGY (what to search for, how to score).

| Instruction file | Rules used in |
|-----------------|---------------|
| `copilot-instructions.md` non-negotiables A–H | Steps 3, 6, 10 |
| `security-and-data-handling.instructions.md` | Step 5 |
| `outbound-http-resttemplate.instructions.md` | Step 3 (outbound HTTP patterns) |
| `mission-critical-checklists.instructions.md` | Step 10 (anti-pattern scan + Socratic) |
| `development-process.instructions.md` | Step 10 (dev process compliance) |

The instruction files are the single source of truth for what the rules ARE. This skill defines HOW to check compliance — the search patterns, diagnostic procedures, and scoring criteria.

## Steps

### Step 1: Hexagonal / Clean Architecture Compliance

**Layer Boundary Violations**:
- Domain layer importing Spring framework classes (should be framework-free)
  - Search for `import org.springframework` in domain packages
  - Search for `@Entity`, `@Repository`, `@Service` annotations in domain layer
- Infrastructure layer bypassing application layer (direct domain access)
- API/Controller layer containing business logic beyond request/response mapping
- Standard: Hexagonal Architecture (Alistair Cockburn), Clean Architecture (Robert Martin)

**Dependency Direction**:
- Verify dependencies flow inward: API → Application → Domain ← Infrastructure
- Flag reverse dependencies (domain importing from infrastructure)
- Check for circular package dependencies
- Standard: Dependency Rule (Clean Architecture)

**Port/Adapter Pattern**:
- Missing port interfaces (services directly coupling to implementations)
- Adapters not implementing port interfaces
- Domain services depending on concrete adapter classes
- Missing anti-corruption layer for external service integration

**Package Structure Evaluation**:
- Is the project package-by-feature or package-by-layer?
- Feature packages should be self-contained bounded contexts
- Shared kernel packages should be minimal and well-defined
- Standard: Package by Feature (not by Layer)

### Step 2: Microservice Boundary Analysis

**Bounded Context Fitness**:
- Is this microservice responsible for exactly ONE bounded context?
- Are there classes/packages that belong to a different domain?
- Is there "feature envy" — this service frequently calling another service
  for data it should own?
- Standard: Domain-Driven Design (Eric Evans), Bounded Contexts

**Service Coupling**:
- Synchronous call chains (Service A → B → C) creating tight coupling
- Shared database access across services (database-level coupling)
- Shared domain models/DTOs between services (class-level coupling)
- Missing event-driven patterns where async communication is appropriate
- Standard: Microservice Patterns (Chris Richardson)

**Data Ownership**:
- Does this service own its data (dedicated database/schema)?
- Is there data duplication that should be synchronized via events?
- Are there foreign keys referencing tables owned by other services?

**Idempotency & Data Consistency**:
- Are POST/PUT endpoints idempotent (idempotency keys for retries)?
- Are message consumers idempotent (deduplication on redelivery)?
- Is there a defined consistency model (strong vs eventual) per data flow?
- Are distributed operations using saga pattern (not 2PC)?
- Are Flowable async tasks safe to retry without side-effect duplication?
- Missing outbox pattern for reliable event publishing alongside DB writes
- Standard: Idempotency Patterns (Stripe API), Saga Pattern (Chris Richardson)

### Step 3: Resilience Patterns (Resilience4j / Spring Retry)

**Rule source**: `copilot-instructions.md` non-negotiable B (bounded execution); `outbound-http-resttemplate.instructions.md` (outbound HTTP patterns).

**Circuit Breaker** — search patterns:
- `RestTemplate`, `WebClient`, `FeignClient` calls WITHOUT `@CircuitBreaker` → unprotected outbound calls
- Circuit breaker with no fallback method
- Default circuit breaker settings (should be tuned per dependency)

**Retry Patterns** — check compliance with non-negotiable B; search patterns:
- Missing retry logic on transient-failure-prone operations
- Retry without exponential backoff → thundering herd risk
- Retry on non-idempotent operations → data duplication risk
- Retries without explicit max count → unbounded
- Missing overall request deadline/budget that caps total retry time

**Timeout Configuration** — check compliance with `outbound-http-resttemplate.instructions.md`; search patterns:
- `RestTemplate` without `setConnectTimeout`/`setReadTimeout`
- `WebClient` without `timeout()` operator
- Database connection pool without connection timeout
- Timeouts longer than upstream caller's timeout → cascading failure
- Standard: Timeout Pattern, Bulkhead Pattern

**Bulkhead Pattern**:
- All external calls sharing the same thread pool → one slow dependency
  blocks everything
- Missing thread pool isolation for different external dependencies
- Missing rate limiting for downstream protection

### Step 4: Observability & Monitoring

**Structured Logging**:
- Using System.out.println instead of SLF4J logger
- Missing MDC context (correlation ID, user ID, request ID)
- Logging sensitive data (PII, credentials, tokens)
- Inconsistent log levels (DEBUG in production code, INFO for debug messages)
- Missing structured logging format (should use JSON in production)
- Standard: Structured Logging Best Practices, ELK/Grafana Loki patterns

**Metrics (Micrometer/Actuator)**:
- Missing custom business metrics (only default JVM/HTTP metrics)
- Missing @Timed annotations on critical service methods
- Missing counter/gauge metrics for business KPIs
- Spring Boot Actuator not properly configured:
  - Health endpoint missing custom health indicators
  - Info endpoint missing build/git information
  - Missing Cloud Foundry health check configuration (http, port, or process type)
  - Missing readiness health group for graceful startup in CF Diego cells
- Standard: RED Method (Rate, Errors, Duration), USE Method

**Distributed Tracing**:
- Missing trace propagation headers (W3C Trace Context or B3)
- Missing Spring Cloud Sleuth / Micrometer Tracing configuration
- External calls not propagating trace context
- Missing span annotations on critical internal methods
- Standard: OpenTelemetry, W3C Trace Context

**Alerting Readiness**:
- No runbook documentation for operational scenarios
- Missing alert-worthy metric thresholds
- No SLI/SLO definitions for the service
- Standard: Google SRE Book (SLIs, SLOs, Error Budgets)

### Step 5: Security Review

**Rule source**: `security-and-data-handling.instructions.md` (security rules); `copilot-instructions.md` Security section; `standards-evaluation` skill (OWASP Top 10 detailed checklists).

Load `security-and-data-handling.instructions.md` and check compliance with each rule. Load `standards-evaluation` skill for the full OWASP Top 10 Spring Boot checklist.

**Key search patterns per OWASP category** (supplement the full checklists from the instruction file and skill):

- **A01 Broken Access Control**: Missing `@PreAuthorize`, IDOR patterns (resource access by ID without ownership check), CORS `*`
- **A02 Cryptographic Failures**: Sensitive data in logs/responses, secrets in `application.yml`, passwords not using BCrypt/Argon2
- **A03 Injection**: SQL string concatenation, JPQL concatenation, missing input validation, EL method invocations without justification
- **A04 Insecure Design**: No rate limiting, no account lockout, no secure-by-default patterns
- **A05 Security Misconfiguration**: Default Spring Security config, actuator exposed without auth, debug messages in production, missing security headers
- **A06 Vulnerable Components**: Dependencies with known CVEs, end-of-life libraries, no automated dependency updates
- **A07 Auth Failures**: Missing session timeout, JWT without expiry/weak signing, no brute-force protection
- **A08 Data Integrity Failures**: No dependency verification, deserialization of untrusted data
- **A09 Logging Failures**: Auth events not logged, missing audit trail, log injection
- **A10 SSRF**: User-controlled URLs passed to HTTP clients without validation/allowlist

### Step 6: Build & CI Quality Culture

**Rule source**: `copilot-instructions.md` non-negotiable F (zero warnings culture); code generation discipline (zero new deps).

**Zero Warnings Compliance** — search patterns:
- Compiler not configured with `-Xlint:all -Werror` (or equivalent)
- `@SuppressWarnings` without justification comments
- Deprecated API usage without migration plan

**Static Analysis Gate** — search patterns:
- SonarQube quality gate not enforced (CI passes despite failure)
- No "zero new findings" policy
- Missing code coverage threshold in CI

**Dependency Hygiene** — check compliance with code generation discipline; search patterns:
- No automated CVE scanning in CI
- No dependency update automation (Renovate/Dependabot)
- Missing BOM for transitive dependency management

### Step 7: 12-Factor App Compliance

Evaluate each factor:

| Factor | Check |
|---|---|
| I. Codebase | One repo per service? Consistent branching? |
| II. Dependencies | All deps declared in build file? No system-level assumptions? |
| III. Config | ALL config externalized? No hardcoded values? |
| IV. Backing Services | DB, message broker, cache swappable via config? | Spring profiles |
| V. Build, Release, Run | Strict separation? Immutable artifacts? | CI/CD pipeline |
| VI. Processes | Stateless? No sticky sessions? No in-memory state? | Shared nothing |
| VII. Port Binding | Self-contained? Embedded server? | Spring Boot default |
| VIII. Concurrency | Horizontally scalable? No singleton bottlenecks? | Thread-safe design |
| IX. Disposability | Fast startup? Graceful shutdown? PreDestroy hooks? | Spring lifecycle |
| X. Dev/Prod Parity | Same backing services? Same configs? | Testcontainers |
| XI. Logs | Treating logs as event streams? Not writing to files? | stdout/stderr |
| XII. Admin Processes | One-off tasks as first-class code? Migration scripts? | Flyway |

### Step 8: API Contract Quality

- Is there an OpenAPI/Swagger specification file?
- Does the spec match the actual implementation?
- Are all request/response models documented?
- Are error responses documented with proper status codes?
- Is API versioning consistent and documented?
- Are deprecated endpoints marked and documented?
- Standard: OpenAPI 3.1 Specification, API Design Guidelines

### Step 9: Performance & Capacity

**Response Time Profiling**:
- Are response time SLAs defined per endpoint tier (sync < 200ms, async < 2s)?
- Are slow endpoints identified and instrumented with @Timed?
- Is there a performance regression test suite (Gatling, k6, JMH)?
- Are P95/P99 latency metrics tracked (not just averages)?
- Standard: Google SRE Book (SLIs/SLOs)

**Database Query Performance**:
- Are slow query logs enabled and reviewed?
- Are N+1 queries detected (Hibernate statistics or datasource-proxy)?
- Are query execution plans reviewed for critical paths?
- Are read-heavy paths using read replicas or caching?
- Missing database index for frequently filtered/sorted columns

**Connection Pool & Resource Sizing**:
- Is HikariCP pool sized for expected concurrency? (formula: connections = (core_count * 2) + disk_spindles)
- Are HTTP client connection pools sized per downstream dependency?
- Are thread pools (async executors, schedulers) sized for production load?
- Are JVM heap/metaspace sizes tuned (not using defaults)?
- Standard: HikariCP Pool Sizing Guide, JVM Ergonomics

**Capacity Planning**:
- Are there load test results documenting max throughput?
- Is horizontal scaling validated (stateless service, shared-nothing)?
- Are auto-scaling policies defined (CPU, memory, custom metrics)?
- Are there capacity alerts before saturation (80% threshold)?
- Are Flowable async executor threads sized for process volume?

### Step 10: Instruction File Compliance & Development Process

**Rule source**: All `.github/instructions/*.instructions.md` files applicable to the target codebase; `development-process.instructions.md`; `mission-critical-checklists.instructions.md`.

This step checks whether the codebase follows its OWN instruction files — a meta-audit that catches drift between the team's stated rules and actual code.

**Instruction file compliance** — for each instruction file with an `applyTo` pattern matching the target codebase:
1. Load the instruction file
2. For each rule/check defined, scan the codebase for violations
3. Report violations grouped by instruction file source

**Development process compliance** — check compliance with `development-process.instructions.md`:
- Are guard tests (ArchUnit or equivalent) present to prevent future drift?
- Is there evidence of TDD practice (test classes created before or alongside production classes)?
- Are definition-of-done criteria met (tests + docs + observability for each feature)?
- Are code comments stating invariants up to date?

**Anti-pattern scan**: Load `mission-critical-checklists.instructions.md` and apply the anti-pattern checklist as a final sweep, reporting findings using the outcome presentation rules defined in that file.

**Socratic self-check**: Apply the Socratic questions from `mission-critical-checklists.instructions.md` before finalizing architecture findings, reporting any newly surfaced risks using the outcome presentation rules.

## Output

Write your findings to `docs/generated/audit/03-ARCHITECTURE.md` immediately upon completing this phase. Do NOT defer writing to a later consolidation phase — the file must be written now to survive context compaction.

The file must follow the finding format defined in `audit-output.instructions.md`.
Use finding IDs prefixed with `AR-` (e.g., AR-001, AR-002).

Include an architecture compliance matrix at the top:
```markdown
## Architecture Compliance Matrix

| Principle | Status | Score (1-5) | Key Findings |
|---|---|---|---|
| Hexagonal Architecture | {✅/⚠️/🛑} | {n}/5 | {summary} |
| Microservice Boundaries | {✅/⚠️/🛑} | {n}/5 | {summary} |
| Resilience Patterns | {✅/⚠️/🛑} | {n}/5 | {summary} |
| Observability | {✅/⚠️/🛑} | {n}/5 | {summary} |
| Security (OWASP Top 10) | {✅/⚠️/🛑} | {n}/5 | {summary} |
| 12-Factor Compliance | {✅/⚠️/🛑} | {n}/5 | {summary} |
| API Contract Quality | {✅/⚠️/🛑} | {n}/5 | {summary} |
| Performance & Capacity | {✅/⚠️/🛑} | {n}/5 | {summary} |
| Build & CI Quality | {✅/⚠️/🛑} | {n}/5 | {summary} |
| Instruction Compliance | {✅/⚠️/🛑} | {n}/5 | {summary} |
```
