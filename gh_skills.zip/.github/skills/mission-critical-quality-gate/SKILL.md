---
name: mission-critical-quality-gate
description: Mandatory end-stage critical review for mission-critical Spring microservices. Audits requirements/change impact vs code, tests, and documentation, detects gaps/flakiness/brittleness, and regenerates missing tests/docs (and code when allowed) until quality gate passes. No performance tests.
---

# Mission-Critical Quality Gate — Critical Review + Regeneration

## Goal
Prevent outputs that are missing key mission-critical coverage or documentation.
Do not finish until the quality gate passes or remaining gaps are clearly documented.

## Inputs
One or more of:
- Acceptance Criteria (AC1..ACn) and constraints
- #changes or diff summary
- List of generated/updated production files
- List of generated/updated test files
- List of generated/updated documentation artifacts
- `.github/shared/playbook-defaults.yaml` (stack/tool defaults and instruction scope catalog)

## Step 1 — Change Inventory & Traceability Matrix
A) Classify changed files by role: Controller/API, DTO/Validation, Service, Repository/DAO, Outbound Client/Adapter, Error/Advice, Security/Filter, Config.
B) Extract behavioral changes: new/changed endpoints, validation/bounds, error mappings, DB queries/transactions, outbound behavior.
C) If requirements exist:
   - Create a matrix: AC -> required scenarios -> test(s) that prove them
D) If only code changes exist:
   - Create a Change Impact map: touched area -> risk -> required tests/docs

## Step 2 — Project Context Map
Do not review changes in isolation. Compare against existing project patterns:
- Similar controllers/endpoints and DTO conventions
- Existing error envelope + errorCode taxonomy
- CorrelationId propagation conventions
- Outbound client configuration pattern (central factory/config vs ad hoc)
- Repository query patterns (pagination/caps, uniqueness, rollback)
- Documentation patterns and existing docs levels
- Existing test conventions:
  - base test classes/utilities
  - naming (ControllerTest/ServiceTest/ClientTest/RepositoryIT)
  - preferred stubbing approach (WireMock/MockWebServer)
  - contract testing approach if present (Spring Cloud Contract/OpenAPI)

Prefer alignment with project conventions unless a deviation clearly reduces risk.

## Step 3 — Whole-Project Invariant Checklist

**Anti-pattern scan**: Scan all changed files against the anti-patterns list in `.github/instructions/mission-critical-checklists.instructions.md` under "Code quality anti-patterns". Flag any match as a finding. Report using the "Anti-Pattern Findings" table format from "Outcome presentation rules" in the same file. Include the table in the Invariant Check Results even if empty (state "Anti-pattern scan: 0 findings").

Verify and flag gaps. See `copilot-instructions.md` non-negotiables A through H for full definitions.

Project invariants:
- **Backward compatibility**: no removed/renamed endpoint params/fields unless versioned; stable errorCode meanings
- **Boundedness**: capped pageSize, batch/list/string size caps, no unbounded loops/retries
- **IO safety**: outbound calls have explicit timeouts + bounded retries + overall deadline
- **Error safety**: consistent safe error envelope (no stack traces, no raw exception text)
- **Idempotency**: side-effecting operations are replay-safe
- **Layering**: controller thin; logic in service; persistence in repo; outbound in client/adapter
- **Security hygiene**: no secrets logged; SSRF allowlist; strict input validation at boundaries
- **Dependency governance**: zero new dependencies unless developer explicitly requested

Non-negotiable C rules (contracts and defensive checks):
- cascade validation, constraint propagation, doc-code invariant consistency

Non-negotiable H rules (code generation discipline):
- boundary symmetry, defensive defaults, error chain integrity, resource acquisition symmetry, singleton safety, API surface stability

## Step 4 — Test Adequacy Matrix
Build a structured matrix: **Change area / risk -> required scenarios -> existing tests -> missing tests**.
Required scenarios (as applicable):
- happy path
- invalid input / validation failure (400)
- cascade validation (nested/map/collection `@Valid`)
- constraint propagation (override mirrors parent)
- doc-code invariant consistency (stated bound has boundary test)
- boundary/cap enforcement
- business error mapping (4xx)
- technical failure mapping (safe 5xx)
- dependency failures for outbound calls (timeout/5xx/malformed)
- idempotency/duplicate behavior for side effects
- error envelope stability (status + errorCode + correlationId)
- dependency governance (risk register entry exists if deps changed)
- boundary symmetry (both `@Min` and `@Max`)
- defensive defaults (default passes validation)
- resource closure (success + exception paths)
- error chain integrity (cause preserved when wrapping)
- test completeness symmetry: every positive assertion has a negative counterpart; every constraint has a violation test
- singleton safety: guard test that singleton-scoped beans have no mutable instance fields

Also verify test quality:
- deterministic (no sleeps)
- non-brittle assertions (no exact internal exception message asserts)
- aligned with existing project test style/utilities (from Project Context Map)
- no redundant duplication
- no real network calls

## Step 5 — Documentation Adequacy Matrix
Build a structured matrix: **Change area / risk -> required doc levels/artifacts -> current state -> gaps**.
Verify:
- business capabilities updated if business-visible behavior changed
- service context updated if dependencies/boundaries changed
- runtime flows updated if behavior/rules/errors/retries changed
- technical map updated if internal structure/testing/config changed
- glossary updated when new business terms appear
- dependency catalog updated when endpoint->backend relationships changed
- ownership/operating rules updated when support or escalation expectations changed
- non-functional rules updated when cross-cutting limits/policies changed
- operations runbook updated when rollout/incident/recovery behavior changed
- release/rollback updated when release risk or migration behavior changed
- data-classification docs updated when data handling/storage/logging obligations changed
- machine manifest/dependency graph/change-impact map updated for API/dependency/rule changes
- rule inventory updated when business or operational rules changed (`docs/generated/14-rule-inventory.md` + `docs/generated/machine/rule-inventory.yaml`)
- entity/attribute catalog updated when entities or logic-bearing attributes changed (`docs/generated/15-entity-attribute-catalog.md` + `docs/generated/machine/entity-catalog.yaml`)
- machine API contract catalog updated when endpoints added/changed (`docs/generated/machine/api-contract-catalog.yaml`)
- docs are useful to business, technical, operations, and machine audiences
- machine-readable contract specs (OpenAPI, WSDL, .proto, AsyncAPI) are consistent with documented API contracts when present

## Step 6 — Regeneration Loop
If any gap is found:
1) Generate missing tests first.
2) Generate/update missing docs second.
3) If tests/docs are blocked by design, propose minimal refactor and apply only if allowed.
4) Re-run the checklists mentally.
Repeat until pass or explicit documented blockers remain.

## Step 7 — Socratic Self-Check (before producing output)
Execute the 11-question Socratic Self-Check from `.github/instructions/mission-critical-checklists.instructions.md` under "Socratic self-check". If any answer reveals an uncaptured risk, add it as a gap and loop back to Step 6. Report using the "Socratic-Revealed Risks" table format from "Outcome presentation rules" in the same file. Include the table in the output even if empty (state "Socratic self-check: 0 new risks surfaced").

## Output
- Change inventory with role classification
- Project context map (patterns matched/deviated)
- Invariant check results
- Test adequacy matrix (change -> required -> existing -> gap)
- Documentation adequacy matrix (change -> required -> current -> gap)
- Regeneration actions taken
- Remaining gaps with blockers and recommended fixes
