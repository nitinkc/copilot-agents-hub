---
name: documentation-visualization-beautification
description: Improve documentation diagrams for mission-critical services. Select the right Mermaid diagram type by audience, keep diagrams readable, and ensure GitHub-renderable visualizations support business, technical, and machine understanding.
---
# Documentation Visualization & Beautification

## Goal
Produce diagrams that are useful, readable, and audience-appropriate.

## Supported Mermaid diagram families to prefer
- business/functionality: flowchart, journey, mindmap, requirementDiagram
- context/architecture: C4, architecture, dependency graph/flowchart LR
- runtime: flowchart, sequenceDiagram, stateDiagram-v2
- data/relationships: erDiagram

## Important note
Mermaid does not currently provide an official UML use-case diagram type.
When a use-case style view is needed, use:
- journey (actor view)
- flowchart (activity/decision flow)
- C4 context (system + actors + boundaries)

## Beautification rules
- one diagram per concern
- stable node ids and short labels
- business wording in high-level diagrams; technical wording in technical diagrams
- avoid giant everything-diagrams
- add a short explanation below each diagram
- split by capability or endpoint family when complexity grows
- show failure branches and important rules in runtime diagrams

## Validation
Before finishing:
- verify the chosen diagram type matches the audience question
- verify the diagram is likely renderable on GitHub
- verify the diagram improves understanding rather than repeating prose
