# Hexagonal Architecture Patterns — OrderTech Reference

## Purpose

Reference for code investigation to understand where errors originate in the
hexagonal architecture and whether boundaries are being violated. Used by the
`code-forensics` skill when analyzing code at deployed commits.

## Layer Definitions

```
┌───────────────────────────────────────────────┐
│             Infrastructure Layer              │
│  (Spring configs, K8s, Observability, DevOps) │
├───────────────────────────────────────────────┤
│               Adapter Layer                   │
│  ┌──────────────┐     ┌────────────────────┐  │
│  │  Inbound      │     │  Outbound          │  │
│  │  (REST, Msg)  │     │  (DB, Feign, Msg)  │  │
│  └──────┬────────┘     └─────────▲──────────┘  │
├─────────▼────────────────────────┤─────────────┤
│             Application Layer                 │
│     (Use Cases, BPMN Delegates, Mappers)      │
├───────────────────────────────────────────────┤
│               Domain Layer                    │
│     (Entities, Value Objects,                 │
│      Domain Services, DRL Rules)              │
└───────────────────────────────────────────────┘
```

## Error Origin by Layer

### Domain Layer
- **Expected**: Business rule violations, entity validation, domain invariants.
- **Exceptions**: `DomainException`, `BusinessRuleViolationException`, `IllegalStateException`.
- **Fix**: Logic fix in domain model. Check invariant correctness or caller misuse.
- **Red flag**: `NullPointerException` in domain → missing guard or bad input from application layer.

### Application Layer
- **Expected**: Use case orchestration failures, mapping errors, Flowable delegate exceptions.
- **Exceptions**: `UseCaseException`, `FlowableException`, `BpmnError`, `MappingException`.
- **Fix**: Check orchestration logic. For BPMN, check process definition + delegate.
- **Red flag**: Catches `SQLException` → hexagonal boundary violation.

### Adapter Layer (Inbound)
- **Expected**: Deserialization, validation, authentication.
- **Exceptions**: `HttpMessageNotReadableException`, `MethodArgumentNotValidException`.
- **Fix**: Controller validation, DTO constraints, security config.
- **Red flag**: Business logic in controller → boundary violation.

### Adapter Layer (Outbound)
- **Expected**: DB access failures, Feign/REST client failures, messaging failures.
- **Exceptions**: `JDBCException`, `FeignException`, `RestClientException`.
- **Fix**: Connection configs, timeout/circuit breaker settings, query performance.
- **Red flag**: Returns domain objects directly → should map through a port.

### Infrastructure Layer
- **Expected**: Spring Boot startup, configuration, K8s probe failures.
- **Exceptions**: `BeanCreationException`, `ConfigurationException`.
- **Fix**: `application.yml`, environment variables, K8s manifests.

## Boundary Violation Detection

| Violation | How to Detect | Impact |
|-----------|--------------|--------|
| Domain depends on infrastructure | Domain imports `javax.persistence.*`, Spring annotations | Tight coupling |
| Application catches infra exceptions | Try-catch around `SQLException` in use case | Leaky abstraction |
| Adapter contains business logic | If-else business rules in controller | Logic duplication |
| Port returns implementation types | Port interface returns JPA entity | Coupling to persistence |
| Controller calls repository directly | REST controller → repository, bypassing service | Skips orchestration |

## Flowable-Specific Patterns

### BPMN Delegate Error Handling
```java
// CORRECT: BpmnError for expected business errors
public class ReserveInventoryDelegate implements JavaDelegate {
    @Override
    public void execute(DelegateExecution execution) {
        try {
            // business logic
        } catch (InsufficientStockException e) {
            throw new BpmnError("INSUFFICIENT_STOCK", e.getMessage());
        }
        // Unexpected exceptions propagate for error boundary events
    }
}
```

### Common Flowable Issues
- **Serialization**: Non-serializable process variables → `SerializationException`
- **Async continuation**: Error in async job → stuck job, manual retry needed
- **Timer boundary**: Timer fires but delegate throws → retry loop
- **Expression resolution**: `${bean.method(arg)}` fails if bean not found
- **DRL interaction**: Drools rule evaluation within delegate → check rule session setup
