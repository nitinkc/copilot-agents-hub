# Code Forensics — Naming Traps & Resolution Reference

> Operational knowledge for resolving configLabel slugs to source repos and
> Artifactory paths. This file captures naming exceptions and verified patterns
> that `service_mappings.json` and `artifactory-path-map.conf` encode but that
> investigation workflows need to understand for fallback scenarios.

---

## 1. configLabel Prefix → Repo Prefix Mapping

| configLabel prefix | Repo prefix pattern | Example |
|---|---|---|
| `mbos-` | `Mbos*` | `mbos-customer-gateway` → `MbosCustomerGateway` |
| `mbo-` | `Mbos*` (NOT `Mbo*`) | `mbo-devicewarranty` → `MbosDeviceWarranty` |
| `bo-` | `Bo*` | `bo-account` → `BoAccount` |
| `ds-` | `Ds*` | `ds-fulfillment-order` → `DsFulfillmentOrder` |
| `wkfl-` | `Wkfl*` | `wkfl-provisioning` → `WkflProvisioning` |
| `xoms-` | `Xoms*` | `xoms-activation-journey` → `XomsActivationJourney` |
| `nxg-` | `nxg-*` (lowercase!) | `nxg-order-orch-service` → `nxg-order-orch-service` |
| `sik-` | `sik-*` (lowercase!) | `sik-order-service` → `sik-order-service` |

---

## 2. Naming Traps (exceptions to standard PascalCase)

These services do NOT follow standard PascalCase conversion. Always use
`service_mappings.json` as the primary lookup to avoid these traps.

| configLabel slug | Actual Repo | Trap |
|---|---|---|
| `mbo-devices` | `MbosDevice` | `mbo-` → `Mbos` + drop trailing `s` |
| `mbo-lineservice` | `MbosLine` | `mbo-` → `Mbos` + drop `service` |
| `mbo-accountservice` | `MbosAccount` | `mbo-` → `Mbos` + drop `service` |
| `mbo-devicewarranty` | `MbosDeviceWarranty` | `mbo-` → `Mbos` |
| `mbo-devicediagnostics` | `MbosDeviceDiagnostics` | `mbo-` → `Mbos` |
| `mbo-audit` | `MbosAudit` | `mbo-` → `Mbos` (not `MboAudit`) |
| `mbos-mno-provisioning2` | `MbosMnoProvisioning` | drop trailing `2` |
| `mbos-async-amdocs-adapter2` | `MbosAsyncAmdocsAdapter` | drop trailing `2` |
| `mbos-vvm` | `MbosVisualVoiceMail` | full name, not abbreviation |
| `xoms-gateway` | `XomsGateway` | NOT in service_mappings.json — use GitHub search |
| `nxg-*` / `sik-*` / `xm-*` | repo name = slug (lowercase) | NOT PascalCase |

**PascalCase fallback command** (cross-platform — macOS, Linux, Windows with Python):
```bash
python3 -c "import re,sys; print(re.sub(r'(?:^|-)(\w)', lambda m: m.group(1).upper(), sys.argv[1]))" "$SLUG"
# mbos-biller-account → MbosBillerAccount
# wkfl-lean-orchestrator → WkflLeanOrchestrator
```
Use ONLY after `service_mappings.json` returns no match. PascalCase does NOT handle the traps above.

---

## 3. Source Repo Branches — Why configLabel Branches Usually Don't Exist

CI (Concourse) creates a branch named after the configLabel at build time,
but branches get cleaned up. **Only ~10/148 currently exist at any time.**

- Source repo branches are Jira-ticket-named (e.g., `CMXOTOS-3605`), not version-named
- No tags are used; pom.xml has SNAPSHOT versions — build numbers are CI-generated
- **Do NOT rely on finding a configLabel branch in the source repo**
- **Use Artifactory → commit SHA** (SKILL.md Step 1c) — this is 100% reliable

---

## 4. Version Pattern → Branch Where Commit Lives

```
Version format          Branch                        Example
─────────────────────   ──────────────────────────    ─────────────────────────────
X.Y.Z (3 segments)      main                          mbos-biller-account-1.0.817 → main
X.Y.Z.N (4 segments)    <slug>-X.Y.Z (hotfix branch)  mbos-customer-gateway-1.0.350.1 → mbos-customer-gateway-1.0.350
Special: *-adapter2     main-2.0                      mbos-async-amdocs-adapter2-2.0.26 → main-2.0
```

---

## 5. Validated End-to-End Examples (live-tested 2026-04-11)

| configLabel | Config | Repo | SHA | PR | Jira | Notes |
|---|---|---|---|---|---|---|
| `wkfl-billing-order-1.0.4264.9` | ✅ | `WkflBillingOrder` | `0f08e063...` | #4775 | CMXOTB-5605 | hotfix, wkfl- prefix |
| `ds-mvno-account-1.0.708.2` | ✅ | `DsMvnoAccount` | `0cd93b4b...` | #709 | CMXOT1-1496 | hotfix, Jira in branch name |
| `mbos-biller-account-1.0.817` | ✅ | `MbosBillerAccount` | `3cf68290...` | #568 | CMXOTB-4951 | base version |
| `xoms-gateway-1.0.117` | ✅ | `XomsGateway` | `b2ab36e8...` | #270 | CMXOTP-4498 | NOT in service_mappings |
| `ds-mvno-order-1.0.680.3` | ✅ | `DsMvnoOrder` | `3098a367...` | #673 | CMXOT2-2536 | hotfix, revert PR |

---

## 6. Jira Ticket Extraction

Common project prefixes (note: some have digits like `CMXOT1`, `CMXOT2`):
- `CMXOTB-*` — billing team
- `CMXOTOS-*` — OT services team
- `CMXOTP-*` — provisioning team
- `CMXOT1-*` — team 1
- `CMXOT2-*` — team 2
- `CMXOTR-*` — another team

Extract with regex: `[A-Z][A-Z0-9]+-\d+` from PR title first, then branch name.

---

## 7. Clone + Checkout Protocol (ALL Clones)

> **Implemented in**: `incident-code-analyst.agent.md` § Clone and Checkout Protocol,
> `code-forensics/SKILL.md` Step 2. Keep all three in sync.

**Always use `--no-checkout` + `fetch SHA`** — for ALL versions, not just hotfix.

**Why not `--depth=N`?**
- `--depth=N` only fetches the default branch's history. Hotfix commits
  (4-segment versions like `X.Y.Z.N`) live on non-default branches and
  will NOT be included even with `--depth=200`.
- Shallow clones produce truncated `git blame` — 99% of lines attribute to
  the graft boundary commit instead of the real author.
- Full clone costs only ~3MB more disk and one extra network call.

**Correct pattern (resolve SHA FIRST, then clone):**
```bash
# 1. Resolve SHA from Artifactory (Step 1c in SKILL.md) — BEFORE clone
# 2. Clone without checking out any branch
git clone --no-checkout git@github.com:comcast-modesto/$REPO /tmp/$REPO
cd /tmp/$REPO
# 3. Fetch the specific SHA (makes it reachable regardless of branch)
git fetch origin $SHA
# 4. Checkout detached HEAD at that SHA
git checkout $SHA
# 5. Verify
[ "$(git rev-parse HEAD)" = "$SHA" ] && echo "MATCH" || echo "MISMATCH"
```
