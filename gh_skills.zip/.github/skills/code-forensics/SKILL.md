---
name: code-forensics
description: >
  Analyze source code at the exact deployed commit for any OrderTech service.
  Uses the configLabel → Artifactory → commit resolution chain, then performs
  git blame, recent change analysis, dependency audit, and config review.
---

# Skill: Code Forensics

## Goal

Analyze source code at the exact deployed commit for an OrderTech service,
identifying the code change, author, and context that caused or contributed
to a production error.

## When to Use

- Investigate the code that caused a production error
- Analyze what changed in a recently deployed service
- Check git blame for error-related lines
- Review configuration drift between builds
- Audit dependencies at the deployed version
- Trace from an ELK log entry to the exact source code

## Step 0 — Load Dependencies

```
read_file .github/skills/code-forensics/NAMING-AND-RESOLUTION.md
read_file .github/skills/code-forensics/HEXAGONAL-PATTERNS.md
```

NAMING-AND-RESOLUTION.md contains the complete traceability chain
(configLabel → Config → Source → Commit → PR → Jira), naming traps,
and Artifactory resolution logic that are critical for this skill.

## Input

One of:
- `configLabel` from an ELK log entry (e.g., `mbos-biller-account-1.0.817`)
- A service name + version
- A specific commit SHA + repo
- A stack trace with service context

Investigation depth:
- **shallow**: Stack trace mapping + blame only
- **standard**: + recent commits + dependencies
- **deep**: + config drift + full module analysis + hexagonal boundary check

## Workflow

### Step 1: Resolve configLabel → Source Repo + Commit

**1a. configLabel → Config Repo** (always works):

The configLabel IS a branch name in MobileBackOfficeConfig:
```bash
# See deployed configuration
gh api repos/comcast-modesto/MobileBackOfficeConfig/git/ref/heads/<configLabel>
```

**1b. configLabel → Source Repo Name**:

Strip version to get slug, then look up in service_mappings.json:
```bash
# Example: mbos-biller-account-1.0.817 → slug: mbos-biller-account
jq -r '.services[] | select(.service == "<slug>") | .repo_name' \
  .github/shared/service_mappings.json
```

If not found, apply naming traps from NAMING-AND-RESOLUTION.md §2.

PascalCase fallback (cross-platform — works on macOS, Linux, Windows with Python):
```bash
python3 -c "import re,sys; print(re.sub(r'(?:^|-)(\w)', lambda m: m.group(1).upper(), sys.argv[1]))" "$SLUG"
```

If still uncertain, try GitHub search:
```bash
gh api -X GET "search/repositories?q=<slug>+org:comcast-modesto" --jq '.items[].name'
```

**1c. configLabel → Exact Commit SHA** (via Artifactory — MANDATORY when configLabel available):

**This step is MANDATORY. Do NOT skip to HEAD of main.** Follow this resolution chain:

**Primary**: Artifactory POM property lookup:
```bash
.github/skills/elk-log-search/scripts/resolve-commits.sh \
  --version-file /tmp/versions.tsv \
  --path-map .github/shared/artifactory-path-map.conf \
  --out-dir /tmp/commits
```

Or manual single-service (fast-fail with alternate path, no sleeps):
```bash
# Determine group path from artifactory-path-map.conf
GROUP_PATH="com/comcast/xfinity/mobile"  # varies by prefix — check path-map
SLUG="mbos-biller-account"
VERSION="1.0.817"
SHA=""

# Attempt 1: standard group path (covers ~80% of services)
SHA=$(curl -sf --max-time 15 \
  "https://artifactory.comcast.com/artifactory/api/storage/xmobile-libs/${GROUP_PATH}/${SLUG}/${VERSION}/${SLUG}-${VERSION}.pom?properties=git.commitId" \
  | jq -r '.properties["git.commitId"][0] // empty')

# Attempt 2: if empty, try alternate group paths (no sleep — different URL, not same retry)
if [[ -z "$SHA" || ${#SHA} -ne 40 ]]; then
  for ALT_PATH in "com/comcast/xfinity/xoms" "com/comcast/xfinity/bo"; do
    [[ "$ALT_PATH" == "$GROUP_PATH" ]] && continue
    SHA=$(curl -sf --max-time 15 \
      "https://artifactory.comcast.com/artifactory/api/storage/xmobile-libs/${ALT_PATH}/${SLUG}/${VERSION}/${SLUG}-${VERSION}.pom?properties=git.commitId" \
      | jq -r '.properties["git.commitId"][0] // empty')
    if [[ -n "$SHA" && ${#SHA} -eq 40 ]]; then
      echo "Artifactory resolved via alternate path ${ALT_PATH}: ${SHA}"
      break
    fi
  done
fi

if [[ -n "$SHA" && ${#SHA} -eq 40 ]]; then
  echo "Artifactory resolved: ${SHA}"
else
  echo "Artifactory resolution failed — falling through to Fallback 1"
fi
# Max 3 HTTP requests, 0s sleep, ~45s max wall time (3 × 15s timeout)
```

**Fallback 1** (if Artifactory unavailable after 3 attempts): Hotfix branch lookup:

OrderTech repos do NOT use git tags (see NAMING-AND-RESOLUTION.md §3).
Instead, use the version pattern to find the branch where the commit lives:

```bash
# Parse version segments from configLabel: <slug>-<version>
# X.Y.Z (3 segments) → commit is on main
# X.Y.Z.N (4 segments) → commit is on hotfix branch: <slug>-X.Y.Z
# Special: *-adapter2 slug → commit is on main-2.0

# Example: wkfl-billing-order-1.0.4338.6 → 4 segments → hotfix branch
HOTFIX_BRANCH="${SLUG}-$(echo $VERSION | sed 's/\.[^.]*$//')"
# → wkfl-billing-order-1.0.4338

# Clone (if not already), then:
git fetch origin "${HOTFIX_BRANCH}"
git log "origin/${HOTFIX_BRANCH}" --oneline -20
# The N-th commit from the tip (where N = last segment, here 6) is the deployed commit.
# Count back from tip: commit at position N (1-indexed from tip) = deployed SHA.
SHA=$(git log "origin/${HOTFIX_BRANCH}" --format='%H' -"${N}" | tail -1)

# For 3-segment versions (no hotfix): commit is on main
git log origin/main --oneline -20
# Use Jira ticket or PR context to identify the exact commit.
```

**Fallback 2** (if branch lookup fails or version is 3-segment with no PR context):
Use HEAD of default branch with explicit warning:
```
⚠️ UNVERIFIED COMMIT: Artifactory resolution failed, hotfix branch lookup inconclusive.
Using HEAD of main. Code analysis may not reflect the exact deployed version.
Risk: If deployed version is a hotfix, rollback, or feature branch, findings may be WRONG.
```
This warning MUST appear in the output and in the final RCA report.

**1d. Commit → PR → Jira**:
```bash
REPO="MbosBillerAccount"
SHA="<commit_sha>"

# Get PR
gh api repos/comcast-modesto/${REPO}/commits/${SHA}/pulls \
  --jq '.[0] | "#\(.number) \(.title) [\(.state)] branch:\(.head.ref)"'

# Extract Jira key from PR title or branch: regex [A-Z][A-Z0-9]+-\d+
```

### Step 2: Clone at Deployed Commit

**Use `--no-checkout` for ALL clones** (not `--depth`). Shallow clones truncate
git blame (99% boundary lines) and cannot reach hotfix-branch SHAs.
See NAMING-AND-RESOLUTION.md §7 for details.

**SHA must be resolved (Step 1c) BEFORE cloning.**

```bash
REPO="MbosBillerAccount"
SHA="<commit_sha>"
WORK_DIR="/tmp/forensics-${REPO}-${SHA:0:8}"

# Reuse existing clone if present (avoids duplicate 60s+ clone operations)
if [ -d "$WORK_DIR/.git" ]; then
  echo "Reusing existing clone: $WORK_DIR"
  cd "$WORK_DIR"
  # Verify correct SHA is checked out; if not, fetch and checkout
  if [ "$(git rev-parse HEAD)" != "$SHA" ]; then
    git fetch origin "$SHA" 2>/dev/null || true
    git checkout "$SHA"
  fi
else
  git clone --no-checkout git@github.com:comcast-modesto/${REPO}.git "$WORK_DIR"
  cd "$WORK_DIR"
  git fetch origin "$SHA"      # ensures reachable even if on a non-default branch
  git checkout "$SHA"
fi

# Verify
[ "$(git rev-parse HEAD)" = "$SHA" ] && echo "MATCH" || echo "MISMATCH"
```

### Step 3: Stack Trace Mapping

If a stack trace is available, parse ALL frames — not just "our code":

```
Tier 1 — Our code (start here):
  com.comcast.xfinity.*
  com.comcast.mobile.*
  com.comcast.xm.*

Tier 2 — Framework/library code (DO NOT SKIP):
  org.flowable.*
  org.springframework.*
  org.apache.ibatis.*
  com.zaxxer.hikari.*
  oracle.jdbc.*

Tier 3 — JVM internals (usually skip unless NPE/concurrency):
  java.* / sun.* / jdk.*
```

For each "our code" frame, note: file, line, method, package.

**CRITICAL — Framework Trace-Through Rule (MANDATORY)**:
Do NOT stop investigation at the boundary between "our code" and framework code.
If the exception originates from or passes through framework/library frames
(org.flowable.*, org.springframework.*, org.apache.*, etc.), you MUST:
1. Identify the exact framework class, method, and line from the stack trace.
2. Read the framework source code at the **deployed version** (from pom.xml dependencies).
   Use: `gh api repos/{org}/{repo}/contents/{path}?ref={version-tag}` for open-source libs.
3. Find the actual null dereference, missing guard, or state corruption in the framework code.
4. Determine WHY the framework code encounters the error — what state was it in?
5. Trace back to what our code (or multi-instance contention) did to create that state.

"The exception is inside the framework" is NEVER an acceptable stopping point.
"Catch the exception" is symptom mitigation, not root cause analysis.
The root cause is: why does the framework reach that state?

**JVM Stack Trace Elision Detection (MANDATORY)**:
If the "Caused by" exception has ZERO stack trace frames (e.g., `NullPointerException: null`
with no `at ...` lines), this indicates JVM's `-XX:+OmitStackTraceInFastThrow` optimization.
The JVM elides stack traces after repeated identical exceptions. This means:
1. The same exception has been thrown MANY times (performance optimization).
2. The original stack trace with full frames existed in earlier log entries.
3. Action: Search ELK for the SAME exception type from the SAME service over a WIDER
   time range (24h-168h) to find the original un-elided stack trace.
4. If no un-elided trace found: read the framework source code directly at the deployed
   version to determine the NPE location from the code structure.
5. Record this finding: "JVM stack trace elision detected — indicates recurring exception."

### Step 3b: Resolve All Runtime Variables (MANDATORY — before Step 4)

Before analyzing the error origin, resolve EVERY runtime variable referenced in the
error context. Analyzing code without knowing the actual runtime values leads to
speculative conclusions. Resolve in this order:

1. **Config properties**: From MobileBackOfficeConfig branch (the configLabel IS the branch):
   ```bash
   gh api repos/comcast-modesto/MobileBackOfficeConfig/contents/application.yml?ref=<configLabel> \
     --jq '.content' | base64 -d
   ```
   Extract: timeouts, retry counts, feature flags, pool sizes, cron expressions.

2. **Timer / duration values**: If the error involves a timer (BPMN, scheduled task, timeout),
   find the actual configured value — not the default in code. Check:
   - Spring config (`application.yml` on the configLabel branch)
   - BPMN process definition (`timerEventDefinition` elements)
   - Hardcoded defaults in Java code (only if no config override)

3. **Feature flags / toggles**: Check if any feature flag gates the error path.
   Search the config for `enabled`, `feature`, `toggle`, `flag` properties.

4. **Environment-specific overrides**: Check `application-{profile}.yml` for the
   target environment (prod, stage, etc.).

**Output required**: A "Runtime Context" table before proceeding to Step 4:
```
| Variable | Source | Value |
|----------|--------|-------|
| <name>   | config/code/BPMN | <actual value> |
```
If a variable cannot be resolved, mark it `UNRESOLVED` with the attempted sources.

**BLOCKING**: If ANY critical variable (timeout, timer duration, retry count, pool size)
is UNRESOLVED after checking all sources, STOP. Do NOT proceed to Step 4. Either:
- Try alternative resolution paths (code defaults, parent POM, Spring profiles)
- Escalate as an investigation gap with explicit impact on analysis confidence

### Step 4: Error Origin Analysis

For the topmost "our code" frame:
1. Read the file — understand the method's purpose and logic.
2. Identify the error trigger — what condition caused the exception?
3. Trace data flow — follow the variable that caused the error backwards.
4. Check hexagonal boundary — is the error in Domain/Application/Adapter/Infrastructure?
   (See HEXAGONAL-PATTERNS.md)

**If the exception originates from a framework class (not our code):**
1. Read the framework class at the deployed version (Step 3 Framework Trace-Through Rule).
2. Identify the exact null dereference or assertion failure in the framework source.
3. Determine what state the framework expected vs. what state it found.
4. Trace backwards: what caused the unexpected state? Options:
   a. **Our code** passed an invalid argument or put the engine in an unexpected state.
   b. **Concurrency** — another thread/instance/DC modified shared state (DB, cache) between read and write.
   c. **Framework bug** — the framework has a known defect (check issue tracker at deployed version).
   d. **Version mismatch** — framework version has a known issue fixed in a later release.
5. For each hypothesis, check the framework issue tracker:
   `gh api "repos/{org}/{repo}/issues?q=<exception>+<method>&state=all" --jq '.[0:5] | .[].title'`
6. If it's a known framework bug fixed in a later version, the ROOT CAUSE is:
   "Framework bug in {lib}:{version} — fixed in {version}. Missing null check at {file}:{line}."
   NOT: "Add try-catch around the call."

### Step 4b: Upstream Producer Inspection (MANDATORY for contract-mismatch RCAs)

When the error involves a field expected to be populated but found null/empty/invalid
(contract mismatch between producer and consumer), the consuming service alone cannot
explain the root cause. You MUST inspect the upstream producer that should populate the field.

**Trigger conditions** (any one = MUST execute this step):
- BPMN variable diff shows a field null in FAIL but populated in CONTROL
- Exception involves a missing/null field that another service is responsible for setting
- Error message references a "not found" / "missing" / "required" value from upstream
- Phase 1 evidence shows the field is populated in some orders but not others

**Procedure**:
1. **Identify the upstream producer service** — from service-traversal DAG (Phase 3),
   API contract docs, or BPMN call activity definitions. The producer is the service
   that SETS the field value before the consuming service reads it.

2. **Resolve the upstream producer's deployed commit** — apply the same configLabel →
   Artifactory → commit SHA resolution chain (Steps 1-2) for the producer service.
   If the producer's configLabel is different from the consumer's, resolve both.

3. **Locate the producer code path** — find the method that populates the field:
   - For REST APIs: find the response DTO builder/mapper where the field is set
   - For BPMN variables: find the delegate/listener that calls `execution.setVariable()`
   - For Feign/downstream: find the client response mapping

4. **Determine WHY the field is not populated** — check:
   - Is the field conditionally set? Under what conditions is it skipped?
   - Is there a code path where the field is never set (missing assignment)?
   - Was the field recently added or changed? (git blame the line where it's set)
   - Is there a data dependency (e.g., field comes from a DB query that returned null)?

5. **Cross-reference with Phase 1 BPMN variable diff** — does the producer behavior
   explain the FAIL vs CONTROL divergence?

6. **Output**: Add to the Code Findings table:
   ```
   | upstream_producer_service | <slug> |
   | upstream_producer_commit  | <SHA> |
   | producer_populates_field  | <true/false — does the code path exist?> |
   | field_population_condition | <when is the field set vs skipped?> |
   | upstream_producer_verified | YES / NO / PARTIAL (<reason>) |
   ```

**BLOCKING**: For contract-mismatch RCAs, Phase 4 CANNOT be marked completed without
`upstream_producer_verified` being either `YES` or `PARTIAL` with documented reason.
`NO` means you did not attempt the inspection — loop back and complete it.

### Step 5: Git Blame + Recent Changes

```bash
# Who last touched the error line?
git blame -L <start>,<end> <file>

# What changed recently in the affected file?
git log --oneline --since="10 days ago" -- <file>

# Full diff of recent changes to the file
git log -p --since="10 days ago" -- <file>

# What changed in the affected package?
git log --oneline --since="10 days ago" -- <package_dir>/
```

**Fallback: GitHub API blame when clone is slow (repos > 1GB)**

If `git clone` times out (>60 seconds) or the repo is too large for local clone:

```bash
# Per-file commit history at the deployed commit (light blame):
gh api "repos/comcast-modesto/${REPO}/commits?sha=${SHA}&path=${FILE}&per_page=10" \
  --jq '.[] | "\(.sha[0:8]) \(.commit.author.date[0:10]) \(.commit.author.name) | \(.commit.message | split("\n")[0])"'

# Find commits mentioning specific method/feature:
gh api "repos/comcast-modesto/${REPO}/commits?sha=${SHA}&path=${FILE}&per_page=30" \
  --jq '.[] | "\(.sha[0:8]) \(.commit.author.date[0:10]) | \(.commit.message | split("\n")[0])"' \
  | grep -i "<method-or-feature-keyword>"

# Link commit to PR:
gh api "repos/comcast-modesto/${REPO}/commits/${SHA}/pulls" \
  --jq '.[0] | "#\(.number) \(.title) [\(.state)] by:\(.user.login)"'
```

This gives file-level history (not line-level), but is sufficient for:
- Identifying who last changed the file and when
- Finding recent modifications related to the error path
- Linking commits to PRs and Jira tickets

Record in the report: "Blame via GitHub API (clone impractical — large repo)."
**This fallback is MANDATORY when clone fails. Do NOT skip blame entirely.**

For each recent commit, assess:
```yaml
commit_assessment:
  sha: string
  author: string
  date: ISO8601
  message: string
  files_changed: string[]
  relevance: "direct" | "indirect" | "unrelated"
  risk_indicators:
    changes_error_handling: boolean
    changes_timeout_config: boolean
    changes_retry_logic: boolean
    changes_data_model: boolean
    changes_api_contract: boolean
    adds_new_dependency: boolean
    refactors_critical_path: boolean
  suspicion_score: float  # 0.0-1.0
```

### Step 6: Configuration Review

Check the deployed configuration via the configLabel branch:
```bash
# Get application.yml for this build
gh api repos/comcast-modesto/MobileBackOfficeConfig/contents/application.yml \
  --ref <configLabel> --jq '.content' | base64 -d
```

Look for:
- Timeout settings relevant to the error
- Circuit breaker configuration
- Connection pool sizes
- Feature flags
- DRL rule files (if Drools-based service)

### Step 7: Dependency Analysis (standard+ depth)

```bash
cd "$WORK_DIR"
# If Maven project:
mvn dependency:tree -DoutputType=text 2>/dev/null | head -100

# Check for recently changed dependencies:
git diff HEAD~5..HEAD -- pom.xml
```

Check for:
- Recently upgraded dependencies
- Transitive dependency conflicts
- SNAPSHOT dependencies in production (should never exist)

### Step 8: Hexagonal Boundary Check (deep depth only)

Using HEXAGONAL-PATTERNS.md:
- Identify which layer the error originates in
- Check for boundary violations
- Verify error handling follows platform patterns
- Check Flowable BPMN delegate expressions if error is in workflow path

### Step 9: BPMN Process Definition Audit (MANDATORY for Flowable services)

If the service under investigation uses Flowable (detected by: `processDefinitionId` in logs,
`FlowableException` in stack trace, `.bpmn20.xml` files in repo, `flowable` in pom.xml):

**9a. Extract deployed process version from logs:**
The `processDefinitionId` field (e.g., `cancelBilling:402`) contains the BPMN deployment version.
Extract the version number (after the colon).

**9b. Find the BPMN definition source file:**
```bash
find "$WORK_DIR" -name "*.bpmn20.xml" -o -name "*.bpmn" | head -20
# Match by process ID from logs
grep -l '<process id="cancelBilling"' $(find "$WORK_DIR" -name '*.bpmn*')
```

**9c. Check BPMN changes in recent commits:**
```bash
git log --oneline --since="30 days ago" -- '*.bpmn20.xml' '*.bpmn'
git log -p --since="30 days ago" -- '*.bpmn20.xml' '*.bpmn'
```

**9d. Analyze the BPMN XML for error-relevant elements:**
- Service task `delegateExpression` values — do they reference the failing delegate?
- Boundary error events — are they catching the right error codes?
- Execution listeners — any listeners on the failing activity?
- Multi-instance configurations — could parallel execution cause state conflicts?
- Timer boundary events — could timer firing overlap with process cancellation?
- Expression syntax — `${bean.method(execution)}` references that could NPE

**9e. Compare with prior version (if available):**
```bash
# If deployer version is known, check what changed between versions
git log --oneline HEAD~10..HEAD -- '*.bpmn20.xml' '*.bpmn'
```

Output: BPMN definition file, deployed version, last change date/commit, relevant expressions and boundary events.

### Step 10: Flowable Engine Deep Dive (when exception is INSIDE Flowable internals)

If the exception chain contains `FlowableException` → `ELException` with NPE,
or other errors from `org.flowable.*` internal classes (not user delegates):

**10a. Identify the failing EL expression:**
From the BPMN XML, find the expression being evaluated when the error occurred.
Match via the service task, boundary event, or listener that was executing.
```bash
# Extract all expressions from the BPMN
grep -oP '\$\{[^}]+\}' <bpmn-file>
```

**10b. Identify the execution state at failure:**
- Was the process being deleted/cancelled? (Check for `deleteProcessInstance` or `PROCESS_CANCELLED` in prior log entries)
- Was the process in an async job? (Check `logType=STANDARD` for job executor entries)
- Was the expression evaluated during a lifecycle event (start/end/take transition)?

**10c. Check Flowable version and known issues:**
```bash
# Get Flowable version from pom.xml
grep -A1 'flowable' "$WORK_DIR/pom.xml" | grep version
```
Search Flowable GitHub issues: `https://github.com/flowable/flowable-engine/issues?q=<exception pattern>`

**10d. Analyze the interaction between user code and engine lifecycle:**
- Does user code call `deleteProcessInstance()` and then try to access process variables?
- Does user code call engine APIs that trigger EL evaluation on a terminated execution?
- Is there a race between process deletion and EL evaluation in boundary/listener events?

**10e. Output:**
- Flowable version deployed
- Failing EL expression
- Engine state at failure (running/deleting/deleted)
- Known Flowable issue match (Y/N + link)
- Interaction defect: what user code triggers the engine-internal failure

## Output Contract

```yaml
code_investigation_result:
  service: string                 # serviceName slug
  configLabel: string             # Exact build
  deployed_commit: string         # Git SHA
  source_repo: string             # GitHub repo name
  pr_number: int
  jira_ticket: string
  investigation_depth: "shallow" | "standard" | "deep"
  error_origin:
    file: string
    line: int
    method: string
    layer: "domain" | "application" | "infrastructure" | "adapter"
    root_cause_description: string
    trigger_condition: string
  git_forensics:
    blame_author: string
    blame_commit: string
    blame_date: ISO8601
    recent_commits: CommitAssessment[]
    most_likely_culprit: string   # Commit SHA
    culprit_confidence: float
  config_findings:
    relevant_configs: ConfigEntry[]
    config_drift: ConfigChange[]  # vs previous version
    misconfiguration_detected: boolean
  dependency_findings:
    recently_changed: Dependency[]
    conflicts: DependencyConflict[]
  evidence_summary:
    - evidence_type: "code" | "commit" | "config" | "dependency"
      description: string
      confidence: float
      reference: string           # file:line or commit SHA
  upstream_producer:              # Present when Step 4b executed (contract-mismatch RCAs)
    upstream_producer_service: string  # serviceName slug of the producer
    upstream_producer_commit: string   # Git SHA of producer's deployed version
    producer_populates_field: boolean  # Does the code path to set the field exist?
    field_population_condition: string # When is the field set vs skipped?
    upstream_producer_verified: "YES" | "NO" | "PARTIAL"  # PARTIAL requires reason
    verification_notes: string    # Details of what was checked
```

## Failure Modes

- **Repo not found**: Check naming traps (NAMING-AND-RESOLUTION.md). Try fallback search.
- **Commit not in Artifactory**: Use configLabel as branch name in source repo (may exist).
- **Stack trace unavailable**: Start from the ELK `logger_name` field to identify the Java class.
- **No recent changes**: The bug may be latent — triggered by new data, load, or upstream change.
