---
applyTo: "**/*.java,**/src/test/**/*.java"
---
# Development Process (Practical Development with TDD)

This instruction file mirrors the `dev-pilot` workflow.
If the agent is selected, follow its phases in order.
If the agent is not selected, emulate the same phases directly from these instructions.
Stack/tool defaults and instruction scope map: `.github/shared/playbook-defaults.yaml`.

## Skill invocation rule
When a workflow step references a "Preferred skill", you MUST use `read_file` to load `.github/skills/<skill-name>/SKILL.md` and follow every step it defines. The inline fallback is only for when the skill file cannot be loaded. Do NOT skip loading the skill file.

## Workflow map (agent <-> skill <-> execution)
1. INTAKE (lightweight)
   - **MANDATORY — Read and follow**: `.github/skills/dev-requirements-intake/SKILL.md`
   - Inline fallback (only if skill file unavailable): summarize intent, infer candidate acceptance criteria, identify constraints and targeted questions
   - **DEVELOPER GATE**: Present ACs, constraints, open questions, and thin-slice order. STOP and WAIT for developer confirmation before proceeding.
   - **AFTER DEVELOPER RESPONDS**: Incorporate feedback into requirements and ACs. Then proceed to **DESIGN**.
2. DESIGN
   - **MANDATORY — Read and follow**: `.github/skills/dev-design-blueprint/SKILL.md`
   - Inline fallback (only if skill file unavailable): define endpoint contract, domain invariants, DB plan, outbound plan, error taxonomy
   - **DEVELOPER GATE**: Present the design blueprint. STOP and WAIT for developer approval before proceeding.
   - **AFTER DEVELOPER RESPONDS**: Incorporate feedback into the blueprint. Then proceed to **PLAN**. **Never skip PLAN.**
3. PLAN
   - **MANDATORY — Read and follow**: `.github/skills/dev-test-plan/SKILL.md`
   - Inline fallback (only if skill file unavailable): map each acceptance criterion (explicit or inferred) to the smallest useful test seam and thin-slice order
   - **DEVELOPER GATE**: Present the test plan. STOP and WAIT for developer approval before proceeding.
   - **AFTER DEVELOPER RESPONDS**: Incorporate feedback into the test plan. Then proceed to **BUILD**. **Never skip PLAN to jump to BUILD.**
4. BUILD
   - **MANDATORY — Read and follow**: `.github/skills/dev-tdd-loop/SKILL.md`
   - Test execution: `.github/skills/ltg-test-execution-loop/SKILL.md` (used at every VERIFY step)
   - Inline fallback (only if skill file unavailable): RED -> GREEN -> REFACTOR per thin slice; run tests via Maven after each step
5. INTEGRATE/HARDEN
   - **MANDATORY — Read and follow**: `.github/skills/dev-integration-hardening/SKILL.md`
   - Test execution: `.github/skills/ltg-test-execution-loop/SKILL.md`
   - Inline fallback (only if skill file unavailable): add DB, dependency failure, security, and guard tests when relevant; execute and verify
6. DOCUMENTATION
   - **MANDATORY — Read and follow**: `.github/skills/documentation-living-views/SKILL.md`
   - Inline fallback (only if skill file unavailable): create/update the affected documentation levels and machine manifest
7. QUALITY GATE (mandatory)
   - **MANDATORY — Read and follow**: `.github/skills/mission-critical-quality-gate/SKILL.md`
   - Test execution: `.github/skills/ltg-test-execution-loop/SKILL.md`
   - Inline fallback (only if skill file unavailable): execute the same checklist described below; run tests via Maven and classify any failures
8. REVIEW
   - **MANDATORY — Read and follow**: `.github/skills/dev-review-ready/SKILL.md`
   - Inline fallback (only if skill file unavailable): summarize changes, test coverage, documentation coverage, compatibility, and remaining gaps

## Primary rule
Development can start from:
- a business need / functional change description, and/or
- current edits (`#changes`), and/or
- explicit requirements/acceptance criteria (if provided)

Do **not** require a formal requirements template.
Infer candidate acceptance criteria from the request + existing project patterns.
Ask only targeted clarifying questions when ambiguity blocks writing correct tests or when a high-risk invariant might be violated.

Execution continuity rule:
- After BUILD becomes green, continue through INTEGRATE/HARDEN, CRITICAL REVIEW, REVIEW-READY DRAFT, TEST VERIFICATION, QUALITY GATE, DOCUMENTATION, FINAL QUALITY GATE, and REVIEW-READY.
- **STOP for developer review** at these checkpoints: step 6 (critical review), step 7 (review-ready draft), step 14 (test verification complete), step 16 (quality gate + documentation mode choice), step 23 (documentation summary), step 24 (final quality gate).
- At every developer checkpoint, present the developer with **explicit numbered action options** (e.g., Approve / Request changes / Approve with notes). Never stop with just a summary — always tell the developer what they can do next and what happens after each choice.
- Between checkpoints, emit Step Summary Blocks showing: what was done, key output, files touched, open items, and next step.
- The developer may say "run all steps inline" to skip intermediate checkpoints (steps 1–3 gates are never skippable).

## Intake checklist
- Summarize what the change is doing (based on request and/or `#changes`).
- Convert the intent into explicit or inferred acceptance criteria (Given/When/Then when possible).
- Identify constraints:
  - backward compatibility
  - idempotency/duplicate handling
  - payload/page/batch/string bounds
  - expected HTTP status and stable errorCode
  - DB and outbound dependency behavior
- Extract business dimensions (from `dimension-extraction.instructions.md`): capability ID, business goal, actor, trigger, outcome, business value, preliminary rule IDs, key entities, requirement keywords.
- Ask only minimal targeted questions (do not request a full template).

## Design checklist
Produce a minimal design blueprint for the next thin slice.
Enforce ALL non-negotiables (A through H) from `copilot-instructions.md` during design. Key items:
- endpoint contract and DTO validation/bounds
- non-negotiable C rules: cascade validation, constraint propagation, doc-code invariant consistency
- service responsibilities and business invariants
- persistence/dedupe/transaction plan
- outbound timeout/retry/parsing/correlation plan
- error taxonomy (errorCode -> status -> meaning)
- dependency governance: NEVER add new dependencies unless developer explicitly requests
- non-negotiable H rules: boundary symmetry, defensive defaults, resource acquisition symmetry, singleton safety

## Plan checklist
For each acceptance criterion (explicit or inferred), choose the smallest useful test seam:
- unit, MockMvc, contract (if used), stubbed client, repository integration, guard tests

Apply the test type decision matrix from `testing-and-determinism.instructions.md` section 11.

Sequence work in thin slices.

## TDD expectations
- RED tests must fail for the correct reason.
- GREEN should implement only what the failing tests require. Enforce ALL non-negotiables (A through H) during GREEN.
- REFACTOR must preserve behavior and compatibility. Verify API surface stability.

Apply mandatory test scenarios (section 12), validate-before-execution rules, failure classification, and fix loop (section 13) from `testing-and-determinism.instructions.md`.

## Mandatory integrate/harden checklist
After a slice is green, add the minimum required hardening:
- repository tests for constraints/rollback/bounded queries if DB touched
- stub tests for timeouts/retry caps/parsing safety if outbound touched
- MockMvc tests for safe error envelope and validation determinism
- security behavior tests when auth/URL input/content limits matter
- guard tests only when they prevent future drift

Apply failure classification and fix loop from `testing-and-determinism.instructions.md` section 13.

## Mandatory documentation step
All `docs/generated/` paths are relative to the project root. In multi-project workspaces, each project maintains its own `docs/generated/` folder.

After integrate/harden and before quality gate:
- If docs do not exist, bootstrap:
  - `docs/generated/01-business-capabilities.md`
  - `docs/generated/02-service-context.md`
  - `docs/generated/03-runtime-flows.md`
  - `docs/generated/04-technical-map.md`
  - `docs/generated/machine/service-manifest.yaml`
  - `docs/generated/machine/dependency-graph.mmd`
- If docs exist, update the affected levels only.
- Focus documentation on capabilities, business behavior, rules, dependencies, and impact clues -- not just code narration.
- For changed APIs/dependencies/rules, update machine-readable manifests and dependency graphs.
- Use Mermaid diagrams where they improve understanding.

## Mandatory end-stage quality gate
Before considering a change done:
1. Build a project context map:
   - compare changes against existing project patterns (error envelope, correlationId, outbound config, repo patterns, test conventions, documentation patterns)
   - flag deviations; accept only when they clearly reduce risk
2. Build a traceability matrix:
   - acceptance criteria (explicit or inferred) OR change areas
   - required scenarios
   - covering tests
3. Whole-project invariant checklist:
   - backward compatibility (no removed/renamed params/fields unless versioned; stable errorCode meanings)
   - boundedness (pagination capped; batch/list/string size caps; no unbounded loops/retries)
   - IO safety (outbound timeouts; bounded retries for safe operations only)
   - error safety (consistent safe error envelope; no stack traces)
   - idempotency (side-effecting operations replay-safe)
   - layering (controller thin; business in service; persistence in repo; outbound in client)
   - security hygiene (no secrets logged; SSRF allowlist; strict boundary validation)
4. Test adequacy matrix:
   - change/risk -> required scenarios -> existing tests -> missing tests
   - check test quality: deterministic, non-brittle, aligned with project conventions
5. Documentation adequacy matrix:
   - change/risk -> required doc levels/artifacts -> current state -> gaps
   - check all levels: business capabilities, service context, runtime flows, technical map, glossary, dependency catalog, machine manifests
6. If any gap exists:
   - generate or update tests first
   - generate or update docs second
   - then make the smallest safe code change needed
   - rerun the quality gate mentally until pass or blockers are documented

Apply introspection questions from `testing-and-determinism.instructions.md` section 14.

## Review-ready output
Always finish with:
- what changed and what behavior it implements
- acceptance criteria addressed (explicit or inferred)
- files changed
- what tests prove
- what docs changed and which audience they serve
- compatibility statement
- confidence statement and remaining risks (see `testing-and-determinism.instructions.md` section 14)
- assumptions, targeted questions (if any), and blockers
