---
applyTo: "**"
---

# ELK Log Search — Quick Reference

> **This file is a compact trigger guide only.**
> When composing any real query, load the full reference first:
> `read_file .github/skills/elk-log-search/FIELD-REFERENCE.md`
> It contains all enum values, query recipes, and serviceName mappings.

## RCA Skill Ecosystem

For investigations beyond simple queries, the `incident-investigator` agent orchestrates:

| User intent | Skill to use |
|---|---|
| Quick "how bad is it?" | `quick-triage` → FMEA scoring + recommendation |
| Impact scope | `blast-radius` → services, DCs, channels, customers |
| Multi-service tracing | `service-traversal` → DAG traversal + pattern detection |
| Code at deployed version | `code-forensics` → configLabel → commit → git blame |
| Full root cause analysis | `rca-synthesis` → 7 frameworks + ACH Matrix + Abductive Verification |
| Adversarial critique | `rca-quality-gate` → 3 critics + meta-reviewer + Socratic gates |
| Fix proposals | `rca-recommendations` → control classification + Jira tickets |
| Error classification | `error-taxonomy` → 8 categories, 30+ subcategories |

# ELK Log Search — Query Composition Reference

> When a user asks about logs, errors, traces, or production behavior,
> compose a precise query using the rules below instead of resorting to
> generic full-text search. Full field reference with enum values and
> query recipes: `.github/skills/elk-log-search/FIELD-REFERENCE.md`

## Step 1 — Map user intent to the right field

| User says | Field to filter | Query type |
|---|---|---|
| "errors for service X" | `level.keyword` = `ERROR` + `serviceName.keyword` wildcard | `term` + `wildcard` |
| "5xx / failures / timeouts" | `status.keyword` in `["500","502","503","504"]` | `terms` |
| "requests to / from service X" | `logType.keyword` = `API_REQUEST` or `API_RESPONSE` | `term` |
| "downstream calls / feign calls" | `logType.keyword` = `DOWNSTREAM_REQUEST` or `FEIGN_REQUEST` | `terms` |
| "trace request ID abc-123" | `GlobalTrackingId` (match) + `globaltrackingid.keyword` (term) | both spellings |
| "TELESALES / WEB / RETAIL channel" | `SalesChannel.keyword` | `term` |
| "postpaid / prepaid accounts" | `TenantId.keyword` | `term` |
| "in datacenter X" | `datacenter.keyword` | `term` |
| "exception / stack trace / NullPointer" | `message` (free text) | `query_string` |
| "slow / high latency" | `logType.keyword` = `API_RESPONSE`, sort by `@timestamp`, show `duration` | filter + `_source` |
| "which services have most errors" | agg on `serviceName.keyword`, filter `level.keyword=ERROR` | `terms` aggregation |

## Step 2 — Field tiers (determines query clause to use)

**Tier 1 — enum, always use `term`/`terms` with `.keyword`:**
`level` · `logType` · `datacenter` · `environment` · `SalesChannel` · `TenantId` · `method` · `status` · `statusCode` · `httpCode`

**Tier 2 — high cardinality, use `term` (exact) or `wildcard` (partial) with `.keyword`:**
`serviceName` · `configLabel` · `globaltrackingid` · `threadContextId` · `requestId` · `logger_name` · `uri` · `url_path` · `comcastAccountNumber` · `domain` · `code`

**Tier 3 — free text only, use `match` or `query_string` (NO `.keyword`):**
`message` · `LogEventMessage` · `GlobalTrackingId` (mixed-case variant) · `SessionId`

## Step 3 — Key enum values to know

```
level:       ERROR | WARN | INFO | DEBUG | TRACE
logType:     STANDARD | API_REQUEST | API_RESPONSE |
             DOWNSTREAM_REQUEST | DOWNSTREAM_RESPONSE |
             FEIGN_REQUEST | FEIGN_RESPONSE
environment: mbosProd (production) | mbosPreprod | mbosStage | mbosQa
status:      200 | 204 | 400 | 404 | 422 | 500 | 502 | 503 | 504
SalesChannel: WEB | TELESALES | RETAIL | XFINITY_APP | ONLINE | ETL | MOBILE
TenantId:    POSTPAID | PREPAID | TRIAL
method:      GET | POST | PUT | PATCH | DELETE
datacenter:  wc-g2 | po-g2 | as-g7 | as-g6 | ho-g3 | ch2-g2
```

## Step 4 — serviceName pattern

Services are named `{datacenter}-{slug}-production`. Always use wildcard:
```json
{ "wildcard": { "serviceName.keyword": "*biller-account*" } }
```

Full alias table and DC prefix mappings are in `FIELD-REFERENCE.md` (loaded in Step 0
of the skill). Do not maintain a separate copy here.

## Step 5 — Always include time range

```json
{ "range": { "@timestamp": { "gte": "now-1h" } } }
```

**Time range by query type:**
| Query type | Default | Notes |
|---|---|---|
| Transaction/ID search (order ID, tracking ID, threadContextId) | `now-168h` (7 days) | Always max for specific IDs |
| Service error search | `now-1h` to `now-24h` | Start narrow, widen as needed |
| Aggregation / top-errors | `now-1h` to `now-4h` | Short windows for current state |
| Trace (`elk-query.sh trace`) | `now-168h` | Hardcoded max |

**Anti-pattern**: using `now-1h` or `now-24h` for order/tracking ID lookups.
When investigating a specific incident with known IDs, ALWAYS use `now-168h`.

## Step 6 — GlobalTrackingId tracing (two spellings required)

```json
{ "bool": { "should": [
  { "match": { "GlobalTrackingId": "<id>" } },
  { "term":  { "globaltrackingid.keyword": "<id>" } },
  { "match": { "threadContextId": "<id>" } }
], "minimum_should_match": 1 }}
```

## Step 7 — Execute using elk-query.sh

```bash
# Preferred: named commands (default: prod)
elk-query.sh search --service biller-account --level ERROR --hours 2
elk-query.sh search --service xoms-biller --query 'updateCMTs' --exclude-level INFO --hours 2
elk-query.sh search --service xoms-biller --source '@timestamp,serviceName,level,status,message'
elk-query.sh search --service ott-fulfillment --level ERROR --agg datacenter:6 --hours 4
elk-query.sh top-errors --hours 1 --top 20
elk-query.sh top-errors --service biller-account --hours 1
elk-query.sh trace <globalTrackingId>
elk-query.sh identify <uuid>                  # auto-detect: GTI vs SessionId (max 2 queries)
elk-query.sh first-occurrence --service lean-orchestrator --query "purchasedOfferId" --hours 168
elk-query.sh errors --service subscriber --hours 4
elk-query.sh field-values --field level
elk-query.sh field-values --field serviceName --top 50
elk-query.sh fields
elk-query.sh fields --index bis-prod-*

# BPMN service commands (wkfl-* services):
elk-query.sh bpmn-variables --service ott-fulfillment --compare-control
elk-query.sh phase1-bpmn --service ott-fulfillment --hours 24

# Raw Elasticsearch JSON (replaces sourcing elk-lib.sh):
elk-query.sh raw --body '{"size":0,"query":{...},"aggs":{...}}'
elk-query.sh raw --body-file /tmp/query.json | jq '.rawResponse.aggregations'
elk-query.sh raw --body '{...}' | python3 -c 'import json,sys; ...'

# Lower environment (stage/QA/dev/preprod):
elk-query.sh --env lower search --service biller-account --level ERROR --hours 2
elk-query.sh --env lower errors --service subscriber --hours 4
elk-query.sh --env lower top-errors --hours 1
elk-query.sh --env lower indices            # discover available index patterns
elk-query.sh --env lower field-values --field environment --top 20
ELK_ENV=lower elk-query.sh trace <globalTrackingId>
```

## Index patterns available

| Pattern | Use for | Cluster |
|---|---|---|
| `order-tech-*` | All OrderTech microservice logs (**default**) | prod + lower |
| `bis-prod-*` | BIS service logs | prod |
| `nginx-prod-*` | NGINX / load balancer access logs | prod |
| `nginx-lower-*` | NGINX / load balancer access logs | lower |
| `vendor-proxy-prod-*` | Vendor proxy layer | prod |
| `bom-prod-*` | BOM service logs | prod |

> **Lower env tip:** Run `elk-query.sh --env lower indices` to discover all
> available index patterns. Use `environment.keyword` to filter within
> `order-tech-*`: `mbosStage`, `mbosQa`, `mbosDev`, `mbosPreprod`.
