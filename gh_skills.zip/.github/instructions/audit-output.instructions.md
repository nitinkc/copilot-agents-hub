---
name: audit-output-standards
description: Formatting standards for all codebase audit output files
applyTo: 'docs/generated/audit/**'
---
# Audit Output Standards

All audit files in this directory must follow these formatting rules:

## File Header
Every file starts with title, metadata block (audit date, repository, auditor,
scope), and a horizontal rule separator.

## Severity Classification
- 🔴 Critical: Production risk, data loss potential, security vulnerability
- 🟠 High: Significant quality/maintainability issue, should address in next sprint
- 🟡 Medium: Improvement opportunity, plan within next 2-3 sprints
- 🟢 Low: Nice-to-have, tech debt reduction, modernization opportunity

## Finding Format
Every finding must include the fields below. Use this template exactly:

```markdown
### {PREFIX-NNN} {Severity Emoji} {Concise Title}

**Severity**: {🔴 Critical | 🟠 High | 🟡 Medium | 🟢 Low}
**Location**: `{file/path.java:L42}` (or "Project-wide")
**Standard**: {Industry standard reference, e.g., OWASP A03, Clean Architecture}
**Impact**: {One-sentence business/technical impact statement}

{2-4 sentence description explaining the issue with specific code references.}

**Evidence**:
```{language}
// code snippet (max 15 lines) demonstrating the issue
```

**Recommendation**: {Specific, actionable fix — detailed enough to create a story}
**Effort**: {S (< 1 day) | M (1-3 days) | L (3-5 days) | XL (1+ sprints)}
```

**Prefix Registry**:
| Prefix | Category | Output File |
|---|---|---|
| TD- | Technical Debt | 01-TECHNICAL-DEBT.md |
| FL- | Flowable/BPMN | 02-FLOWABLE-BPMN.md |
| AR- | Architecture | 03-ARCHITECTURE.md |
| TQ- | Test Quality | 04-TEST-QUALITY.md |
| BP- | Business/Ops | 05-BUSINESS-PERSPECTIVE.md |
| SC- | Security (consolidated) | 06-SECURITY-COMPLIANCE.md |

## Summary Tables
Each category file includes a summary table at the top with severity counts.
The executive summary includes the overall health score calculation.

## Action Items File
The 07-ACTION-ITEMS.md file consolidates all findings as story-ready items
with title, description, acceptance criteria, effort, priority, and category tags.
