---
applyTo: "**/src/test/**/*.java,**/*Test.java,**/*IT.java"
---
# Mission-Critical Testing for Spring Boot REST Microservices (No Performance Tests)

This instruction file mirrors the `test-generator` workflow.
If the agent is selected, follow its steps in order.
If the agent is not selected, use this file to execute the same test-generation and review workflow inline.
Stack/tool defaults and instruction scope map: `.github/shared/playbook-defaults.yaml`.

## Skill invocation rule
When a workflow step references a skill by name, you MUST use `read_file` to load `.github/skills/<skill-name>/SKILL.md` and follow every step it defines. The inline fallback is only for when the skill file cannot be loaded. Do NOT skip loading the skill file.

## Workflow map (agent <-> skill <-> execution)
1. ANALYZE
   - **MANDATORY — Read and follow**: `.github/skills/ltg-code-analysis/SKILL.md` + `.github/skills/ltg-best-practice-context/SKILL.md`
   - Inline fallback (only if skill file unavailable): identify modified production files, extract changed public methods/endpoints, detect test gaps, load repo testing standards
2. DETERMINE
   - **MANDATORY — Read and follow**: `.github/skills/ltg-test-type-determination/SKILL.md`
   - Inline fallback (only if skill file unavailable): apply the test type decision matrix from `testing-and-determinism.instructions.md` section 11 to classify each changed file and choose the smallest test seam
3. GENERATE
   - **MANDATORY — Read and follow**: `.github/skills/ltg-test-generation/SKILL.md`
   - Inline fallback (only if skill file unavailable): generate test classes using repo conventions -- happy path, validation, boundary, timeout, idempotency scenarios
4. VALIDATE
   - **MANDATORY — Read and follow**: `.github/skills/ltg-validation/SKILL.md`
   - Inline fallback (only if skill file unavailable): check determinism (no sleeps), no redundant duplicates, compilation sanity
5. EXECUTE
   - **MANDATORY — Read and follow**: `.github/skills/ltg-test-execution-loop/SKILL.md`
   - Inline fallback (only if skill file unavailable): run tests via Maven, classify failures (COMPILE/MOCK_WIRING/ASSERTION/SCHEMA/ENVIRONMENT/PRODUCTION_BUG), loop back max 5 iterations
6. CRITICAL REVIEW
   - **MANDATORY — Read and follow**: `.github/skills/ltg-critical-review/SKILL.md`
   - Inline fallback (only if skill file unavailable): cross-check completeness, run introspection questions, regenerate missing tests (max 3 gap-fill iterations)

## Test design fundamentals
Follow the determinism, isolation, and bounds rules from `testing-and-determinism.instructions.md` section 0.

## Required test layers (as applicable)
A) Unit tests
- JUnit 5 + Mockito
- Happy path, invalid input, boundary values, business errors, technical errors
- Idempotency/dedupe tests for side-effecting flows

B) Provider-side API tests
- MockMvc for controller behavior
- Validate:
  - success responses
  - 400 validation responses
  - 401/403 when applicable
  - safe error envelope with stable errorCode
- If the repo uses Spring Cloud Contract (or equivalent), update provider verification as part of controller/API changes

C) Consumer/dependency tests
- Use WireMock or MockWebServer for outbound HTTP dependencies
- Prove:
  - request shape
  - timeout enforcement
  - retry cap enforcement
  - parsing safety for malformed/missing fields/unexpected status codes

D) Repository/DAO integration tests
- Use embedded DB slice tests where appropriate
- Prove:
  - unique constraints for dedupe/idempotency
  - rollback behavior
  - bounded queries and pagination caps

E) Resilience/security behavior tests
- Add tests for:
  - dependency timeouts
  - dependency 5xx responses
  - malformed payloads
  - 401/403 behavior
  - SSRF allowlists if URL input exists
  - payload/page/batch cap enforcement

## Test review checklist (mandatory)
Before finishing:
- Are negative tests present?
- Are boundary tests present for every declared cap?
- Are dependency failure tests present where outbound dependencies exist?
- Are duplicate/idempotency tests present where side effects exist?
- Are error assertions stable (status, errorCode, key fields) rather than brittle exception text?
- Are tests deterministic and free of sleeps or hidden timing assumptions?

## Mandatory regeneration and guard tests
Apply gap regeneration rules from `testing-and-determinism.instructions.md` section 14.
For guard test details, see `testing-and-determinism.instructions.md` section 9.
