---
applyTo: "**/*.java,**/*.md,**/*.yml,**/*.yaml,**/*.bpmn20.xml,**/*.bpmn"
---

# Jira & Wiki Context Integration

## When to fetch Jira/wiki context

Agents MUST invoke the `jira-wiki-reader` skill when **any** of these are true:

1. **User provides a ticket key or Jira URL** — fetch the ticket immediately.
2. **User provides a Confluence/wiki URL** — fetch the wiki page immediately.
3. **PR title, branch name, or commit message contains a ticket key** (pattern: `[A-Z][A-Z0-9]+-\d+`) — fetch the ticket for traceability.
4. **Grooming, planning, or refinement** — user says "groom", "refine", "plan", "break down" with a ticket reference.
5. **Development kickoff** — user says "start working on", "pick up", "implement" with a ticket reference.
6. **Bug investigation** — git log/blame output contains ticket references.
7. **Wiki links in ticket descriptions** — after fetching a ticket, scan the description for `etwiki.sys.comcast.net` URLs and **automatically** fetch them. Do NOT ask for permission.

## How to invoke

Read the full skill procedure from `.github/skills/jira-wiki-reader/SKILL.md` before first use.

Quick reference:
```bash
# Fetch ticket (primary command — always start here)
bash .github/skills/jira-wiki-reader/scripts/fetch-ticket.sh <TICKET_KEY>

# Fetch wiki page (auto-fetch when found in ticket description)
bash .github/skills/jira-wiki-reader/scripts/fetch-wiki.sh "<CONFLUENCE_URL>"

# Extract ticket key from arbitrary text
bash .github/skills/jira-wiki-reader/scripts/extract-ticket-key.sh "<any_text>"

# Additional context (as needed)
bash .github/skills/jira-wiki-reader/scripts/fetch-links.sh <TICKET_KEY>
bash .github/skills/jira-wiki-reader/scripts/fetch-subtasks.sh <TICKET_KEY>
bash .github/skills/jira-wiki-reader/scripts/fetch-comments.sh <TICKET_KEY> [MAX]
bash .github/skills/jira-wiki-reader/scripts/fetch-sprint.sh <TICKET_KEY>
```

## Presentation rules

- **Never show raw JSON** — parse and present a human-readable summary (see Step 4 in SKILL.md).
- **Always include**: ticket details table, description (Jira markup → Markdown), acceptance criteria.
- **Auto-include wiki content**: if wiki pages were fetched, include a `### Referenced Wiki Documentation` section.
- **Tailor depth** to the workflow:
  - **Grooming**: full details + linked issues + comments + wiki + acceptance criteria gaps
  - **PR review**: ticket table + acceptance criteria + description (traceability)
  - **Development**: full details + subtasks + sprint + wiki design docs
  - **Bug investigation**: ticket table + description + comments

## Token handling

If a script fails with "PAT is not set" or returns 401/403:
- **Direct users to create env files** (see SKILL.md for full procedure):
  1. Create `~/.jira-reader.env` containing exactly one line: `JIRA_PAT="<your_token>"`
  2. Create `~/.wiki-reader.env` containing exactly one line: `WIKI_PAT="<your_token>"`
  3. File paths: Mac `/Users/<you>/`, Linux/WSL `/home/<you>/`, Git Bash `C:\Users\<NTID>\`
  4. Quick commands:
     ```
     echo 'JIRA_PAT="<token>"' > ~/.jira-reader.env && chmod 600 ~/.jira-reader.env
     echo 'WIKI_PAT="<token>"' > ~/.wiki-reader.env && chmod 600 ~/.wiki-reader.env
     ```
  Scripts source these on every run — no terminal restart needed.
- For temporary use: `export JIRA_PAT="<token>"` (current session only, lost when terminal closes).
- **Do NOT suggest pasting tokens in chat** — accept if they do, but never offer it as an option.

## Mid-workflow token recovery

When a token fails during an active workflow (PR review, code review, dev-pilot, incident investigation):

1. The agent presents the PAT Prompt (see `jira-wiki-reader/SKILL.md` PAT Prompt and Save Procedure).
2. The agent **continues with degraded Jira context** — never block the entire workflow on a token issue.
3. The agent offers a **"retry Jira"** option at the next checkpoint or lead interaction point.
4. On retry success: re-run Jira-dependent analysis (e.g., Dimension H traceability in PR review, ticket context in dev-pilot).
5. On retry failure (2nd attempt): finalize without Jira context, note the gap explicitly in output.
6. Agents MUST log the degradation: `[JIRA UNAVAILABLE: <reason> — proceeding without ticket context]`

**Per-agent behavior** (currently implemented in `pr-code-review`; other agents follow the standard PAT Prompt procedure from SKILL.md without mid-workflow recovery until updated):

| Agent | On Jira failure | Retry point | Impact if no retry |
|-------|----------------|-------------|--------------------|
| `pr-code-review` | Dimension H capped at score 2, Pattern Deviation +1 penalty | Phase 4 lead checkpoint | Reduced traceability confidence in Change Fit Report |
| `code-review` | Traceability section marked degraded | End of review | Noted in Change Fit Report |
| `dev-pilot` | Requirements intake uses only user-provided context | Before implementation starts | May miss linked issues, wiki design docs |
| `incident-investigator` | Skip Jira recurrence check, note gap | Phase 0 triage summary | Recurrence check incomplete |
| `requirements-grooming` | Cannot proceed — Jira is primary input | Immediate (BLOCKING) | Agent asks user to fix token before continuing |

## Agent-specific usage

| Agent | When to fetch | What to fetch |
|-------|--------------|---------------|
| `dev-pilot` | Kickoff, requirements intake | Ticket + subtasks + wiki + sprint |
| `requirements-grooming` | Always (primary input) | Ticket + links + subtasks + comments + wiki |
| `pr-code-review` | PR has ticket key | Ticket + acceptance criteria |
| `code-review` | Changes reference a ticket | Ticket + acceptance criteria |
| `test-generator` | Tests reference ticket ACs | Ticket + acceptance criteria |
| `doc-maintainer` | Documenting a feature/change | Ticket + wiki for context |
| `code-health-auditor` | Ticket-driven audit scope | Ticket + links for scope |
