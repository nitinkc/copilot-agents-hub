---
applyTo: "**/*.java,**/*.yml,**/*.yaml,**/*.properties,**/src/test/**/*.java,**/*.md"
---
# Living Documentation, Multi-View Architecture, and Visualization Standards (Mission-Critical)

Documentation is not optional. When code or tests change, create or update documentation so the repository remains understandable to:
- business stakeholders
- engineers, architects, and operators
- machines/automation/LLMs

Documentation must be useful, audience-specific, and decision-oriented.
Do NOT produce a dump of words.

## Recommended documentation model
Use **4 primary levels + cross-cutting overlays + a machine-readable dimension**.
This is the recommended depth because:
- 3 levels is usually too coarse for enterprise microservices
- 5+ primary levels usually create maintenance drag
- 4 levels plus overlays gives clear audience separation without waste

## Primary levels
### Level 0 — Business capabilities
Files:
- `docs/generated/01-business-capabilities.md`
- `docs/generated/glossary.md`
- `docs/generated/14-rule-inventory.md`
- `docs/generated/15-entity-attribute-catalog.md`
Purpose:
- explain what the service does in business language
- explain business capabilities, actors, triggers, and outcomes
- capture business rules and vocabulary
- maintain a structured rule inventory with stable rule IDs
- maintain an entity/attribute catalog linking data to rules and capabilities
Questions answered:
- Could a business person understand what this service does?
- Could a planner infer whether a requirement likely impacts this repo?
- Which business rules govern each capability?
- Which data entities carry logic-bearing attributes?
Preferred diagrams:
- `flowchart`
- `journey`
- `mindmap`
- `requirementDiagram`
Avoid code-level wording unless unavoidable.

### Level 1 — Service context / system fit
Files:
- `docs/generated/02-service-context.md`
- `docs/generated/05-dependency-catalog.md`
- `docs/generated/ownership-and-operating-rules.md`
Purpose:
- define service boundaries and responsibilities
- show upstream callers, downstream systems, databases, queues, owners
- explain capability-to-backend mapping
Questions answered:
- Where does this service fit in the larger system?
- What systems and datasets does it depend on?
Preferred diagrams:
- C4 context/container
- `architecture`
- dependency graph / `flowchart LR`

### Level 2 — Runtime and functional flows
Files:
- `docs/generated/03-runtime-flows.md`
- `docs/generated/change-impact-patterns.md`
- `docs/generated/non-functional-rules.md`
Purpose:
- show what happens for key flows and endpoints
- connect validation, business rules, idempotency, retries, timeouts, failures, and safe outcomes
Questions answered:
- What happens when API X or capability Y runs?
- Which backends are touched and in what order?
- Where are rules and failure branches applied?
Preferred diagrams:
- `flowchart`
- `sequenceDiagram`
- `stateDiagram-v2`
- `requirementDiagram`

### Level 3 — Technical map
Files:
- `docs/generated/04-technical-map.md`
- `docs/generated/adr/README.md`
- ADR records under `docs/generated/adr/`
Purpose:
- map packages/components/config/security/hooks/tests
- explain where developers start and what code owns what
- preserve key architecture decisions and tradeoffs
Questions answered:
- Where do I change the code?
- Which classes and packages implement which capability?
- What rules and decisions constrain technical changes?
Preferred diagrams:
- component/dependency graph
- `erDiagram` when data structures matter
- focused technical flowcharts

## Cross-cutting overlays (must exist for a maintained repo)
Files:
- `docs/generated/06-operations-runbook.md`
- `docs/generated/07-release-readiness-and-rollback.md`
- `docs/generated/08-data-classification-and-controls.md`
- `docs/generated/09-slos-alerts-and-observability.md`
- `docs/generated/10-known-failure-modes.md`
- `docs/generated/11-security-threat-model.md`
- `docs/generated/12-data-lifecycle.md`
- `docs/generated/13-documentation-validation-and-coverage.md`
Purpose:
- capture operating rules, release discipline, observability, failure handling, data handling, and security controls
- provide maintainability and SDLC continuity beyond code comments/tests

## Machine-readable dimension (mandatory)
Files:
- `docs/generated/machine/service-manifest.yaml`
- `docs/generated/machine/dependency-graph.mmd`
- `docs/generated/machine/change-impact-map.yaml`
- `docs/generated/machine/doc-index.yaml`
- `docs/generated/machine/rule-inventory.yaml`
- `docs/generated/machine/entity-catalog.yaml`
- `docs/generated/machine/api-contract-catalog.yaml`
Purpose:
- support automation, impact analysis, and org-wide dependency/knowledge graph ingestion
- encode endpoints, capabilities, dependencies, invariants, ownership, docs coverage, and impact keywords
- provide machine-readable rule inventories and entity catalogs for LLM-driven analysis
Questions answered:
- Can an LLM determine whether a new requirement likely impacts this repo?
- Can a graphing system connect this service to related services and dependencies?
- Can automation trace a business rule to its capability, code, tests, and docs?

OpenAPI is the machine-readable standard for HTTP API capability discovery. For non-HTTP APIs (SOAP/WSDL, gRPC/.proto, messaging/AsyncAPI, BPMN service tasks), their respective contract specs are authoritative. When a machine-readable spec exists, reference or derive from it rather than duplicating contract details in documentation. When no spec exists, document the API fully in the machine API contract catalog (`docs/generated/machine/api-contract-catalog.yaml`). See `dimension-extraction.instructions.md` for the full contract hierarchy.

## Documentation update rules (must)
When code/tests change, update docs proportionally:
- business-visible behavior changes -> update Levels 0, 1, 2 and machine docs as needed
- dependency/backend changes -> update Levels 1, 2, dependency catalog, ops docs, and machine docs
- rules/errors/bounds changes -> update Levels 0 or 2, non-functional rules, rule inventory, and machine docs
- internal-only technical refactors -> update Level 3 and ADRs if decisions changed
- security/operations/release/data handling changes -> update the corresponding overlays
- entity/data model changes -> update entity-attribute catalog, data classification, data lifecycle, and machine docs
- API endpoint changes -> update dependency catalog, machine manifest, and machine API contract catalog
- if docs do not exist, bootstrap the full standard set

**Override prevention (MUST)**:
When updating any existing documentation file:
1. **Read first**: Always read the existing file before generating new content.
2. **Section completeness check**: Verify the new output has at least the same sections as the existing file. If the existing file has sections not in the mandatory template, preserve them.
3. **Content richness check**: If an existing section has more detail than the generated replacement, merge the richer content into the generated structure — do not replace rich content with thin content.
4. **Never drop sections**: If a template section has no new content to add, keep the existing content unchanged for that section rather than omitting it.
5. **Never silently discard**: If content cannot be merged, append it in a `## Preserved from Previous Version` section at the bottom.

**Mandatory document sections (MUST)**:
- `docs/generated/01-business-capabilities.md` must include: Service Overview, Actors & Stakeholders, Core Business Capabilities, Business Rules Summary, Business Process Diagrams, Key Business Outcomes. Never produce only one section.
- `docs/generated/03-runtime-flows.md` must include: Overview, Per-API/Capability Flows, Cross-Cutting Runtime Behaviors, Runtime Diagrams.
- `docs/generated/04-technical-map.md` must include: Package & Component Structure, Controller/Service/Repository/Client Map, Configuration, Exception & Error Mapping, Security Hooks, Observability, Testing Strategy, Technical Diagrams.
See `documentation-living-views` skill and `documentation-business-functional-views` skill for full templates.

When extracting or updating documentation, apply the dimension extraction framework from `dimension-extraction.instructions.md`:
- extract business, logic, data, integration, risk/operability, and traceability dimensions
- maintain the rule inventory (`docs/generated/14-rule-inventory.md` + `docs/generated/machine/rule-inventory.yaml`)
- maintain the entity/attribute catalog (`docs/generated/15-entity-attribute-catalog.md` + `docs/generated/machine/entity-catalog.yaml`)
- maintain the machine API contract catalog (`docs/generated/machine/api-contract-catalog.yaml`)
- cross-reference: rule IDs in capabilities, entities reference rules, tests reference rules, impact maps reference capabilities

## Visualization rules (must)
Use diagrams intentionally by audience and question being answered.
Recommended Mermaid types:
- business/functionality: `flowchart`, `journey`, `mindmap`, `requirementDiagram`
- context/architecture: C4, `architecture`, dependency graph / `flowchart LR`
- runtime/behavior: `flowchart`, `sequenceDiagram`, `stateDiagram-v2`
- data: `erDiagram`
- machine-friendly dependency graph: Mermaid graph with stable node ids

Important limitation:
- Mermaid does not currently provide an official UML use-case diagram type.
- If a use-case view is needed, approximate it with:
  - `journey` (actor experience)
  - `flowchart` (activity/business decision flow)
  - C4 context (system and actors)

Visualization best practices:
- one diagram per concern
- short, stable node labels
- split large diagrams by capability or endpoint family
- add a short explanatory paragraph under each diagram
- prefer business terms in Level 0/1 diagrams, technical names in Level 3 diagrams
- ensure diagrams show rules and failure branches where relevant

## Multi-project workspaces
All `docs/generated/` paths are relative to the project root, not the workspace root.
In multi-project workspaces, each project maintains its own `docs/generated/` folder under its own root directory.

## Documentation quality checklist
Before finishing, verify:
- Level 0 explains capabilities and outcomes in non-code language
- Level 1 clearly lists upstream/downstream systems and owners
- Level 2 explains flows, dependencies, rules, errors, retries, and idempotency where applicable
- Level 3 maps code structure, config, and tests to capabilities
- overlays are updated when their subject changed
- machine docs reflect endpoints, dependencies, rules, and impact clues
- diagrams are readable, scoped, and renderable in GitHub
- documentation is actionable for business, technical, and machine consumers

## File-existence gate (Full Regeneration)
In Full Regeneration mode, verify all 28 required files exist before marking documentation complete. See `documentation-living-views/SKILL.md` under "File-Existence Verification Gate" for the authoritative checklist. Missing required files are blocking failures, not informational gaps — generate them before proceeding.
