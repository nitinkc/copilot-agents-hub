---
applyTo: "**/*.java,**/*.kt,**/*.xml,**/*.yml,**/*.yaml,**/*.properties,**/*.md,**/*.json,**/*.bpmn"
---
# Pull Request Code Review Standards

When reviewing a pull request, always evaluate changes in the context of the whole repository, never in isolation.
These standards apply as ambient context to all PR reviews — whether invoked via the `pr-code-review` agent, the `code-review` agent, or manual review.

## Related assets
- **Agent**: `.github/agents/pr-code-review.agent.md` (full 7-phase interactive PR review workflow — the single orchestrator)
- **Sub-skills**: `pr-cognitive-debiasing`, `pr-diff-review`, `pr-change-fit-analysis`, `pr-deployment-readiness`, `pr-risk-scoring`

## Cognitive debiasing mandate
- Read the diff BEFORE reading the PR title/description — form an independent assessment first.
- If PR exceeds 400 LOC or 15 files, note reduced reviewer confidence and recommend splitting.
- Never relax scrutiny based on author reputation or seniority.
- After forming an initial impression, deliberately search for one counter-example.
- Before finalizing verdict: "What evidence would make me change my verdict?" / "Am I approving because the code is safe, or because reviewing further feels exhausting?"
- See `.github/skills/pr-cognitive-debiasing/SKILL.md` for the full 12-bias countermeasure protocol.

## Mandatory PR review dimensions
1. **Diff correctness** — does the code do what the PR/ticket says?
2. **Full-repo pattern fit** — does the change follow established project conventions?
3. **Backward compatibility** — are public APIs, error codes, process variables, and config contracts preserved?
4. **Test adequacy** — is every changed behavior covered by a test in this PR or existing suite?
5. **Security posture** — no new secrets, log leaks, injection surfaces, or unsafe error exposure?
6. **Operational readiness** — timeouts, retries, idempotency, observability, and rollback behavior correct?
7. **Documentation delta** — are docs, machine manifests, and impact intelligence artifacts updated?
8. **Reuse check** — is there existing code in the repo that this PR should have leveraged?
9. **Cross-service impact** — do API/contract/BPMN changes affect downstream consumers?
10. **Deployment safety** — is the change safe during rolling deployment? Is rollback non-destructive?
11. **Data/state management** — are migrations reversible, transactions bounded, side-effects idempotent?
12. **Runtime integration compliance** — do new/changed outbound calls (HTTP, DB, BPMN, messaging, cache) comply with instruction file patterns? Are timeouts, retries, error mapping, trace propagation, and bounded result sets in place?

## Risk classification
Every finding must have a severity:
- **Critical** — will cause production incident, data loss, security breach, or contract break
- **High** — likely to cause user-visible defect, performance degradation, or operational issue
- **Medium** — code quality, maintainability, or pattern deviation that accumulates tech debt
- **Low** — style, naming, minor improvements

## Anti-patterns and Socratic self-check
Both checklists and their **outcome presentation rules** are defined in `mission-critical-checklists.instructions.md` (the single source of truth, shared across all agents).
- **Anti-patterns** — scan every diff file against the full list; flag any match as a finding. Report using the "Anti-Pattern Findings" table format.
- **Socratic self-check** — execute before finalizing the PR verdict. If any answer reveals an uncaptured risk, add it as a finding and re-assess. Report using the "Socratic-Revealed Risks" table format.
- Both tables MUST appear in the output, even if empty (state "0 findings" / "0 new risks surfaced").

## Verdict rules
See `.github/skills/pr-risk-scoring/SKILL.md` for the full scoring model, override rules, and routing thresholds.
Key ambient rules:
- Never approve a PR with unresolved Critical findings.
- Approve with Conditions requires all conditions to be specific and verifiable.
- Request Changes must include a prioritized action list.
- Block must include evidence of why the PR cannot be safely fixed in-place.

## Ticket alignment (when ticket details provided)
See `.github/skills/pr-change-fit-analysis/SKILL.md` Dimension H for the full traceability protocol.
Key ambient rules:
- Every acceptance criterion maps to code or is explicitly out of scope.
- Code changes not traced to an AC must be justified (refactor, prerequisite, tech debt).
- Behavioral changes not covered by ACs represent scope drift and must be flagged.

## Cross-service impact (when applicable)
See `.github/skills/pr-change-fit-analysis/SKILL.md` Dimension E for the full 6-category cross-service analysis.
Key ambient rules:
- Identify consumer services for any modified API/event/BPMN contracts.
- Verify contract test coverage exists for affected consumers.
- Flag process variable changes in Flowable BPMN that affect downstream service tasks.

## Deployment safety (mandatory for all PRs)
- Assess rolling deployment safety: can old and new code coexist?
- Verify database migration backward compatibility.
- Identify rollback path and blast radius.
- Recommend feature flags for high-risk changes.
- See `.github/skills/pr-deployment-readiness/SKILL.md` for the full assessment protocol.
