---
applyTo: "**/pom.xml,**/*.java,**/src/test/**/*.java,**/.github/workflows/**/*.yml"
---
# Dependency known-issues controls (MUST follow)

## Zero new dependencies by default (code generation discipline)

NEVER introduce a new library, framework, or runtime dependency unless the developer explicitly requests it.
Use ONLY existing project dependencies when generating code.
If a feature genuinely requires a new dependency, STOP and ASK the developer before adding it.

This applies to all agents, skills, and manual prompts — no exceptions.

## When adding OR changing ANY dependency (developer-approved only)
You MUST:
1) Run dependency vulnerability scanning (CI gate must fail on high severity).
2) Update the project's third-party risk register (e.g., `docs/generated/third-party-risk-register.md`) with:
   - dependency name/version
   - known issues / CVE classes (if any)
   - mitigations (config/code)
   - how we verify mitigation (test/build rule)
3) Add a guardrail so the risky functionality cannot be reintroduced:
   - build-time rule (preferred): forbidden-apis / enforcer / banned-dependencies
   - or code-time rule: ArchUnit test preventing dangerous API usage
   - plus at least one regression test if the issue is configuration-related

### Design-time enforcement (MUST)
- During the DESIGN phase (blueprint), any new dependency MUST be identified and its risk register entry drafted.
- During the CRITICAL REVIEW and QUALITY GATE phases, verify that every new dependency introduced in the change has a corresponding risk register entry. Flag missing entries as a gap.
- Do not defer dependency governance to post-merge — it is part of the definition of done for the change.

## Known-issue patterns we always guard against
- Java deserialization APIs (ObjectInputStream)
- Command execution (Runtime.exec, ProcessBuilder)
- Unbounded thread pools / queues (Executors.newCachedThreadPool, newFixedThreadPool without bounds rationale)
- Reflection in business logic
- Expression evaluation on untrusted input (SpEL, script engines)
- XML parsers without secure processing flags (XXE risk)
- "Infinite timeout" outbound HTTP calls
- Unbounded collections returned from endpoints
- Bare `!= null` checks instead of utility methods (see `java8-critical.instructions.md` under "Null-safety")
- `java.util.Random` in security-sensitive contexts (use `SecureRandom`)
- Weak hash algorithms (MD5, SHA-1) for integrity/security
- Path traversal via unsanitized file paths
- Log injection via unsanitized user input in log statements
- Disabled SSL/TLS certificate verification
- Raw string concatenation in SQL, LDAP, or log statements

## Mandatory "dependency gates" in the build
- Maven Enforcer:
  - ban version ranges / LATEST / RELEASE
  - require upper-bound dependency convergence
  - ban known-bad artifacts explicitly (denylist)
- OWASP Dependency-Check (or equivalent):
  - fail build above severity threshold
  - suppressions require justification in config/dependency-check-suppressions.xml
- Forbidden APIs:
  - ban dangerous JDK and risky third-party calls
- ArchUnit:
  - enforce layering and forbidden packages/APIs
