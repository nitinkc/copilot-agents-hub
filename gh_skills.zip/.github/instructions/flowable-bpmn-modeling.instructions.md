---
applyTo: "**/*.bpmn20.xml,**/*.bpmn"
---
# Flowable BPMN Modeling Rules (Mission-Critical)

Modeling invariants (must be true for every process):
- Every process MUST have:
  - explicit Start Event
  - explicit End Event for every normal completion path
  - explicit modeled termination for abnormal paths (e.g., error boundary -> recovery -> End, or escalation -> wait state with SLA timer)
- No "dangling" paths:
  - No token may be left waiting forever without an explicit operator action or timeout path.
  - Any message/event catch MUST have a timeout boundary or alternate SLA path.

Boundedness:
- Any loop (standard loop, multi-instance, cyclic flow) MUST have:
  - an explicit maximum iteration bound, AND
  - a modeled stop condition, AND
  - a timeout/SLA mechanism that guarantees the process can reach a terminal modeled state.
- Multi-instance cardinalities MUST be validated and capped (defensive guard) before the MI activity.

Service tasks & external integration:
- Any service task that performs IO (HTTP/DB/MQ/files) MUST be asynchronous (`flowable:async="true"`) and MUST define retries.
- Every async service task MUST define a retry policy using `flowable:failedJobRetryTimeCycle` OR be covered by an explicit global policy documented in the repo.
- Every IO service task MUST model error handling:
  - Business errors are mapped to BPMN error codes and caught via boundary error events.
  - Technical failures use retries; if exhausted, route to a "technical failure" handling path (operator task / compensation / escalation).

Exception mapping:
- Prefer explicit mapping of Java exceptions to BPMN error codes using `flowable:mapException` when the failure is a business fault and has a modeled recovery path.
- Never convert technical exceptions to BPMN errors unless the process has a safe recovery and the external side effects are idempotent.

Call Activity rules (subprocess invocation):
- Prefer explicit variable mapping using `<flowable:in/>` and `<flowable:out/>`; avoid `inheritVariables="true"` unless the variable set is small and stable.
- Propagate business key: default to `flowable:inheritBusinessKey="true"` unless a strong reason exists.
- Version safety:
  - If the parent and called process must stay in lockstep, require `flowable:sameDeployment="true"` and deploy together.
- Do not rely on out-mapped variables being present when the called process exits via BPMN Error; explicitly set parent variables when modeling error exits.

Naming/versioning/backward compatibility:
- Treat all BPMN element IDs as stable API:
  - Never rename IDs for user tasks, service tasks, gateways, events after a process is live.
- Add new variables as optional with safe defaults.
- Never change the semantic meaning of an existing variable name/type without a migration plan.
- Add process-level documentation with:
  - required input variables (name/type/constraints)
  - business key format
  - idempotency key rules
  - SLA timeouts

Duplication/idempotency:
- Any process start must be idempotent:
  - requires externalRequestId/idempotencyKey
  - uses a unique constraint (in business tables) to prevent starting duplicates
  - on duplicate: return existing processInstanceId/businessKey (do not start another instance)

Performance:
- Avoid huge variable payloads; store references (IDs) and keep variables small.
- Avoid `inheritVariables="true"` when variables may be large.
- Avoid inclusive gateways unless essential (harder to reason about and test).
