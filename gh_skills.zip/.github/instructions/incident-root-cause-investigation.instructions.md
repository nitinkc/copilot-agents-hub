---
applyTo: "**/*.md,**/*.java,**/*.yml,**/*.yaml,**/*.properties,**/*.drl,**/*.bpmn20.xml,**/*.bpmn"
---
# Incident Root Cause Investigation

When a developer provides a Jira ticket key, GitHub PR/commit link, or description of a production incident/bug and asks to investigate, diagnose, or find the root cause — follow this procedure systematically.

## Related Skills (load as needed)

This instruction integrates with the RCA skill ecosystem. For production log-based
investigations, the `incident-investigator` agent orchestrates these skills:

| Skill | Purpose | Load When |
|-------|---------|----------|
| `elk-log-search` | ELK query engine | Any log-based investigation |
| `error-taxonomy` | Error classification (8 categories) | Classifying production errors |
| `quick-triage` | Rapid severity assessment | First response to incident |
| `blast-radius` | Impact scope analysis | Scoping incident impact |
| `service-traversal` | Cross-service error tracing | Multi-service failures |
| `code-forensics` | Code analysis at deployed commit | Code-level root cause |
| `rca-synthesis` | Multi-framework RCA + ACH + Abductive Verification | Full root cause analysis |
| `rca-quality-gate` | Adversarial critique (3 critics) + meta-reviewer + Socratic gates | Tier 2+: after synthesis |
| `rca-recommendations` | Fix proposals, prevention, Jira tickets | After quality gate passes |

**For log-based investigations**, prefer the `incident-investigator` agent which
orchestrates all skills in a phased workflow.

**For Jira-ticket-based investigations** (process/governance focus), follow
the phases below which emphasize PR review, branch protection, and process gaps.

## Trigger phrases
- "investigate", "root cause", "RCA", "what caused", "why did this break", "diagnose", "incident analysis", "postmortem", "post-mortem", "bug investigation", "find the issue"

## Phase 1 — Gather Context

### 1a. Jira ticket (if provided or extractable)
- Invoke the `jira-wiki-reader` skill (or follow its steps inline) to fetch full ticket details.
- Extract: summary, description, status, priority, components, linked issues, comments, timeline.
- If the ticket description contains Confluence wiki URLs, fetch those automatically.
- If linked issues exist, fetch their details — they often contain the originating story or related changes.

### 1b. Identify referenced commits, PRs, and repositories
- Scan ticket description, comments, and linked issues for:
  - GitHub commit URLs → extract repo + SHA
  - GitHub PR URLs → extract repo + PR number
  - Build numbers → trace to the originating commit
  - Branch names → identify release/environment context
- Clone or shallow-fetch the relevant repository(ies) via SSH (`git@github.com:{owner}/{repo}.git`).

### 1c. Fetch commit and PR details
For each identified commit/PR:
- `git show --stat <SHA>` — what files changed?
- `git show <SHA> -- <key_files>` — what exactly changed in production-relevant files?
- `gh pr view <number> --json author,mergedBy,reviews,reviewRequests,mergedAt,createdAt,state,baseRefName,headRefName,statusCheckRollup,labels` — who authored, reviewed, approved, and merged?
- If a revert commit exists, fetch it too — compare original vs revert to isolate the exact breaking change.

### 1d. Check repository governance
- `gh api repos/{owner}/{repo}/branches/{branch}/protection` — are there branch protection rules?
- `gh api repos/{owner}/{repo}/rulesets` — any repository rulesets?
- Check for `CODEOWNERS` file presence.
- Note: a 404 on branch protection means **no protection exists** — this is a finding.

## Phase 2 — Establish Timeline

Build a chronological timeline from all gathered evidence:

| Time | Event | Actor | Evidence |
|------|-------|-------|----------|
| ... | Story/ticket created | reporter | Jira |
| ... | PR created | author | GitHub |
| ... | PR approved | reviewer | GitHub reviews |
| ... | PR merged | merger | GitHub mergedBy |
| ... | Deployed to lower env | CI/CD | Jira comments / build system |
| ... | Deployed to prod | CI/CD or manual | Jira comments / deploy logs |
| ... | Incident starts | system | monitoring / ticket description |
| ... | Incident detected | person/alert | ticket description / comments |
| ... | Mitigation begins | responder | ticket / revert PR |
| ... | Full recovery | system | ticket description |

Key metrics to compute:
- **Time to detect (TTD)**: incident start → detection
- **Time to mitigate (TTM)**: detection → mitigation start
- **Time to recover (TTR)**: mitigation start → full recovery
- **Total impact window**: incident start → full recovery

## Phase 3 — Analyze the Breaking Change

### 3a. Diff analysis
- Read the full diff of the offending commit/PR for production-relevant files.
- Identify what was added, removed, or modified.
- Determine whether the change is: code, configuration, infrastructure, data, or permissions.

### 3b. Dependency analysis
- Did the change introduce references to classes, methods, or APIs that don't exist in the target runtime?
- Did the change assume a dependency (service, library, schema, config) that wasn't deployed?
- Was there a version mismatch between the change and its runtime environment?

### 3c. Environment scope analysis
- Which environments were affected by the change?
- Was the change applied to all environments simultaneously or promoted gradually?
- Was there a way for the change to reach production without passing through lower environments?

### 3d. CI/CD analysis
- What CI checks ran on the PR? List each check, its result, and whether it could have caught the issue.
- Identify the gap: what validation was missing that would have prevented the incident?

## Phase 4 — Identify Contributing Factors

Evaluate each dimension. For each, state the **current state** and whether it contributed:

| Dimension | Questions to answer |
|-----------|-------------------|
| **Branch protection** | Were required reviewers enforced? Was self-merge blocked? Were status checks required? |
| **Review quality** | How many reviewers? Were there substantive review comments? Was the PR description informative? |
| **Change management** | Was there CAB/approval for production changes? Was the Jira ticket in the right status? |
| **Environment isolation** | Could the change reach prod without lower-env validation? Were environments coupled? |
| **CI validation** | Did CI checks validate the actual failure mode? What class of error was missed? |
| **Deployment sequencing** | Were dependencies deployed in the correct order? Was there a code-config version mismatch? |
| **Observability** | How long until detection? Were there relevant alerts? Did monitoring catch the failure mode? |
| **Rollback readiness** | Was rollback automated or manual? How fast was recovery? |

## Phase 5 — Produce the Report

### Required output format

```markdown
# <TICKET_KEY>: <summary>

---

## Incident Overview
<!-- Table: ticket, type, status, priority, component, reporter, assignee, created -->
<!-- Impact window, mitigation, recovery times -->
<!-- Customer impact: who was affected, how many, what they experienced -->

## Root Cause
<!-- 2-3 paragraphs explaining:
     1. What change was made (commit SHA, PR number, repo, author)
     2. What the change did technically (files modified, logic added/removed)
     3. Why it broke (the specific failure mechanism — missing class, wrong config, version mismatch, etc.)
-->
<!-- Include: the revert commit/PR if one exists -->

## Who Approved & Merged
<!-- Table for the offending PR: author, reviewer(s), merger, timestamps -->
<!-- Table of PR attributes: base branch, PR body, review comments, files changed, lines changed -->
<!-- Key findings: self-merge? rubber-stamp? empty description? -->
<!-- If a revert PR exists, show its approval chain too for comparison -->
<!-- CI checks table: check name, result, why it didn't catch the issue -->

## Contributing Factors
<!-- Numbered table: factor name + detail for each contributing cause -->

## Prevention at Every Level
<!-- For each level (1-6), a table with columns: Gap | Current State | Recommendation | Effort -->
### Level 1 — Repository & Branch Governance
### Level 2 — Environment Isolation
### Level 3 — CI/CD Validation
### Level 4 — Change Management Process
### Level 5 — Review Quality
### Level 6 — Observability & Rollback

## Recommended Immediate Actions
<!-- Priority-ordered table: Priority (P0-P3) | Action | What it prevents | Effort (Low/Medium/High) -->
```

### Report quality rules
- **Every claim must have evidence** — commit SHA, PR number, API response, timestamp. No speculation.
- **Attribution is factual, not blame** — state who did what and when; do not editorialize on intent.
- **Recommendations must be actionable** — specific enough that someone could create a Jira ticket for each one.
- **Effort estimates are relative** — Low (< 1 day), Medium (1–5 days), High (1–2 sprints).
- **Priority is based on recurrence risk** — P0 prevents this exact incident from happening again; P3 is systemic improvement.

### Output file location
Save the report to `docs/incidents/<TICKET_KEY>-root-cause-analysis.md`.

## Cross-cutting rules
- **Read-only investigation** — never modify the target codebase, Jira tickets, or GitHub PRs during investigation.
- **SSH for git** — all git clone/fetch operations use SSH URLs per playbook Git protocol rules.
- **Token security** — never log, echo, or display PATs or credentials in output.
- **Jira context** — always invoke the `jira-wiki-reader` skill (or its inline steps) when a ticket key is present. Auto-fetch wiki links found in ticket descriptions.
- **Timeout** — if a repository is not accessible or a PAT is missing, report the gap and continue with available evidence rather than blocking the entire investigation.
