---
name: flowable-bpmn-standards
description: Standards for Flowable BPMN process definitions and implementations
applyTo: '**/*.bpmn20.xml,**/*.bpmn, **/processes/**, **/delegate/**, **/listener/**'
---
# Flowable BPMN Standards

## Process Definition Standards
- Every process must have both `id` and `name` attributes
- Process IDs follow: {bounded-context}-{process-name} (kebab-case)
- Every service task must have an error boundary event
- Long-running service tasks must have timer boundary events
- Exclusive gateways must have a default sequence flow
- Parallel gateways must have matching fork/join pairs
- Sub-processes preferred over monolithic single-level processes (>15 tasks)
- Documentation elements required on complex gateways

## JavaDelegate Standards
- Delegates must be stateless (no instance fields storing state)
- Use delegateExpression (Spring bean) not flowable:class (no DI)
- Delegate logic should delegate to Spring services, not contain business logic
- BpmnError codes must be constants/enums, not string literals
- All delegates must handle exceptions and wrap in BpmnError where appropriate

## Variable Standards
- Process variables use camelCase naming
- Complex objects stored as JSON strings or referenced by ID
- Sensitive data (PII, credentials) must not be stored as process variables
- Variable scope should be as narrow as possible (local > execution > process)
- Variable DTOs must have @JsonIgnoreProperties(ignoreUnknown = true)

## Testing Standards
- Every process definition requires a test class with @Deployment
- Tests must cover: happy path, all gateway branches, error boundaries, timers
- Tests must assert process variables at completion
- Tests must verify process history events
- Use FlowableRule/FlowableExtension for JUnit 5 integration
