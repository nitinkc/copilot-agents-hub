---
applyTo: "**/*.java"
---
# Java 8 mission-critical rules

## Control flow & boundedness
- NO recursion.
- Every loop must have an obvious upper bound (MAX_* constant or validated size).
- Avoid unbounded stream pipelines (especially collect()) unless input size is proven bounded.

## Contracts / invariants
- Every public method validates inputs:
  - nullability, range checks, size checks
- Checks must be side-effect free.
- Prefer explicit checks + typed exceptions over Java `assert` (assert may be disabled).

### Null-safety: prefer utility methods over raw `!= null`
- Do NOT generate bare `!= null` / `== null` checks. Use the safer Spring / Apache Commons utilities:
  - **Strings**: `StringUtils.hasText(s)`, `StringUtils.isEmpty(s)` (Spring) or `StringUtils.isNotBlank(s)` (Commons Lang)
  - **Collections**: `CollectionUtils.isEmpty(c)` (Spring or Commons) — handles both null and empty
  - **Objects**: `ObjectUtils.isEmpty(o)` (Spring) or `Objects.nonNull(o)` / `Objects.isNull(o)` (JDK)
  - **Maps**: `CollectionUtils.isEmpty(map)` or `MapUtils.isEmpty(map)` (Commons)
- When a null parameter is never valid, use `Objects.requireNonNull(param, "param must not be null")` so the failure message is clear.
- For Optional-returning methods: return `Optional.empty()` instead of `null`. Never call `Optional.get()` without `isPresent()` or use `orElse` / `orElseThrow`.
- Import preference order: Spring utilities > JDK `java.util.Objects` > Apache Commons (to minimize extra dependencies).

## Error handling
- Never catch `Exception` broadly unless translating to a typed domain exception with context.
- Never swallow InterruptedException; either:
  - restore interrupt flag (Thread.currentThread().interrupt()) and fail safely, OR
  - propagate.

## Resource safety
- Always use try-with-resources for Closeable/AutoCloseable.
- Do not leak threads, connections, files, or subscriptions.
- No mutable static fields; avoid shared mutable singletons.

## Determinism
- No direct Instant.now()/System.currentTimeMillis() in business logic; inject java.time.Clock.
- Randomness must be injected and seeded in tests.

## Dangerous features are prohibited in application code
- No sun.misc.Unsafe, JNI, custom classloading, runtime bytecode generation.
- No Java deserialization of untrusted data (ObjectInputStream).
- No Runtime.exec / ProcessBuilder in request path.

## Common static-analysis violations (Sonar / FindBugs / PMD)
These patterns are frequently flagged in CI. Agents MUST NOT generate code containing them.

### Null & emptiness
- No bare `!= null` / `== null` — see Null-safety rules above.
- No returning `null` from methods whose contract is a Collection or array — return empty collection/array.
- No exposing internal mutable collections — return `Collections.unmodifiableList(list)` or a defensive copy.

### String handling
- No string equality via `==` or `!=` — use `Objects.equals(a, b)` or `"literal".equals(variable)`.
- No string concatenation in loops — use `StringBuilder`.
- No `String.format()` in hot paths or log statements — use parameterized logging (`log.info("msg {}", val)`).

### Resource & lifecycle
- No `System.out.println` / `System.err.println` — use SLF4J logger.
- No `printStackTrace()` — log the exception with the logger.
- No `new Date()` / `new Timestamp(System.currentTimeMillis())` — use injected `Clock` (see Determinism rules).
- No `Thread.sleep()` in production code — use scheduled executors with bounded timeout.

### Complexity & structure
- Keep cyclomatic complexity per method ≤ 15. Refactor if higher.
- Max method length: ~40 lines (excluding test methods). Extract helpers when longer.
- No deeply nested `if/else` (> 3 levels) — prefer early returns or guard clauses.
- No empty `catch` blocks — at minimum log at WARN level or rethrow.

### Type safety
- No raw generic types (`List` instead of `List<String>`) — always parameterize.
- No unchecked casts without `@SuppressWarnings("unchecked")` with a justification comment.
- No catching `NullPointerException` — fix the root cause with proper null checks.
