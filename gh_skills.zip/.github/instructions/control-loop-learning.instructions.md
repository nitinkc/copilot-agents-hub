---
applyTo: "**/*.java,**/*.xml,**/*.yml,**/*.yaml,**/*.properties,**/*.bpmn20.xml,**/*.bpmn,**/*.md"
---

# Control-Loop Learning System

Converts escaped defects and developer corrections into reusable knowledge that strengthens agent instructions, skills, and guardrails over time. Every entry must answer: **why did this happen systemically, and what broad guardrail prevents the entire class of similar issues?**

## Core principles

- **Broad categories over specific issues** — capture the pattern class, not the individual code change
- **Why of why** — trace past the symptom to the systemic cause (missing guardrail, missing question, wrong default)
- **Action-oriented** — every entry must propose a concrete guardrail, not just describe what happened
- **No noise** — if it doesn't strengthen an instruction, skill, checklist, or gate, don't capture it
- **Deduplicate** — before writing, search existing files; if a matching entry exists, update its `last_seen` date and `occurrence_count` instead of creating a new entry

## Output location — one file per session per type

All entries are written to per-session YAML files under `docs/generated/control-loop/`:
- `learnings/YYYY-MM-DD-session.yaml` — all root cause analysis entries for this session
- `feedback/YYYY-MM-DD-session.yaml` — all developer feedback entries for this session

One file per type per session. Multiple entries accumulate in the same file. Do NOT create per-event files.

## Tool Invocation Protocol — MANDATORY

Writing entries means **invoking file-system tools to write to disk**. Describing an entry in conversation text is NOT writing. Agents MUST use the tool invocation pattern below — no exceptions.

### First capture event in a session (file does not exist)

Use `create_file` to create the session file with this structure:

```yaml
# Control-Loop Session: YYYY-MM-DD
# Agent: <agent-name>
# Type: learnings | feedback

entries:
  - id: "LRN-YYYY-MM-DD-001"   # or FBK- for feedback
    # ... full entry fields per format below ...

# --- END OF ENTRIES ---
```

Create the directories (`docs/generated/control-loop/learnings/` or `feedback/`) on first write if they do not exist.

### Subsequent capture events in the same session (file already exists)

Use `replace_string_in_file` to append the new entry **immediately before** the sentinel line:

- **oldString**: `# --- END OF ENTRIES ---`
- **newString**: the new entry YAML block followed by a blank line and `# --- END OF ENTRIES ---`

This deterministically appends without duplicating or rewriting the file.

### Sequence numbering

Entries within a session are numbered sequentially: `LRN-YYYY-MM-DD-001`, `LRN-YYYY-MM-DD-002`, ... (or `FBK-` prefix for feedback). Increment the counter based on the highest existing entry `id` in the current session file.

### Verification

After every `create_file` or `replace_string_in_file` call, confirm the tool call succeeded. If it fails, retry once with corrected parameters. If it fails again, report the failure to the developer — do not silently skip.

### What NOT to do

- Do NOT describe entries only in conversation text — that is not writing.
- Do NOT create a new file per event — one file per type per session.
- Do NOT skip tool invocation because "the entry is implied by the conversation."
- Do NOT defer writing to a later step — write within the same response turn that processes the correction, after content generation is complete.
- Do NOT skip the capture because content generation consumed available attention — the capture is mandatory even though it runs after content generation. Treat it as the final required action before moving to the next workflow step.

## Capture Procedure — execute at every capture point

Whenever a workflow step says "Capture" (learning or feedback), execute this exact procedure:

**Response-turn ordering constraint**: When a developer correction triggers both content revision AND a capture (e.g., "Request changes" requires producing revised output AND writing feedback), **incorporate the feedback and generate revised content FIRST**, then write the feedback entry to disk AFTER. This ordering ensures the capture entry documents what actually changed (richer `developer_correction`, `systemic_cause`, and `guardrail_proposal` fields) rather than recording the raw correction before evaluating its impact. The sequence is: incorporate feedback → generate revised content → classify → write to disk → verify. The capture is MANDATORY — completing content generation does not excuse skipping it.

1. **Classify** — determine entry type (`learnings` or `feedback`), fill all 4 classification dimensions, AND (for learnings only) fill `preventable_by_agent` and `existing_rule_missed` fields.
2. **Existing-rule gate (learnings only)** — if type is `learnings`, check the `existing_rule_missed` field from step 1. If it is populated (i.e., an existing rule already covers this bug class), STOP — do not write. Note in conversation: "Existing rule [{existing_rule_missed}] already covers this class — enforcement gap, not a missing rule." Continue the workflow without writing.
3. **Determine target file** — `docs/generated/control-loop/{learnings|feedback}/YYYY-MM-DD-session.yaml` (use today's date).
3.5. **Retention cleanup (first capture in session only)** — if this is the first capture of either type in this session, run the Retention Policy cleanup procedure (see "Retention policy" section below). On subsequent captures in the same session, skip this step.
4. **Check file existence** — use `read_file` (or `list_dir` on the parent directory) to check if the session file already exists.
5. **Branch**:
   - **File does NOT exist** → use `create_file` with the full session file structure (header + first entry + `# --- END OF ENTRIES ---` sentinel).
   - **File ALREADY exists** → read it to get the highest entry `id` number, then run the Deduplication Protocol. If not a duplicate, use `replace_string_in_file` with `oldString: "# --- END OF ENTRIES ---"` and `newString:` the new entry YAML block + blank line + `# --- END OF ENTRIES ---`.
6. **Verify** — confirm the tool call succeeded. Retry once on failure.
7. **Continue workflow** — only after the disk write is confirmed (or skipped by the existing-rule gate).

This procedure is non-negotiable. Every "Capture" instruction in every agent workflow triggers this procedure.

## When to capture

### Root cause learning

Capture when the developer's request describes fixing a **bug, defect, incident, regression, production issue, optimization of broken behavior, or correcting incorrect behavior**. The agent infers this from the input — no explicit "this is a bug" declaration is required.

Inference signals: words like "bug", "fix", "defect", "broken", "incorrect", "regression", "incident", "issue", "not working", "fails when", "wrong result", "error in production", "hotfix", "patch", references to tickets/JIRA with "bug" type, or developer stating what the system does wrong vs. what it should do.

**Existing-rule gate**: The Capture Procedure (step 2) uses the `existing_rule_missed` field to decide whether to write. See that procedure for the full logic. Do not duplicate the gate check here — the Capture Procedure is authoritative.

When the gate passes (no existing rule covers it), capture root cause BEFORE starting the fix — during INTAKE, not after.

### Developer feedback

Capture when the developer **modifies, rejects, overrides, or corrects** an agent recommendation at any Developer Gate or Checkpoint. Specifically:
- Developer chooses "Request changes" and explains what to change
- Developer chooses "Approve with notes/answers" and the notes correct the agent's assumptions
- Developer overrides a finding or accepts a risk with explanation
- Developer modifies scope, constraints, architecture, test coverage, or documentation

Do NOT capture when developer simply approves without changes — no learning signal.

## Four-dimension root cause classification

Classify every learning and feedback entry across ALL four dimensions. Pick the BEST fit in each.

### Dimension 1 — ODC Defect Type

| Type | When to use |
|------|-------------|
| **Assignment** | Wrong value, wrong variable, wrong constant, wrong default, wrong configuration |
| **Checking** | Missing validation, missing null check, missing boundary check, missing state check |
| **Algorithm** | Wrong logic, wrong formula, wrong ordering, wrong aggregation, wrong transformation |
| **Function** | Missing capability, wrong capability, capability doesn't match requirements |
| **Timing** | Race condition, ordering dependency, timeout logic, retry timing, lifecycle issue |
| **Interface** | Wrong API contract, wrong parameter, wrong return type, wrong error code, protocol mismatch |
| **Relationship** | Wrong association between entities, wrong cardinality, wrong ownership, wrong dependency direction |

### Dimension 2 — Architecture Layer

| Layer | Scope |
|-------|-------|
| **Domain** | Business logic, domain rules, entity invariants, state transitions |
| **Application** | Use case orchestration, service coordination, transaction boundaries |
| **Adapter-In** | Controllers, message consumers, scheduled triggers, input validation |
| **Adapter-Out** | Repository/DAO implementations, HTTP clients, message producers, external integrations |
| **Infrastructure** | Configuration, security filters, observability, deployment, CI/CD, framework setup |

### Dimension 3 — Failure Pattern

| Pattern | Description |
|---------|-------------|
| **Cascading failure** | One failure triggers uncontrolled chain of downstream failures |
| **Retry storm** | Unbounded or misconfigured retries amplify load during outage |
| **Boundary leak** | Internal details (exceptions, IDs, schemas) exposed across architectural boundaries |
| **Contract violation** | API, event, or data contract changed without consumer coordination |
| **Silent data corruption** | Invalid data accepted and persisted because validation was incomplete |
| **State inconsistency** | Partial updates leave system in inconsistent state |
| **Resource exhaustion** | Unbounded collections, connections, threads, or memory consumption |
| **Security surface** | New attack vector via injection, exposure, missing authz, or unsafe defaults |
| **Observability gap** | Issue invisible to monitoring, alerting, or debugging tools |
| **Test escape** | Scenario reachable in production but not covered by any test |
| **Configuration drift** | Works in dev/test but fails in production due to env-specific config |
| **Requirement gap** | Behavior undefined, ambiguous, or contradictory in requirements |

### Dimension 4 — Cognitive Bias Indicator

| Bias | How it manifests in agent/developer work |
|------|------------------------------------------|
| **Confirmation** | Only tested the happy path; didn't seek disconfirming evidence |
| **Optimism** | Assumed dependency would always be available, fast, or correct |
| **Anchoring** | First design idea was kept despite later evidence favoring alternatives |
| **Cargo cult** | Pattern copied from elsewhere without understanding why it was applicable |
| **Recency** | Over-weighted the last similar problem; ignored structural differences |
| **Automation** | Blindly trusted generated code, framework defaults, or tool output |
| **Sunk cost** | Continued with flawed approach because significant effort was already invested |
| **Not applicable** | No identifiable cognitive bias contributed |

## Learning entry format

### Root cause entry

```yaml
id: "LRN-YYYY-MM-DD-NNN"
last_seen: "YYYY-MM-DD"
occurrence_count: 1
status: "new"  # new | validated | operationalized | retired

trigger: "<1 line: what bug/issue is being fixed>"
inferred_from: "<what in the developer's input signaled this was a bug fix>"

classification:
  odc_type: "<from Dimension 1>"
  architecture_layer: "<from Dimension 2>"
  failure_pattern: "<from Dimension 3>"
  cognitive_bias: "<from Dimension 4>"

# The "why of why" — not the specific issue, but the systemic gap
systemic_cause: "<1-2 sentences: what guardrail, process, question, or constraint was missing that allowed this entire CLASS of issue>"
why_agent_missed_it: "<1 sentence: what the agent should have checked, asked, or enforced but didn't>"

# Action-oriented outputs
guardrail_proposal:
  type: "question | constraint | pattern | anti-pattern | test-obligation | checklist-item | instruction-update | gate"
  description: "<specific, operational guardrail to prevent this class of issue>"
  target_file: "<which instruction, skill, or checklist file should be updated>"

preventable_by_agent: true | false
existing_rule_missed: "<which existing non-negotiable, instruction, or checklist rule already covered this — or empty/none if no existing rule covers it>"
```

### Developer feedback entry

```yaml
id: "FBK-YYYY-MM-DD-NNN"
last_seen: "YYYY-MM-DD"
occurrence_count: 1
status: "new"  # new | validated | operationalized | retired

step: "<agent step/phase where correction occurred>"
agent_recommendation: "<brief: what the agent suggested — the pattern, not the specific code>"
developer_correction: "<brief: what the developer changed and why — the principle, not the specific fix>"

classification:
  odc_type: "<from Dimension 1>"
  architecture_layer: "<from Dimension 2>"
  failure_pattern: "<closest match or 'not applicable'>"
  cognitive_bias: "<from Dimension 4>"

# The "why of why"
systemic_cause: "<why the agent's reasoning was wrong — the broad category, not the specific instance>"

# Action-oriented outputs
guardrail_proposal:
  type: "question | constraint | pattern | anti-pattern | test-obligation | checklist-item | instruction-update | gate"
  description: "<specific, operational change to prevent this class of mismatch>"
  target_file: "<which instruction, skill, or checklist file should be updated>"

applicability: "<when does this feedback apply — broad conditions, not specific to this one change>"
```

## Deduplication protocol

Before writing a new entry:
1. Read the current session file (if it exists) and check existing entries for matching `classification` (same values across all 4 dimensions) AND similar `systemic_cause`
2. If a match is found in the current session file:
   - Use `replace_string_in_file` to update that entry's `last_seen` to today's date and increment its `occurrence_count`
   - If `occurrence_count` crosses a promotion threshold (see Promotion Rules), flag for promotion
   - Do NOT add a duplicate entry
3. If no match in the current session file, also search prior session files under `docs/generated/control-loop/learnings/` or `feedback/` for the same match
4. If a match is found in a prior session file:
   - Use `replace_string_in_file` to update the prior file's matching entry (`last_seen`, `occurrence_count`)
   - Still add the entry to the current session file with a `cross_ref` field pointing to the prior entry ID
5. If no match anywhere, append a new entry to the current session file using the Tool Invocation Protocol above

## Promotion rules

Repeated entries are patterns. Patterns must escalate into stronger guardrails.

| Occurrences | Action |
|:-----------:|--------|
| 1 | Record in learning or feedback file |
| 2 | Add checklist item or reusable example to the `target_file` |
| 3 | Add or tighten an instruction rule in the `target_file` |
| 4+ | Propose automated gate, template, or architecture constraint |

When promoting:
- Update the entry's `status` to `operationalized`
- Note what was changed and where in the entry's `guardrail_proposal`
- Agents must prefer durable controls (rules, gates, constraints) over repeated reminders

## Retention policy

Session files accumulate over time. To prevent unbounded growth, enforce a maximum file count per type.

**Limits:**
- `docs/generated/control-loop/learnings/` — max **20** files
- `docs/generated/control-loop/feedback/` — max **20** files

**Cleanup procedure (once per session, on first capture of either type):**
1. List files in the target directory using `list_dir`.
2. Count the files. If count is **at or above** the max (20), delete the oldest files to bring the count down to max minus 5 (i.e., keep 15), making room for new sessions.
3. Files are named `YYYY-MM-DD-session.yaml` — alphabetical order = chronological order. Delete from the oldest (top of sorted list).
4. Before deleting, check if any entry in the file has `status: "validated"` or `occurrence_count >= 3`. If so, skip that file (it contains high-value patterns that should be promoted, not deleted). Flag it in conversation: "Retention: skipping {filename} — contains high-value entries pending promotion."
5. Use terminal command to delete: `rm docs/generated/control-loop/{type}/{filename}`
6. Log in conversation: "Retention cleanup: deleted {N} old {type} files, kept {M}."

**When to run**: Once per session, triggered by the first Capture Procedure execution (step 3.5 below). Do not re-run on subsequent captures in the same session.

**Why max minus 5**: Deleting down to 15 when hitting 20 avoids running cleanup on every session. Provides a 5-session buffer.

## Entry quality standard

Every entry MUST be:
- **Broad** — describes a class of issues, not a specific code change
- **Systemic** — identifies the missing guardrail, not just the symptom
- **Actionable** — proposes a concrete guardrail with a target file
- **Reusable** — another agent working on a different feature could apply this lesson

REJECT entries like:
- "Need to be more careful" (not actionable)
- "Bug in line 42 of OrderService" (too specific)
- "Developer changed the code" (no insight)

PREFER entries like:
- "Agent assumed update calls were safe to retry, but the endpoint lacked idempotency semantics. Guardrail: add 'confirm replay safety' to the bounded execution non-negotiable checklist before recommending retries for side-effecting operations."
- "Agent proposed synchronous cross-service writes, violating existing service boundaries. Guardrail: add 'verify transaction boundary stays within one service' to the dev-design-blueprint's dependency plan step."

## Capture protocol

1. Identify the trigger (bug inference or developer correction)
2. **Deduplicate**: search existing files for matching 4-dimension classification + similar systemic cause
3. If duplicate: update `last_seen` and `occurrence_count`; check promotion threshold
4. If new: classify across all 4 dimensions, write the entry with guardrail proposal
5. Present the captured entry to the developer for confirmation:
   - "I've captured this learning: [systemic cause + guardrail proposal]. Is the classification accurate?"
   - If developer corrects the classification, update the entry
6. If `occurrence_count` crosses a promotion threshold, state: "This pattern has occurred N times. Proposing promotion: [guardrail description] → [target file]. Approve?"


