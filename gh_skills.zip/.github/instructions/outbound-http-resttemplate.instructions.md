---
applyTo: "**/client/**/*.java,**/*Client.java,**/*Gateway.java,**/*Adapter.java"
---
# Outbound HTTP rules (Spring MVC / RestTemplate)

## Timeouts (MUST)
- Every outbound call must set:
  - connect timeout
  - read timeout
  - overall deadline/budget (stop retrying past the deadline)
- Never rely on default infinite timeouts.

## RestTemplate construction (safe patterns)
- Do not create RestTemplate with `new RestTemplate()` in business code.
- Provide a single factory/configuration that sets:
  - timeouts
  - interceptors for correlationId propagation
  - safe message converters (bounded payload handling where possible)

## Retries (bounded, safe)
- Retries MUST be explicitly bounded:
  - maxAttempts
  - bounded backoff (+ jitter if implemented)
  - must stop after overall deadline
- Retry only idempotent operations or operations protected by idempotency keys.
- Never implement unbounded retry loops.

## Response parsing safety
- Treat responses as untrusted:
  - validate required fields
  - bound array/list sizes
  - reject oversized payloads where possible
- Do not log entire response bodies (risk + size).

## Bounded concurrency
- Fan-out calls must have max parallelism and bounded queueing.
- Ensure cancellation is honored (do not continue heavy work after request completes/fails).

## Data validation
- Validate and bound response sizes before parsing (especially JSON arrays / large strings).
- Validate required fields, ranges, and schema assumptions.

## Observability
- Record dependency metrics: latency, errors, timeouts, retries.
- Log failures with correlation/trace id; never log secrets.

## SLA, Timeout Configuration & Response Time Impact (MUST)
When adding a new backend HTTP endpoint, **MUST document and validate**:

### Required Documentation (per endpoint)
- **SLA target response time** (p99 latency, max acceptable response time)
- **Timeout values**:
  - connect timeout (milliseconds)
  - read timeout (milliseconds)
  - overall deadline/budget from request start to response received
- **Retry strategy**:
  - max attempts
  - backoff timing (linear, exponential, with jitter)
  - idempotency key strategy
- **Worst-case latency calculation**:
  - formula: (connect timeout + read timeout) x max attempts + backoff windows
  - compare against upstream SLA (e.g., REST controller timeout, process timeout, job deadline)
- **Cascading failure impact**:
  - if this dependency is slow or unavailable, what is the user-facing SLA breach window?
  - document timeout/failure mode: should caller fail fast, queue for retry, or degrade gracefully?

### Required Validation (before deployment)
- [ ] Timeout values are set **explicitly** in code (not default/implicit)
- [ ] Worst-case latency + retry budget is less than upstream SLA
- [ ] If multiple HTTP calls are made in the same request path, aggregate their worst-case latencies
- [ ] Circuit breaker or fail-fast behavior configured if cascading failure risk is high
- [ ] Alert/runbook available if the endpoint consistently approaches its SLA

### Impact Analysis Checklist
Before adding new backend endpoint:
- [ ] Does this call execute in critical path (request-response)? If yes, add to latency budget.
- [ ] Does this call execute async (job/background task)? Document job SLA and deadline.
- [ ] Are there multiple parallel calls to this (or other) backends? Max parallelism must be bounded.
- [ ] What is the dependency's availability requirement? (e.g., "must be available 99.5% of the time")
- [ ] If dependency is unavailable, document fallback behavior (retry, queue, degrade, fail).
- [ ] Latency profile documented in metrics: p50, p95, p99, max observed
- [ ] Runbook created: what to do if endpoint is slow or broken
