---
applyTo: "**/*.java"
---
# Mission-Critical Testing Instructions for Spring Boot REST Microservices
Stack/tool defaults: `.github/shared/playbook-defaults.yaml` (`stackDefaults`).

These rules apply whenever you change production code OR tests.
Any production change MUST include (or update) the appropriate tests described below.
Prefer deterministic, bounded tests that fail fast and explain exactly what broke.
Enforce ALL non-negotiables (A through H) from `copilot-instructions.md`, with special attention to code generation discipline test scenarios.

=====================================================================
0) Test Design Fundamentals (MUST)
=====================================================================

Determinism (MUST)
- No Thread.sleep() in tests.
- If waiting/polling is required, use bounded waits only:
  - hard timeout (seconds, not minutes)
  - clear failure message that includes what condition was not met
- Control time explicitly:
  - business logic must accept an injected Clock; tests use fixed clocks
- Avoid nondeterministic randomness:
  - inject Random and use a fixed seed in tests

Isolation and clarity (MUST)
- Each test must assert behavior, not implementation detail.
- Tests must use explicit, stable input data.
- Failures must be actionable (assert on errorCode, status, key fields).

Bounds (MUST)
- If production code enforces bounds (max page size, max payload size, retry caps, timeout budgets),
  tests MUST cover boundary values and prove caps are enforced.

=====================================================================
1) Required Test Layers (Mission-Critical Taxonomy)
=====================================================================

A) Unit tests (fast, isolated, deterministic)
B) Contract tests (provider + consumer expectations)
C) Component/mock tests (Spring context + mocked backends/DB where appropriate)
D) Integration tests (real wiring across layers; DB and HTTP stack)
E) Resilience/fault-injection tests (timeouts, 5xx, malformed payloads)
F) Security behavior tests (authz/authn, SSRF allowlists, validation, sensitive output)

Notes:
- Not every change needs every layer, but every change MUST have a justified testing story.
- Critical endpoints and side-effecting flows typically require: A + B + C + D (+ E/F as relevant).

=====================================================================
2) Unit Tests (MUST)
=====================================================================

Tools (recommended)
- JUnit 5 + Mockito (and optional AssertJ/Hamcrest if project standard)

Must exist for every new/changed class in:
- service layer (*Service)
- outbound client adapters (*Client/*Gateway/*Adapter)
- validators/mappers/translators
- idempotency/dedupe components

Coverage requirements (MUST)
- Happy path
- Invalid input tests (nulls, missing fields, invalid formats)
- Boundary tests:
  - max string lengths
  - max list sizes
  - max page size
  - empty/minimum cases
- Error-path tests:
  - domain/business error -> mapped to typed exception (and later to 4xx)
  - technical error -> thrown as RuntimeException (and later to safe 5xx)
- Idempotency tests for side-effecting operations:
  - same idempotency key does not duplicate state changes
  - duplicate key behavior handled deterministically

Retry/timeout logic tests (MUST where implemented)
- If code contains retry loops or retry decorators:
  - prove maxAttempts is enforced
  - prove overall time budget/deadline is enforced
- If code enforces timeouts:
  - prove that a simulated slow dependency causes a timeout and correct error mapping

=====================================================================
3) Provider Contract Tests (Inbound API) (MUST for public endpoints)
=====================================================================

Goal
- Prevent breaking clients when API evolves.

You MUST have provider-side contract verification for every public endpoint using ONE of:
- OpenAPI-based contract verification (schema + compatibility checks), OR
- a contract framework (Spring Cloud Contract or Pact), depending on repo standard.

Provider contract test requirements (MUST)
- Request/response schema shape:
  - required/optional fields
  - field types
- Status codes and error envelope:
  - stable errorCode meanings
  - validation error structure is deterministic
- Backward compatibility checks:
  - additive changes only by default (no remove/rename of fields unless versioned)
  - do not change meaning/type of existing fields in-place

If you introduce a new versioned endpoint:
- add a separate contract suite for v2
- keep v1 contracts passing until explicit deprecation plan is implemented

=====================================================================
4) Consumer Contract / Dependency Tests (Outbound Clients) (MUST for each dependency)
=====================================================================

Goal
- Prevent integration drift and unsafe parsing/timeout behavior.

For every outbound dependency client (*Client/*Gateway/*Adapter), provide tests that verify:
Request contract (MUST)
- HTTP method + path
- required headers (including correlation id propagation)
- body schema (when applicable)

Response contract and parsing safety (MUST)
- correct parsing for expected responses
- behavior when:
  - missing fields
  - malformed JSON
  - unexpected status codes
  - huge arrays / oversized payloads (must be rejected/bounded)
- NEVER log full dependency payloads in assertions or production

Failure mode behavior (MUST)
- dependency timeout -> your code times out (not infinite wait) and returns safe error mapping
- dependency 5xx -> bounded retries (if applicable) then safe failure
- retries must stop at maxAttempts and/or deadline

Implementation guidance (code-controlled)
- Use a stub server (WireMock / MockWebServer) to simulate:
  - delayed responses (timeout)
  - 5xx bursts (retry)
  - malformed bodies
- Tests must assert the number of attempts does not exceed the configured cap.

=====================================================================
5) Component / Mock Tests (Spring Context + Mocked Backends) (MUST for critical flows)
=====================================================================

Goal
- Validate wiring and orchestration while keeping dependencies controlled and deterministic.

Component test scope (MUST)
- Start Spring context (limited or full) and test through service boundary or HTTP boundary.
- Mock external dependencies via stub servers (WireMock/MockWebServer) or mock beans.

Must verify in component tests (as applicable)
- controller -> service -> repository orchestration
- validation: invalid requests return 400 with stable error structure
- consistent error envelope (no stack traces; stable errorCode)
- correlation id:
  - accepted/generated inbound
  - propagated outbound
- idempotency:
  - duplicate request does not duplicate side effects
- outbound behavior:
  - timeouts configured and enforced
  - retry caps enforced

DB mocking note
- Prefer real DB behavior for persistence invariants (unique constraints) rather than mocking repositories
  when the correctness depends on DB semantics (e.g., dedupe uniqueness).

=====================================================================
6) Integration Tests (MUST for endpoints and persistence invariants)
=====================================================================

Goal
- Validate real wiring across layers and real serialization/mapping.

Web integration tests (MUST)
- Use MockMvc (or full HTTP if project standard) to verify:
  - happy path response
  - validation failures (400)
  - auth failures (401/403) where applicable
  - error envelope consistency for handled and unhandled errors

Persistence integration tests (MUST where DB logic matters)
- Validate:
  - unique constraints enforce dedupe/idempotency
  - transaction boundaries and rollback behavior
  - bounded queries (no unbounded list loads)
- Tests must be deterministic and bounded:
  - do not rely on long sleeps
  - use bounded waits only

Schema/migration-sensitive logic (SHOULD)
- If your change relies on a new constraint/index/column:
  - add an integration test that fails without that schema element
  - ensure application behavior is safe and explicit if schema is missing/mismatched

=====================================================================
7) Resilience / Fault-Injection Tests (MUST for critical dependencies)
=====================================================================

Goal
- Prove boundedness and safe behavior under failure.

You MUST add fault-injection tests for critical outbound dependencies:
- dependency timeout / high latency
- dependency 5xx bursts
- malformed/partial payloads
- connection refused / DNS failure simulation (as feasible)

Assertions (MUST)
- your code enforces timeouts (no hanging tests)
- retries are bounded:
  - never exceed maxAttempts
  - never exceed overall deadline/budget
- errors returned to callers are safe and consistent:
  - stable errorCode
  - no secrets/stack traces in body
- idempotency still holds when callers retry

=====================================================================
8) Security Behavior Tests (MUST where applicable)
=====================================================================

AuthN/AuthZ tests (MUST for protected endpoints)
- unauthenticated -> 401
- unauthorized -> 403
- authorized -> success

SSRF / outbound URL safety tests (MUST if URL input exists)
- allow-list enforced
- internal ranges blocked
- malformed URL rejected deterministically

Input validation tests (MUST)
- oversized payload/batch/list/pageSize rejected
- invalid formats rejected (e.g., UUID formats, enums)
- content-type restrictions enforced for uploads (if applicable)

Cascade / nested validation tests (MUST where nested beans exist)
- `@Valid` on nested DTO fields: prove invalid nested fields trigger 400
- `@Valid` on Map/List value types: prove invalid collection entries trigger 400
- Override / per-tenant config types: prove constraints from parent type are enforced on child fields
  (e.g., 0 or -1 for a field that requires @Min(1) on the parent is rejected)
- Null override with parent default fallback: prove default is used and is within bounds

Doc-code invariant consistency tests (MUST)
- For every bound stated in Javadoc, comments, or config metadata (e.g., "max 10000"):
  - test with value AT the bound (accepted)
  - test with value ABOVE the bound (rejected)
- If the bound is stated but no runtime constraint or test exists, flag as a gap

Sensitive-data tests (SHOULD where risk exists)
- ensure error responses never include stack traces
- ensure logs/test outputs do not contain secrets
  (in code: avoid logging raw tokens; in tests: do not print secrets)

=====================================================================
9) Code-Enforceable Guard Tests (MUST)
=====================================================================

These are tests that enforce conventions so unsafe patterns or missing tests are detected by running tests.

9.1 Architecture guard tests (recommended: ArchUnit) (MUST)
Add tests that enforce:
- Layering:
  - controllers do not depend on repositories/DAOs
  - repositories do not call outbound clients
- Outbound HTTP safety:
  - forbid `new RestTemplate()` outside a dedicated configuration/factory package
- Forbidden APIs:
  - forbid ObjectInputStream/readObject
  - forbid Runtime.exec and ProcessBuilder
  - forbid System.exit and Thread.stop/suspend/resume

9.2 Test pairing guard (MUST)
Add a JUnit test that:
- scans production classes for:
  - `*Controller`
  - `*Service`
  - `*Client/*Gateway/*Adapter`
- asserts corresponding tests exist by naming convention:
  - Controller -> `XControllerTest` and/or `XApiIT`
  - Service -> `XServiceTest`
  - Client/Adapter -> `XClientTest` plus dependency stub/contract test

The goal:
- Changes without tests are detected by running the test suite.

=====================================================================
10) When generating code, ALWAYS generate tests (MUST)
=====================================================================

When you add or modify:
- a controller endpoint:
  - add/update MockMvc tests (validation + happy path + error mapping)
  - update provider contract verification (OpenAPI/contract framework)
- a service/business rule:
  - add/update unit tests (including boundary/error cases)
- an outbound client:
  - add/update consumer contract/stub tests proving timeouts, retry caps, parsing safety
- idempotency/dedupe logic:
  - add concurrency/duplicate-key tests and deterministic replay behavior tests

## Boundedness tests
- If code retries/polls/batches: include tests proving maxAttempts/maxBatchSize is enforced.

## Static analysis expectations
- If an analyzer warning appears, rewrite code to become simpler/clearer.

=====================================================================
11) Test Type Decision Matrix
=====================================================================

Use this matrix to select the right test type for each code category:

| Code Category | Test Type | Key Assertions |
|--------------|-----------|----------------|
| Controller | MockMvc + contract verification | Status, errorCode, response shape |
| Service | Unit (JUnit 5 + Mockito) | Business logic, branches, boundaries |
| Outbound Client | Stub server (WireMock/MockWebServer) | Request shape, timeout, retry cap, parsing |
| Repository/DAO | Embedded DB (@JdbcTest/@DataJpaTest) | Constraints, rollback, bounded queries |
| Error/Advice | MockMvc | Error envelope, safe 5xx, no PII |
| Security/Filter | MockMvc | Auth, validation, header checks |
| Cross-cutting | ArchUnit guard tests | Layering, forbidden APIs, test pairing |

=====================================================================
12) Mandatory Test Scenarios
=====================================================================

Where applicable, every change must include tests for:
- Happy path
- Validation failures (400) for all user inputs
- Non-negotiable C rules (cascade validation, constraint propagation, doc-code invariant consistency)
- Domain error mapping (4xx) for business rule violations
- Technical failure mapping (safe 5xx) with no PII in errors
- Boundary/cap tests at and beyond the limit
- Timeout enforcement for outbound calls
- Retry cap exhaustion behavior
- Dedupe/idempotency for side-effecting operations

Code generation discipline scenarios:
- Boundary symmetry: for every `@Min` verify a matching `@Max` exists; test at both limits
- Defensive defaults: test that default/fallback values pass validation (a default of 0 on `@Min(1)` must fail)
- Resource closure: test that opened resources are closed on success AND on exception paths
- Error chain integrity: test that wrapped exceptions preserve the original cause
- Singleton safety: guard test (ArchUnit or equivalent) that singleton-scoped beans have no mutable instance fields
- Zero new dependencies: guard test that pom.xml changes are flagged (or risk register updated)

=====================================================================
13) Test Execution, Failure Classification, and Fix Loop
=====================================================================

Execution
- Execute tests via Maven.

Failure classification categories
- COMPILE: import/type/syntax errors
- MOCK_WIRING: missing @MockBean, stub setup, schema DDL
- ASSERTION: expected vs actual mismatch
- SCHEMA: missing CREATE TABLE, constraints, test data
- ENVIRONMENT: classpath, configuration, resource issues
- PRODUCTION_BUG: test is correct but production code has a genuine bug

Recommendation after execution
- ALL_PASS: proceed to next phase
- LOOP_BACK: scoped re-analysis -> category-specific fix -> re-validate -> re-execute
- ESCALATE: developer action needed (iteration cap reached or production bug in test-only mode)

Fix loop rules
- Bounded: max 5 iterations per VERIFY step; never infinite.
- Never weaken assertions or disable tests to force green.
- Never delete or @Disabled a failing test.
- Scoped: re-analyze only failing tests and their production code.
- Category-specific fixes:
  - COMPILE: fix imports, signatures, types, annotations
  - MOCK_WIRING: add missing mocks, fix stub setup, add schema DDL
  - ASSERTION: correct expected values -- never weaken
  - SCHEMA: add DDL, constraints, test data
- PRODUCTION_BUG handling depends on workflow:
  - TDD builder (owns code): fix inline
  - LTG (tests only): escalate to developer

Validate before execution
- No Thread.sleep; bounded waits only (hard timeout + clear failure message)
- Fixed Clock where time matters
- No redundant duplicates (extend existing tests when they already cover a scenario)
- Compilation sanity: correct imports, annotations, JUnit 5 usage

=====================================================================
14) Test Quality Introspection and Confidence
=====================================================================

Introspection questions (ask before considering tests complete)
- "What could break in production that isn't tested?"
- "What edge cases might a QA engineer find?"
- "What would an attacker try?"
- "What assumptions am I making that need tests?"

Gap regeneration
- For each identified gap, generate the missing test.
- Max 3 gap-fill iterations.
- Prefer extending existing tests over duplicating coverage.
- If blocked by code structure, document the smallest testability refactor needed.

Confidence statement
- Produce a production-readiness assessment: HIGH / MEDIUM / LOW with justification.
- Include remaining risks, assumptions, and manual testing recommendations.
