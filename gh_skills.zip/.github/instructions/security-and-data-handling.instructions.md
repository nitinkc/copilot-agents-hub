---
applyTo: "**/*.java,**/*.yml,**/*.yaml,**/*.properties"
---
# Security & data-handling rules

## Secrets
- Never hardcode secrets (passwords, API keys, tokens, connection strings).
- Never log tokens/credentials/private keys at any log level.
- Treat logs as sensitive production data; redact before writing.
- Use environment variables or a secrets manager (e.g., Spring Cloud Config + Vault) for all credentials.

## PII / Sensitive Data
- Identify PII fields explicitly: names, email, phone, SSN, addresses, account numbers, IP addresses.
- Never log PII unless explicitly required and redacted/masked (e.g., last 4 digits only).
- In error responses: never return PII in error messages, detail fields, or correlation metadata.
- In test fixtures: use synthetic/fake data -- never copy real customer data into tests.

## Log Redaction Patterns
- Before logging any object that may contain sensitive fields, apply a redaction filter.
- Redact at the logging boundary, not inside domain objects.
- Minimum redacted fields: password, token, authorization, cookie, ssn, accountNumber, cardNumber, cvv.
- Use a consistent redaction marker (e.g., `[REDACTED]`) -- never partially mask in inconsistent ways.

## Input Handling
- Validate all external input (HTTP headers, query params, path vars, bodies).
- Use allow-lists for enum-like values; reject anything not explicitly allowed.
- For file uploads: enforce size limit + content-type allowlist + safe storage path.
- For string inputs: enforce max length at the boundary (controller/message consumer).
- For numeric inputs: enforce range bounds.
- Reject null/empty where the contract requires a value -- fail fast with 400.

## SSRF / Outbound Safety
- Do not allow callers to supply arbitrary outbound URLs.
- If URL input exists, validate against an allowlist and block internal/private IP ranges (10.x, 172.16-31.x, 192.168.x, 127.x, 169.254.x, ::1).
- Do not follow redirects to internal addresses.

## Serialization Safety
- Do not use Java serialization (`ObjectInputStream`) for untrusted data.
- JSON parsing must be bounded; reject oversized content (enforce max payload size).
- Configure Jackson to fail on unknown properties in external-facing DTOs.

## CORS
- Do not use `allowedOrigins("*")` in production.
- Explicitly list allowed origins; restrict to known domains.
- If CORS is not needed, do not enable it.

## Security Headers
- Ensure responses include: `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY` (or SAMEORIGIN if framing is required).
- Do not expose `Server` or `X-Powered-By` headers with version details.

## Rate Limiting / Abuse Prevention
- Public-facing or high-risk endpoints should have rate limiting at the gateway or application layer.
- Log rate-limit violations with correlation context for monitoring.

## Spring Boot Actuator / Admin Endpoints
- Do not expose sensitive endpoints by default.
- If actuator is enabled, restrict it behind authentication/authorization and network controls.
- Disable or restrict: `/env`, `/configprops`, `/heapdump`, `/threaddump` in production.

## Authorization
- Default-deny: require explicit authorization for every endpoint.
- Never rely on client-side authorization checks alone.
- Use Spring Security method-level or URL-based authorization.

## Error Responses
- Never expose stack traces, internal class names, or SQL fragments in API error responses.
- Use a consistent error envelope (status + errorCode + correlationId).
- Map all exceptions to safe, stable error codes before returning to the caller.

## Common code-level security findings (Snyk / OWASP)
These patterns are frequently flagged by Snyk Code, OWASP scans, or security-focused SAST tools. Agents MUST NOT generate code containing them.

### Injection & traversal
- No path traversal: sanitize file paths — reject `..`, normalize with `Path.normalize()`, and validate the resolved path stays within the allowed directory.
- No log injection: sanitize user-controlled values before logging — strip `\n`, `\r`, and other control characters to prevent log forging.
- No LDAP injection: use parameterized LDAP queries; never concatenate user input into search filters.
- No XSS: encode output in templates; do not insert raw user input into HTML/JS responses.

### Cryptography & randomness
- No `java.util.Random` for security-sensitive operations — use `java.security.SecureRandom`.
- No weak hash algorithms: no MD5 or SHA-1 for integrity/security — use SHA-256 or stronger.
- No hardcoded encryption keys or salts in source code.
- No ECB cipher mode — use GCM or CBC with proper IV.

### Authentication & session
- No hardcoded credentials in any form (strings, byte arrays, char arrays).
- No permissive CSRF configuration for state-changing endpoints.
- No disabled SSL/TLS certificate verification (even in test code, use a test truststore instead).
- No overly broad `@PermitAll` / `.permitAll()` — explicitly declare allowed endpoints.

### Information exposure
- No Spring Boot Actuator endpoints exposed without authentication in production profiles (see the "Spring Boot Actuator" section above for full guidance).
- No verbose error messages containing SQL, class names, or dependency versions to external callers (see the "Error Responses" section above).
- No exposing HTTP headers that reveal framework/server versions (see the "Security Headers" section above).

### Dependency hygiene
- No dependencies with known critical/high CVEs without documented suppression + mitigation.
- Flag transitive dependencies that introduce risk (e.g., vulnerable XML parsers pulled in by a library).
- Keep dependency versions pinned — no SNAPSHOT, LATEST, or RELEASE in non-development builds.
