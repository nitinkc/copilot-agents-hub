---
applyTo: "**/*.md,**/*.mmd,**/*.yaml,**/*.yml"
---
# Documentation Visualization Standards (Mission-Critical)

This is a focused visualization reference that auto-loads for diagram and documentation files (`.md`, `.mmd`, `.yaml`, `.yml`).
The full documentation framework is in `documentation-living-views.instructions.md`.

Use diagrams as part of documentation when they improve comprehension, navigation, or impact analysis.
Prefer Mermaid types supported by GitHub.

## Diagram selection by audience
- Business / product:
  - `journey`
  - `flowchart`
  - `mindmap`
  - `requirementDiagram`
- Architects / platform:
  - C4 context/container
  - `architecture`
  - dependency graph / `flowchart LR`
- Developers / operators:
  - `sequenceDiagram`
  - `stateDiagram-v2`
  - `erDiagram`
  - focused technical flowcharts

## Rules
- Every important business capability should have at least one business-oriented flow or journey view.
- Every major dependency boundary should appear in context/dependency diagrams.
- Every stateful lifecycle or retry/failure process should use a state or sequence diagram where that improves clarity.
- Do not create giant omnibus diagrams.
- Prefer several focused diagrams over one unreadable diagram.
- Add a short interpretation paragraph under each diagram.
- Reference business rule IDs from the rule inventory in requirement diagrams where applicable.
- Reference entity names from the entity/attribute catalog in ER diagrams where applicable.

## Use-case and activity diagrams
Mermaid does not provide an official UML use-case diagram type.
For a use-case style view, use:
- `journey` for actor-centric steps
- `flowchart` for activity/business decisions
- C4 context for system boundaries and actors

## Validation
Before finishing documentation:
- make sure diagrams answer a real audience question
- ensure node names are stable and meaningful
- include business wording in high-level diagrams
- include technical wording only in technical diagrams
