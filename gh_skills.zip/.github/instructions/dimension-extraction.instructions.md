---
applyTo: "**/*.java,**/*.yml,**/*.yaml,**/*.properties,**/*.md,**/*.bpmn20.xml,**/*.bpmn"
---
# Dimension Extraction Framework (Mission-Critical)

When documenting or analyzing a service, extract structured dimensions from the codebase.
These dimensions feed into business capabilities docs, rule inventories, entity catalogs, impact-triage maps, and machine-readable manifests.

## When to extract dimensions
- Bootstrapping docs for a new or undocumented service (full extraction)
- Feature adds or changes business-visible behavior (delta extraction)
- Requirement grooming or impact analysis (targeted extraction)
- Quality gate finds documentation gaps in dimension coverage

## Dimension categories

### 1. Business dimensions
Extract per capability:
| Field | Description |
|---|---|
| Capability ID | Stable identifier (e.g., `CAP-ORDER-CREATE`) |
| Capability Name | Human-readable label |
| Business Goal | What business outcome this achieves |
| Actor / Persona | Who triggers or benefits |
| Trigger | What initiates the flow (API call, event, schedule) |
| Outcome | Observable success result |
| Business Value | Why the business cares (revenue, compliance, risk reduction, efficiency) |
| Business Rule IDs | References to rules in the Rule Inventory (e.g., `RULE-IDEMPOTENCY-001`) |

Destination docs:
- `docs/generated/01-business-capabilities.md` (human-readable, Level 0)
- `docs/generated/machine/service-manifest.yaml` → `capabilities` section

### 2. Logic dimensions
Extract per capability or rule:
| Field | Description |
|---|---|
| Rule Name / Rule ID | Stable identifier for the business or technical rule |
| Validations | Input and state validations the capability enforces |
| Decision Points | Branch/switch logic that changes behavior |
| Branching Attributes | Data attributes used in conditional logic, filtering, routing |
| Idempotency Key | Attribute(s) used for deduplication |
| Compatibility Constraints | What must remain stable for backward compatibility |

Destination docs:
- `docs/generated/14-rule-inventory.md` (human-readable)
- `docs/generated/machine/rule-inventory.yaml` (machine-readable)
- `docs/generated/non-functional-rules.md` (cross-cutting rules)

### 3. Data dimensions
Extract per entity:
| Field | Description |
|---|---|
| Entity Name | Domain object name |
| Purpose | Why this entity exists |
| Key Attributes | Fields that matter to business logic, routing, or compatibility |
| Logic-Bearing Attributes | Fields used in decision points, branching, filtering |
| Identifiers | Primary keys, business keys, correlation IDs |
| State Transitions | Valid state changes and their triggers |
| Data Classification | Sensitivity level (public, internal, confidential, restricted) |

Destination docs:
- `docs/generated/15-entity-attribute-catalog.md` (human-readable)
- `docs/generated/machine/entity-catalog.yaml` (machine-readable)
- `docs/generated/08-data-classification-and-controls.md` (classification overlay)
- `docs/generated/12-data-lifecycle.md` (lifecycle overlay)

### 4. Integration dimensions
Extract per endpoint or dependency:
| Field | Description |
|---|---|
| Public APIs / Endpoints | Method + path (HTTP), operation (SOAP/WSDL), method (gRPC), topic/queue (messaging), service task (BPMN) |
| Protocol | REST, SOAP, gRPC, JMS, Kafka, AMQP, BPMN service task, internal method, etc. |
| Contract Spec | Reference to machine-readable contract (OpenAPI, WSDL, .proto, AsyncAPI, BPMN XML, or none) |
| Downstream / Backends | Services, datastores, queues called |
| DB Tables / Stores / Queues | Specific persistence and messaging targets touched |
| Ownership / Team | Who owns the API, the backend, or the data |

When a machine-readable contract specification exists (OpenAPI, WSDL, .proto, AsyncAPI), it is the authoritative source of truth for that interface's contract details.
Documentation should reference or derive from the spec rather than duplicating contract details inline.
Destination docs:
- `docs/generated/02-service-context.md` (Level 1 context)
- `docs/generated/05-dependency-catalog.md` (dependency detail)
- `docs/generated/machine/service-manifest.yaml` → `apis` and `dependencies` sections
- `docs/generated/machine/dependency-graph.mmd`
- `docs/generated/machine/api-contract-catalog.yaml` (machine-readable)

### 5. Risk / Operability dimensions
Extract per capability or integration edge:
| Field | Description |
|---|---|
| Compatibility Sensitivity | How likely a change here breaks callers (High/Medium/Low) |
| Timeout / Retry Sensitivity | How sensitive this path is to latency or retry storms |
| Safe Failure Mode | What happens when this capability or dependency fails |
| Observability / Alerts | Metrics, dashboards, alert rules covering this area |
| Support / Runbook Relevance | Which runbook sections and escalation paths apply |

Destination docs:
- `docs/generated/10-known-failure-modes.md`
- `docs/generated/09-slos-alerts-and-observability.md`
- `docs/generated/06-operations-runbook.md`
- `docs/generated/non-functional-rules.md`

### 6. Traceability dimensions
Extract per capability:
| Field | Description |
|---|---|
| Related Docs | Which doc files cover this capability |
| Related Tests | Test classes/methods that prove behavior |
| Likely Code Areas | Packages, classes, configs involved |
| Requirement Keywords / Aliases | Phrases that should trigger impact analysis for this capability |

Destination docs:
- `docs/generated/change-impact-patterns.md`
- `docs/generated/machine/change-impact-map.yaml`
- `docs/generated/13-documentation-validation-and-coverage.md`

---

## Rule Inventory

### Purpose
Capture business and non-functional rules in a stable, referenceable form.
Rules are the bridge between business capabilities, code behavior, and test coverage.
Every rule should be traceable to at least one capability and at least one test.

### Rule template
```
- Rule ID: <stable identifier, e.g., RULE-IDEMPOTENCY-001>
- Rule Name: <human-readable rule description>
- Rule Type: business | validation | compatibility | security | operational
- Description: <what the rule enforces or ensures>
- Applies To Capability: <capability ID(s)>
- Trigger / Condition: <when this rule activates>
- Expected Behavior: <what should happen when the rule applies>
- Failure Behavior: <what happens when the rule is violated or infrastructure fails>
- Related API(s): <endpoint(s) where this rule is enforced>
- Related Code Areas: <packages/classes that implement or enforce this rule>
- Related Tests: <test classes/methods that prove this rule>
- Notes / Exceptions: <edge cases, temporary waivers, or planned changes>
```

### Rule types
| Type | Covers |
|---|---|
| business | Domain logic, workflow rules, outcome constraints |
| validation | Input validation, data format, boundary enforcement |
| compatibility | Backward compatibility, versioning, contract stability |
| security | AuthN/AuthZ, input sanitization, data protection |
| operational | Timeouts, retries, circuit breakers, idempotency, observability |

### Rule naming convention
`RULE-<CATEGORY>-<NNN>` where category is a short domain keyword (e.g., `IDEMPOTENCY`, `AUTH`, `ORDER-VALIDATE`, `TIMEOUT`).

### Destination
- `docs/generated/14-rule-inventory.md` — human-readable catalog
- `docs/generated/machine/rule-inventory.yaml` — machine-readable for automation/LLM

---

## Entity and Attribute Catalog

### Purpose
List domain objects and the attributes that matter to business logic, routing, validation, compatibility, or downstream behavior.
This is the structured bridge between data design, business rules, and change-impact analysis.

### Entity template
```
- Entity: <domain object name>
- Purpose: <why this entity exists>
- Key Attributes:
  - <attribute name>:
    - type: <data type>
    - why it matters: <role in business logic, routing, or compatibility>
    - used in rules: <rule ID(s)>
    - compatibility sensitivity: High | Medium | Low
- State Transitions: <valid state changes and triggers, if applicable>
- Data Classification: public | internal | confidential | restricted
- Related Capabilities: <capability ID(s)>
- Related APIs: <endpoint(s) that read/write this entity>
- Related Persistence: <table(s), store(s), or queue(s)>
- Related Dependencies: <downstream systems that consume or produce this entity>
```

### Destination
- `docs/generated/15-entity-attribute-catalog.md` — human-readable catalog
- `docs/generated/machine/entity-catalog.yaml` — machine-readable for automation/LLM

---

## API Contract Source of Truth

Not all APIs have an OpenAPI spec. The playbook supports any protocol and any contract format.

### Contract specification hierarchy
When a machine-readable contract spec exists for an API, it is the authoritative source of truth for that interface:

| Protocol | Machine-Readable Spec | Standard |
|---|---|---|
| REST / HTTP | OpenAPI (Swagger) | OpenAPI 3.x preferred |
| SOAP / XML-RPC | WSDL | WSDL 1.1 / 2.0 |
| gRPC | Protocol Buffers (.proto) | proto3 preferred |
| Async messaging (Kafka, JMS, AMQP) | AsyncAPI | AsyncAPI 2.x / 3.x |
| BPMN service tasks | BPMN XML | Flowable / BPMN 2.0 |
| Internal / no spec | API Contract Catalog entry | `docs/generated/machine/api-contract-catalog.yaml` |

### Rules
- When a machine-readable spec exists, documentation SHOULD reference or derive from it rather than duplicating contract details inline.
- The machine API contract catalog (`docs/generated/machine/api-contract-catalog.yaml`) is the universal fallback and summary for ALL APIs, regardless of whether a spec exists.
- The machine manifest (`docs/generated/machine/service-manifest.yaml`) SHOULD include a `contract-spec` field per API referencing the spec type and location.
- If documentation and a machine-readable spec diverge, the spec is authoritative for contract details (schemas, methods, endpoints, validation).

### When no machine-readable spec exists
- Document the API fully in the machine API contract catalog (`docs/generated/machine/api-contract-catalog.yaml`).
- Consider generating a spec from code annotations or definitions as part of the build pipeline where feasible.

---

## Extraction procedure (for doc-maintainer and all documentation skills)

1. **Identify capabilities** from controllers, service classes, and existing docs.
2. **Extract business dimensions** per capability: goal, actor, trigger, outcome, value, rule IDs.
3. **Extract logic dimensions**: scan for validation logic, conditional branches, idempotency checks, compatibility guards. Create/update rule inventory entries.
4. **Extract data dimensions**: scan entities/DTOs/repositories for key attributes, state transitions, data classification. Create/update entity catalog entries.
5. **Extract integration dimensions**: scan controllers, clients, repositories, message listeners, and BPMN service tasks for endpoints, backends, DB tables. Identify the protocol and contract spec type per API. Reference machine-readable specs (OpenAPI, WSDL, .proto, AsyncAPI, BPMN XML) when available. Create/update API contract catalog entries.
6. **Extract risk/operability dimensions**: scan for timeout/retry configs, circuit breakers, fallback paths, alert configurations.
7. **Extract traceability dimensions**: map capabilities to docs, tests, code areas, and requirement keywords.
8. **Cross-reference**: ensure rule IDs appear in capabilities, entities reference rules, tests reference rules, and impact maps reference capabilities.

## Quality checks
- Every capability has at least business goal, actor, trigger, and outcome.
- Every rule has at least one related capability and one related test.
- Every entity with logic-bearing attributes references the rules that use those attributes.
- Traceability links are bidirectional (capability → test, test → capability).
- Machine-readable contract specs (when present) and documentation are consistent for API contracts.
- Every API endpoint appears in the machine API contract catalog (`docs/generated/machine/api-contract-catalog.yaml`) with protocol and contract spec reference.
