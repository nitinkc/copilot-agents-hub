---
applyTo: "**/controller/**/*.java,**/*Controller.java,**/web/**/*.java,**/api/**/*.java"
---
# Spring Boot 2.2 + Spring MVC REST rules

## Layering
- Controllers MUST be thin: DTO mapping + validation + call service.
- No persistence logic in controllers.
- No retries, no loops over unbounded data in controllers.

## Validation & bounds
- All request DTOs MUST use Bean Validation (javax.validation).
- Enforce hard maximums:
  - max payload size
  - max page size
  - max batch/list sizes
- Enforce boundary symmetry and defensive defaults (see `copilot-instructions.md` non-negotiable H).
- Reject invalid inputs with a stable typed error.

### Cascade validation (MUST)
- Any field whose type is a bean (nested DTO, Map value, Collection element) MUST be annotated with `@Valid` so Bean Validation cascades into the nested type.
- Without `@Valid`, constraints on nested/child fields are silently ignored at binding time.
- Applies to: nested DTOs, `Map<K, V>` values, `List<T>` / `Set<T>` elements, configuration-properties maps (e.g., per-tenant override maps).

### Constraint propagation to nested / override types (MUST)
- When a parent type defines constraints (e.g., `@Min`, `@Max`, `@NotNull`), any child / override / per-tenant variant type that represents the same concept MUST mirror those constraints.
- Do not allow override/child fields to be unconstrained while the parent enforces bounds — this creates a validation bypass for values like 0, -1, or arbitrarily large numbers.
- If an override field is `null` (meaning "use parent default"), document that convention and test it explicitly.

### Doc-code invariant consistency (MUST)
- If Javadoc, comments, constants, or configuration-properties metadata state an invariant (e.g., "max 10000"), the code MUST enforce that invariant with a matching runtime constraint (e.g., `@Max(10000)`).
- If a bound is stated but not enforced, either add the constraint or soften the documentation — never leave a gap between stated and enforced behavior.
- Every stated-and-enforced bound MUST have a corresponding test that proves the bound is active (accept at limit, reject above).

## Error model (consistent, safe)
- Use a global @ControllerAdvice/@RestControllerAdvice.
- Return a consistent RFC7807-like JSON envelope:
  - type, title, status, detail, instance
  - plus stable errorCode
  - plus correlationId/traceId
- Never return stack traces or internal exception messages to clients.

## API correctness
- GET/PUT/DELETE are idempotent.
- POST is not assumed idempotent; if clients retry POST, require an Idempotency-Key (or equivalent).
- Use pagination; never return unbounded lists.

## Backward compatibility
- Prefer additive changes.
- Do not remove/rename fields without versioning.
- Update OpenAPI documentation if present.
