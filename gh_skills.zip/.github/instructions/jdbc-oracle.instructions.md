---
applyTo: "**/repository/**/*.java,**/dao/**/*.java,**/*Repository.java,**/*Dao.java,**/persistence/**/*.java"
---
# JDBC / Oracle-Safe Persistence Rules (Mission-Critical)

## SQL safety
- No string-concatenated SQL with user input.
- Use parameter binding (JdbcTemplate / NamedParameterJdbcTemplate).
- Avoid SELECT * in production code; select explicit columns.

## Bounded queries
- Any query that can return many rows MUST be paginated or hard-capped.
- Never load unbounded result sets into memory.

## Transaction boundaries
- Transactions belong in service layer (@Transactional) not controllers.
- Never call outbound HTTP inside a DB transaction.
- Keep transactions short and deterministic.
- Avoid transactions for read-only queries.

## Concurrency & idempotency
- Enforce idempotency and dedupe with Oracle UNIQUE constraints.
- Handle duplicate-key exceptions deterministically (treat as duplicate request, not unknown error).

## Mapping
- Row mappers must be deterministic and null-safe.
- Avoid time-zone ambiguity; use consistent time representations.

## Connection Pool Management (MUST)
- Use HikariCP (default in Spring Boot 2.x).
- Configure explicit pool size: minimumIdle, maximumPoolSize based on request load and job executor threads.
- Set connectionTimeout (max time to acquire connection from pool).
- Enable connection validation: validationQuery or isValid() to detect stale connections.
- Set leakDetectionThreshold to catch connection leaks in development/staging.
- Monitor pool metrics: active connections, idle connections, wait queue depth.

## Query Performance & Indexes (MUST)
- For every query, verify it uses an appropriate index (check Oracle EXPLAIN PLAN in SQL*Plus or IDE).
- Avoid index hints in code; ensure schema has proper indexes instead.
- Avoid full table scans for large tables; use LIMIT/OFFSET with indexed columns when paginating.
- Use COUNT(*) only for small reference tables; for large tables, maintain a summary count elsewhere or estimate via sampling.
- Avoid correlated subqueries; use JOIN instead if possible.
- Document expected row count and max query latency for significant queries.

## Error Handling & Oracle-Specific Exceptions (MUST)
- Catch SQLIntegrityConstraintViolationException explicitly for duplicate-key violations (idempotency checks).
- Catch SQLException and inspect error codes for Oracle-specific issues:
  - ORA-00001: unique constraint violated
  - ORA-00060: deadlock detected
  - ORA-01000: maximum open cursors exceeded (resource leak indicator)
  - ORA-12514: TNS listener could not resolve connection (infrastructure alert)
- Never log raw SQL with bind values; log parameterized query shape for debugging.
- Log correlation ID / trace ID with every DB error for tracing.

## Data Type Mapping & Oracle NULL Semantics (MUST)
- Oracle treats empty string ('') as NULL; never assume empty string persistence.
- String columns: validate max length against Oracle VARCHAR2(N); use VARCHAR2 MAX length in schema.
- Numbers: map Oracle NUMBER(p,s) correctly to Java BigDecimal (never Double for precision-sensitive data).
- Dates/Timestamps: always store in UTC; use TIMESTAMP WITH TIME ZONE or explicit UTC conversion.
- Boolean: store as CHAR(1) ('Y'/'N') or NUMBER(1) to avoid portability issues.
- LOBs (BLOB/CLOB): stream large objects; never load fully into memory; use DBMS_LOB for manipulation if needed.

## Transaction Isolation & Locking (MUST)
- Default Oracle isolation level (READ COMMITTED) is appropriate; avoid SERIALIZABLE unless latency tolerates it.
- For pessimistic locking: use SELECT ... FOR UPDATE (row-level lock); set timeout expectation and document why lock is necessary.
- If lock waits exceed SLA, redesign to optimistic locking (version column) or queue-based processing.
- Document which tables require locks and why; review in code review.

## Monitoring, Observability & Slow Queries (MUST)
- Enable slow query logging (Spring Data JPA show_sql=false in prod; use queryTimeout for explicit enforcement).
- Emit metrics for every DAO/repository method:
  - execution time (latency)
  - row count affected/returned
  - cache hit/miss if caching is used
- Set queryTimeout on JdbcTemplate via QueryTimeoutException to fail fast if query exceeds SLA.
- Log query execution time; alert if consistently > expected baseline.
- Maintain query performance baseline document (max expected row count, execution time, index strategy).

## Schema Migrations & Versioning (MUST)
- Use Liquibase (or Flyway) for all schema changes; never manual ALTER TABLE in production.
- Version migrations as code; review all migrations in PR alongside Java changes.
- Migrations must be idempotent (safe to re-run).
- For large table migrations (ADD COLUMN, CREATE INDEX on huge table): plan off-peak windows and use ONLINE operations where Oracle supports.
- Test rollback plan for every migration in staging DB matching production schema size.
- Maintain docs/generated/schema-changes/ with migration summary, downtime impact, and rollback procedure.

## Resource Cleanup & Connection Leaks (MUST)
- Always close ResultSet, Statement, Connection in finally or try-with-resources.
- JdbcTemplate handles this; never manually fetch connections unless required.
- If using raw JDBC: use try-with-resources(Connection, PreparedStatement, ResultSet).
- Monitor connection pool for leaks: check active-vs-idle ratio and alertThreshold.

## Memory & Result Set Limits (MUST)
- Never iterate a ResultSet into an unbounded List; instead process row-by-row or use pagination.
- If using row mapper + stream: set fetchSize on Statement to reduce memory footprint (e.g., fetchSize=100 for large results).
- Use JdbcTemplate.queryForObject(...) for single-row queries; queryForList(...) only if bounded count.
- Validate result set size before processing; fail fast if unexpected large result.
