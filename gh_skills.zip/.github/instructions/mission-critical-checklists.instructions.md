---
applyTo: "**/*.java,**/*.xml,**/*.yml,**/*.yaml,**/*.properties,**/*.bpmn20.xml,**/*.bpmn"
---

# Mission-Critical Checklists

Reusable checklists for any agent, skill, or manual workflow that reviews, generates, or validates code.
These are **not** PR-specific — they apply whenever code quality or production safety is being evaluated.

## Code quality anti-patterns (flag immediately)

This is the **single source of truth** for anti-patterns. All agents, skills, and instruction files reference this list.

- Production code changes with zero test changes
- Catch-all exception handlers that swallow errors
- Hardcoded URLs, credentials, or environment-specific values
- Unbounded queries or result sets
- New outbound calls without explicit timeouts (connect + read + deadline)
- Removed or renamed public API fields without deprecation or versioning
- BPMN variable contract changes without consumer analysis
- Configuration changes that affect all environments without profile scoping
- Database migrations without rollback scripts
- Copy-paste from other services without shared library consideration
- God-class changes (one file with 500+ lines changed)
- Shotgun surgery (20+ files changed for one concern)
- Logging changes that might expose sensitive data (PII, tokens, Authorization headers)
- New secrets or credentials in code/config (should be in vault/env)
- Missing pagination on new list endpoints
- Ignored return values, futures, or I/O outcomes
- Hidden control flow: over-clever streams, reflection tricks, dynamic proxies beyond framework needs
- Expression Language method invocations without explicit review justification
- Manual thread creation (use managed executors)
- Unbounded executors or queues
- String concatenation for SQL/commands (use parameterized statements)
- Feature flags without clear cleanup plan
- New dependencies added without explicit developer request (code generation discipline — zero new deps)
- One-sided constraints (`@Min` without `@Max`, or vice versa) — boundary symmetry violation
- Default/fallback values that violate their own field's constraints
- Caught exceptions with cause chain lost during wrapping
- Resources opened without guaranteed close path
- Mutable instance fields in singleton-scoped Spring beans
- Public API field removal/rename/type change without new version

## Socratic self-check (before finalizing any output)

Before output, challenge the goal, assumptions, boundaries, failure modes, evidence, compatibility, and operational impact. Ask people only when the answer materially changes risk or correctness.

Before producing a final verdict, confidence statement, review-ready summary, or quality gate result, answer silently:

1. What is the worst production incident this change could cause?
2. What user-visible behavior changes that isn't obvious from the diff?
3. What existing test would start failing if this change has a subtle bug?
4. What documentation is now wrong that nobody will notice for weeks?
5. What would the on-call engineer wish was different about this change?
6. What downstream service will break if this merges?
7. What monitoring alert will fire unexpectedly?
8. What happens to in-flight requests during deployment of this change?
9. What happens at midnight, month-end, year-end, or DST transitions?
10. If we need to revert this change, what is the blast radius?
11. Are there data migrations that make reverting non-trivial?

If any answer reveals an uncaptured risk, add it as a finding and re-assess the output.

## Outcome presentation rules (MANDATORY)

Anti-pattern and Socratic outcomes MUST be visible in the final output. Silent consumption without reporting is prohibited.

### Anti-pattern findings
When flagged during review or generation, report as a labeled section in the output:
```
### Anti-Pattern Findings
| # | Anti-pattern | File / Area | Severity | Action taken |
```
When flagged during grooming or design (risk preview), report as:
```
### Implementation Risk Flags (from anti-pattern preview)
| # | Risk pattern | Requirement / Design area | Likelihood | Mitigation note |
```
If no anti-patterns are found, state: "Anti-pattern scan: 0 findings."

### Socratic-revealed risks
When the Socratic self-check reveals uncaptured risks, report them alongside findings:
```
### Socratic-Revealed Risks
| # | Question that surfaced it | Risk | Action taken |
```
If all 11 questions confirm no uncaptured risks, state: "Socratic self-check: 0 new risks surfaced."

### Why this matters
Without visible outcomes, the developer cannot distinguish "the check ran and found nothing" from "the check was skipped."

## When to use each checklist

| Checklist | Use when | Examples |
|-----------|----------|---------|
| Anti-patterns | **Reviewing or generating code** — scan for unsafe patterns | PR review, code review, critical review, TDD GREEN, code health audit |
| Anti-patterns (as risk preview) | **Grooming or designing** — check whether the requirement or design will likely lead to these patterns | Requirements grooming Step 4 (Critical Feedback), dev-pilot DESIGN phase |
| Socratic self-check | **Finalizing any deliverable** — prevent blind spots before a verdict, decision, or handoff | PR verdict, review-ready summary, quality gate confidence, audit report, **DoR decision, design developer gate** |
| Test introspection (section 14 of `testing-and-determinism.instructions.md`) | Evaluating test completeness | Test generation critical review, TDD VERIFY, quality gate test adequacy |

### Anti-pattern risk preview (for requirements and design phases)

When used during grooming or design (before code exists), reframe each anti-pattern as a risk question:
> "Does this requirement/design, as currently specified, make it likely the implementation will exhibit this anti-pattern?"

Examples:
- Requirement with no pagination or size limits → **unbounded queries or result sets**
- Requirement that changes existing API response shape → **removed or renamed API fields without versioning**
- Requirement with no failure/timeout behavior specified → **new outbound calls without explicit timeouts**
- Requirement with no test criteria → **production code changes with zero test changes**

Flag matching risks in the Critical Feedback or Design concerns. Do not require the requirement to be rewritten — flag the risk so the developer/designer is aware and can address it in implementation.
