---
applyTo: "**/*.bpmn20.xml,**/*.bpmn,**/delegate/**/*.java,**/listener/**/*.java,**/flowable/**/*.java,**/bpmn/**/*.java,**/process/**/*.java"
---
# Mission-Critical BPMN + Java + Tests Instructions
# Stack/tool defaults: `.github/shared/playbook-defaults.yaml` (`stackDefaults`).
# Deployment context: multiple instances in Cloud Foundry, and potentially multiple datacenters.

This repository contains mission-critical orchestration logic. Optimize for:
correctness, determinism, bounded behavior, idempotency, and verifiability.

If requirements are unclear, ask questions and choose the safest default.

=====================================================================
0) Core Principles (apply to BPMN + Java + configuration + tests)
=====================================================================

P0. Simple, analyzable control flow
- NO recursion.
- Avoid clever/implicit control flow (over-complex streams, reflection tricks, magic side effects).
- Keep nesting shallow; prefer early returns for error paths.

P1. Everything must be bounded
- Every loop/retry/poll MUST have a hard upper bound.
- Every IO call MUST have explicit timeouts (HTTP/DB/queue/file).
- Memory must be bounded: no unbounded collections/caches/queues in request or job execution paths.

P2. Explicit contracts and defensive checks
- Validate all external inputs at boundaries (HTTP + message consumers + process start).
- Validate required process variables at the start of every delegate/listener.
- Fail fast with typed/structured errors; do NOT continue after invalid state is detected.

P3. Correct error semantics
- Business fault (expected domain fault): map to BPMN Error and handle in BPMN.
- Technical fault (timeouts, transient infra issues, unknown exceptions): trigger retries and then a terminal failure path (dead-letter/operator handling). Never silently swallow.

P4. Idempotency everywhere
Assume at-least-once execution:
- async job retries
- lock expiration
- instance restarts
- duplicate inbound requests/events
Any side effect MUST be idempotent via stable idempotency keys + dedupe storage + unique constraints.

P5. Verifiable rules > "best intentions"
- Add build gates and tests that enforce these rules automatically.
- If a tool flags something, prefer rewriting code/model to become simpler rather than suppressing.

=====================================================================
1) Traceability & Repository Contracts (MUST)
=====================================================================

1.1 Process contract documentation (MUST)
For each processDefinitionKey, maintain:
- docs/generated/process-contracts/<processKey>.md
Include:
- required input variables (name/type/constraints/defaults)
- businessKey format + uniqueness rules
- idempotency strategy (externalRequestId/idempotencyKey)
- external side effects list + their idempotency keys
- SLAs/timeouts + escalation rules
- BPMN Error codes + meaning
- duplicate request rules (start + callbacks/messages)
- backward compatibility notes (what must never change)

1.2 BPMN <-> Java mapping (MUST)
- Every Service Task using delegateExpression MUST reference a Spring bean with:
  - stable bean name
  - stable class/interface contract
  - unit tests
- Every ExecutionListener / TaskListener reference MUST point to a stateless, thread-safe bean.
- If BPMN changes, update:
  - the referenced Java delegates/listeners/services
  - tests (unit + flow + integration)
  - process contract docs if inputs/outputs or behavior changed

=====================================================================
2) Backward Compatibility Contract (MUST) -- BPMN + Java
=====================================================================

Principle:
Running and historic process instances MUST remain executable and diagnosable across deployments.
Treat BPMN IDs/codes and Java delegate entrypoints as stable public API.

2.1 BPMN compatibility (MUST)
- DO NOT rename or remove existing BPMN element IDs after go-live:
  - serviceTask, userTask, scriptTask, sendTask, receiveTask
  - gateways, events (message/signal/timer/error/escalation), subprocesses, callActivities
- DO NOT rename:
  - processDefinitionKey/id
  - message names, signal names
  - BPMN error codes, escalation codes
  - any identifier used by correlation, monitoring, runbooks, or queries (activityId/taskDefinitionKey)
- DO NOT reuse an old ID for different semantics.
- If behavior must change:
  - add NEW elements with NEW IDs (e.g., Task_Foo_V2)
  - route NEW instances to V2 elements
  - keep OLD elements available for older in-flight instances

2.2 Java compatibility (MUST)
- DO NOT rename or remove any Spring bean referenced from BPMN:
  - delegateExpression / expressions
  - task listeners / execution listeners
- Bean names referenced in BPMN are immutable API:
  - if refactoring, keep the old bean name as a compatibility wrapper/shim delegating to the new implementation
- Do not change the semantic meaning of existing delegate behavior without:
  - updating process-contract docs
  - adding tests proving old and new processes behave safely
- Backward-compatible variables:
  - existing variable names/types must continue to work
  - new variables must be optional with safe defaults
  - never remove variables still read by old versions

2.3 Coexistence of multiple versions (MUST)
- Assume multiple process definition versions run concurrently in production.
- New deployment MUST allow:
  - new instances to start safely
  - old instances (created before deployment) to complete normally

2.4 Incompatible change policy (MUST)
If compatibility cannot be preserved:
- create a new processDefinitionKey (e.g., OrderFulfillmentV2) and keep V1 deployed, OR
- execute a controlled migration project (separate change set) with:
  - migration strategy documented
  - rollback plan
  - load/chaos tests
  - operational runbook

2.5 "No breaking change" enforcement (MUST)
Maintain:
- docs/generated/bpmn-compatibility/bpmn-api-snapshot.json containing:
  - processDefinitionKey
  - BPMN element IDs (activity ids)
  - message/signal names
  - error codes / escalation codes
  - delegateExpression bean names used
CI MUST fail if an existing ID/name/code/delegate reference is removed or renamed.
Additive changes are allowed.

=====================================================================
3) BPMN Modeling Best Practices for Flowable (MUST/SHOULD)
=====================================================================

3.1 Closed flow and termination (MUST)
- Every normal completion path MUST reach an explicit End Event.
- Every non-happy path MUST be modeled to a terminal state:
  - End Event / Terminate End Event (if intentionally killing all tokens), OR
  - explicit operator-handling wait state that has:
    - SLA timer escalation path
    - documented runbook entry
- No dangling tokens:
  - Any message/event catch MUST have a timeout boundary or alternate SLA path.
  - Any User Task MUST have:
    - due date / SLA timer boundary (or explicit documented reason why not)
    - escalation/timeout handling
- Avoid Inclusive Gateways unless truly necessary (harder to reason about and test).

3.2 Boundedness (MUST)
- Any loop (standard loop, cyclic flow, multi-instance) MUST be bounded by:
  - explicit maximum iterations/cardinality, AND
  - explicit stop condition, AND
  - SLA timeout/abort path that guarantees eventual modeled closure
- Multi-instance:
  - validate and cap cardinality BEFORE entering the MI activity
  - default to sequential MI unless parallelism is proven safe and idempotent

3.3 External IO modeling (MUST)
- Any step performing IO (HTTP/DB/MQ/files) MUST NOT be a synchronous in-transaction side effect.
- Model IO as async work:
  - async Service Task (`flowable:async="true"`) with bounded retries, OR
  - outbox/event pattern step that is async and retryable
- Every async IO step MUST define retry behavior:
  - bounded max attempts
  - terminal failure path after exhaustion (dead-letter/operator handling or recovery subprocess)

3.4 Error semantics: Business vs Technical (MUST)
- Business error (expected domain fault):
  - throw BPMN Error (BpmnError) with stable errorCode
  - MUST be caught by boundary error event or error subprocess
  - MUST lead to a closed modeled state
- Technical error (timeouts, network failures, DB transient failures, unknown exceptions):
  - MUST trigger retries (async job retry)
  - after exhaustion, MUST route to terminal failure handling (dead-letter/operator handling)
  - MUST NOT be silently converted to business error

3.5 Variables: size, schema, compatibility (MUST)
- Keep variables small; store references/IDs, not huge payloads.
- Variables are part of the contract:
  - new variables MUST be optional with defaults
  - do not change meaning/type of existing variables without migration plan
  - do not remove variables used by older in-flight instances
- Prefer local variables for activity-scoped data to reduce cross-branch collisions.

3.6 Task definition best practices (User Tasks) (SHOULD)
- Keep User Task IDs stable forever (taskDefinitionKey is derived from BPMN id).
- Keep candidate groups/assignees stable and versioned by policy (document in contract).
- Use explicit form keys if UI depends on it; treat as compatibility contract.
- Always model "abandon/timeout/escalation" for long-lived tasks.

3.7 Call Activities / Subprocesses (SHOULD)
- Prefer explicit in/out mappings; avoid inheritVariables unless variable set is small and stable.
- Propagate businessKey intentionally; document rule in process contract.
- If parent+child must remain in lockstep, deploy together and require same-deployment behavior.
- If called process can throw BPMN Error:
  - DO NOT rely on out-mapped variables on error path.
  - explicitly set parent variables before throwing BPMN Error or in boundary handler.

3.8 Duplicate request processing (MUST)
Assume duplicate starts and duplicate callbacks/messages can happen.
- Process start MUST be idempotent:
  - require externalRequestId / idempotencyKey
  - enforce dedupe via Oracle UNIQUE constraint in a business table
  - on duplicate: return existing processInstanceId/businessKey; do not start another instance
- Message correlation/callback handling MUST be idempotent:
  - dedupe on (businessKey + messageType + externalEventId/version) via UNIQUE constraint

=====================================================================
4) Java Implementation Rules for Flowable Tasks & Listeners (MUST)
=====================================================================

4.1 Delegate/listener design (MUST)
- Delegates/listeners MUST be stateless, thread-safe, deterministic:
  - no mutable instance fields
  - no reliance on shared mutable singletons
- NO recursion.
- All loops must be bounded.
- No blocking IO without explicit timeouts.
- Do not directly SQL-update Flowable runtime tables (ACT_*).

4.2 Delegate/API immutability (MUST)
- Any Spring bean name referenced from BPMN is immutable API.
- If refactoring:
  - keep original @Component("<beanName>")
  - implement it as a compatibility wrapper that delegates to new code
- Never remove a delegate bean while any deployed process definition may reference it.

4.3 Idempotency and dedupe (MUST)
Assume same delegate can execute multiple times:
- Any external side effect MUST use idempotency key + dedupe storage:
  - stable key = (processInstanceId + activityId + externalRequestId) OR domain unique key
  - persist "already executed" record in Oracle with UNIQUE constraint
  - on duplicate: return success WITHOUT repeating side effect

4.4 Exception mapping (MUST)
- Business faults: throw BpmnError(errorCode, message).
- Technical faults: throw RuntimeException to allow Flowable retries.
- Never swallow exceptions.
- Never "log and continue" in unknown/invalid state.
- Handle InterruptedException correctly:
  - restore interrupt flag or propagate safely.

4.5 Validation and bounds (MUST)
At start of every delegate/listener:
- Validate required variables (presence/type/range/size).
- Enforce max sizes (string length, list size, payload size).
- Validate externally-derived values (headers, callback payloads).
- Fail fast with a meaningful errorCode for business faults.

4.6 Outbound HTTP / DB / Oracle 12c (MUST)
- Every outbound HTTP call MUST set:
  - connect timeout
  - read timeout
  - an overall deadline/budget
- Retries MUST be bounded and only for idempotent operations.
- Database:
  - use prepared statements / parameter binding only
  - queries must be bounded (pagination/LIMIT equivalents)
  - transactions must be short; do not call external HTTP inside DB transactions
  - enforce unique constraints for dedupe and idempotency

4.7 Observability (MUST)
Every delegate/listener/boundary handler MUST:
- log with correlation context:
  - businessKey, processInstanceId, executionId, activityId, externalRequestId/idempotencyKey
- emit metrics:
  - retries, failures, deadletters, SLA timeouts, duplicate detections

=====================================================================
5) Scaling & Performance (Cloud Foundry + Multi-Instance + Multi-DC)
=====================================================================

5.1 Statelessness (MUST)
- No local disk reliance for correctness (logs aside).
- No in-memory locks used for correctness.
- Assume any instance can pick up any job.

5.2 Recommended topology (SHOULD)
Split roles:
- API instances: async executor OFF (handle inbound HTTP, start/inspect processes)
- Worker instances: async executor ON (execute async jobs/timers)
Rationale: predictable scaling, reduced contention, safer operations.

5.3 Bounded parallelism (MUST)
- Worker thread pools MUST be bounded.
- DB connection pool MUST be sized to support worker threads.
- Never configure more job executor threads than reliable DB connections.

5.4 Multi-datacenter safety (MUST)
- Treat multi-DC against a shared DB as correctness-risky (latency/clock skew).
- Require NTP clock sync everywhere.
- Require load + chaos testing for:
  - lock expiry behavior
  - retries and dead-letter behavior
  - duplicate execution of side effects
- If DB is not shared across DCs:
  - you MUST document orchestration handoff/replication strategy and failure modes.

=====================================================================
6) Framework Constraints & Known-Issue Guardrails (MUST)
=====================================================================

6.1 Living constraints doc (MUST)
Maintain docs/generated/framework-constraints.md with:
- pinned versions (Boot 2.2.7, Flowable 6.5.0, Oracle driver, Jackson, etc.)
- known issues/gotchas and mitigations
- how mitigation is verified (test/build rule)
- upgrade policy and security scanning policy

6.2 Two-layer enforcement (MUST)
1) Build-time gates:
   - Maven Enforcer:
     - ban version ranges / LATEST / RELEASE
     - require dependency convergence / upper-bound deps
     - ban known-bad artifacts by denylist
   - CVE scanning (fail build above severity threshold unless suppressed with:
     - reason + ticket/link + expiry date)
   - Forbidden APIs:
     - ban dangerous JDK APIs (ObjectInputStream, Runtime.exec, ProcessBuilder, System.exit, Thread.stop, etc.)
2) Code-time architecture tests (ArchUnit):
   - forbid direct Java deserialization usage
   - forbid ProcessBuilder/Runtime.exec usage
   - enforce layering (controller -> service -> repo)
   - enforce: Flowable delegates call services, not repositories directly
   - enforce: delegates are stateless (no mutable fields)

6.3 Flowable gotchas requiring explicit checks (MUST)
- Call activity out-mapping + BPMN Error: do not rely on out vars on BPMN error exit.
- Delegate field injection into singleton beans: avoid; prefer stateless beans or prototype.
- Optimistic locking under heavy parallelism: prove safe via stress tests or redesign to exclusive patterns.
- Production schema update must be OFF; migrations must be controlled outside the app.

=====================================================================
7) Testing Requirements (MANDATORY) -- Unit + Mock Flow + Integration
=====================================================================

A change is NOT complete without tests proving:
- correctness (happy path)
- business errors mapped and handled (BPMN Errors)
- technical failures retried and then terminal failure path reached
- duplicate processing safety (idempotency)
- process closure (no dangling tokens/jobs beyond intended wait states)
- backward compatibility (old instances can complete after new deploy)

7.1 Unit tests (MUST)
For every delegate/service:
- JUnit 5 + Mockito unit tests:
  - input validation failures
  - idempotency/dedupe behavior
  - exception semantics (BpmnError vs technical exception)
  - timeouts and bounded retries (prove maxAttempts/budget)
- No sleeps; use injected Clock for time.

7.2 Mock "complete flow" tests (MUST)
Provide flow-level tests that execute BPMN end-to-end with mocked external dependencies:
- Boot a Spring test context with Flowable engine.
- Deploy BPMN under test into the engine.
- Replace external integrations (HTTP clients, gateways) with mocks/stubs.
- Start process instance with required variables.
- Drive the process deterministically:
  - recommended: disable async executor in tests and execute jobs manually via ManagementService
- Assertions MUST include:
  - process ended OR waiting at explicitly expected wait state
  - variables as expected
  - no unexpected jobs/timers remain
  - duplicate start/callback does not duplicate effects

7.3 Integration tests (MUST)
Provide integration tests validating:
- REST endpoint -> process start behavior (MockMvc)
- persistence correctness (Oracle semantics verified in staging/pipeline if local Oracle not feasible)
- error envelope correctness (no stack traces; stable errorCode)
- at-least-once realities:
  - simulate retry and ensure idempotency holds
Guidance:
- "test" profile: in-memory DB for fast flow checks
- "it" profile: closer to production (real DB in pipeline/staging if Oracle container is not viable)
- If async executor enabled in integration tests:
  - assertions must poll with bounded timeouts (no infinite waits)

7.4 BPMN static lint tests (MUST)
Add tests that parse all *.bpmn20.xml and enforce:
- every process has at least one End Event reachable from Start Event
- no unbounded loops/multi-instance without explicit caps
- all IO service tasks are async and have retry configuration
- message catch/user tasks have timeouts/escalation paths
- call activities follow mapping rules and do not rely on out vars on BPMN error exits

7.5 Backward compatibility tests (MUST)
Provide tests proving in-flight instances survive a new deployment:
- Deploy BPMN v1
- Start an instance and drive it to a mid-state (e.g., before an async job or waiting at user task)
- Deploy BPMN v2 into the same engine
- Continue the original v1 instance to completion
- Assert:
  - it completes safely
  - no missing delegates/beans
  - no unexpected deadletter jobs
  - idempotency holds if a job executes twice

7.6 "No breaking change" snapshot test (MUST)
Add a test that:
- loads docs/generated/bpmn-compatibility/bpmn-api-snapshot.json from previous release
- parses current BPMN XML set
- fails if any prior IDs/names/codes/delegate references are missing or renamed

=====================================================================
8) Definition of Done Checklist (MUST)
=====================================================================

For any BPMN or Flowable Java change:
- [ ] Process is closed (all paths end or explicitly wait with SLA/escalation)
- [ ] Loops/MI are bounded and capped
- [ ] External side effects are async + retryable + idempotent
- [ ] Business vs technical errors modeled and tested
- [ ] Duplicate start/callback handled (unique constraint + tests)
- [ ] Backward compatibility preserved:
  - no task/event/gateway ID rename/remove
  - no message/signal/error code rename/remove
  - no delegate bean rename/remove
  - v1 instance completes after v2 deploy test exists
- [ ] Unit tests added/updated
- [ ] Mock "complete flow" tests added/updated with mocks
- [ ] Integration tests added/updated (REST + persistence + error envelope)
- [ ] BPMN static lint tests pass
- [ ] Dependency gates updated if dependencies changed
