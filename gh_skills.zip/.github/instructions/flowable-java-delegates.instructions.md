---
applyTo: "**/*.java"
---
# Flowable Java Delegates (Java 8, Spring Boot 2.2) - Mission-Critical Rules

Scope:
These rules apply to implementations of:
- org.flowable.engine.delegate.JavaDelegate
- ExecutionListener, TaskListener
- Any Spring beans referenced from BPMN via delegateExpression / expressions.

Thread-safety and determinism:
- Delegates MUST be stateless and thread-safe.
  - No mutable instance fields (especially not fields populated by BPMN field injection).
  - If field injection is required, use prototype scope OR fetch expressions safely per execution.
- Delegates MUST be deterministic and bounded:
  - No unbounded loops.
  - No blocking calls without explicit timeouts.
  - No uncontrolled parallelism.

Idempotency (mandatory):
- Assume the delegate can run multiple times (retries, restarts, lock expiry).
- Any side-effecting action MUST use an idempotency key:
  - Derive a stable key from (processInstanceId + activityId + externalRequestId) or a domain unique identifier.
  - Store dedupe state in a business table with a UNIQUE constraint in Oracle.
  - On duplicate, return success and do not repeat side effects.

Error semantics:
- Business fault:
  - throw org.flowable.engine.delegate.BpmnError(errorCode, message)
  - ensure the BPMN model catches it with boundary error or error subprocess
- Technical fault:
  - throw RuntimeException (or checked exception) so Flowable retries per model/engine config
  - never convert unknown technical exceptions into BPMN errors

Variable hygiene:
- Validate required inputs at the start of the delegate:
  - check presence, type, range/size limits
- Keep process variables small:
  - store IDs and references, not large payloads
  - avoid storing raw external responses unless capped and justified
- Use local variables for activity-scoped values when appropriate to reduce collisions.

Do NOT:
- Do not directly update Flowable runtime tables (ACT_*) with SQL.
- Do not swallow exceptions.
- Do not rely on "exactly-once" execution.

Observability:
- Always log with correlation identifiers:
  - businessKey
  - processInstanceId
  - executionId
  - activityId
  - externalRequestId/idempotencyKey
- Emit metrics for: retries, failures, deadletters, SLA breaches.

Testing:
- Provide unit tests that prove:
  - duplicate execution does not duplicate side effects
  - timeout path works
  - business error is mapped and caught
  - technical error retries then dead-letters
- Use mocks/stubs for external dependencies; do not rely on an actual Flowable engine in unit tests.
- Provide integration tests with an embedded Flowable engine to verify end-to-end behavior, including error paths and retries.