---
applyTo: "**/*.md,**/*.txt,**/*.yaml,**/*.yml,**/*.bpmn20.xml,**/*.bpmn"
---
# Requirements Grooming Standards

This instruction file mirrors the `requirements-grooming` workflow.
If the agent is selected, follow its phases in order.
If the agent is not selected, emulate the same phases directly from these instructions.
Stack/tool defaults and instruction scope map: `.github/shared/playbook-defaults.yaml`.

## Skill invocation rule
When a workflow step references a skill file, you MUST use `read_file` to load `.github/skills/<skill-name>/SKILL.md` and follow every step it defines. The inline fallback is only for when the skill file cannot be loaded. Do NOT skip loading the skill file.

## Workflow map (agent <-> skill <-> execution)
1. INTAKE & CLARIFY
   - **MANDATORY — Read and follow**: `.github/skills/requirements-intake-clarify/SKILL.md`
   - Inline fallback (only if skill file unavailable): restate request in plain language, identify business goal/actors/triggers/outcomes, find gaps, ask targeted questions, label assumptions
2. ACCEPTANCE CRITERIA
   - **MANDATORY — Read and follow**: `.github/skills/acceptance-criteria-gherkin/SKILL.md`
   - Inline fallback (only if skill file unavailable): convert to Given/When/Then ACs covering happy path, error, boundary, idempotency, dependency failure, backward compatibility
3. STORY QUALITY
   - **MANDATORY — Read and follow**: `.github/skills/story-quality-invest/SKILL.md`
   - Inline fallback (only if skill file unavailable): evaluate each story against INVEST + backward compat, business rule clarity, failure behavior, observability, security
4. CRITICAL FEEDBACK
   - (Inline step): produce concerns from customer/user, operational, backward compatibility, and testing/observability perspectives
5. IMPLEMENTATION IMPACT
   - (Inline step): preview likely endpoints, components, dependencies, docs, and tests impacted
6. STAKEHOLDER REVIEW
   - **MANDATORY — Read and follow**: `.github/skills/stakeholder-review-pack/SKILL.md`
   - Inline fallback (only if skill file unavailable): compile summary, open questions with owners, decisions needed with trade-offs, recommended next steps
7. DEFINITION OF READY
   - **MANDATORY — Read and follow**: `.github/skills/definition-of-ready-gate/SKILL.md`
   - Inline fallback (only if skill file unavailable): evaluate completeness criteria, classify gaps, decide Ready/Needs Clarification/Not Ready, list blocking items with owners
8. GROOMING PACKAGE
   - (Inline step): compile all outputs from steps 1–7 into a single presentable package

## Goals
Produce a useful grooming artifact that helps:
- business understand what is being asked
- PM/leads identify missing decisions
- developers understand functional intent and likely impact
- future agents/LLMs decide whether this repo is impacted

## Always include
- business goal
- actors/personas
- user/customer value
- primary and alternate use cases
- acceptance criteria in Given/When/Then form
- business rules and constraints
- assumptions (labeled SAFE/RISKY)
- ambiguities and targeted questions
- implementation impact preview
- definition of ready decision

## Review mindset
Critically evaluate:
- Is the request outcome-focused or implementation-prescriptive?
- Is the problem statement clear?
- Are success and failure behaviors both defined?
- Are business rules explicit?
- Are edge cases and boundaries understood?
- Are dependencies, ownership, and rollout constraints known?
- Does this change affect contracts, docs, observability, security, data handling, or support workflows?

## Ask questions only when high-value
Do not overwhelm stakeholders with generic questions.
Ask only questions that:
- change acceptance criteria
- reduce business/technical risk
- unblock design and development
- clarify ownership, data, compatibility, or failure handling

## Definition of Ready categories
Use one:
- **Ready**: All criteria pass, no blockers
- **Needs Clarification**: Core requirement understood but specific items need stakeholder input
- **Not Ready**: Fundamental gaps exist

Explain why, with concrete missing items and suggested owners.